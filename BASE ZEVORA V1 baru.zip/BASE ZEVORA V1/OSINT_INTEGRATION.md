# OSINT tools integration

The Tools > OSINT sheet now opens:
- Phone Lookup -> `lib/phone_lookup_page.dart`
- Email OSINT -> `lib/email_osint_page.dart`

The pages are imported directly by `lib/tools_gateway.dart`; the items are no longer locked/Coming Soon.

Phone Lookup:
- IP lookup uses HTTPS `ip-api.com`.
- Phone lookup calls the app backend endpoint `/api/phone-lookup`.
- User-data is optional and uses the configured `Api.api` base URL.

Email OSINT:
- Email analysis uses `api.eva.pingutil.com/email`.
- If that external service is unavailable, the page falls back to local format/disposable-domain checks rather than crashing.

Run `flutter pub get` and then `flutter analyze` before building the APK.
