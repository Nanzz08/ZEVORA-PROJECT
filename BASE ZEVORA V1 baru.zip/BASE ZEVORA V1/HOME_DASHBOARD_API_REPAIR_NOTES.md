# Home Page, Dashboard, API & Typography Repair

## Changes
- Updated the central first-party API base URL in `lib/Qaxer/api.dart` to `http://www.adit.web.id:2022`. Existing endpoint paths, HTTP methods, query keys, and request payloads were not renamed by this change.
- Updated `ProfilePage` to use the same central API base URL while retaining its existing `/api/getProfile`, `/api/uploadProfileImage`, and `/api/updateProfile` paths.
- Repaired HomePage sender loading to read the supplied-reference endpoints `/mySender` and (for the roles listed in the supplied reference) `/getPublicSenders`, with a compatibility fallback to the existing `/getActiveSenders` endpoint on HTTP 404. It parses the response shapes found in the supplied reference and shows useful errors/retry state.
- Fixed HomePage back handling: when embedded inside DashboardPage, the callback now returns to the dashboard without also attempting to pop the dashboard route.
- Updated dashboard drawer and bottom navigation surfaces to a more translucent glass finish without replacing dashboard routing, state, WebSocket, or action handlers.
- Removed the hard-coded Roboto font override from the global theme so Flutter can use native platform typography (San Francisco on iOS and the platform default on Android). Existing bundled display fonts remain available.

## Safety / behavior boundary
The supplied Home Page reference contains a `/sendBug` request that sends a selected bug payload to a phone number or WhatsApp group. That disruptive send operation was not restored or wired. The Home Page keeps local phone/link validation and static code inspection, plus read-only sender listing.

## Verification limits
The supplied dashboard reference files import packages and Dart pages that are absent from this project (including `glaze_nav_bar`, `configuration.dart`, and several page files), so they were not copied wholesale. Existing dashboard class, constructor, routes, callbacks, role checks, and WebSocket code were preserved.

The API hostname could not be resolved from the build environment during this repair, and Flutter/Dart SDKs are not installed here. Therefore live API connectivity, `flutter pub get`, `flutter analyze`, and Android build remain unverified and must be checked in an environment with network/DNS access and Flutter installed. Android already has `usesCleartextTraffic="true"` in its manifest, and iOS `Info.plist` now includes a domain-scoped ATS exception for `www.adit.web.id` because the requested base URL uses HTTP.
