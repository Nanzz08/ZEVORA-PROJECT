# Voice Note – Community Chat

Fitur voice note sudah ditambahkan ke `lib/publik_chat.dart`.

## Client
- Rekam dari mikrofon dengan `record: ^6.2.1`.
- Format rekaman: AAC-LC/M4A, mono, 64 kbps.
- Maksimum rekaman: 120 detik.
- Permission mikrofon Android/iOS sudah ditambahkan.
- Voice note dikirim multipart ke:
  `POST /chat/upload-voice`
- Field file: `voice`
- Fields tambahan: `userId`, `username`, `role`, `duration`, `mimeType`.
- Voice note dapat diputar langsung di chat memakai `audioplayers`.

## Backend response
Endpoint upload sebaiknya mengembalikan HTTP 200/201. Setelah upload, endpoint `GET /chat/messages` harus mengembalikan salah satu field berikut pada message:

```json
{
  "voiceUrl": "https://ortaxxpanellegalnihdeck.xyzraa.biz.id/audio/voice_xxx.m4a"
}
```

atau URL audio dapat ditempatkan di field `message` dengan ekstensi audio yang dikenali.

## Build
Jalankan di komputer yang memiliki Flutter SDK:

```bash
flutter clean
flutter pub get
flutter build apk --release
```

Jika backend belum memiliki `/chat/upload-voice`, endpoint tersebut perlu ditambahkan di server agar file voice disimpan dan `voiceUrl` dikembalikan pada daftar pesan.
