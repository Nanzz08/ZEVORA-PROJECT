# ZEVORA PROJECT — Tools Gateway & Theme Update

## Updated
- Tools Gateway now includes a dedicated **Bug WhatsApp** entry.
- Opening Bug WhatsApp routes to the existing HomePage mode selector, where users choose Bug Number, Bug Group, Test Function, or Spam Pairing before the existing form opens.
- Passed the existing username, password, session key, role, expiry, bug-number list, and bug-group list into that route. Existing request/API logic is not rewritten.
- Reworked category selection sheets into a searchable, responsive two-column tool selector with clearer visual hierarchy and locked/coming-soon states.
- Added **Theme & Appearance** inside the Tools category.
- Reworked ThemePickerPage to show every registered AppTheme preset (rather than only a short fixed subset), with search, active-state indicator, preview, haptics, and persistent selection through the existing AppTheme controller.
- Kept existing feature pages, callbacks, API endpoints, and role checks intact.

## Validation
- Checked the changed Dart files for balanced delimiters and verified route/field wiring.
- Confirmed the previous `main.dart` archive has only one `dividerTheme` declaration.
- Flutter/Dart SDK is not installed in this environment, so `flutter analyze` and APK build could not be run here. Run `flutter analyze` and `flutter build apk --release` in the project CI after download.
