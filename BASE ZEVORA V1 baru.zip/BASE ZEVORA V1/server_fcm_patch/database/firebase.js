const admin = require('firebase-admin');
const { cert, getApps } = require('firebase-admin/app');
const { getMessaging } = require('firebase-admin/messaging');
const fs = require('fs');
const path = require('path');

function findServiceAccount() {
  const candidates = [
    path.join(__dirname, '..', 'firebase-adminsdk.json'),
    path.join(__dirname, '..', 'firebase-adminsdk.json.json'),
  ];

  for (const file of candidates) {
    if (fs.existsSync(file)) return file;
  }

  throw new Error(
    'Firebase service account tidak ditemukan. Letakkan firebase-adminsdk.json di root server.'
  );
}

const serviceAccount = require(findServiceAccount());
const app = getApps().length
  ? getApps()[0]
  : admin.initializeApp({ credential: cert(serviceAccount) });

// Compatible with code that calls admin.messaging().sendEachForMulticast(...)
if (typeof admin.messaging !== 'function') {
  admin.messaging = () => getMessaging(app);
}

module.exports = admin;
