# Fix FCM notification server

Screenshot Qaxer menunjukkan error `admin.messaging is not a function`. Penyebabnya biasanya Firebase Admin SDK di server belum diinisialisasi dengan benar, atau file service-account memakai nama yang tidak sesuai.

## 1. Ganti `database/firebase.js`

Gunakan versi yang ada di folder `server_fcm_patch/database/firebase.js`.

## 2. Pastikan service account

File service account harus tersedia sebagai `firebase-adminsdk.json` di root server. Jika file yang sekarang bernama `firebase-adminsdk.json.json`, rename menjadi `firebase-adminsdk.json`.

**Jangan upload service-account JSON ke GitHub atau membagikannya ke orang lain.**

## 3. Install dependency

```bash
npm install firebase-admin@14.3.0
```

## 4. Restart server

```bash
npm start
```

Endpoint notifikasi Qaxer memakai:

`GET /send/notification?key=...&title=...&message=...&type=...`

Aplikasi juga mencoba POST terlebih dahulu dan otomatis fallback ke GET untuk server lama.
