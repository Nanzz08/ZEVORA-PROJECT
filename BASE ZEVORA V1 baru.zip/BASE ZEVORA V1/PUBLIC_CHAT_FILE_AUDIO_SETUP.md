# Public Chat — File / Document / Audio

`publik_chat.dart` sekarang menyediakan:

- 📎 Kirim file/dokumen dari file picker.
- 🎵 Kirim file audio dari file picker.
- 📄 Tampilan dokumen dengan nama, MIME type, ukuran, dan tombol buka.
- ▶️ Playback audio langsung dari chat.
- 🔒 Validasi ukuran maksimum 50 MB untuk file dan audio.
- 🔁 Fallback endpoint: jika endpoint khusus mengembalikan 404/405, client mencoba `/chat/upload-file`.

## Endpoint yang diharapkan

### Dokumen / file
`POST /chat/upload-document` atau fallback `POST /chat/upload-file`

Multipart:
- `file`: binary file
- `userId`
- `username`
- `role`
- `type=document`
- `fileName`
- `mimeType`

Server harus menyimpan file dan membuat pesan yang dikembalikan oleh `/chat/messages`, misalnya:

```json
{
  "documentUrl": "/uploads/chat/example.pdf",
  "documentName": "example.pdf",
  "mimeType": "application/pdf",
  "fileSize": 12345
}
```

`fileUrl` juga didukung sebagai alias untuk `documentUrl`.

### Audio file
`POST /chat/upload-audio` atau fallback `POST /chat/upload-file`

Multipart:
- `audio`: binary audio
- `userId`
- `username`
- `role`
- `type=audio`
- `fileName`
- `mimeType`

Server harus mengembalikan pesan dengan salah satu bentuk:

```json
{ "audioUrl": "/uploads/chat/music.mp3", "fileName": "music.mp3", "mimeType": "audio/mpeg" }
```

atau URL audio dapat diletakkan pada `message`.

## Penting
Flutter client tidak dapat membuat endpoint backend yang belum ada. Jika API `ranxdanzx.adit.web.id:2368` belum menyediakan endpoint di atas, endpoint tersebut harus ditambahkan di server agar upload benar-benar tersimpan dan dapat dibaca pengguna lain.
