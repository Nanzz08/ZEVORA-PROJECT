# Gemini AI setup

`lib/ai_page.dart` sekarang memakai Gemini API resmi melalui `generateContent`.

## 1. Buat API key
Buat API key Gemini di Google AI Studio, lalu jangan menaruh key langsung di source code.

## 2. Jalankan/build
Contoh:

```bash
flutter pub get
flutter run --dart-define=GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

Untuk APK release:

```bash
flutter build apk --release --dart-define=GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

## 3. Perbaikan AI
- Menghapus endpoint AI lama yang tidak diperlukan.
- Memakai endpoint Gemini resmi.
- Riwayat percakapan dikirim sebagai multi-turn `user` / `model`.
- Pesan terbaru tidak lagi dikirim dua kali ke Gemini.
- Menampilkan error API secara lebih jelas.
- API key dibaca melalui `String.fromEnvironment`.

## 4. Perbaikan private chat
`lib/publik_chat.dart` sekarang melakukan deduplikasi pesan berdasarkan `id`, `_id`, `messageId`, atau fingerprint pesan. Ini mencegah event acknowledgement + broadcast WebSocket yang sama tampil dua kali di UI.
