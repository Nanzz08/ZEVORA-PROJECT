# ZEVORA PROJECT — Landing / Login / Fingerprint / Splash UI Update

## Updated files
- `lib/landing.dart` — added shared liquid-glass treatment to the feature panel and reused the new glass icon badge. The `/login` navigation and existing landing actions remain intact.
- `lib/login_page.dart` — placed the existing login form inside a glass panel, added a secure sign-in section header, and removed hard-coded Roboto from generic labels so platform-native typography can be used. Authentication and request construction were preserved.
- `lib/fingerprint_page.dart` — applied a glass surface to the timezone selector. Hold-to-verify callbacks, haptics, progress behavior, sound effects, and navigation remain intact.
- `lib/splash.dart` — added a glass loading footer, guarded against duplicate splash navigation, starts the intro theme at splash, and stops it before opening Dashboard.
- `lib/glass_kit.dart` — added reusable `GlassIconBadge` and `GlassSectionHeader` components.
- `lib/splash_music_service.dart` — new small audio service using the already-installed `audioplayers` package.
- `assets/sounds/splash_theme.wav` — original generated 8-second ambient intro cue, looped only during splash/onboarding.
- `pubspec.yaml` — registered the new WAV asset; no dependency versions were changed.

## ZEVORA API preservation
- `lib/Qaxer/api.dart` remains the single API base: `http://www.adit.web.id:2022`.
- Existing Login API references and request construction were compared against the source project and remain unchanged (`/myInfo`, `/updateFCM`, `/validate`).
- Landing, Fingerprint and Splash do not introduce replacement API endpoints.
- Android cleartext HTTP setting and the iOS ATS exception for `www.adit.web.id` were already present and have been preserved.

## Typography
The global theme keeps `fontFamily: null` so iOS uses its native system font and Android uses its native system font. Existing registered display fonts remain available for branded headings.

## Validation
- ZIP structure and asset registration checked.
- `pubspec.yaml` parsed successfully.
- Modified Dart files passed delimiter-balance checks and local import existence checks.
- No new package dependency was added.
- `flutter pub get`, `flutter analyze`, and Android/iOS builds were **not run** because Flutter/Dart SDK is not installed in the editing environment. Runtime audio playback and visual layout still need device verification.
