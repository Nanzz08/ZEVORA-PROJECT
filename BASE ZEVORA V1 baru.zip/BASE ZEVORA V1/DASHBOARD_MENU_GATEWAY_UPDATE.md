# Dashboard, Menu, Select Page & Tools Gateway Update

## Source and integration approach
The four Dart references supplied in this turn were inspected. The supplied `dashboard_page.dart`, `menu_page.dart`, and `tools_gateway.dart` use a different set of local page files and constructor contracts from the current ZEVORA project. They were therefore used as UI/structure references rather than copied wholesale, which would introduce missing imports and break the current app's route contracts.

The supplied `bug_menu.dart` imports `tes_func_page.dart`, which is not present in the current project. The current project already has a compatible `SelectPage` -> `HomePage(initialMode: ...)` flow, so that route is retained and clarified instead of introducing an incompatible page.

## Files updated
- `lib/dashboard_page.dart`
  - Added a responsive Quick Access strip for Bug Center, Tools Gateway, and Menu Utama.
  - Added Bug Center as the first dashboard carousel quick action, followed by Tools Gateway and Menu Utama.
  - Added Tools Gateway and Menu Utama quick actions.
  - All three reuse existing dashboard callbacks/routes and session state.
  - Added semantics and tooltip to the existing hamburger/drawer control.
  - Kept the existing account, API, websocket, and navigation implementations.
- `lib/menu_page.dart`
  - Clarified Bug Center and Tools Gateway descriptions.
  - Updated menu heading and helper copy.
  - Existing callbacks remain the source of navigation.
- `lib/select_page.dart`
  - Clarified Number, Group, and Test Function choices.
  - Describes local function checking rather than execution against another device.
  - Preserved return IDs (`number`, `group`, `testfunc`, `spam`) for existing callers.
- `lib/tools_gateway.dart`
  - Updated gateway heading and search-empty copy.
  - Added accessibility semantics to category cards.
  - Preserved the existing `ToolsPage` constructor and category callback structure.

## Validation
- ZIP archive integrity checked after creation.
- Local Dart import paths checked for all four edited files.
- Delimiter balance checked for all four edited files.
- `flutter analyze` and Android build were not run because Flutter/Dart SDK is not available in the execution environment.
- Live backend behavior was not changed or claimed as verified.
