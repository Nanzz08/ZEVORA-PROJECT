# Backend fixes required by the Flutter client

The uploaded ZIP contains the Flutter client only; the Node/Express backend behind `Api.api` is not included. Two reported errors therefore cannot be fully repaired from Dart alone.

## 1. Firebase Admin: `admin.messaging is not a function`

If the backend uses the modern Firebase Admin SDK, use the modular API:

```js
const { getApps, initializeApp, cert } = require('firebase-admin/app');
const { getMessaging } = require('firebase-admin/messaging');

if (!getApps().length) {
  initializeApp({
    credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)),
  });
}

const messaging = getMessaging();
await messaging.send({
  token,
  notification: { title, body: message },
  data: { type: String(type || 'info') },
});
```

Do not call `admin.messaging.send(...)` when `admin` is imported from `firebase-admin/app`. If using the legacy namespace import instead, the equivalent is `admin.messaging().send(...)`.

## 2. Telegram Send OTP

The Flutter client now URL-encodes `+628...` phone numbers with `Uri.queryParameters`. The backend should accept:

`GET /telegram/login?key=...&phone=%2B628...`

and return JSON similar to:

```json
{
  "valid": true,
  "loginId": "...",
  "step": "wait_code",
  "message": "OTP sent"
}
```

If `/telegram/login` was renamed, update the single endpoint in `lib/telegram.dart`; the previous raw query construction could turn a leading `+` into a space on some server stacks.

## 3. Rebuild

Run `flutter pub get`, then `flutter analyze`, then `flutter build apk --release`.
