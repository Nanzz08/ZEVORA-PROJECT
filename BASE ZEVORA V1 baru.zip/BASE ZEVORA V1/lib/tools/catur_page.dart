// catur_page.dart (Exotory Style - Chess vs AI - FIXED)

import 'dart:math';
import 'package:flutter/material.dart';

class CaturPage extends StatefulWidget {
  const CaturPage({super.key});

  @override
  State<CaturPage> createState() => _CaturPageState();
}

class _CaturPageState extends State<CaturPage> {
  late List<List<String>> board;
  List<int>? selected;
  List<List<int>> validMoves = [];
  bool whiteTurn = true;
  String statusMsg = 'Giliran Kamu (Putih)';
  bool gameOver = false;
  int whiteCaptures = 0;
  int blackCaptures = 0;

  // ─── EXOTORY COLORS ──────────────────────────────────────────────────────
  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color glowColor = const Color(0xFF9C27B0);
  final Color backgroundColor = const Color(0xFF0D0618);
  final Color surfaceColor = const Color(0xFF1A0B2E);
  final Color cardColor = const Color(0xFF2D1B4E);
  final Color textMuted = const Color(0xFFB39DDB);
  final Color textSecondary = const Color(0xFFE1BEE7);

  @override
  void initState() {
    super.initState();
    _initBoard();
  }

  void _initBoard() {
    board = [
      ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
      ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
      ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
    ];
    selected = null;
    validMoves = [];
    whiteTurn = true;
    statusMsg = 'Giliran Kamu (Putih)';
    gameOver = false;
    whiteCaptures = 0;
    blackCaptures = 0;
  }

  bool _isWhite(String p) => p.isNotEmpty && p == p.toUpperCase() && p != p.toLowerCase();
  bool _isBlack(String p) => p.isNotEmpty && p == p.toLowerCase();
  bool _isEmpty(String p) => p.isEmpty;
  bool _inBounds(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;

  List<List<int>> _getMoves(int r, int c) {
    final piece = board[r][c];
    if (piece.isEmpty) return [];
    final moves = <List<int>>[];
    final up = piece == piece.toUpperCase();
    final dir = up ? -1 : 1;
    final enemy = up ? _isBlack : _isWhite;
    final ally = up ? _isWhite : _isBlack;

    void addIfValid(int nr, int nc) {
      if (_inBounds(nr, nc) && !ally(board[nr][nc])) moves.add([nr, nc]);
    }

    void slide(List<List<int>> dirs) {
      for (final d in dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (_inBounds(nr, nc)) {
          if (ally(board[nr][nc])) break;
          moves.add([nr, nc]);
          if (enemy(board[nr][nc])) break;
          nr += d[0];
          nc += d[1];
        }
      }
    }

    switch (piece.toUpperCase()) {
      case 'P':
        if (_inBounds(r + dir, c) && _isEmpty(board[r + dir][c])) {
          moves.add([r + dir, c]);
          final startRow = up ? 6 : 1;
          if (r == startRow && _isEmpty(board[r + dir * 2][c])) {
            moves.add([r + dir * 2, c]);
          }
        }
        for (final dc in [-1, 1]) {
          if (_inBounds(r + dir, c + dc) && enemy(board[r + dir][c + dc])) {
            moves.add([r + dir, c + dc]);
          }
        }
        break;
      case 'N':
        for (final d in [
          [-2, -1], [-2, 1], [-1, -2], [-1, 2],
          [1, -2], [1, 2], [2, -1], [2, 1]
        ]) {
          addIfValid(r + d[0], c + d[1]);
        }
        break;
      case 'B':
        slide([[-1, -1], [-1, 1], [1, -1], [1, 1]]);
        break;
      case 'R':
        slide([[-1, 0], [1, 0], [0, -1], [0, 1]]);
        break;
      case 'Q':
        slide([
          [-1, -1], [-1, 1], [1, -1], [1, 1],
          [-1, 0], [1, 0], [0, -1], [0, 1]
        ]);
        break;
      case 'K':
        for (final d in [
          [-1, -1], [-1, 0], [-1, 1], [0, -1],
          [0, 1], [1, -1], [1, 0], [1, 1]
        ]) {
          addIfValid(r + d[0], c + d[1]);
        }
        break;
    }
    return moves;
  }

  void _onTap(int r, int c) {
    if (gameOver || !whiteTurn) return;
    final piece = board[r][c];

    if (selected != null) {
      final isValid = validMoves.any((m) => m[0] == r && m[1] == c);
      if (isValid) {
        _movePiece(selected![0], selected![1], r, c);
        setState(() {
          selected = null;
          validMoves = [];
          whiteTurn = false;
          statusMsg = 'AI sedang berpikir...';
        });
        Future.delayed(const Duration(milliseconds: 600), _aiMove);
        return;
      }
    }

    if (_isWhite(piece)) {
      setState(() {
        selected = [r, c];
        validMoves = _getMoves(r, c);
      });
    } else {
      setState(() {
        selected = null;
        validMoves = [];
      });
    }
  }

  void _movePiece(int fr, int fc, int tr, int tc) {
    final target = board[tr][tc];
    if (target.isNotEmpty) {
      if (_isWhite(board[fr][fc])) blackCaptures++;
      else whiteCaptures++;
      if (target.toLowerCase() == 'k') {
        gameOver = true;
        statusMsg = _isWhite(board[fr][fc]) ? '🎉 Kamu Menang!' : '😔 AI Menang!';
      }
    }
    board[tr][tc] = board[fr][fc];
    board[fr][fc] = '';
    if (board[tr][tc] == 'P' && tr == 0) board[tr][tc] = 'Q';
    if (board[tr][tc] == 'p' && tr == 7) board[tr][tc] = 'q';
  }

  void _aiMove() {
    if (gameOver) return;
    final rng = Random();
    final allMoves = <List<int>>[];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (_isBlack(board[r][c])) {
          final moves = _getMoves(r, c);
          for (final m in moves) {
            allMoves.add([r, c, m[0], m[1]]);
          }
        }
      }
    }
    if (allMoves.isEmpty) {
      setState(() {
        gameOver = true;
        statusMsg = '🎉 Kamu Menang! AI Menyerah.';
      });
      return;
    }
    final captures = allMoves.where((m) => _isWhite(board[m[2]][m[3]])).toList();
    final move = captures.isNotEmpty
        ? captures[rng.nextInt(captures.length)]
        : allMoves[rng.nextInt(allMoves.length)];
    setState(() {
      _movePiece(move[0], move[1], move[2], move[3]);
      whiteTurn = true;
      if (!gameOver) statusMsg = 'Giliran Kamu (Putih)';
    });
  }

  Color _squareColor(int r, int c) {
    final isDark = (r + c) % 2 == 1;
    return isDark
        ? const Color(0xFF1A0B2E)
        : const Color(0xFF2D1B4E);
  }

  String _pieceEmoji(String p) {
    const map = {
      'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
      'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟',
    };
    return map[p] ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.4),
                  Colors.black.withOpacity(0.7),
                ],
              ),
            ),
          ),
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Column(
            children: [
              _buildStatusBar(),
              _buildCapturesBar(),
              Expanded(
                child: Center(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 8,
                        ),
                        itemCount: 64,
                        itemBuilder: (_, idx) {
                          final r = idx ~/ 8;
                          final c = idx % 8;
                          final isSelected = selected != null &&
                              selected![0] == r &&
                              selected![1] == c;
                          final isValidMove = validMoves.any((m) => m[0] == r && m[1] == c);
                          final piece = board[r][c];

                          Color bg = _squareColor(r, c);
                          if (isSelected) {
                            bg = accentColor.withOpacity(0.5);
                          }
                          if (isValidMove) {
                            bg = Colors.green.withOpacity(0.3);
                          }

                          return GestureDetector(
                            onTap: () => _onTap(r, c),
                            child: Container(
                              color: bg,
                              child: Stack(
                                children: [
                                  if (isValidMove && piece.isEmpty)
                                    Center(
                                      child: Container(
                                        width: 10,
                                        height: 10,
                                        decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.green,
                                        ),
                                      ),
                                    ),
                                  Center(
                                    child: Text(
                                      _pieceEmoji(piece),
                                      style: TextStyle(
                                        fontSize: 22,
                                        color: _isWhite(piece)
                                            ? Colors.white
                                            : Colors.grey.shade800,
                                        shadows: [
                                          Shadow(
                                            color: _isWhite(piece)
                                                ? Colors.black54
                                                : Colors.white54,
                                            blurRadius: 2,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
              if (gameOver) _buildGameOverButton(),
              const SizedBox(height: 16),
            ],
          ),
        ],
      ),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Text(
              '♟',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
              ),
            ),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentColor, primaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              '♟ CATUR',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: primaryColor.withOpacity(0.3)),
          ),
          child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFCE93D8), size: 16),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.refresh_rounded, color: accentColor),
          onPressed: () => setState(_initBoard),
          tooltip: 'Reset Game',
        ),
      ],
    );
  }

  // ─── STATUS BAR ──────────────────────────────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10),
      color: surfaceColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: whiteTurn ? Colors.white : Colors.grey.shade800,
              border: Border.all(color: Colors.white24),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            statusMsg,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: gameOver ? Colors.amber : Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // ─── CAPTURES BAR ──────────────────────────────────────────────────────────
  Widget _buildCapturesBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '⚪ Kamu: $whiteCaptures',
            style: TextStyle(
              color: textMuted,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
          ),
          Text(
            '⚫ AI: $blackCaptures',
            style: TextStyle(
              color: textMuted,
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // ─── GAME OVER BUTTON ──────────────────────────────────────────────────────
  Widget _buildGameOverButton() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 8,
          shadowColor: primaryColor.withOpacity(0.4),
        ),
        icon: const Icon(Icons.refresh_rounded),
        label: const Text(
          'MAIN LAGI',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
        onPressed: () => setState(_initBoard),
      ),
    );
  }
}