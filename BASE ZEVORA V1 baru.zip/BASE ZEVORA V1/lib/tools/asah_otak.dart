// asah_otak.dart - Game Asah Otak Pilihan Ganda (Anti Eror)

import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AsahOtakPage extends StatefulWidget {
  const AsahOtakPage({super.key});

  @override
  State<AsahOtakPage> createState() => _AsahOtakPageState();
}

class _AsahOtakPageState extends State<AsahOtakPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;
  late AnimationController _correctController;
  late Animation<double> _correctAnimation;
  late AnimationController _wrongController;
  late Animation<double> _wrongAnimation;

  bool _isLoading = false;
  bool _isAnswered = false;
  bool _isCorrect = false;
  int _currentIndex = 0;
  int _score = 0;
  int _totalSoal = 10;
  String _feedback = "";
  Color _feedbackColor = Colors.white;
  String _selectedOption = "";
  String _correctAnswer = "";
  String _correctAnswerText = "";

  List<Map<String, dynamic>> _soalList = [];
  Map<String, dynamic> _currentSoal = {};

  final String _apiKey = "kyzz";
  final String _baseUrl = "https://api.ikyyxd.my.id/games/pilihanganda";

  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color surfaceColor = const Color(0xFF1A0B2E);
  final Color cardColor = const Color(0xFF2D1B4E);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFE1BEE7);

  final List<String> _optionKeys = ['a', 'b', 'c', 'd'];
  final Map<String, String> _optionLabels = {
    'a': 'A',
    'b': 'B',
    'c': 'C',
    'd': 'D',
  };

  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _fetchSoalList();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.04).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 15).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );

    _correctController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _correctAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _correctController, curve: Curves.easeOutBack),
    );

    _wrongController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _wrongAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _wrongController, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _shakeController.dispose();
    _correctController.dispose();
    _wrongController.dispose();
    super.dispose();
  }

  Future<void> _fetchSoalList() async {
    setState(() {
      _isLoading = true;
      _soalList = [];
      _currentIndex = 0;
      _score = 0;
      _feedback = "";
      _feedbackColor = Colors.white;
      _isAnswered = false;
    });

    try {
      for (int i = 0; i < _totalSoal; i++) {
        final url = Uri.parse('$_baseUrl?apikey=$_apiKey');
        final response = await http.get(url).timeout(const Duration(seconds: 10));

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['status'] == true) {
            _soalList.add(data['result']);
          } else {
            _soalList.add({
              'question': 'Soal tidak tersedia',
              'options': {'a': '-', 'b': '-', 'c': '-', 'd': '-'},
              'answer': 'a',
              'category': 'Error',
            });
          }
        } else {
          _soalList.add({
            'question': 'Error: ${response.statusCode}',
            'options': {'a': '-', 'b': '-', 'c': '-', 'd': '-'},
            'answer': 'a',
            'category': 'Error',
          });
        }
      }

      setState(() {
        _isLoading = false;
        _currentSoal = _soalList.isNotEmpty ? _soalList[0] : {};
        _correctAnswer = _currentSoal['answer'] ?? 'a';
        _correctAnswerText = _currentSoal['options']?[_correctAnswer] ?? '';
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _currentSoal = {
          'question': 'Error: $e',
          'options': {'a': '-', 'b': '-', 'c': '-', 'd': '-'},
          'answer': 'a',
          'category': 'Error',
        };
        _correctAnswer = 'a';
        _correctAnswerText = '';
      });
    }
  }

  void _selectOption(String key) {
    if (_isAnswered || _isLoading) return;

    final selectedText = _currentSoal['options']?[key] ?? '';
    final correctText = _currentSoal['options']?[_correctAnswer] ?? '';
    final isCorrect = key == _correctAnswer;

    setState(() {
      _isAnswered = true;
      _selectedOption = key;
      _isCorrect = isCorrect;
      _correctAnswerText = correctText;

      if (isCorrect) {
        _score++;
        _feedback = "✅ Benar! Jawaban: $correctText";
        _feedbackColor = Colors.green;
        _correctController.forward(from: 0);
      } else {
        _feedback = "❌ Salah! Jawaban yang benar: $correctText";
        _feedbackColor = Colors.red;
        _wrongController.forward(from: 0);
        _shakeController.forward(from: 0);
      }
    });

    Future.delayed(const Duration(milliseconds: 2000), () {
      if (mounted) {
        _nextSoal();
      }
    });
  }

  void _nextSoal() {
    if (_currentIndex < _soalList.length - 1) {
      setState(() {
        _currentIndex++;
        _currentSoal = _soalList[_currentIndex];
        _correctAnswer = _currentSoal['answer'] ?? 'a';
        _correctAnswerText = _currentSoal['options']?[_correctAnswer] ?? '';
        _isAnswered = false;
        _isCorrect = false;
        _selectedOption = "";
        _feedback = "";
        _feedbackColor = Colors.white;
      });
    } else {
      _showResultDialog();
    }
  }

  void _showResultDialog() {
    final persentase = (_score / _totalSoal * 100);
    String predikat = persentase >= 90 ? '🏆 LUAR BIASA!' :
                      persentase >= 70 ? '⭐ BAGUS SEKALI!' :
                      persentase >= 50 ? '👍 CUKUP BAIK' :
                      '📚 BELAJAR LAGI!';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 500),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) =>
              Transform.scale(scale: scale, child: child),
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(
                color: persentase >= 70
                    ? Colors.amber.withOpacity(0.3)
                    : accentColor.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  persentase >= 70 ? Icons.emoji_events_rounded : Icons.school_rounded,
                  color: persentase >= 70 ? Colors.amber : accentColor,
                  size: 56,
                ),
                const SizedBox(height: 12),
                const Text(
                  '🏁 Selesai!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [primaryColor, accentColor],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      Text(
                        '$_score / $_totalSoal',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 42,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      Text(
                        '${persentase.toStringAsFixed(0)}%',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  predikat,
                  style: TextStyle(
                    color: persentase >= 70 ? Colors.amber : accentColor,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _fetchSoalList();
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryColor, accentColor],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: primaryColor.withOpacity(0.3),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              '🔄 MAIN LAGI',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.1),
                            ),
                          ),
                          child: const Center(
                            child: Text(
                              'KEMBALI',
                              style: TextStyle(
                                color: Colors.white54,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCloud(double width, double height, double opacity) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white.withOpacity(0.03),
              Colors.white.withOpacity(0.01),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(100),
        ),
        child: Row(
          children: [
            Container(
              width: width * 0.3,
              height: height * 1.2,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                shape: BoxShape.circle,
              ),
            ),
            Container(
              width: width * 0.4,
              height: height * 0.8,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.03),
                shape: BoxShape.circle,
              ),
            ),
            Container(
              width: width * 0.3,
              height: height * 1.1,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.psychology_rounded,
                color: Colors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'ASAH OTAK',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        elevation: 0,
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFF4A148C).withOpacity(0.85),
                const Color(0xFF1A0B2E).withOpacity(0.95),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 22),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/landing.jpg'),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(Colors.black45, BlendMode.darken),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  const Color(0xFF1A0B2E).withOpacity(0.8),
                  const Color(0xFF0D0618).withOpacity(0.9),
                  const Color(0xFF080012).withOpacity(0.95),
                ],
              ),
            ),
          ),
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [primaryColor.withOpacity(0.08), Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -60,
            left: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [accentColor.withOpacity(0.05), Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(
            top: 60,
            left: -20,
            child: _buildCloud(150, 60, 0.3),
          ),
          Positioned(
            top: 120,
            right: -30,
            child: _buildCloud(120, 50, 0.2),
          ),
          Positioned(
            bottom: 200,
            left: -40,
            child: _buildCloud(180, 70, 0.15),
          ),
          Positioned(
            top: 180,
            left: 80,
            child: _buildCloud(100, 40, 0.1),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildProgressBar(),
                  const SizedBox(height: 16),
                  Expanded(
                    child: _isLoading
                        ? const Center(
                            child: CircularProgressIndicator(
                              color: Color(0xFFCE93D8),
                              strokeWidth: 3,
                            ),
                          )
                        : _buildQuestionCard(),
                  ),
                  const SizedBox(height: 12),
                  _buildFeedback(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: surfaceColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentColor.withOpacity(0.1)),
              ),
              child: Text(
                '${_currentIndex + 1}/$_totalSoal',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.amber.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.star_rounded, color: Colors.amber, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        '$_score',
                        style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accentColor.withOpacity(0.1)),
                  ),
                  child: Text(
                    _currentSoal['category'] ?? 'Random',
                    style: TextStyle(
                      color: accentColor.withOpacity(0.5),
                      fontSize: 8,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: (_currentIndex + 1) / _totalSoal,
            backgroundColor: Colors.white.withOpacity(0.08),
            valueColor: AlwaysStoppedAnimation<Color>(accentColor),
            minHeight: 4,
          ),
        ),
      ],
    );
  }

  Widget _buildQuestionCard() {
    final options = _currentSoal['options'] ?? {};
    final question = _currentSoal['question'] ?? 'Soal tidak tersedia';

    return AnimatedBuilder(
      animation: _shakeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(
            _isCorrect ? 0 : _shakeAnimation.value * (_random.nextBool() ? 1 : -1),
            0,
          ),
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [surfaceColor, cardColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: _isAnswered
                        ? (_isCorrect ? Colors.green : Colors.red).withOpacity(0.3)
                        : accentColor.withOpacity(0.15),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withOpacity(0.25),
                      blurRadius: 40,
                      spreadRadius: 5,
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      question,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Column(
                      children: _optionKeys.map((key) {
                        final optionText = options[key] ?? '-';
                        final isSelected = _selectedOption == key;
                        final isCorrectOption = key == _correctAnswer;
                        final showResult = _isAnswered;

                        Color backgroundColor = Colors.transparent;
                        Color borderColor = Colors.white.withOpacity(0.05);
                        Color textColor = Colors.white70;
                        bool showCheck = false;
                        bool showWrong = false;

                        if (showResult && isSelected) {
                          if (_isCorrect) {
                            backgroundColor = Colors.green.withOpacity(0.15);
                            borderColor = Colors.green;
                            showCheck = true;
                            textColor = Colors.white;
                          } else {
                            backgroundColor = Colors.red.withOpacity(0.15);
                            borderColor = Colors.red;
                            showWrong = true;
                            textColor = Colors.white;
                          }
                        } else if (showResult && isCorrectOption) {
                          backgroundColor = Colors.green.withOpacity(0.1);
                          borderColor = Colors.green;
                          showCheck = true;
                          textColor = Colors.white;
                        } else if (isSelected) {
                          backgroundColor = accentColor.withOpacity(0.1);
                          borderColor = accentColor;
                          textColor = Colors.white;
                        }

                        return GestureDetector(
                          onTap: () => _selectOption(key),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              color: backgroundColor,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: borderColor,
                                width: showResult || isSelected ? 1.5 : 0.5,
                              ),
                              boxShadow: isSelected
                                  ? [
                                      BoxShadow(
                                        color: accentColor.withOpacity(0.1),
                                        blurRadius: 8,
                                        spreadRadius: 1,
                                      ),
                                    ]
                                  : [],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 28,
                                  height: 28,
                                  decoration: BoxDecoration(
                                    gradient: isSelected || showResult
                                        ? LinearGradient(
                                            colors: showResult && isCorrectOption
                                                ? [Colors.green, Colors.green.shade700]
                                                : showResult && isSelected && !_isCorrect
                                                    ? [Colors.red, Colors.red.shade700]
                                                    : [primaryColor, accentColor],
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                        : null,
                                    color: isSelected || showResult
                                        ? null
                                        : Colors.white.withOpacity(0.05),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: isSelected || showResult
                                          ? Colors.transparent
                                          : Colors.white.withOpacity(0.1),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      _optionLabels[key]!,
                                      style: TextStyle(
                                        color: isSelected || showResult
                                            ? Colors.white
                                            : Colors.white38,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    optionText,
                                    style: TextStyle(
                                      color: textColor,
                                      fontSize: 14,
                                      fontWeight: isSelected || showResult
                                          ? FontWeight.w600
                                          : FontWeight.normal,
                                    ),
                                  ),
                                ),
                                if (showCheck)
                                  const Icon(
                                    Icons.check_circle_rounded,
                                    color: Colors.green,
                                    size: 18,
                                  ),
                                if (showWrong)
                                  const Icon(
                                    Icons.cancel_rounded,
                                    color: Colors.red,
                                    size: 18,
                                  ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              if (_isCorrect && _correctAnimation.value > 0)
                Positioned.fill(
                  child: AnimatedBuilder(
                    animation: _correctAnimation,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _correctAnimation.value * 0.12,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.green.withOpacity(0.3),
                                blurRadius: 50,
                                spreadRadius: 20,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Transform.scale(
                              scale: 0.5 + (_correctAnimation.value * 0.5),
                              child: Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: Colors.green.withOpacity(0.8),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.green.withOpacity(0.4),
                                      blurRadius: 40,
                                      spreadRadius: 20,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.check_rounded,
                                  color: Colors.white,
                                  size: 50,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              if (!_isCorrect && _isAnswered && _wrongAnimation.value > 0)
                Positioned.fill(
                  child: AnimatedBuilder(
                    animation: _wrongAnimation,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _wrongAnimation.value * 0.12,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.withOpacity(0.3),
                                blurRadius: 50,
                                spreadRadius: 20,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Transform.scale(
                              scale: 0.5 + (_wrongAnimation.value * 0.5),
                              child: Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: Colors.red.withOpacity(0.8),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.red.withOpacity(0.4),
                                      blurRadius: 40,
                                      spreadRadius: 20,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.close_rounded,
                                  color: Colors.white,
                                  size: 50,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFeedback() {
    if (_feedback.isEmpty) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: _feedbackColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _feedbackColor.withOpacity(0.15), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _feedbackColor.withOpacity(0.05),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(
            _isCorrect ? Icons.check_circle_rounded : Icons.cancel_rounded,
            color: _feedbackColor,
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _feedback,
              style: TextStyle(
                color: _feedbackColor,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}