import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:math';
import 'package:share_plus/share_plus.dart';

class SlotMachineTools extends StatefulWidget {
  const SlotMachineTools({super.key});

  @override
  State<SlotMachineTools> createState() => _SlotMachineToolsState();
}

class _SlotMachineToolsState extends State<SlotMachineTools>
    with SingleTickerProviderStateMixin {
  final Random _random = Random();
  final List<String> _icons = ["🍒", "🍊", "🍋", "🍉", "⭐", "💎", "7️⃣", "🎰"];
  
  String _reel1 = "🎰";
  String _reel2 = "🎰";
  String _reel3 = "🎰";
  
  int _score = 100;
  int _bet = 10;
  bool _isSpinning = false;
  String _resultMessage = "Tekan SPIN untuk mulai!";
  
  late AnimationController _animationController;
  late Animation<double> _shakeAnimation;

  final Color bgDark = const Color(0xFF1A0B2E);
  final Color surfaceColor = const Color(0xFF2D1B4E);
  final Color cardColor = const Color(0xFF3D2A5E);
  final Color primaryPurple = const Color(0xFF6A1B9A);
  final Color accentPurple = const Color(0xFF9C27B0);
  final Color lightPurple = const Color(0xFFCE93D8);
  final Color goldAccent = const Color(0xFFFFD700);

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.elasticIn),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _spin() {
    if (_isSpinning) return;
    if (_score < _bet) {
      setState(() {
        _resultMessage = "❌ Saldo tidak cukup! Ambil koin gratis!";
      });
      return;
    }

    setState(() {
      _isSpinning = true;
      _resultMessage = "🔄 Memutar...";
      _score -= _bet;
    });

    // Animasi spinning
    int spinCount = 0;
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (spinCount >= 15) {
        timer.cancel();
        _stopSpin();
      } else {
        setState(() {
          _reel1 = _icons[_random.nextInt(_icons.length)];
          _reel2 = _icons[_random.nextInt(_icons.length)];
          _reel3 = _icons[_random.nextInt(_icons.length)];
        });
        spinCount++;
      }
    });
  }

  void _stopSpin() {
    final int winAmount = _calculateWin();
    
    setState(() {
      _isSpinning = false;
      
      if (winAmount > 0) {
        _score += winAmount;
        _resultMessage = "🎉 MENANG! +$winAmount koin! 🎉";
        _animationController.forward().then((_) => _animationController.reset());
      } else if (_reel1 == _reel2 && _reel2 == _reel3) {
        _score += _bet * 5;
        _resultMessage = "✨ JACKPOT! +${_bet * 5} koin! ✨";
        _animationController.forward().then((_) => _animationController.reset());
      } else {
        _resultMessage = "😢 Coba lagi!";
      }
    });
  }

  int _calculateWin() {
    if (_reel1 == "7️⃣" && _reel2 == "7️⃣" && _reel3 == "7️⃣") {
      return _bet * 10;
    }
    if (_reel1 == "💎" && _reel2 == "💎" && _reel3 == "💎") {
      return _bet * 8;
    }
    if (_reel1 == "⭐" && _reel2 == "⭐" && _reel3 == "⭐") {
      return _bet * 6;
    }
    if (_reel1 == _reel2 && _reel2 == _reel3) {
      return _bet * 3;
    }
    if (_reel1 == _reel2 || _reel2 == _reel3 || _reel1 == _reel3) {
      return _bet * 1;
    }
    return 0;
  }

  void _changeBet(int amount) {
    if (_isSpinning) return;
    int newBet = _bet + amount;
    if (newBet >= 5 && newBet <= 50) {
      setState(() {
        _bet = newBet;
      });
    }
  }

  void _takeFreeCoins() {
    if (_isSpinning) return;
    setState(() {
      _score += 50;
      _resultMessage = "🎁 +50 koin gratis! 🎁";
    });
  }

  void _resetGame() {
    if (_isSpinning) return;
    setState(() {
      _score = 100;
      _bet = 10;
      _reel1 = "🎰";
      _reel2 = "🎰";
      _reel3 = "🎰";
      _resultMessage = "Game direset!";
    });
  }

  void _shareScore() {
    final message = "🎰 *SLOT MACHINE SCORE* 🎰\n\n"
        "💰 Koin: $_score\n"
        "🎲 Bet: $_bet\n"
        "🎯 Hasil: $_reel1 $_reel2 $_reel3\n"
        "📊 Status: $_resultMessage\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✨ Main slot seru tanpa judi! ✨";
    
    Share.share(message);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          "Slot Machine",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        centerTitle: true,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: Color(0xFFFFD700)),
            onPressed: _shareScore,
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFFFFD700)),
            onPressed: _resetGame,
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: _shakeAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(_shakeAnimation.value, 0),
            child: child,
          );
        },
        child: Column(
          children: [
            // Header Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryPurple, accentPurple],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.casino,
                    color: Color(0xFFFFD700),
                    size: 40,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "SLOT MACHINE",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.monetization_on, color: Color(0xFFFFD700), size: 16),
                            const SizedBox(width: 4),
                            Text(
                              "$_score",
                              style: const TextStyle(
                                color: Color(0xFFFFD700),
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.local_play, color: Color(0xFFFFD700), size: 16),
                            const SizedBox(width: 4),
                            Text(
                              "$_bet",
                              style: const TextStyle(
                                color: Color(0xFFFFD700),
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Slot Reels
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: cardColor,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: accentPurple.withOpacity(0.3)),
                        boxShadow: [
                          BoxShadow(
                            color: primaryPurple.withOpacity(0.2),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildReel(_reel1),
                          _buildReel(_reel2),
                          _buildReel(_reel3),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Spin Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isSpinning ? null : _spin,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: goldAccent,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: _isSpinning
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.black,
                                ),
                              )
                            : const Text(
                                "SPIN",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  letterSpacing: 2,
                                ),
                              ),
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Bet Controls
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _changeBet(-5),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: lightPurple),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              "- BET",
                              style: TextStyle(color: Color(0xFFCE93D8)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _takeFreeCoins,
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: Colors.green),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              "FREE COINS",
                              style: TextStyle(color: Colors.green),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => _changeBet(5),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: lightPurple),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              "+ BET",
                              style: TextStyle(color: Color(0xFFCE93D8)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Result Message
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: surfaceColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: accentPurple.withOpacity(0.2)),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            _resultMessage.contains("MENANG") || _resultMessage.contains("JACKPOT")
                                ? Icons.emoji_events
                                : _resultMessage.contains("Coba")
                                    ? Icons.sentiment_dissatisfied
                                    : Icons.info_outline,
                            color: _resultMessage.contains("MENANG") || _resultMessage.contains("JACKPOT")
                                ? goldAccent
                                : lightPurple,
                            size: 20,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _resultMessage,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReel(String icon) {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: goldAccent.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: goldAccent.withOpacity(0.1),
            blurRadius: 10,
          ),
        ],
      ),
      child: Center(
        child: Text(
          icon,
          style: const TextStyle(fontSize: 48),
        ),
      ),
    );
  }
}