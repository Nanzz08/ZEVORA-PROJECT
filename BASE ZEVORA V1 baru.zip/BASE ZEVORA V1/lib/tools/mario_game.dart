// mario_game.dart (Exotory Style - Super Dart Mario)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:math';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with TickerProviderStateMixin {
  // ─── EXOTORY COLORS ──────────────────────────────────────────────
  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color glowColor = const Color(0xFF9C27B0);
  final Color backgroundColor = const Color(0xFF0D0618);
  final Color surfaceColor = const Color(0xFF1A0B2E);
  final Color cardColor = const Color(0xFF2D1B4E);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFE1BEE7);
  final Color textMuted = const Color(0xFFB39DDB);

  static const Color bg       = Color(0xFF0D0618);
  static const Color bgSurface= Color(0xFF1A0B2E);
  static const Color bgCard   = Color(0xFF2D1B4E);
  static const Color border   = Color(0xFF4A148C);
  static const Color accent   = Color(0xFFCE93D8);
  static const Color accentDim= Color(0xFF9C27B0);
  static const Color textMain = Color(0xFFFFFFFF);
  static const Color textSub  = Color(0xFFB39DDB);
  static const Color danger   = Color(0xFFFF3B5C);
  static const Color success  = Color(0xFF00E5A0);
  static const Color warning  = Color(0xFFFFA500);

  // ──────────────────────────────────────────────────────────────
  // GAME VARIABLES
  // ──────────────────────────────────────────────────────────────

  static const double GRAVITY = 0.6;
  static const double JUMP_FORCE = -12;
  static const double MOVE_SPEED = 5;
  static const double GROUND_Y = 550;
  static const int MAX_LEVELS = 5;

  // Player
  double playerX = 50;
  double playerY = GROUND_Y - 40;
  double playerVX = 0;
  double playerVY = 0;
  double playerWidth = 30;
  double playerHeight = 40;
  bool isJumping = false;
  bool isGrounded = true;
  bool isMovingRight = false;
  bool isMovingLeft = false;
  int direction = 1;

  // Level
  int currentLevel = 1;
  int score = 0;
  int coins = 0;
  int lives = 3;
  bool isGameOver = false;
  bool isLevelComplete = false;
  bool _showStats = false;

  // Platforms, enemies, coins
  List<Platform> platforms = [];
  List<Enemy> enemies = [];
  List<Coin> coinList = [];
  List<Platform> pipes = [];
  List<Platform> flagPoles = [];

  // Camera
  double cameraX = 0;
  double levelWidth = 800;

  // Game loop
  Timer? gameTimer;
  final int fps = 60;
  bool isPaused = false;
  late AnimationController _statsController;
  late Animation<double> _statsAnimation;

  // Keys
  final Set<String> keysPressed = {};

  @override
  void initState() {
    super.initState();
    _statsController = AnimationController(duration: const Duration(milliseconds: 300), vsync: this);
    _statsAnimation = CurvedAnimation(parent: _statsController, curve: Curves.easeOut);
    loadLevel(1);
    _startGameLoop();
  }

  void loadLevel(int level) {
    platforms.clear();
    enemies.clear();
    coinList.clear();
    pipes.clear();
    flagPoles.clear();

    playerX = 50;
    playerY = GROUND_Y - 40;
    playerVX = 0;
    playerVY = 0;
    isJumping = false;
    isGrounded = true;
    cameraX = 0;
    isLevelComplete = false;

    switch (level) {
      case 1: _buildLevel1(); break;
      case 2: _buildLevel2(); break;
      case 3: _buildLevel3(); break;
      case 4: _buildLevel4(); break;
      case 5: _buildLevel5(); break;
      default: _buildLevel1();
    }

    levelWidth = 800 + (platforms.length * 50);
  }

  void _buildLevel1() {
    platforms.add(Platform(0, GROUND_Y, 1600, 30, const Color(0xFF4A148C)));
    platforms.add(Platform(200, 450, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(350, 380, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(500, 310, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(700, 450, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(900, 380, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(1050, 310, 100, 20, const Color(0xFF6D28D9)));

    pipes.add(Platform(300, GROUND_Y - 60, 40, 60, const Color(0xFF9C27B0)));
    pipes.add(Platform(600, GROUND_Y - 60, 40, 60, const Color(0xFF9C27B0)));
    pipes.add(Platform(1100, GROUND_Y - 60, 40, 60, const Color(0xFF9C27B0)));

    coinList.add(Coin(230, 410));
    coinList.add(Coin(260, 410));
    coinList.add(Coin(380, 340));
    coinList.add(Coin(530, 270));
    coinList.add(Coin(730, 410));
    coinList.add(Coin(930, 340));

    enemies.add(Enemy(400, 370, 1, 200, 600));
    enemies.add(Enemy(650, 300, -1, 500, 800));

    flagPoles.add(Platform(1350, 500, 10, 80, Colors.yellow));
  }

  void _buildLevel2() {
    platforms.add(Platform(0, GROUND_Y, 2000, 30, const Color(0xFF4A148C)));
    platforms.add(Platform(150, 480, 80, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(300, 420, 80, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(450, 350, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(650, 420, 80, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(800, 480, 80, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(950, 350, 100, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(1150, 420, 80, 20, const Color(0xFF6D28D9)));

    coinList.add(Coin(180, 440));
    coinList.add(Coin(330, 380));
    coinList.add(Coin(480, 310));
    coinList.add(Coin(680, 380));

    enemies.add(Enemy(350, 400, 1, 300, 500));
    enemies.add(Enemy(700, 400, -1, 600, 900));

    flagPoles.add(Platform(1550, 500, 10, 80, Colors.yellow));
  }

  void _buildLevel3() {
    platforms.add(Platform(0, GROUND_Y, 2200, 30, const Color(0xFF4A148C)));
    for (int i = 0; i < 8; i++) {
      platforms.add(Platform(200 + (i * 250), 400 - (i % 3 * 80), 100, 20, const Color(0xFF6D28D9)));
    }
    for (int i = 0; i < 15; i++) {
      coinList.add(Coin(250 + (i * 130), 350 - (i % 3 * 70)));
    }
    for (int i = 0; i < 3; i++) {
      enemies.add(Enemy(300 + (i * 600), 350, (i % 2 == 0 ? 1 : -1), 200, 800));
    }
    flagPoles.add(Platform(1850, 500, 10, 80, Colors.yellow));
  }

  void _buildLevel4() {
    platforms.add(Platform(0, GROUND_Y, 2400, 30, const Color(0xFF4A148C)));
    platforms.add(Platform(200, 450, 150, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(500, 350, 150, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(900, 400, 150, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(1300, 300, 150, 20, const Color(0xFF6D28D9)));
    platforms.add(Platform(1700, 400, 150, 20, const Color(0xFF6D28D9)));

    for (int i = 0; i < 20; i++) {
      coinList.add(Coin(220 + (i * 110), 400 - (i % 4 * 60)));
    }
    for (int i = 0; i < 4; i++) {
      enemies.add(Enemy(350 + (i * 600), 330, (i % 2 == 0 ? 1 : -1), 200, 900));
    }
    flagPoles.add(Platform(1950, 500, 10, 80, Colors.yellow));
  }

  void _buildLevel5() {
    platforms.add(Platform(0, GROUND_Y, 2800, 30, const Color(0xFF4A148C)));
    for (int i = 0; i < 10; i++) {
      platforms.add(Platform(150 + (i * 260), 420 - (i % 4 * 90), 120, 20, const Color(0xFF6D28D9)));
    }
    for (int i = 0; i < 25; i++) {
      coinList.add(Coin(200 + (i * 110), 370 - (i % 5 * 50)));
    }
    for (int i = 0; i < 5; i++) {
      enemies.add(Enemy(300 + (i * 520), 350, (i % 2 == 0 ? 1 : -1), 200, 1000));
    }
    flagPoles.add(Platform(2350, 500, 10, 80, Colors.yellow));
  }

  void _startGameLoop() {
    gameTimer = Timer.periodic(Duration(milliseconds: 1000 ~/ fps), (_) {
      if (!isPaused && !isGameOver && mounted) {
        setState(() => _updateGame());
      }
    });
  }

  void _updateGame() {
    if (isMovingLeft) playerVX = -MOVE_SPEED;
    if (isMovingRight) playerVX = MOVE_SPEED;
    if (!isMovingLeft && !isMovingRight) playerVX *= 0.8;

    playerVY += GRAVITY;
    playerX += playerVX;
    playerY += playerVY;

    bool wasGrounded = isGrounded;
    isGrounded = false;

    for (var platform in platforms) {
      if (playerX + playerWidth > platform.x && playerX < platform.x + platform.width &&
          playerY + playerHeight >= platform.y && playerY + playerHeight <= platform.y + platform.height + 10 &&
          playerVY >= 0) {
        playerY = platform.y - playerHeight;
        playerVY = 0;
        isGrounded = true;
      }
    }

    if (isGrounded && keysPressed.contains('up') && !isJumping) {
      playerVY = JUMP_FORCE;
      isJumping = true;
    }
    if (!isGrounded) isJumping = false;

    if (!wasGrounded && isGrounded) {
      score += 10;
    }

    for (var coin in List.from(coinList)) {
      if ((playerX - coin.x).abs() < 30 && (playerY - coin.y).abs() < 30) {
        coinList.remove(coin);
        coins += 1;
        score += 100;
      }
    }

    for (var enemy in enemies) {
      enemy.update();
      if ((playerX - enemy.x).abs() < 40 && (playerY - enemy.y).abs() < 40) {
        lives--;
        if (lives <= 0) {
          isGameOver = true;
        } else {
          playerX = 50;
          playerY = GROUND_Y - 40;
          playerVY = 0;
        }
      }
    }

    if (playerY > GROUND_Y + 100) {
      lives--;
      if (lives <= 0) {
        isGameOver = true;
      } else {
        playerX = 50;
        playerY = GROUND_Y - 40;
      }
    }

    for (var flag in flagPoles) {
      if (playerX > flag.x - 30 && playerX < flag.x + 30) {
        isLevelComplete = true;
      }
    }

    if (playerX < 0) playerX = 0;
    if (playerX > levelWidth) playerX = levelWidth - playerWidth;

    if (playerX > 400) cameraX = playerX - 100;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // ─── STATS BAR ──────────────────────────────────────────────
          ScaleTransition(
            scale: _statsAnimation,
            child: Visibility(
              visible: _showStats,
              child: Container(
                color: surfaceColor,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _statItem('🎯 Score', '$score', accentColor),
                    _statItem('🪙 Coins', '$coins', Colors.green),
                    _statItem('❤️ Lives', '$lives', Colors.red),
                    _statItem('🌍 Level', '$currentLevel', Colors.amber),
                  ],
                ),
              ),
            ),
          ),

          // ─── GAME CANVAS ────────────────────────────────────────────
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.2),
                    Colors.black.withOpacity(0.4),
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: -80,
                    right: -80,
                    child: Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            primaryColor.withOpacity(0.12),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: -40,
                    left: -60,
                    child: Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            accentColor.withOpacity(0.08),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  CustomPaint(
                    painter: GamePainter(
                      playerX: playerX,
                      playerY: playerY,
                      playerWidth: playerWidth,
                      playerHeight: playerHeight,
                      platforms: platforms,
                      enemies: enemies,
                      coins: coinList,
                      pipes: pipes,
                      flagPoles: flagPoles,
                      cameraX: cameraX,
                    ),
                    size: Size.infinite,
                  ),
                ],
              ),
            ),
          ),

          // ─── GAME CONTROLS ──────────────────────────────────────────
          _buildControls(),
        ],
      ),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: primaryColor.withOpacity(0.3)),
          ),
          child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFCE93D8), size: 16),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Icon(Icons.games_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentColor, primaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              'SUPER DART MARIO',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: Icon(
            Icons.info_outline_rounded,
            color: accentColor,
          ),
          onPressed: () {
            setState(() => _showStats = !_showStats);
            if (_showStats) _statsController.forward();
            else _statsController.reverse();
          },
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _statItem(String label, String value, Color color) => Column(
    children: [
      Text(label, style: TextStyle(color: textMuted, fontSize: 10, fontFamily: 'ShareTechMono')),
      const SizedBox(height: 2),
      Text(value, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w800, fontFamily: 'ShareTechMono')),
    ],
  );

  // ─── CONTROLS ──────────────────────────────────────────────────────────────
  Widget _buildControls() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: surfaceColor,
        border: Border(top: BorderSide(color: primaryColor.withOpacity(0.1))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _controlButton('⬅️', () => setState(() {
            isMovingLeft = true;
            isMovingRight = false;
            direction = -1;
          }), onRelease: () => setState(() => isMovingLeft = false)),
          const SizedBox(width: 16),
          _controlButton('⬆️', () => setState(() {
            if (isGrounded) {
              playerVY = JUMP_FORCE;
              isJumping = true;
            }
          })),
          const SizedBox(width: 16),
          _controlButton('➡️', () => setState(() {
            isMovingRight = true;
            isMovingLeft = false;
            direction = 1;
          }), onRelease: () => setState(() => isMovingRight = false)),
          const SizedBox(width: 16),
          _controlButton(isPaused ? '▶️' : '⏸️', () => setState(() => isPaused = !isPaused)),
        ],
      ),
    );
  }

  Widget _controlButton(String label, VoidCallback onPressed, {VoidCallback? onRelease}) {
    return GestureDetector(
      onTapDown: (_) => onPressed(),
      onTapUp: (_) => onRelease?.call(),
      onTapCancel: () => onRelease?.call(),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryColor, accentColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: primaryColor.withOpacity(0.3),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    gameTimer?.cancel();
    _statsController.dispose();
    super.dispose();
  }
}

// ────────────────────────────────────────────────────────────────
// GAME PAINTER
// ────────────────────────────────────────────────────────────────

class GamePainter extends CustomPainter {
  final double playerX, playerY, playerWidth, playerHeight, cameraX;
  final List<Platform> platforms, pipes, flagPoles;
  final List<Enemy> enemies;
  final List<Coin> coins;

  GamePainter({
    required this.playerX,
    required this.playerY,
    required this.playerWidth,
    required this.playerHeight,
    required this.platforms,
    required this.enemies,
    required this.coins,
    required this.pipes,
    required this.flagPoles,
    required this.cameraX,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // ─── PLATFORMS ──────────────────────────────────────────────────
    for (var platform in platforms) {
      final paint = Paint()
        ..color = platform.color
        ..style = PaintingStyle.fill;

      // Efek 3D untuk platform
      canvas.drawRect(
        Rect.fromLTWH(platform.x - cameraX, platform.y, platform.width, platform.height),
        paint,
      );

      // Highlight atas
      canvas.drawRect(
        Rect.fromLTWH(platform.x - cameraX, platform.y, platform.width, 3),
        Paint()
          ..color = platform.color.withOpacity(0.3)
          ..style = PaintingStyle.fill,
      );
    }

    // ─── PIPES ──────────────────────────────────────────────────────
    for (var pipe in pipes) {
      final paint = Paint()
        ..color = pipe.color
        ..style = PaintingStyle.fill;

      canvas.drawRect(
        Rect.fromLTWH(pipe.x - cameraX, pipe.y, pipe.width, pipe.height),
        paint,
      );

      // Detail pipe (top)
      canvas.drawRect(
        Rect.fromLTWH(pipe.x - 5 - cameraX, pipe.y - 5, pipe.width + 10, 10),
        Paint()
          ..color = pipe.color.withOpacity(0.6)
          ..style = PaintingStyle.fill,
      );
    }

    // ─── COINS ──────────────────────────────────────────────────────
    for (var coin in coins) {
      // Glow
      canvas.drawCircle(
        Offset(coin.x - cameraX, coin.y),
        10,
        Paint()
          ..color = Colors.yellow.withOpacity(0.15)
          ..style = PaintingStyle.fill,
      );
      // Coin body
      canvas.drawCircle(
        Offset(coin.x - cameraX, coin.y),
        8,
        Paint()..color = Colors.yellow,
      );
      // Inner
      canvas.drawCircle(
        Offset(coin.x - cameraX, coin.y),
        6,
        Paint()..color = Colors.yellow.shade700,
      );
      // Shine
      canvas.drawCircle(
        Offset(coin.x - 3 - cameraX, coin.y - 3),
        2,
        Paint()..color = Colors.white.withOpacity(0.5),
      );
    }

    // ─── ENEMIES ────────────────────────────────────────────────────
    for (var enemy in enemies) {
      // Body
      canvas.drawRect(
        Rect.fromLTWH(enemy.x - cameraX, enemy.y, 30, 30),
        Paint()..color = Colors.red.shade700,
      );
      // Eyes
      canvas.drawCircle(
        Offset(enemy.x + 8 - cameraX, enemy.y + 10),
        4,
        Paint()..color = Colors.white,
      );
      canvas.drawCircle(
        Offset(enemy.x + 22 - cameraX, enemy.y + 10),
        4,
        Paint()..color = Colors.white,
      );
      // Pupils
      canvas.drawCircle(
        Offset(enemy.x + 10 - cameraX, enemy.y + 10),
        2,
        Paint()..color = Colors.black,
      );
      canvas.drawCircle(
        Offset(enemy.x + 24 - cameraX, enemy.y + 10),
        2,
        Paint()..color = Colors.black,
      );
    }

    // ─── FLAG POLES ──────────────────────────────────────────────────
    for (var flag in flagPoles) {
      canvas.drawRect(
        Rect.fromLTWH(flag.x - cameraX, flag.y, flag.width, flag.height),
        Paint()..color = flag.color,
      );
      // Flag
      final flagPaint = Paint()
        ..color = Colors.red
        ..style = PaintingStyle.fill;
      canvas.drawPath(
        Path()
          ..moveTo(flag.x + 10 - cameraX, flag.y)
          ..lineTo(flag.x + 40 - cameraX, flag.y + 15)
          ..lineTo(flag.x + 10 - cameraX, flag.y + 30)
          ..close(),
        flagPaint,
      );
    }

    // ─── PLAYER ──────────────────────────────────────────────────────
    // Shadow
    canvas.drawOval(
      Rect.fromLTWH(playerX - cameraX, playerY + playerHeight - 5, playerWidth, 8),
      Paint()
        ..color = Colors.black.withOpacity(0.2)
        ..style = PaintingStyle.fill,
    );

    // Body
    canvas.drawRect(
      Rect.fromLTWH(playerX - cameraX, playerY, playerWidth, playerHeight),
      Paint()
        ..color = Colors.red.shade700
        ..style = PaintingStyle.fill,
    );

    // Outline
    canvas.drawRect(
      Rect.fromLTWH(playerX - cameraX, playerY, playerWidth, playerHeight),
      Paint()
        ..color = Colors.red.shade900.withOpacity(0.2)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );

    // Hat
    canvas.drawRect(
      Rect.fromLTWH(playerX - 2 - cameraX, playerY - 4, playerWidth + 4, 6),
      Paint()
        ..color = Colors.red.shade900
        ..style = PaintingStyle.fill,
    );

    // Eyes
    canvas.drawCircle(
      Offset(playerX + 8 - cameraX, playerY + 10),
      4,
      Paint()..color = Colors.white,
    );
    canvas.drawCircle(
      Offset(playerX + 22 - cameraX, playerY + 10),
      4,
      Paint()..color = Colors.white,
    );
    canvas.drawCircle(
      Offset(playerX + 10 - cameraX, playerY + 10),
      2,
      Paint()..color = Colors.black,
    );
    canvas.drawCircle(
      Offset(playerX + 24 - cameraX, playerY + 10),
      2,
      Paint()..color = Colors.black,
    );

    // Mustache
    canvas.drawRect(
      Rect.fromLTWH(playerX + 4 - cameraX, playerY + 16, 22, 4),
      Paint()
        ..color = Colors.brown.shade800
        ..style = PaintingStyle.fill,
    );
  }

  @override
  bool shouldRepaint(GamePainter oldDelegate) => true;
}

// ────────────────────────────────────────────────────────────────
// DATA MODELS
// ────────────────────────────────────────────────────────────────

class Platform {
  double x, y, width, height;
  Color color;
  Platform(this.x, this.y, this.width, this.height, this.color);
}

class Enemy {
  double x, y;
  int direction;
  double minX, maxX;
  Enemy(this.x, this.y, this.direction, this.minX, this.maxX);

  void update() {
    x += direction * 2;
    if (x < minX || x > maxX) direction *= -1;
  }
}

class Coin {
  double x, y;
  Coin(this.x, this.y);
}