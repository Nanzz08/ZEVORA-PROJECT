// berhitung_cepat.dart (Exotory Style - Math Quiz - FIXED)

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BerhitungCepatPage extends StatefulWidget {
  const BerhitungCepatPage({super.key});

  @override
  State<BerhitungCepatPage> createState() => _BerhitungCepatPageState();
}

class _BerhitungCepatPageState extends State<BerhitungCepatPage>
    with SingleTickerProviderStateMixin {
  static const int _timeLimit = 30;
  final _rng = Random();

  int _num1 = 0, _num2 = 0;
  String _op = '+';
  int _answer = 0;
  List<int> _choices = [];

  int _score = 0;
  int _best = 0;
  int _timeLeft = _timeLimit;
  int _streak = 0;
  bool _started = false;
  bool _finished = false;
  Timer? _timer;

  late AnimationController _flashCtrl;
  Color _bgFlash = Colors.transparent;

  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color glowColor = const Color(0xFF9C27B0);
  final Color backgroundColor = const Color(0xFF0D0618);
  final Color surfaceColor = const Color(0xFF1A0B2E);
  final Color cardColor = const Color(0xFF2D1B4E);
  final Color textMuted = const Color(0xFFB39DDB);
  final Color textSecondary = const Color(0xFFE1BEE7);

  @override
  void initState() {
    super.initState();
    _loadBestScore();
    _flashCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _generateQuestion();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _flashCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadBestScore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getInt('berhitung_best_score');
      if (saved != null && mounted) {
        setState(() => _best = saved);
      }
    } catch (e) {
      debugPrint('Error loading best score: $e');
    }
  }

  Future<void> _saveBestScore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('berhitung_best_score', _best);
    } catch (e) {
      debugPrint('Error saving best score: $e');
    }
  }

  void _generateQuestion() {
    final ops = ['+', '-', '×'];
    _op = ops[_rng.nextInt(3)];
    switch (_op) {
      case '+':
        _num1 = _rng.nextInt(50) + 1;
        _num2 = _rng.nextInt(50) + 1;
        _answer = _num1 + _num2;
        break;
      case '-':
        _num1 = _rng.nextInt(50) + 10;
        _num2 = _rng.nextInt(_num1) + 1;
        _answer = _num1 - _num2;
        break;
      case '×':
        _num1 = _rng.nextInt(10) + 1;
        _num2 = _rng.nextInt(10) + 1;
        _answer = _num1 * _num2;
        break;
    }

    final Set<int> choiceSet = {_answer};
    while (choiceSet.length < 4) {
      final wrong = _answer + _rng.nextInt(21) - 10;
      if (wrong != _answer && wrong > 0) choiceSet.add(wrong);
    }
    _choices = choiceSet.toList()..shuffle();
    if (mounted) setState(() {});
  }

  void _startGame() {
    _score = 0;
    _streak = 0;
    _timeLeft = _timeLimit;
    _finished = false;
    _started = true;
    _generateQuestion();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        _timeLeft--;
        if (_timeLeft <= 0) {
          t.cancel();
          _finished = true;
          if (_score > _best) {
            _best = _score;
            _saveBestScore();
          }
        }
      });
    });
    setState(() {});
  }

  void _onChoiceTap(int val) {
    if (!_started || _finished) return;
    if (val == _answer) {
      _streak++;
      final bonus = _streak >= 3 ? 20 : 10;
      _score += bonus;
      _bgFlash = Colors.green.withOpacity(0.3);
    } else {
      _streak = 0;
      _bgFlash = Colors.red.withOpacity(0.3);
    }
    _flashCtrl.forward(from: 0).then((_) {
      if (mounted) setState(() => _bgFlash = Colors.transparent);
    });
    _generateQuestion();
  }

  @override
  Widget build(BuildContext context) {
    final pct = _timeLeft / _timeLimit;
    final timerColor = pct > 0.5
        ? Colors.green
        : pct > 0.25
            ? Colors.orange
            : Colors.red;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.4),
                  Colors.black.withOpacity(0.7),
                ],
              ),
            ),
          ),
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Container(
            color: Color.lerp(Colors.transparent, _bgFlash, 0.5),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: !_started && !_finished
                ? _buildStart()
                : _finished
                    ? _buildFinish()
                    : _buildGame(timerColor, pct),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Icon(Icons.calculate_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentColor, primaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              'BERHITUNG CEPAT',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: primaryColor.withOpacity(0.3)),
          ),
          child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFCE93D8), size: 16),
        ),
        onPressed: () => Navigator.pop(context),
      ),
    );
  }

  Widget _buildStart() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.4),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: const Text(
                '⚡',
                style: TextStyle(fontSize: 48),
              ),
            ),
            const SizedBox(height: 24),
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [accentColor, primaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(bounds),
              child: const Text(
                'Berhitung Cepat',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                color: surfaceColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentColor.withOpacity(0.2)),
              ),
              child: Text(
                'Jawab sebanyak mungkin dalam $_timeLimit detik!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: textMuted,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.amber.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.whatshot_rounded, color: Colors.amber, size: 16),
                  SizedBox(width: 6),
                  Text(
                    'Streak 3+ = bonus poin! 🔥',
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: _startGame,
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 8,
                shadowColor: primaryColor.withOpacity(0.4),
              ),
              child: const Text(
                'MULAI',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
            ),
            if (_best > 0) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: surfaceColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.amber.withOpacity(0.2)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.emoji_events_rounded, color: Colors.amber, size: 16),
                    const SizedBox(width: 8),
                    Text(
                      'Rekor terbaik: $_best poin',
                      style: TextStyle(
                        color: Colors.amber,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      );

  Widget _buildFinish() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('⏱️', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            const Text(
              'Waktu Habis!',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.4),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    'SKOR KAMU',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                  Text(
                    '$_score',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const Divider(color: Colors.white30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.emoji_events_rounded, color: Colors.amber, size: 16),
                      const SizedBox(width: 8),
                      Text(
                        'Rekor: $_best',
                        style: const TextStyle(
                          color: Colors.amber,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _startGame,
              icon: const Icon(Icons.refresh_rounded, color: Colors.white),
              label: const Text(
                'MAIN LAGI',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 8,
                shadowColor: primaryColor.withOpacity(0.4),
              ),
            ),
          ],
        ),
      );

  Widget _buildGame(Color timerColor, double pct) => Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: accentColor.withOpacity(0.1)),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'SKOR',
                        style: TextStyle(
                          color: textMuted,
                          fontSize: 10,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                      Text(
                        '$_score',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: accentColor.withOpacity(0.1)),
                  ),
                  child: Column(
                    children: [
                      Text(
                        'WAKTU',
                        style: TextStyle(
                          color: textMuted,
                          fontSize: 10,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                      Text(
                        '$_timeLeft',
                        style: TextStyle(
                          color: timerColor,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (_streak >= 2) ...[
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Colors.amber.withOpacity(0.2),
                    ),
                  ),
                  child: Column(
                    children: [
                      Text(
                        '🔥 STREAK',
                        style: TextStyle(
                          color: Colors.amber,
                          fontSize: 10,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                      Text(
                        '$_streak',
                        style: const TextStyle(
                          color: Colors.amber,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct.clamp(0.0, 1.0),
              backgroundColor: surfaceColor,
              color: timerColor,
              minHeight: 6,
            ),
          ),
          const Spacer(),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [surfaceColor, backgroundColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: accentColor.withOpacity(0.15),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.1),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Text(
              '$_num1  $_op  $_num2  =  ?',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
                letterSpacing: 2,
              ),
            ),
          ),
          const Spacer(),
          GridView.count(
            shrinkWrap: true,
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 2.2,
            physics: const NeverScrollableScrollPhysics(),
            children: _choices.map((c) {
              final isCorrect = c == _answer;
              return ElevatedButton(
                onPressed: () => _onChoiceTap(c),
                style: ElevatedButton.styleFrom(
                  backgroundColor: cardColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  side: BorderSide(
                    color: accentColor.withOpacity(0.1),
                    width: 1,
                  ),
                  elevation: 0,
                ).copyWith(
                  overlayColor: WidgetStateProperty.all(
                    isCorrect ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                  ),
                ),
                child: Text(
                  '$c',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
        ],
      );
}