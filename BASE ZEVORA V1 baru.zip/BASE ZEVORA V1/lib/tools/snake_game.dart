// snake_game.dart (Exotory Style - Snake Game - FIXED)

import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SnakeGamePage extends StatefulWidget {
  const SnakeGamePage({super.key});

  @override
  State<SnakeGamePage> createState() => _SnakeGamePageState();
}

class _SnakeGamePageState extends State<SnakeGamePage> {
  static const int cols = 20;
  static const int rows = 20;

  List<Offset> snake = [];
  Offset food = const Offset(10, 10);
  Offset direction = const Offset(1, 0);
  Offset nextDir = const Offset(1, 0);
  bool running = false;
  bool gameOver = false;
  int score = 0;
  int highScore = 0;
  Timer? _timer;
  final rng = Random();
  int _speed = 200;

  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color glowColor = const Color(0xFF9C27B0);
  final Color backgroundColor = const Color(0xFF0D0618);
  final Color surfaceColor = const Color(0xFF1A0B2E);
  final Color cardColor = const Color(0xFF2D1B4E);
  final Color textMuted = const Color(0xFFB39DDB);
  final Color textSecondary = const Color(0xFFE1BEE7);

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _resetGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadHighScore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getInt('snake_high_score');
      if (saved != null && mounted) {
        setState(() => highScore = saved);
      }
    } catch (e) {
      debugPrint('Error loading high score: $e');
    }
  }

  Future<void> _saveHighScore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('snake_high_score', highScore);
    } catch (e) {
      debugPrint('Error saving high score: $e');
    }
  }

  void _resetGame() {
    _timer?.cancel();
    snake = [
      const Offset(10, 10),
      const Offset(9, 10),
      const Offset(8, 10),
    ];
    direction = const Offset(1, 0);
    nextDir = const Offset(1, 0);
    _spawnFood();
    score = 0;
    running = false;
    gameOver = false;
    _speed = 200;
  }

  void _spawnFood() {
    Offset pos;
    do {
      pos = Offset(rng.nextInt(cols).toDouble(), rng.nextInt(rows).toDouble());
    } while (snake.contains(pos));
    food = pos;
  }

  void _startGame() {
    running = true;
    _timer?.cancel();
    _timer = Timer.periodic(Duration(milliseconds: _speed), (_) => _tick());
  }

  void _tick() {
    if (!running || !mounted) return;
    setState(() {
      direction = nextDir;
      final head = snake.first;
      final newHead = Offset(
        (head.dx + direction.dx) % cols,
        (head.dy + direction.dy) % rows,
      );
      if (snake.contains(newHead)) {
        running = false;
        gameOver = true;
        if (score > highScore) {
          highScore = score;
          _saveHighScore();
        }
        _timer?.cancel();
        return;
      }
      snake.insert(0, newHead);
      if (newHead == food) {
        score++;
        _spawnFood();
        if (score % 5 == 0 && _speed > 80) {
          _speed -= 20;
          _timer?.cancel();
          _timer = Timer.periodic(Duration(milliseconds: _speed), (_) => _tick());
        }
      } else {
        snake.removeLast();
      }
    });
  }

  void _changeDir(Offset newDir) {
    if (newDir.dx == -direction.dx && newDir.dy == -direction.dy) return;
    nextDir = newDir;
    if (!running && !gameOver) {
      _startGame();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.4),
                  Colors.black.withOpacity(0.7),
                ],
              ),
            ),
          ),
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Column(
            children: [
              _buildScoreBar(),
              Expanded(
                child: GestureDetector(
                  onVerticalDragUpdate: (d) {
                    if (d.primaryDelta! < -5) _changeDir(const Offset(0, -1));
                    if (d.primaryDelta! > 5) _changeDir(const Offset(0, 1));
                  },
                  onHorizontalDragUpdate: (d) {
                    if (d.primaryDelta! < -5) _changeDir(const Offset(-1, 0));
                    if (d.primaryDelta! > 5) _changeDir(const Offset(1, 0));
                  },
                  child: Center(
                    child: AspectRatio(
                      aspectRatio: cols / rows,
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: LayoutBuilder(builder: (_, constraints) {
                          final cellW = constraints.maxWidth / cols;
                          final cellH = constraints.maxHeight / rows;
                          return Stack(children: [
                            CustomPaint(
                              size: Size(constraints.maxWidth, constraints.maxHeight),
                              painter: _GridPainter(cols, rows),
                            ),
                            ...snake.asMap().entries.map((e) {
                              final i = e.key;
                              final pos = e.value;
                              final isHead = i == 0;
                              return Positioned(
                                left: pos.dx * cellW + 1,
                                top: pos.dy * cellH + 1,
                                width: cellW - 2,
                                height: cellH - 2,
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 50),
                                  decoration: BoxDecoration(
                                    gradient: isHead
                                        ? LinearGradient(
                                            colors: [accentColor, primaryColor],
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          )
                                        : LinearGradient(
                                            colors: [
                                              primaryColor.withOpacity(0.8),
                                              primaryColor.withOpacity(0.4),
                                            ],
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                          ),
                                    borderRadius: BorderRadius.circular(4),
                                    boxShadow: isHead ? [
                                      BoxShadow(
                                        color: accentColor.withOpacity(0.6),
                                        blurRadius: 10,
                                        spreadRadius: 2,
                                      ),
                                    ] : null,
                                  ),
                                  child: isHead
                                      ? Center(
                                          child: Container(
                                            width: cellW * 0.3,
                                            height: cellW * 0.3,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(2),
                                            ),
                                          ),
                                        )
                                      : null,
                                ),
                              );
                            }),
                            Positioned(
                              left: food.dx * cellW + 1,
                              top: food.dy * cellH + 1,
                              width: cellW - 2,
                              height: cellH - 2,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Colors.red.shade400, Colors.red.shade700],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(cellW / 2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.red.withOpacity(0.6),
                                      blurRadius: 10,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    '🍎',
                                    style: TextStyle(fontSize: cellW * 0.45),
                                  ),
                                ),
                              ),
                            ),
                            if (!running || gameOver)
                              Container(
                                color: Colors.black54,
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      if (gameOver) ...[
                                        Container(
                                          padding: const EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: surfaceColor.withOpacity(0.8),
                                            borderRadius: BorderRadius.circular(16),
                                            border: Border.all(
                                              color: Colors.red.withOpacity(0.3),
                                            ),
                                          ),
                                          child: Column(
                                            children: [
                                              const Text(
                                                '💀 GAME OVER',
                                                style: TextStyle(
                                                  color: Colors.red,
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.w900,
                                                  fontFamily: 'Orbitron',
                                                  letterSpacing: 2,
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  const Icon(
                                                    Icons.emoji_events_rounded,
                                                    color: Colors.amber,
                                                    size: 20,
                                                  ),
                                                  const SizedBox(width: 8),
                                                  Text(
                                                    'Skor: $score',
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 18,
                                                      fontWeight: FontWeight.bold,
                                                      fontFamily: 'ShareTechMono',
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              if (score >= highScore && score > 0) ...[
                                                const SizedBox(height: 4),
                                                Container(
                                                  padding: const EdgeInsets.symmetric(
                                                    horizontal: 12, vertical: 4,
                                                  ),
                                                  decoration: BoxDecoration(
                                                    color: Colors.amber.withOpacity(0.2),
                                                    borderRadius: BorderRadius.circular(8),
                                                    border: Border.all(
                                                      color: Colors.amber.withOpacity(0.3),
                                                    ),
                                                  ),
                                                  child: const Text(
                                                    '🏆 REKOR BARU!',
                                                    style: TextStyle(
                                                      color: Colors.amber,
                                                      fontSize: 12,
                                                      fontWeight: FontWeight.bold,
                                                      fontFamily: 'Orbitron',
                                                      letterSpacing: 1,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                              const SizedBox(height: 16),
                                              ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: primaryColor,
                                                  foregroundColor: Colors.white,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(12),
                                                  ),
                                                  elevation: 8,
                                                  shadowColor: primaryColor.withOpacity(0.4),
                                                ),
                                                onPressed: () => setState(_resetGame),
                                                child: const Text(
                                                  'MAIN LAGI',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w800,
                                                    fontFamily: 'Orbitron',
                                                    letterSpacing: 1,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ] else ...[
                                        Container(
                                          padding: const EdgeInsets.all(24),
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              colors: [primaryColor, accentColor],
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                            ),
                                            borderRadius: BorderRadius.circular(20),
                                            boxShadow: [
                                              BoxShadow(
                                                color: primaryColor.withOpacity(0.4),
                                                blurRadius: 30,
                                                spreadRadius: 5,
                                              ),
                                            ],
                                          ),
                                          child: Column(
                                            children: [
                                              const Text(
                                                '🐍 SNAKE',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 32,
                                                  fontWeight: FontWeight.w900,
                                                  fontFamily: 'Orbitron',
                                                  letterSpacing: 2,
                                                ),
                                              ),
                                              const SizedBox(height: 8),
                                              Text(
                                                'Swipe atau tekan tombol\nuntuk mulai',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: textSecondary.withOpacity(0.7),
                                                  fontSize: 14,
                                                  fontFamily: 'ShareTechMono',
                                                ),
                                              ),
                                              const SizedBox(height: 16),
                                              ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor: Colors.green.shade700,
                                                  foregroundColor: Colors.white,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius.circular(12),
                                                  ),
                                                  elevation: 8,
                                                  shadowColor: Colors.green.withOpacity(0.4),
                                                ),
                                                onPressed: _startGame,
                                                child: const Text(
                                                  'MULAI',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 16,
                                                    fontFamily: 'Orbitron',
                                                    letterSpacing: 2,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ),
                          ]);
                        }),
                      ),
                    ),
                  ),
                ),
              ),
              _buildDpad(),
            ],
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Icon(Icons.games_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentColor, primaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              'SNAKE GAME',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: primaryColor.withOpacity(0.3)),
          ),
          child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFCE93D8), size: 16),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.amber, Colors.orange],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.amber.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 14),
                const SizedBox(width: 4),
                Text(
                  '$highScore',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildScoreBar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8),
      color: surfaceColor.withOpacity(0.8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Skor: ',
            style: TextStyle(
              color: textMuted,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
          ),
          Text(
            '$score',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(width: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Text(
              'Speed: ${((400 - _speed) / 300 * 100).round()}%',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDpad() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        children: [
          _dpadBtn(Icons.keyboard_arrow_up_rounded, const Offset(0, -1)),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _dpadBtn(Icons.keyboard_arrow_left_rounded, const Offset(-1, 0)),
              const SizedBox(width: 56),
              _dpadBtn(Icons.keyboard_arrow_right_rounded, const Offset(1, 0)),
            ],
          ),
          _dpadBtn(Icons.keyboard_arrow_down_rounded, const Offset(0, 1)),
        ],
      ),
    );
  }

  Widget _dpadBtn(IconData icon, Offset dir) {
    return GestureDetector(
      onTap: () => _changeDir(dir),
      child: Container(
        width: 52,
        height: 52,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [surfaceColor, cardColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: accentColor.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: primaryColor.withOpacity(0.15),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Icon(
          icon,
          color: accentColor,
          size: 28,
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final int cols, rows;
  _GridPainter(this.cols, this.rows);

  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = accentColor.withOpacity(0.1)
      ..strokeWidth = 0.5;

    final cw = size.width / cols;
    final ch = size.height / rows;

    for (int i = 0; i <= cols; i++) {
      canvas.drawLine(Offset(i * cw, 0), Offset(i * cw, size.height), paint);
    }
    for (int i = 0; i <= rows; i++) {
      canvas.drawLine(Offset(0, i * ch), Offset(size.width, i * ch), paint);
    }

    final borderPaint = Paint()
      ..shader = LinearGradient(
        colors: [primaryColor, accentColor],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      borderPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}