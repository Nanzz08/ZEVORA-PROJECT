import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:http/http.dart' as http;
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:share_plus/share_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class FakeStoryPage extends StatefulWidget {
  const FakeStoryPage({Key? key}) : super(key: key);

  @override
  State<FakeStoryPage> createState() => _FakeStoryPageState();
}

class _FakeStoryPageState extends State<FakeStoryPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _captionController = TextEditingController();
  final TextEditingController _avatarUrlController = TextEditingController();

  bool _isLoading = false;
  bool _imageGenerated = false;
  Uint8List? _generatedImage;
  bool _isSharing = false;

  @override
  void initState() {
    super.initState();
    _usernameController.text = "REGELION AYUN💕";
    _captionController.text = "Bismillah Until Jannah";
    _avatarUrlController.text =
        "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
  }

  Future<void> _generateStory() async {
    if (_usernameController.text.isEmpty) {
      _showToast("Masukkan username");
      return;
    }
    if (_captionController.text.isEmpty) {
      _showToast("Masukkan caption");
      return;
    }
    if (_avatarUrlController.text.isEmpty) {
      _showToast("Masukkan URL avatar");
      return;
    }

    setState(() {
      _isLoading = true;
      _imageGenerated = false;
    });

    try {
      // 1) Coba API eksternal dulu
      Uint8List? bytes = await _tryRemoteStory();
      // 2) Fallback: generate lokal (anti 403 / offline mati)
      bytes ??= await _generateStoryLocal();

      if (bytes == null || bytes.isEmpty) {
        throw Exception('Gagal membuat story');
      }

      setState(() {
        _generatedImage = bytes;
        _imageGenerated = true;
      });
      _showToast("Story berhasil dibuat!");
    } catch (e) {
      _showToast("Error: ${e.toString().replaceFirst('Exception: ', '')}");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<Uint8List?> _tryRemoteStory() async {
    try {
      final encodedUsername = Uri.encodeComponent(_usernameController.text);
      final encodedCaption = Uri.encodeComponent(_captionController.text);
      final encodedAvatar = Uri.encodeComponent(_avatarUrlController.text);
      final apiUrl =
          'https://api.ryzumi.net/api/image/fake-story?username=$encodedUsername&caption=$encodedCaption&avatar=$encodedAvatar';
      final response = await http
          .get(Uri.parse(apiUrl), headers: {'accept': 'image/png'})
          .timeout(const Duration(seconds: 12));
      if (response.statusCode == 200 &&
          response.bodyBytes.length > 500 &&
          (response.headers['content-type'] ?? '').contains('image')) {
        return response.bodyBytes;
      }
    } catch (_) {}
    return null;
  }

  Future<ui.Image?> _loadNetworkImage(String url) async {
    try {
      final res = await http
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return null;
      final codec = await ui.instantiateImageCodec(res.bodyBytes);
      final frame = await codec.getNextFrame();
      return frame.image;
    } catch (_) {
      return null;
    }
  }

  Future<Uint8List?> _generateStoryLocal() async {
    const double W = 1080;
    const double H = 1920;
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final rect = Rect.fromLTWH(0, 0, W, H);

    // Background gradient (IG story style)
    final bg = Paint()
      ..shader = ui.Gradient.linear(
        const Offset(0, 0),
        const Offset(W, H),
        const [
          Color(0xFF1A0533),
          Color(0xFF0F172A),
          Color(0xFF1E1B4B),
          Color(0xFF312E81),
        ],
        const [0.0, 0.35, 0.7, 1.0],
      );
    canvas.drawRect(rect, bg);

    // Soft orbs
    canvas.drawCircle(
      const Offset(200, 400),
      280,
      Paint()..color = const Color(0xFF7C3AED).withOpacity(0.25),
    );
    canvas.drawCircle(
      const Offset(900, 1400),
      320,
      Paint()..color = const Color(0xFFEC4899).withOpacity(0.18),
    );

    // Progress bars (IG style)
    final barY = 48.0;
    final barH = 4.0;
    final gap = 8.0;
    final barW = (W - 64 - gap * 2) / 3;
    for (int i = 0; i < 3; i++) {
      final x = 32 + i * (barW + gap);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, barY, barW, barH),
          const Radius.circular(2),
        ),
        Paint()..color = Colors.white.withOpacity(i == 0 ? 0.95 : 0.35),
      );
    }

    // Avatar
    final avatarImg = await _loadNetworkImage(_avatarUrlController.text.trim());
    const avatarR = 48.0;
    const avatarCx = 80.0;
    const avatarCy = 130.0;
    final avatarPath = Path()
      ..addOval(Rect.fromCircle(center: const Offset(avatarCx, avatarCy), radius: avatarR));
    canvas.save();
    canvas.clipPath(avatarPath);
    if (avatarImg != null) {
      paintImage(
        canvas: canvas,
        rect: Rect.fromCircle(center: const Offset(avatarCx, avatarCy), radius: avatarR),
        image: avatarImg,
        fit: BoxFit.cover,
      );
    } else {
      canvas.drawCircle(
        const Offset(avatarCx, avatarCy),
        avatarR,
        Paint()..color = const Color(0xFF6366F1),
      );
      final tp = TextPainter(
        text: TextSpan(
          text: _usernameController.text.isNotEmpty
              ? _usernameController.text[0].toUpperCase()
              : '?',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 40,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(avatarCx - tp.width / 2, avatarCy - tp.height / 2));
    }
    canvas.restore();
    // avatar ring
    canvas.drawCircle(
      const Offset(avatarCx, avatarCy),
      avatarR,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );

    // Username
    final nameTp = TextPainter(
      text: TextSpan(
        text: _usernameController.text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 32,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.3,
        ),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: W - 200);
    nameTp.paint(canvas, const Offset(148, 108));

    // time ago
    final timeTp = TextPainter(
      text: const TextSpan(
        text: '1j',
        style: TextStyle(color: Color(0xFFCBD5E1), fontSize: 24),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    timeTp.paint(canvas, Offset(148 + nameTp.width + 12, 112));

    // Caption (center area)
    final captionTp = TextPainter(
      text: TextSpan(
        text: _captionController.text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 44,
          fontWeight: FontWeight.w600,
          height: 1.35,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(maxWidth: W - 120);
    captionTp.paint(
      canvas,
      Offset((W - captionTp.width) / 2, H * 0.42 - captionTp.height / 2),
    );

    // Bottom brand hint
    final brand = TextPainter(
      text: const TextSpan(
        text: 'Instagram Story • Preview',
        style: TextStyle(color: Color(0x99FFFFFF), fontSize: 22),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    brand.paint(canvas, Offset((W - brand.width) / 2, H - 80));

    final picture = recorder.endRecording();
    final img = await picture.toImage(W.toInt(), H.toInt());
    final bd = await img.toByteData(format: ui.ImageByteFormat.png);
    return bd?.buffer.asUint8List();
  }

  Future<void> _saveToGallery() async {
    if (_generatedImage == null) {
      _showToast("Buat story terlebih dahulu!");
      return;
    }

    try {
      setState(() {
        _isSharing = true;
      });

      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/fake_story_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);
      final ok = await GallerySaver.saveImage(file.path) ?? false;
      if (ok) {
        _showToast("✅ Story disimpan ke galeri!");
      } else {
        _showToast("❌ Gagal menyimpan story");
      }
    } catch (e) {
      _showToast("Error: ${e.toString()}");
    } finally {
      setState(() {
        _isSharing = false;
      });
    }
  }

  Future<void> _shareStory() async {
    if (_generatedImage == null) {
      _showToast("Buat story terlebih dahulu!");
      return;
    }

    try {
      setState(() {
        _isSharing = true;
      });

      final tempDir = await getTemporaryDirectory();
      final file = File(
          '${tempDir.path}/fake_story_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_generatedImage!);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Lihat fake story ini!',
        subject: 'Fake Instagram Story',
      );
    } catch (e) {
      _showToast("Error membagikan story");
    } finally {
      setState(() {
        _isSharing = false;
      });
    }
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black87,
      textColor: Colors.white,
      fontSize: 14.0,
    );
  }

  void _resetForm() {
    setState(() {
      _usernameController.clear();
      _captionController.clear();
      _avatarUrlController.clear();
      _generatedImage = null;
      _imageGenerated = false;
    });
    _usernameController.text = "REGELION AYUN💕";
    _captionController.text = "Bismillah Until Jannah✨";
    _avatarUrlController.text =
        "https://i.pinimg.com/originals/03/28/21/03282165e143dc1aabc6335fe3ab8fbe.jpg";
  }

  void _pasteFromClipboard() {
    _showToast("Tempel dari clipboard");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Pembuat Fake Story",
          style: TextStyle(
            fontWeight: FontWeight.w700,
            color: Colors.white,
            fontSize: 18,
            letterSpacing: 0.5,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, size: 22),
            onPressed: _resetForm,
            tooltip: "Reset Form",
          ),
        ],
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(20),
            bottomRight: Radius.circular(20),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFF5F7FF),
              Color(0xFFE8EAF6),
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Preview Card
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueGrey.withOpacity(0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border: Border.all(color: const Color(0xFFE3F2FD), width: 1),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1A237E).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  "Pratinjau Story",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF1A237E),
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          _generatedImage != null
                              ? Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(16),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.08),
                                        blurRadius: 20,
                                        spreadRadius: 0,
                                      ),
                                    ],
                                    border: Border.all(
                                      color: Colors.grey.shade200,
                                      width: 1,
                                    ),
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(16),
                                    child: Image.memory(
                                      _generatedImage!,
                                      fit: BoxFit.contain,
                                      height: 300,
                                    ),
                                  ),
                                )
                              : Container(
                                  height: 300,
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade50,
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: Colors.grey.shade200,
                                      width: 2,
                                      style: BorderStyle.solid,
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(20),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: const Color(0xFF1A237E)
                                              .withOpacity(0.05),
                                        ),
                                        child: Icon(
                                          Icons.photo_camera_outlined,
                                          size: 60,
                                          color: Colors.blueGrey.shade400,
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Text(
                                        "Story akan muncul di sini",
                                        style: TextStyle(
                                          color: Colors.blueGrey.shade600,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        "Isi form di bawah untuk membuat pratinjau",
                                        style: TextStyle(
                                          color: Colors.blueGrey.shade400,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                          const SizedBox(height: 20),
                          if (_imageGenerated)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 12),
                              decoration: BoxDecoration(
                                color: const Color(0xFF4CAF50).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: const Color(0xFF4CAF50),
                                  width: 1,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.check_circle,
                                      color: const Color(0xFF4CAF50), size: 20),
                                  const SizedBox(width: 10),
                                  Text(
                                    "Story Siap Digunakan!",
                                    style: TextStyle(
                                      color: const Color(0xFF2E7D32),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 15,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 25),

              // Form Card
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueGrey.withOpacity(0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border: Border.all(color: const Color(0xFFE3F2FD), width: 1),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      // Username Field
                      Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.person_outline,
                                    size: 18, color: Colors.blueGrey.shade700),
                                const SizedBox(width: 8),
                                Text(
                                  "Username Instagram",
                                  style: TextStyle(
                                    color: Colors.blueGrey.shade800,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            TextFormField(
                              controller: _usernameController,
                              style: TextStyle(
                                color: Colors.blueGrey.shade900,
                                fontSize: 16,
                              ),
                              decoration: InputDecoration(
                                hintText: "Masukkan username Instagram",
                                filled: true,
                                fillColor: Colors.grey.shade50,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(
                                    color: Colors.grey.shade300,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF1A237E),
                                    width: 2,
                                  ),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 16),
                              ),
                              maxLength: 30,
                            ),
                          ],
                        ),
                      ),

                      // Caption Field
                      Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.chat_bubble_outline,
                                    size: 18, color: Colors.blueGrey.shade700),
                                const SizedBox(width: 8),
                                Text(
                                  "Caption Story",
                                  style: TextStyle(
                                    color: Colors.blueGrey.shade800,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            TextFormField(
                              controller: _captionController,
                              style: TextStyle(
                                color: Colors.blueGrey.shade900,
                                fontSize: 16,
                              ),
                              decoration: InputDecoration(
                                hintText: "Masukkan caption story...",
                                filled: true,
                                fillColor: Colors.grey.shade50,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(
                                    color: Colors.grey.shade300,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF1A237E),
                                    width: 2,
                                  ),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 16),
                              ),
                              maxLines: 3,
                              maxLength: 100,
                            ),
                          ],
                        ),
                      ),

                      // Avatar URL Field
                      Container(
                        margin: const EdgeInsets.only(bottom: 25),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.link,
                                    size: 18, color: Colors.blueGrey.shade700),
                                const SizedBox(width: 8),
                                Text(
                                  "URL Foto Profil",
                                  style: TextStyle(
                                    color: Colors.blueGrey.shade800,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            TextFormField(
                              controller: _avatarUrlController,
                              style: TextStyle(
                                color: Colors.blueGrey.shade900,
                                fontSize: 16,
                              ),
                              decoration: InputDecoration(
                                hintText: "https://contoh.com/avatar.jpg",
                                filled: true,
                                fillColor: Colors.grey.shade50,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide.none,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(
                                    color: Colors.grey.shade300,
                                    width: 1,
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: const BorderSide(
                                    color: Color(0xFF1A237E),
                                    width: 2,
                                  ),
                                ),
                                suffixIcon: Container(
                                  margin: const EdgeInsets.all(4),
                                  child: ElevatedButton(
                                    onPressed: _pasteFromClipboard,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor:
                                          const Color(0xFF1A237E).withOpacity(0.1),
                                      foregroundColor: const Color(0xFF1A237E),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12),
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      "Tempel",
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: const Color(0xFF1A237E),
                                      ),
                                    ),
                                  ),
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 16),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: const Color(0xFFE8EAF6),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: const Color(0xFFC5CAE9),
                                  width: 1,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.info_outline,
                                      size: 16, color: const Color(0xFF1A237E)),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Text(
                                      "Pastikan URL adalah link langsung ke gambar (format: .jpg, .png, dll)",
                                      style: TextStyle(
                                        color: Colors.blueGrey.shade700,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Generate Button
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _generateStory,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1A237E),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 24),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 4,
                            shadowColor: const Color(0xFF1A237E).withOpacity(0.3),
                          ),
                          child: _isLoading
                              ? const SizedBox(
                                  height: 24,
                                  width: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 3,
                                    valueColor:
                                        AlwaysStoppedAnimation(Colors.white),
                                  ),
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.auto_awesome,
                                        size: 22, color: Colors.white),
                                    const SizedBox(width: 12),
                                    Text(
                                      "BUAT FAKE STORY",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                        letterSpacing: 0.5,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),

                      if (_imageGenerated) ...[
                        const SizedBox(height: 30),
                        const Divider(height: 1, color: Color(0xFFE0E0E0)),
                        const SizedBox(height: 20),
                        Text(
                          "Bagikan Story Anda",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Colors.blueGrey.shade800,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: _isSharing ? null : _saveToGallery,
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                      color: Color(0xFF1A237E), width: 1.5),
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 16),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  backgroundColor: Colors.white,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      _isSharing
                                          ? Icons.hourglass_bottom
                                          : Icons.save_alt_rounded,
                                      color: const Color(0xFF1A237E),
                                      size: 20,
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      _isSharing ? "Menyimpan..." : "SIMPAN",
                                      style: TextStyle(
                                        color: const Color(0xFF1A237E),
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: ElevatedButton(
                                onPressed: _isSharing ? null : _shareStory,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF1565C0),
                                  foregroundColor: Colors.white,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 16),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  elevation: 4,
                                  shadowColor:
                                      const Color(0xFF1565C0).withOpacity(0.3),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      _isSharing
                                          ? Icons.hourglass_bottom
                                          : Icons.share_rounded,
                                      size: 20,
                                      color: Colors.white,
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      _isSharing ? "Membagikan..." : "BAGIKAN",
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // Guide Card
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueGrey.withOpacity(0.08),
                      blurRadius: 25,
                      spreadRadius: 0,
                      offset: const Offset(0, 8),
                    ),
                  ],
                  border: Border.all(color: const Color(0xFFE3F2FD), width: 1),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xFF1A237E).withOpacity(0.1),
                            ),
                            child: Icon(Icons.help_outline_rounded,
                                color: const Color(0xFF1A237E), size: 22),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            "Panduan Penggunaan",
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              color: Colors.blueGrey.shade900,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildStep(1, "Masukkan username Instagram"),
                          _buildStep(2, "Tulis caption story yang diinginkan"),
                          _buildStep(3, "Tempel URL langsung ke foto profil"),
                          _buildStep(4, "Klik tombol 'Buat Fake Story'"),
                          _buildStep(5, "Tunggu hingga gambar muncul"),
                          _buildStep(6, "Simpan atau bagikan hasilnya"),
                        ],
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE8EAF6),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: const Color(0xFFC5CAE9),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.lightbulb_outline_rounded,
                                color: const Color(0xFF1A237E), size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                "Pastikan URL gambar adalah link langsung yang berakhir dengan ekstensi .jpg, .png, atau format gambar lainnya",
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.blueGrey.shade700,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStep(int number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: const Color(0xFF1A237E),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF1A237E).withOpacity(0.3),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Center(
              child: Text(
                "$number",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                text,
                style: TextStyle(
                  color: Colors.blueGrey.shade800,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  height: 1.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _captionController.dispose();
    _avatarUrlController.dispose();
    super.dispose();
  }
}