import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'app_theme.dart';

class MusicMcLarenEngineerPage extends StatefulWidget {
  final String username;
  final String role;
  final VoidCallback onContinue;

  const MusicMcLarenEngineerPage({
    super.key,
    required this.username,
    required this.role,
    required this.onContinue,
  });

  @override
  State<MusicMcLarenEngineerPage> createState() =>
      _MusicMcLarenEngineerPageState();
}

class _MusicMcLarenEngineerPageState extends State<MusicMcLarenEngineerPage>
    with TickerProviderStateMixin {
  // Accent and surfaces follow the app-wide theme selected by the user.
  static Color get _purple => AppTheme.I.accent;
  static Color get _purpleBright => AppTheme.I.accentFrost;
  static Color get _purpleDeep => AppTheme.I.accentDark;
  static Color get _ink => AppTheme.I.bg;
  static Color get _card => AppTheme.I.card;

  late final VideoPlayerController _video;
  late final AudioPlayer _audio;
  late final AnimationController _rotation;
  late final AnimationController _pulse;
  late final AnimationController _entry;
  late final AnimationController _bars;
  late final AnimationController _toneArm;

  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<Duration>? _durationSub;
  StreamSubscription<PlayerState>? _playerStateSub;

  bool _videoReady = false;
  bool _audioReady = false;
  bool _isPlaying = false;
  bool _continuing = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  @override
  void initState() {
    super.initState();
    _rotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    )..repeat(reverse: true);
    _entry = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
    )..forward();
    _bars = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 760),
    )..repeat(reverse: true);
    _toneArm = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 720),
      reverseDuration: const Duration(milliseconds: 520),
    );

    _audio = AudioPlayer();
    _initMedia();
  }

  Future<void> _initMedia() async {
    _video = VideoPlayerController.asset('assets/videos/splash.mp4');
    try {
      await _video.initialize();
      await _video.setLooping(true);
      await _video.setVolume(0);
      await _video.play();
      if (mounted) setState(() => _videoReady = true);
    } catch (_) {
      if (mounted) setState(() => _videoReady = false);
    }

    _positionSub = _audio.onPositionChanged.listen((value) {
      if (!mounted) return;
      setState(() => _position = value);
    });
    _durationSub = _audio.onDurationChanged.listen((value) {
      if (!mounted) return;
      setState(() => _duration = value);
    });
    _playerStateSub = _audio.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      final playing = state == PlayerState.playing;
      setState(() => _isPlaying = playing);
      _syncToneArm(playing);
    });

    try {
      await _audio.setReleaseMode(ReleaseMode.loop);
      await _audio.setVolume(.78);
      await _audio.play(AssetSource('sounds/splash_theme.wav'));
      if (mounted) setState(() => _audioReady = true);
    } catch (_) {
      if (mounted) setState(() => _audioReady = false);
    }
  }

  void _syncToneArm(bool playing) {
    if (!mounted) return;
    if (playing) {
      _toneArm.forward();
    } else {
      _toneArm.reverse();
    }
  }

  Future<void> _toggleToneArm() async {
    if (!_audioReady) return;
    await _togglePlay();
  }

  Future<void> _togglePlay() async {
    if (!_audioReady) return;
    if (_isPlaying) {
      await _audio.pause();
      return;
    }
    if (_position == Duration.zero) {
      await _audio.play(AssetSource('sounds/splash_theme.wav'));
    } else {
      await _audio.resume();
    }
  }

  Future<void> _stopMusic() async {
    if (!_audioReady) return;
    await _audio.stop();
    if (mounted) {
      setState(() {
        _isPlaying = false;
        _position = Duration.zero;
      });
    }
  }

  Future<void> _seek(double value) async {
    if (_duration == Duration.zero) return;
    final target = Duration(
      milliseconds: (_duration.inMilliseconds * value).round(),
    );
    await _audio.seek(target);
  }

  Future<void> _continue() async {
    if (_continuing) return;
    setState(() => _continuing = true);
    await _audio.stop();
    await _video.pause();
    if (!mounted) return;
    widget.onContinue();
  }

  @override
  void dispose() {
    _positionSub?.cancel();
    _durationSub?.cancel();
    _playerStateSub?.cancel();
    _rotation.dispose();
    _pulse.dispose();
    _entry.dispose();
    _bars.dispose();
    _toneArm.dispose();
    _audio.dispose();
    _video.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Material(
      color: _ink,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_videoReady)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _video.value.size.width,
                height: _video.value.size.height,
                child: VideoPlayer(_video),
              ),
            ),
          Container(color: Colors.black.withOpacity(.70)),
          Positioned.fill(
            child: CustomPaint(
              painter: _CheckerPainter(),
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _ink.withOpacity(.76),
                    _purpleDeep.withOpacity(.22),
                    _ink.withOpacity(.96),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(
                parent: _entry,
                curve: Curves.easeOutCubic,
              ),
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
                      child: Column(
                        children: [
                          _buildHeroIntro(),
                          const SizedBox(height: 14),
                          _buildPlayer(size),
                          const SizedBox(height: 14),
                          _buildProcessing(),
                          const SizedBox(height: 14),
                          _buildTransport(),
                          const SizedBox(height: 14),
                          _buildContinueButton(),
                          const SizedBox(height: 10),
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 4),
      child: _glass(
        radius: 25,
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
        child: Row(
          children: [
            _avatar(),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'MUSIC ZEVORA ENGINEER',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'AKUN: ${widget.username}',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: _purpleBright.withOpacity(.92),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
            _stereoPill(),
          ],
        ),
      ),
    );
  }

  Widget _avatar() {
    return Container(
      width: 49,
      height: 49,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: _purpleBright, width: 1.6),
        boxShadow: [
          BoxShadow(
            color: _purple.withOpacity(.35),
            blurRadius: 18,
          ),
        ],
      ),
      child: ClipOval(
        child: Image.asset(
          'assets/icon/icon.jpg',
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Icon(
            Icons.graphic_eq_rounded,
            color: _purpleBright,
          ),
        ),
      ),
    );
  }

  Widget _stereoPill() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.38),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(.11)),
        boxShadow: [
          BoxShadow(color: _purple.withOpacity(.13), blurRadius: 16),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isPlaying ? const Color(0xFF7CFFB2) : Colors.white38,
              boxShadow: _isPlaying
                  ? [BoxShadow(color: const Color(0xFF7CFFB2).withOpacity(.7), blurRadius: 9)]
                  : null,
            ),
          ),
          const SizedBox(width: 7),
          Text(
            _isPlaying ? 'STEREO' : 'PAUSED',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 7.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.2,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroIntro() {
    return _glass(
      radius: 26,
      padding: const EdgeInsets.fromLTRB(18, 17, 18, 16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 8),
            decoration: BoxDecoration(
              color: _purple.withOpacity(.14),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _purpleBright.withOpacity(.38)),
              boxShadow: [
                BoxShadow(color: _purple.withOpacity(.18), blurRadius: 18),
              ],
            ),
            child: Text(
              'S O U N D T R A C K',
              style: TextStyle(
                color: _purpleBright,
                fontSize: 9.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 3.0,
                fontFamily: 'Rajdhani',
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'INTRO ZEVORA',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 27,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.1,
              fontFamily: 'Qaxer',
              shadows: [Shadow(color: _purple, blurRadius: 24)],
            ),
          ),
          const SizedBox(height: 7),
          Text(
            'MUSIC ENGINEER • PAPAYA RACING AUDIO SYSTEM',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(.52),
              fontSize: 8.5,
              letterSpacing: 1.6,
              fontWeight: FontWeight.w800,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayer(Size size) {
    final diameter = math.min<double>(size.width * .70, 300.0).clamp(226.0, 300.0).toDouble();
    return SizedBox(
      width: double.infinity,
      child: _glass(
        radius: 30,
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 15),
        child: Column(
          children: [
            Row(
              children: [
                _tinyLabel('[ DIRECT DRIVE • MX-IV ]'),
                const Spacer(),
                _tinyLabel(_isPlaying ? 'TONEARM • PLAYING' : 'TONEARM • PARKED'),
              ],
            ),
            const SizedBox(height: 8),
            AnimatedBuilder(
              animation: Listenable.merge([_rotation, _pulse]),
              builder: (_, __) {
                final glow = 15 + (_pulse.value * 13);
                return SizedBox(
                  width: diameter + 54,
                  height: diameter + 54,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Transform.rotate(
                        angle: _rotation.value * math.pi * 2,
                        child: CustomPaint(
                          size: Size(diameter + 42, diameter + 42),
                          painter: _RacingRingPainter(_purpleBright, _purple),
                        ),
                      ),
                      Container(
                        width: diameter,
                        height: diameter,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF0A0A0E),
                          border: Border.all(
                            color: _purpleBright.withOpacity(.78),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _purple.withOpacity(.23),
                              blurRadius: glow,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: ClipOval(
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if (_videoReady)
                                FittedBox(
                                  fit: BoxFit.cover,
                                  child: SizedBox(
                                    width: _video.value.size.width,
                                    height: _video.value.size.height,
                                    child: VideoPlayer(_video),
                                  ),
                                ),
                              Container(color: Colors.black.withOpacity(.46)),
                              CustomPaint(painter: _DiscGroovesPainter()),
                              Center(child: _centerMusicCore()),
                            ],
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: IgnorePointer(
                          ignoring: false,
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: _toggleToneArm,
                            child: AnimatedBuilder(
                              animation: _toneArm,
                              builder: (_, __) => CustomPaint(
                                painter: _ToneArmPainter(
                                  progress: Curves.easeOutCubic.transform(_toneArm.value),
                                  purple: _purpleBright,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(top: 7, right: 18, child: _liveDot()),
                      Positioned(bottom: 10, left: 12, child: _rpmPill()),
                      Positioned(bottom: 10, right: 12, child: _musicGlyph()),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _centerMusicCore() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        final scale = .95 + (_pulse.value * .06);
        return Transform.scale(
          scale: scale,
          child: Container(
            width: 94,
            height: 94,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(.78),
              border: Border.all(color: _purpleBright, width: 2),
              boxShadow: [
                BoxShadow(color: _purple.withOpacity(.40), blurRadius: 26),
              ],
            ),
            child: ClipOval(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/icon/icon.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.music_note_rounded,
                      color: _purpleBright,
                      size: 44,
                    ),
                  ),
                  Container(color: Colors.white.withOpacity(.08)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _liveDot() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => Container(
        width: 14 + (_pulse.value * 2),
        height: 14 + (_pulse.value * 2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _purpleBright,
          boxShadow: [
            BoxShadow(
              color: _purpleBright.withOpacity(.72),
              blurRadius: 15 + (_pulse.value * 8),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rpmPill() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.58),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _purpleBright.withOpacity(.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _purpleBright,
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            '33% RPM • READY',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 7,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.0,
              fontFamily: 'Rajdhani',
            ),
          ),
        ],
      ),
    );
  }

  Widget _musicGlyph() {
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.55),
        shape: BoxShape.circle,
        border: Border.all(color: _purpleBright.withOpacity(.24)),
      ),
      child: Icon(
        Icons.music_note_rounded,
        color: _purpleBright,
        size: 18,
      ),
    );
  }

  Widget _buildProcessing() {
    final progress = _duration.inMilliseconds > 0
        ? (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0)
        : 0.0;
    return _glass(
      radius: 24,
      padding: const EdgeInsets.fromLTRB(15, 13, 15, 14),
      child: Column(
        children: [
          Row(
            children: [
              _animatedWaveIcon(),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'MEMUAT INTRO MUSIC...',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),
              Text(
                '${(progress * 100).round()}%',
                style: TextStyle(
                  color: _purpleBright,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Rajdhani',
                ),
              ),
            ],
          ),
          const SizedBox(height: 11),
          _waveform(),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: Stack(
              children: [
                Container(height: 7, color: Colors.white.withOpacity(.07)),
                FractionallySizedBox(
                  widthFactor: progress,
                  child: Container(
                    height: 7,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_purple, _purpleBright],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 7),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_format(_position), style: _timeStyle()),
              Text(_format(_duration), style: _timeStyle()),
            ],
          ),
        ],
      ),
    );
  }

  Widget _animatedWaveIcon() {
    return AnimatedBuilder(
      animation: _bars,
      builder: (_, __) {
        return SizedBox(
          width: 23,
          height: 23,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: List.generate(4, (index) {
              final wave = .35 + (((_bars.value + index * .17) % 1) * .65);
              return Container(
                width: 3.5,
                height: 7 + (13 * wave),
                decoration: BoxDecoration(
                  color: index.isEven ? _purpleBright : _purple,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: _purple.withOpacity(.42),
                      blurRadius: 7,
                    ),
                  ],
                ),
              );
            }),
          ),
        );
      },
    );
  }

  Widget _waveform() {
    return AnimatedBuilder(
      animation: _bars,
      builder: (_, __) => SizedBox(
        height: 29,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: List.generate(28, (index) {
            final phase = (_bars.value * math.pi * 2) + index * .52;
            final h = 5 + (math.sin(phase).abs() * 20);
            return Container(
              width: 2.4,
              height: h,
              decoration: BoxDecoration(
                color: index % 3 == 0 ? _purpleBright : Colors.white.withOpacity(.48),
                borderRadius: BorderRadius.circular(5),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildTransport() {
    final value = _duration.inMilliseconds == 0
        ? 0.0
        : (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: _tiltedSpotyCard(),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _glass(
            radius: 24,
            padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.headphones_rounded, color: _purpleBright, size: 17),
                    const SizedBox(width: 7),
                    const Expanded(
                      child: Text(
                        'INTRO ZEVORA',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.0,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ),
                    Icon(
                      _isPlaying ? Icons.graphic_eq_rounded : Icons.pause_circle_outline_rounded,
                      color: _purpleBright,
                      size: 17,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'ZEVORA X-MERCURY',
                  style: TextStyle(
                    color: Colors.white.withOpacity(.58),
                    fontSize: 7,
                    letterSpacing: 1.0,
                    fontFamily: 'Rajdhani',
                  ),
                ),
                const SizedBox(height: 4),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 3,
                    thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 4),
                    overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                    activeTrackColor: _purpleBright,
                    inactiveTrackColor: Colors.white12,
                    thumbColor: Colors.white,
                    overlayColor: _purple.withOpacity(.15),
                  ),
                  child: Slider(
                    value: value,
                    onChanged: _duration == Duration.zero ? null : (value) => _seek(value),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _roundControl(Icons.stop_rounded, _stopMusic),
                    _roundControl(
                      _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                      _togglePlay,
                      large: true,
                    ),
                    _roundControl(Icons.skip_next_rounded, () async {
                      await _audio.seek(Duration.zero);
                    }),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _tiltedSpotyCard() {
    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, .0015)
        ..rotateX(-.035)
        ..rotateY(-.10)
        ..rotateZ(-.045),
      child: Container(
        height: 192,
        decoration: BoxDecoration(
          color: const Color(0xFF0B0B0F).withOpacity(.94),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(.10)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.48), blurRadius: 25, offset: const Offset(0, 14)),
            BoxShadow(color: _purple.withOpacity(.18), blurRadius: 28),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/logo.png',
                fit: BoxFit.cover,
                opacity: const AlwaysStoppedAnimation(.18),
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 13, 12, 11),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 86,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(17),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF25103D), Color(0xFF08080B)],
                      ),
                      border: Border.all(color: _purple.withOpacity(.28)),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(17),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (_videoReady)
                            FittedBox(
                              fit: BoxFit.cover,
                              child: SizedBox(
                                width: _video.value.size.width,
                                height: _video.value.size.height,
                                child: VideoPlayer(_video),
                              ),
                            ),
                          Container(color: Colors.black.withOpacity(.44)),
                          Center(
                            child: Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black.withOpacity(.65),
                                border: Border.all(color: _purpleBright.withOpacity(.7)),
                              ),
                              child: const Icon(
                                Icons.music_note_rounded,
                                color: Colors.white,
                                size: 21,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 9),
                  const Text(
                    "ZEVORA AUDIO',
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 7,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.3,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const SizedBox(height: 3),
                  const Text(
                    'Intro ZEVORA',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      Icon(Icons.equalizer_rounded, color: _purpleBright, size: 14),
                      const SizedBox(width: 5),
                      Text(
                        _isPlaying ? 'PLAYING' : 'READY',
                        style: TextStyle(
                          color: _purpleBright,
                          fontSize: 7,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.0,
                          fontFamily: 'Rajdhani',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roundControl(IconData icon, VoidCallback onTap, {bool large = false}) {
    final size = large ? 46.0 : 34.0;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(size),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: large ? _purple.withOpacity(.25) : Colors.white.withOpacity(.055),
          border: Border.all(color: large ? _purpleBright.withOpacity(.62) : Colors.white.withOpacity(.10)),
          boxShadow: large
              ? [BoxShadow(color: _purple.withOpacity(.26), blurRadius: 18)]
              : null,
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: large ? 23 : 17,
        ),
      ),
    );
  }

  Widget _buildContinueButton() {
    return GestureDetector(
      onTap: _continue,
      child: Container(
        height: 68,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23),
          gradient: LinearGradient(
            colors: [_purple, _purpleBright],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          border: Border.all(color: Colors.white.withOpacity(.18)),
          boxShadow: [
            BoxShadow(
              color: _purple.withOpacity(.34),
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Row(
          children: [
            const SizedBox(width: 16),
            Container(
              width: 41,
              height: 41,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.22),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                _continuing ? Icons.hourglass_top_rounded : Icons.rocket_launch_rounded,
                color: Colors.white,
                size: 21,
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'LANJUTKAN KE DASHBOARD',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.1,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Enter ZEVORA X-MERCURY',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 7.5,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 25),
            const SizedBox(width: 17),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _isPlaying ? const Color(0xFF7CFFB2) : Colors.white38,
            boxShadow: _isPlaying
                ? [BoxShadow(color: const Color(0xFF7CFFB2).withOpacity(.6), blurRadius: 8)]
                : null,
          ),
        ),
        const SizedBox(width: 7),
        Text(
          _isPlaying
              ? 'ENGINE ONLINE • MUSIC STREAM ACTIVE'
              : 'ENGINE ONLINE • MUSIC PAUSED',
          style: TextStyle(
            color: Colors.white.withOpacity(.40),
            fontSize: 7,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.0,
            fontFamily: 'Rajdhani',
          ),
        ),
      ],
    );
  }

  Widget _tinyLabel(String text) {
    return Text(
      text,
      style: TextStyle(
        color: Colors.white.withOpacity(.42),
        fontSize: 6.5,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.0,
        fontFamily: 'ShareTechMono',
      ),
    );
  }

  TextStyle _timeStyle() {
    return TextStyle(
      color: Colors.white.withOpacity(.36),
      fontSize: 7,
      fontWeight: FontWeight.w800,
      fontFamily: 'Rajdhani',
    );
  }

  String _format(Duration value) {
    final minutes = value.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = value.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  Widget _glass({
    required Widget child,
    double radius = 24,
    EdgeInsets padding = EdgeInsets.zero,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: _card.withOpacity(.74),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: Colors.white.withOpacity(.10)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.35),
                blurRadius: 24,
                offset: const Offset(0, 12),
              ),
              BoxShadow(
                color: _purple.withOpacity(.09),
                blurRadius: 25,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _ToneArmPainter extends CustomPainter {
  final double progress;
  final Color purple;

  _ToneArmPainter({required this.progress, required this.purple});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final s = size.shortestSide;
    final pivot = Offset(center.dx + s * .315, center.dy - s * .235);
    final baseRadius = s * .045;

    // Parked -> playing arc. The arm settles gently over the record.
    final angle = -1.02 + (progress * .93);
    final armLength = s * .30;
    final elbow = Offset(
      pivot.dx + math.cos(angle) * armLength,
      pivot.dy + math.sin(angle) * armLength,
    );
    final headAngle = angle + .10;
    final headLength = s * .075;
    final needle = Offset(
      elbow.dx + math.cos(headAngle) * headLength,
      elbow.dy + math.sin(headAngle) * headLength,
    );

    final shadow = Paint()
      ..color = Colors.black.withOpacity(.55)
      ..strokeWidth = s * .030
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(pivot, elbow, shadow);

    final arm = Paint()
      ..shader = ui.Gradient.linear(
        pivot,
        elbow,
        [Colors.white.withOpacity(.95), purple, Colors.white.withOpacity(.78)],
      )
      ..strokeWidth = s * .018
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(pivot, elbow, arm);

    final elbowGlow = Paint()
      ..color = purple.withOpacity(.26)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);
    canvas.drawCircle(elbow, baseRadius * 1.7, elbowGlow);

    final head = Paint()
      ..color = purple
      ..strokeWidth = s * .020
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(elbow, needle, head);

    final pivotGlow = Paint()
      ..color = purple.withOpacity(.35)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 11);
    canvas.drawCircle(pivot, baseRadius * 2.2, pivotGlow);

    final pivotPaint = Paint()
      ..color = const Color(0xFF0C0C12)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(pivot, baseRadius * 1.55, pivotPaint);
    canvas.drawCircle(
      pivot,
      baseRadius * 1.55,
      Paint()
        ..color = purple.withOpacity(.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3,
    );
    canvas.drawCircle(
      pivot,
      baseRadius * .58,
      Paint()..color = Colors.white.withOpacity(.9),
    );

    final needlePaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      needle,
      Offset(needle.dx, needle.dy + s * .018),
      needlePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _ToneArmPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.purple != purple;
}

class _CheckerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const tile = 28.0;
    final paint = Paint();
    for (double y = 0; y < size.height; y += tile) {
      for (double x = 0; x < size.width; x += tile) {
        final even = ((x / tile).floor() + (y / tile).floor()).isEven;
        paint.color = even ? Colors.white.withOpacity(.018) : Colors.black.withOpacity(.035);
        canvas.drawRect(Rect.fromLTWH(x, y, tile, tile), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _CheckerPainter oldDelegate) => false;
}

class _RacingRingPainter extends CustomPainter {
  final Color bright;
  final Color purple;

  _RacingRingPainter(this.bright, this.purple);

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2;
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = bright.withOpacity(.48);
    canvas.drawCircle(center, radius - 3, ring);

    final tick = Paint()..strokeCap = StrokeCap.round;
    for (var i = 0; i < 42; i++) {
      final angle = i * math.pi * 2 / 42;
      final outer = radius - 1;
      final inner = radius - (i % 3 == 0 ? 13 : 8);
      tick.strokeWidth = i % 3 == 0 ? 2.6 : 1.3;
      tick.color = (i % 3 == 0 ? bright : purple).withOpacity(
        i % 3 == 0 ? .86 : .27,
      );
      canvas.drawLine(
        Offset(center.dx + inner * math.cos(angle), center.dy + inner * math.sin(angle)),
        Offset(center.dx + outer * math.cos(angle), center.dy + outer * math.sin(angle)),
        tick,
      );
    }

    final accent = Paint()
      ..color = bright.withOpacity(.8)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
      Offset(center.dx + (radius - 5), center.dy),
      4,
      accent,
    );
  }

  @override
  bool shouldRepaint(covariant _RacingRingPainter oldDelegate) => false;
}

class _DiscGroovesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final max = size.shortestSide / 2;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .65
      ..color = Colors.white.withOpacity(.09);
    for (var i = 0; i < 15; i++) {
      canvas.drawCircle(center, max - 7 - (i * 6.2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DiscGroovesPainter oldDelegate) => false;
}
