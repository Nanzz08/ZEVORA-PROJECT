import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:fiona/Qaxer/api.dart';

import 'publik_chat.dart';
import 'chat_ai_page.dart';
import 'app_theme.dart';
import 'wa_settings_page.dart';
import 'wa_call_page.dart';
import 'premium_service.dart';

// ─── Tema dinamis (mengikuti AppTheme / Ganti Warna) ───────────────
Color get _kPurple => AppTheme.I.accent;
Color get _kPurpleDark => AppTheme.I.bg;
Color get _kPurpleCard => AppTheme.I.card;
Color get _kPurpleSoft => AppTheme.I.accentSoft;
Color get _kBg => AppTheme.I.bg;
const Color _kText = Colors.white;
Color get _kMuted => AppTheme.I.textSub;

final String _api = Api.api;

/// Halaman utama Chat bergaya WhatsApp
/// Tab: Chats | Updates | Calls
class ChatPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const ChatPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _searchCtrl.addListener(() {
      setState(() => _query = _searchCtrl.text.trim().toLowerCase());
    });
  }

  @override
  void dispose() {
    _tabs.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _kText, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Chats',
          style: TextStyle(
            color: _kText,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.camera_alt_outlined, color: _kText),
            onPressed: () => _openStatusComposer(),
            tooltip: 'Buat status',
          ),
          IconButton(
            icon: const Icon(Icons.search, color: _kText),
            onPressed: () {
              // Fokus ke search di tab Chats
              _tabs.animateTo(0);
            },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: _kText),
            color: _kPurpleCard,
            onSelected: (v) {
              if (v == 'group') _showCreateGroup();
              if (v == 'broadcast') {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Broadcast list segera hadir')),
                );
              }
              if (v == 'settings') {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => WaSettingsPage(
                      username: widget.username,
                      role: widget.role,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'group',
                child: Text('Grup baru', style: TextStyle(color: _kText)),
              ),
              PopupMenuItem(
                value: 'broadcast',
                child: Text('Siaran baru', style: TextStyle(color: _kText)),
              ),
              PopupMenuItem(
                value: 'settings',
                child: Text('Pengaturan', style: TextStyle(color: _kText)),
              ),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: _kPurple,
          indicatorWeight: 3,
          indicatorSize: TabBarIndicatorSize.label,
          dividerColor: Colors.white.withOpacity(0.06),
          labelColor: _kText,
          unselectedLabelColor: _kMuted,
          labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          tabs: const [
            Tab(text: 'Chats'),
            Tab(text: 'Updates'),
            Tab(text: 'Calls'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _ChatsTab(
            username: widget.username,
            role: widget.role,
            sessionKey: widget.sessionKey,
            searchQuery: _query,
            searchController: _searchCtrl,
            onCreateGroup: _showCreateGroup,
          ),
          _UpdatesTab(
            username: widget.username,
            sessionKey: widget.sessionKey,
            onCreateStatus: _openStatusComposer,
          ),
          _CallsTab(username: widget.username),
        ],
      ),
      floatingActionButton: AnimatedBuilder(
        animation: _tabs,
        builder: (_, __) {
          final i = _tabs.index;
          if (i == 0) {
            return FloatingActionButton(
              backgroundColor: _kPurple,
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              onPressed: () => _showNewChatSheet(),
              child: const Icon(Icons.message, color: Colors.white),
            );
          }
          if (i == 1) {
            return FloatingActionButton(
              backgroundColor: _kPurple,
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              onPressed: _openStatusComposer,
              child: const Icon(Icons.camera_alt, color: Colors.white),
            );
          }
          return FloatingActionButton(
            backgroundColor: _kPurple,
            elevation: 6,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            onPressed: () => _showNewCallSheet(),
            child: const Icon(Icons.add_call, color: Colors.white),
          );
        },
      ),
    );
  }

  void _showNewChatSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _kPurpleCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: _kPurple,
                child: Icon(Icons.group_add, color: Colors.white),
              ),
              title: const Text('Grup baru', style: TextStyle(color: _kText)),
              onTap: () {
                Navigator.pop(ctx);
                _showCreateGroup();
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: _kPurple,
                child: Icon(Icons.public, color: Colors.white),
              ),
              title: const Text('Chat Global', style: TextStyle(color: _kText)),
              subtitle: Text('Ruang publik semua user',
                  style: TextStyle(color: _kMuted, fontSize: 12)),
              onTap: () {
                Navigator.pop(ctx);
                _openGlobal();
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: _kPurple,
                child: Icon(Icons.lock, color: Colors.white),
              ),
              title: const Text('Chat Privat', style: TextStyle(color: _kText)),
              onTap: () {
                Navigator.pop(ctx);
                _openPrivateList();
              },
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundColor: _kPurple,
                child: Icon(Icons.auto_awesome, color: Colors.white),
              ),
              title: const Text('ZEVORA PROJECT AI', style: TextStyle(color: _kText)),
              onTap: () {
                Navigator.pop(ctx);
                _openAI();
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  void _showNewCallSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _kPurpleCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.call, color: _kPurple),
              title: const Text('Panggilan suara baru',
                  style: TextStyle(color: _kText)),
              onTap: () {
                Navigator.pop(ctx);
                _openPrivateList(forCall: true, video: false);
              },
            ),
            ListTile(
              leading: Icon(Icons.videocam, color: _kPurple),
              title: const Text('Panggilan video baru',
                  style: TextStyle(color: _kText)),
              onTap: () {
                Navigator.pop(ctx);
                _openPrivateList(forCall: true, video: true);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showCreateGroup() {
    final nameCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _kPurpleCard,
        title: const Text('Buat grup', style: TextStyle(color: _kText)),
        content: TextField(
          controller: nameCtrl,
          style: TextStyle(color: _kText),
          decoration: InputDecoration(
            hintText: 'Nama grup',
            hintStyle: TextStyle(color: _kMuted),
            filled: true,
            fillColor: _kPurpleSoft,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Batal', style: TextStyle(color: _kMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _kPurple),
            onPressed: () async {
              final name = nameCtrl.text.trim();
              if (name.isEmpty) return;
              final prefs = await SharedPreferences.getInstance();
              final raw = prefs.getStringList('chat_groups_v1') ?? [];
              raw.insert(
                0,
                jsonEncode({
                  'id': 'g_${DateTime.now().millisecondsSinceEpoch}',
                  'name': name,
                  'owner': widget.username,
                  'members': [widget.username],
                  'created_at': DateTime.now().toIso8601String(),
                }),
              );
              await prefs.setStringList('chat_groups_v1', raw);
              if (mounted) {
                Navigator.pop(ctx);
                setState(() {});
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Grup "$name" dibuat')),
                );
              }
            },
            child: const Text('Buat', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _openGlobal() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _GlobalChatScreen(
          username: widget.username,
          role: widget.role,
        ),
      ),
    );
  }

  void _openPrivateList({bool forCall = false, bool video = false}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _PrivateListScreen(
          username: widget.username,
          sessionKey: widget.sessionKey,
          forCall: forCall,
          videoCall: video,
        ),
      ),
    );
  }

  void _openAI() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatAIPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
        ),
      ),
    );
  }

  void _openStatusComposer() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _StatusComposerPage(username: widget.username),
      ),
    ).then((_) {
      if (mounted) setState(() {});
    });
  }
}

// ═══════════════════════════════════════════════════════════════
// TAB: CHATS
// ═══════════════════════════════════════════════════════════════
class _ChatsTab extends StatefulWidget {
  final String username, role, sessionKey, searchQuery;
  final TextEditingController searchController;
  final VoidCallback onCreateGroup;

  const _ChatsTab({
    required this.username,
    required this.role,
    required this.sessionKey,
    required this.searchQuery,
    required this.searchController,
    required this.onCreateGroup,
  });

  @override
  State<_ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<_ChatsTab> {
  List<Map<String, dynamic>> _groups = [];

  @override
  void initState() {
    super.initState();
    _loadGroups();
  }

  Future<void> _loadGroups() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('chat_groups_v1') ?? [];
    final list = <Map<String, dynamic>>[];
    for (final s in raw) {
      try {
        final m = jsonDecode(s);
        if (m is Map) list.add(Map<String, dynamic>.from(m));
      } catch (_) {}
    }
    if (mounted) setState(() => _groups = list);
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.searchQuery;
    bool match(String title, String sub) {
      if (q.isEmpty) return true;
      return title.toLowerCase().contains(q) || sub.toLowerCase().contains(q);
    }

    final items = <_ChatListItem>[
      _ChatListItem(
        icon: Icons.public,
        title: 'Chat Global',
        subtitle: 'Ruang publik ZEVORA PROJECT',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => _GlobalChatScreen(
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      ),
      _ChatListItem(
        icon: Icons.lock,
        title: 'Chat Privat',
        subtitle: 'Pesan pribadi, media, VN & panggilan',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => _PrivateListScreen(
                username: widget.username,
                sessionKey: widget.sessionKey,
              ),
            ),
          );
        },
      ),
      _ChatListItem(
        icon: Icons.auto_awesome,
        title: 'ZEVORA PROJECT AI',
        subtitle: 'Asisten AI',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ChatAIPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
              ),
            ),
          );
        },
      ),
      ..._groups.map(
        (g) => _ChatListItem(
          icon: Icons.group,
          title: g['name']?.toString() ?? 'Grup',
          subtitle: 'Grup · ${g['owner'] ?? ''}',
          onTap: () {
            // Buka room group terpisah (room id = group:nama) — pesan tidak bercampur dengan Chat Global
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => _GlobalChatScreen(
                  username: widget.username,
                  role: widget.role,
                  title: g['name']?.toString() ?? 'Grup',
                ),
              ),
            );
          },
        ),
      ),
    ].where((e) => match(e.title, e.subtitle)).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: TextField(
            controller: widget.searchController,
            style: TextStyle(color: _kText),
            decoration: InputDecoration(
              hintText: 'Cari chat',
              hintStyle: TextStyle(color: _kMuted),
              prefixIcon: Icon(Icons.search, color: _kMuted),
              filled: true,
              fillColor: Colors.white.withOpacity(0.07),
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(28),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(28),
                borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(28),
                borderSide: BorderSide(color: _kPurple.withOpacity(0.6)),
              ),
            ),
          ),
        ),
        Expanded(
          child: items.isEmpty
              ? Center(
                  child: Text('Tidak ada chat',
                      style: TextStyle(color: _kMuted)),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final it = items[i];
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.08),
                        ),
                      ),
                      child: ListTile(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      onTap: it.onTap,
                      leading: Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [_kPurple, AppTheme.I.accentDark],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _kPurple.withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(it.icon, color: Colors.white, size: 24),
                      ),
                      title: Text(
                        it.title,
                        style: const TextStyle(
                          color: _kText,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        ),
                      ),
                      subtitle: Text(
                        it.subtitle,
                        style: TextStyle(color: _kMuted, fontSize: 13),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _ChatListItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  _ChatListItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

// ═══════════════════════════════════════════════════════════════
// GLOBAL CHAT SCREEN (WhatsApp-style room)
// ═══════════════════════════════════════════════════════════════
class _GlobalChatScreen extends StatelessWidget {
  final String username, role;
  final String? title;

  const _GlobalChatScreen({
    required this.username,
    required this.role,
    this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title ?? 'Chat Global',
              style: const TextStyle(
                color: _kText,
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
            Text(
              'Online',
              style: TextStyle(color: _kMuted, fontSize: 12),
            ),
          ],
        ),
        iconTheme: const IconThemeData(color: _kText),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {},
          ),
        ],
      ),
      body: GlobalChatTab(
        username: username,
        role: role,
        typingRoomId: title != null && title!.isNotEmpty
            ? 'group:${title!.toLowerCase().replaceAll(' ', '_')}'
            : 'global',
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// PRIVATE LIST + ROOM
// ═══════════════════════════════════════════════════════════════
class _PrivateListScreen extends StatelessWidget {
  final String username, sessionKey;
  final bool forCall;
  final bool videoCall;

  const _PrivateListScreen({
    required this.username,
    required this.sessionKey,
    this.forCall = false,
    this.videoCall = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Text(
          forCall
              ? (videoCall ? 'Panggilan video' : 'Panggilan suara')
              : 'Chat Privat',
          style: TextStyle(color: _kText, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: _kText),
      ),
      body: forCall
          ? _CallUserPicker(
              username: username,
              sessionKey: sessionKey,
              video: videoCall,
            )
          : PrivateChatTab(username: username, sessionKey: sessionKey),
    );
  }
}

class _CallUserPicker extends StatefulWidget {
  final String username, sessionKey;
  final bool video;
  const _CallUserPicker({
    required this.username,
    required this.sessionKey,
    required this.video,
  });

  @override
  State<_CallUserPicker> createState() => _CallUserPickerState();
}

class _CallUserPickerState extends State<_CallUserPicker> {
  List<UserModel> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final res = await http
          .get(Uri.parse('$_api/api/chatUsers'))
          .timeout(const Duration(seconds: 10));
      final decoded = jsonDecode(res.body);
      if (decoded is Map && decoded['success'] == true) {
        final list = (decoded['users'] as List? ?? [])
            .map((u) => UserModel.fromJson(u as Map<String, dynamic>))
            .where((u) => u.username != widget.username)
            .toList();
        if (mounted) setState(() {
          _users = list;
          _loading = false;
        });
        return;
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _startCall(UserModel u) async {
    await _CallHistory.add(
      peer: u.username,
      isVideo: widget.video,
      isOutgoing: true,
      status: 'outgoing',
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WaCallPage(
          peerName: u.displayName.isNotEmpty ? u.displayName : u.username,
          isVideo: widget.video,
          isOutgoing: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(child: CircularProgressIndicator(color: _kPurple));
    }
    if (_users.isEmpty) {
      return Center(
        child: Text('Tidak ada user', style: TextStyle(color: _kMuted)),
      );
    }
    return ListView.builder(
      itemCount: _users.length,
      itemBuilder: (_, i) {
        final u = _users[i];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: _kPurple,
            child: Text(
              (u.displayName.isNotEmpty ? u.displayName : u.username)
                  .substring(0, 1)
                  .toUpperCase(),
              style: const TextStyle(color: Colors.white),
            ),
          ),
          title: Text(
            u.displayName.isNotEmpty ? u.displayName : u.username,
            style: TextStyle(color: _kText),
          ),
          subtitle: Text(u.username, style: TextStyle(color: _kMuted)),
          trailing: Icon(
            widget.video ? Icons.videocam : Icons.call,
            color: _kPurple,
          ),
          onTap: () => _startCall(u),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// UPDATES (Status + Channels)
// ═══════════════════════════════════════════════════════════════
class _UpdatesTab extends StatefulWidget {
  final String username, sessionKey;
  final VoidCallback onCreateStatus;

  const _UpdatesTab({
    required this.username,
    required this.sessionKey,
    required this.onCreateStatus,
  });

  @override
  State<_UpdatesTab> createState() => _UpdatesTabState();
}

class _UpdatesTabState extends State<_UpdatesTab> {
  List<_StatusItem> _mine = [];
  List<_StatusItem> _others = [];
  Timer? _syncTimer;

  @override
  void initState() {
    super.initState();
    _load();
    // Sinkron periodik agar story orang lain muncul tanpa harus buka chat
    _syncTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (mounted) _load();
    });
  }

  @override
  void dispose() {
    _syncTimer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    // Tarik status dari server dulu, baru baca local store
    try {
      await _StatusStore.syncFromServer();
    } catch (_) {}
    final all = await _StatusStore.loadAll();
    final now = DateTime.now();
    final active = all
        .where((s) => now.difference(s.createdAt).inHours < 24)
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (!mounted) return;
    setState(() {
      _mine = active.where((s) => s.username == widget.username).toList();
      _others = active.where((s) => s.username != widget.username).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: _kPurple,
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Text(
              'Status',
              style: TextStyle(
                color: _kMuted,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
          // My status
          ListTile(
            onTap: () {
              if (_mine.isNotEmpty) {
                _openViewer(_mine, 0);
              } else {
                widget.onCreateStatus();
              }
            },
            leading: Stack(
              children: [
                Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _mine.isNotEmpty ? _kPurple : Colors.white24,
                      width: 2,
                    ),
                  ),
                  child: CircleAvatar(
                    radius: 26,
                    backgroundColor: _kPurpleSoft,
                    child: Text(
                      widget.username.isNotEmpty
                          ? widget.username[0].toUpperCase()
                          : '?',
                      style: TextStyle(color: _kText, fontSize: 20),
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: GestureDetector(
                    onTap: widget.onCreateStatus,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: _kPurple,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.add, size: 16, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            title: const Text('Status saya',
                style: TextStyle(color: _kText, fontWeight: FontWeight.w600)),
            subtitle: Text(
              _mine.isEmpty
                  ? 'Ketuk untuk menambahkan pembaruan status'
                  : '${_mine.length} pembaruan',
              style: TextStyle(color: _kMuted, fontSize: 13),
            ),
          ),
          if (_others.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Pembaruan terkini',
                style: TextStyle(
                  color: _kMuted,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
            ..._groupByUser(_others).entries.map((e) {
              final list = e.value;
              final first = list.first;
              return ListTile(
                onTap: () => _openViewer(list, 0),
                leading: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _kPurple, width: 2.5),
                  ),
                  child: CircleAvatar(
                    radius: 26,
                    backgroundColor: _kPurpleSoft,
                    child: Text(
                      first.username.isNotEmpty
                          ? first.username[0].toUpperCase()
                          : '?',
                      style: TextStyle(color: _kText, fontSize: 20),
                    ),
                  ),
                ),
                title: VerifiedName(
                  username: first.username,
                  displayName: first.username,
                  style: const TextStyle(
                      color: _kText, fontWeight: FontWeight.w600),
                  badgeSize: 15,
                ),
                subtitle: Text(
                  _timeAgo(first.createdAt),
                  style: TextStyle(color: _kMuted, fontSize: 12),
                ),
              );
            }),
          ] else
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Belum ada status dari pengguna lain.\nStatus semua orang akan muncul di sini (24 jam).',
                textAlign: TextAlign.center,
                style: TextStyle(color: _kMuted),
              ),
            ),
          const Divider(color: Colors.white12, height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Text(
              'Channel',
              style: TextStyle(
                color: _kMuted,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
          ListTile(
            leading: CircleAvatar(
                backgroundColor: _kPurple,
              child: Icon(Icons.campaign, color: Colors.white),
            ),
            title: const Text('Jelajahi channel',
                style: TextStyle(color: _kText, fontWeight: FontWeight.w600)),
            subtitle: Text(
              'Ikuti channel berita & pengumuman',
              style: TextStyle(color: _kMuted, fontSize: 12),
            ),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    'Channel: hubungkan ke server pengumuman (segera)',
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Map<String, List<_StatusItem>> _groupByUser(List<_StatusItem> items) {
    final map = <String, List<_StatusItem>>{};
    for (final s in items) {
      map.putIfAbsent(s.username, () => []).add(s);
    }
    return map;
  }

  void _openViewer(List<_StatusItem> items, int index) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _StatusViewerPage(items: items, initialIndex: index),
      ),
    ).then((_) => _load());
  }

  String _timeAgo(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inMinutes < 1) return 'Baru saja';
    if (d.inMinutes < 60) return '${d.inMinutes} menit yang lalu';
    if (d.inHours < 24) return '${d.inHours} jam yang lalu';
    return '${d.inDays} hari yang lalu';
  }
}

// ═══════════════════════════════════════════════════════════════
// CALLS TAB
// ═══════════════════════════════════════════════════════════════
class _CallsTab extends StatefulWidget {
  final String username;
  const _CallsTab({required this.username});

  @override
  State<_CallsTab> createState() => _CallsTabState();
}

class _CallsTabState extends State<_CallsTab> {
  List<_CallEntry> _calls = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await _CallHistory.load();
    if (mounted) setState(() => _calls = list);
  }

  @override
  Widget build(BuildContext context) {
    if (_calls.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.call, size: 64, color: _kMuted.withOpacity(0.4)),
            const SizedBox(height: 12),
            Text(
              'Belum ada riwayat panggilan',
              style: TextStyle(color: _kMuted),
            ),
            const SizedBox(height: 8),
            Text(
              'Ketuk tombol + untuk memulai panggilan',
              style: TextStyle(color: _kMuted, fontSize: 12),
            ),
          ],
        ),
      );
    }
    return RefreshIndicator(
      color: _kPurple,
      onRefresh: _load,
      child: ListView.builder(
        itemCount: _calls.length,
        itemBuilder: (_, i) {
          final c = _calls[i];
          final isMissed = c.status == 'missed';
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: _kPurpleSoft,
              child: Text(
                c.peer.isNotEmpty ? c.peer[0].toUpperCase() : '?',
                style: TextStyle(color: _kText),
              ),
            ),
            title: Text(
              c.peer,
              style: TextStyle(
                color: isMissed ? Colors.redAccent : _kText,
                fontWeight: FontWeight.w600,
              ),
            ),
            subtitle: Row(
              children: [
                Icon(
                  c.isOutgoing
                      ? Icons.call_made
                      : (isMissed ? Icons.call_missed : Icons.call_received),
                  size: 14,
                  color: isMissed ? Colors.redAccent : _kMuted,
                ),
                const SizedBox(width: 4),
                Text(
                  _formatCallTime(c.at),
                  style: TextStyle(color: _kMuted, fontSize: 12),
                ),
              ],
            ),
            trailing: IconButton(
              icon: Icon(
                c.isVideo ? Icons.videocam : Icons.call,
                color: _kPurple,
              ),
              onPressed: () async {
                await _CallHistory.add(
                  peer: c.peer,
                  isVideo: c.isVideo,
                  isOutgoing: true,
                  status: 'outgoing',
                );
                if (!mounted) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => WaCallPage(
                      peerName: c.peer,
                      isVideo: c.isVideo,
                      isOutgoing: true,
                    ),
                  ),
                ).then((_) => _load());
              },
            ),
          );
        },
      ),
    );
  }

  String _formatCallTime(DateTime t) {
    final now = DateTime.now();
    if (now.difference(t).inDays == 0) {
      return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
    }
    return '${t.day}/${t.month} ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }
}

// ═══════════════════════════════════════════════════════════════
// STATUS COMPOSER / VIEWER / STORE
// ═══════════════════════════════════════════════════════════════
class _StatusItem {
  final String id, username, type, content, bgColor;
  final String caption;
  final DateTime createdAt;

  _StatusItem({
    required this.id,
    required this.username,
    required this.type, // text | image | video | voice
    required this.content,
    required this.bgColor,
    required this.createdAt,
    this.caption = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'type': type,
        'content': content,
        'bg_color': bgColor,
        'caption': caption,
        'created_at': createdAt.toIso8601String(),
      };

  factory _StatusItem.fromJson(Map<String, dynamic> j) => _StatusItem(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        type: j['type']?.toString() ?? 'text',
        content: j['content']?.toString() ?? '',
        bgColor: j['bg_color']?.toString() ?? '#1A0F2E',
        caption: j['caption']?.toString() ?? '',
        createdAt:
            DateTime.tryParse(j['created_at']?.toString() ?? '') ?? DateTime.now(),
      );
}

class _StatusStore {
  static const _key = 'wa_status_v1';

  static Future<List<_StatusItem>> loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final out = <_StatusItem>[];
    final seen = <String>{};
    for (final s in raw) {
      try {
        final item = _StatusItem.fromJson(jsonDecode(s) as Map<String, dynamic>);
        if (item.id.isEmpty || seen.contains(item.id)) continue;
        seen.add(item.id);
        out.add(item);
      } catch (_) {}
    }
    return out;
  }

  /// Simpan / merge status ke local store (dedupe by id).
  static Future<void> _mergeLocal(List<_StatusItem> incoming) async {
    if (incoming.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final byId = <String, String>{};
    for (final s in raw) {
      try {
        final m = jsonDecode(s);
        if (m is Map && m['id'] != null) {
          byId[m['id'].toString()] = s;
        }
      } catch (_) {}
    }
    for (final item in incoming) {
      if (item.id.isEmpty) continue;
      byId[item.id] = jsonEncode(item.toJson());
    }
    final list = byId.values.toList();
    // sort by created_at desc roughly by keeping newest first from incoming order
    while (list.length > 150) {
      list.removeLast();
    }
    await prefs.setStringList(_key, list);
  }

  static Future<void> add(_StatusItem item) async {
    await _mergeLocal([item]);

    // Broadcast ke semua user lewat chat global + endpoint status (best-effort)
    final payload = item.toJson();
    final body = {
      'id': item.id,
      'userId': item.username,
      'username': item.username,
      'role': 'Member',
      'message': '__STATUS__${jsonEncode(payload)}',
      'timestamp': item.createdAt.toIso8601String(),
      'type': 'status',
      'room': 'global',
      'roomId': 'global',
    };
    try {
      await http
          .post(
            Uri.parse('$_api/chat/send'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {}
    // Endpoint khusus status jika server support
    for (final path in ['/api/status', '/chat/status', '/api/stories']) {
      try {
        await http
            .post(
              Uri.parse('$_api$path'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode(payload),
            )
            .timeout(const Duration(seconds: 5));
      } catch (_) {}
    }
  }

  /// Tarik status dari server agar semua user bisa melihat story orang lain.
  /// Sumber: /chat/messages (__STATUS__), /api/status, /chat/status, /api/stories.
  static Future<void> syncFromServer() async {
    final incoming = <_StatusItem>[];

    // 1) Chat messages — payload __STATUS__{...}
    try {
      final uri = Uri.parse('$_api/chat/messages').replace(
        queryParameters: {'room': 'global', 'roomId': 'global'},
      );
      final res =
          await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        dynamic decoded = jsonDecode(res.body);
        List list = [];
        if (decoded is List) {
          list = decoded;
        } else if (decoded is Map) {
          list = (decoded['messages'] ?? decoded['data'] ?? []) as List? ?? [];
        }
        for (final raw in list) {
          if (raw is! Map) continue;
          final msg = raw['message']?.toString() ?? '';
          if (!msg.startsWith('__STATUS__')) continue;
          try {
            final map = jsonDecode(msg.substring('__STATUS__'.length));
            if (map is Map<String, dynamic>) {
              final item = _StatusItem.fromJson({
                'id': map['id'] ??
                    raw['id'] ??
                    'st_${raw['timestamp'] ?? DateTime.now().millisecondsSinceEpoch}',
                'username': map['username'] ??
                    raw['username'] ??
                    raw['userId'] ??
                    '',
                'type': map['type'] ?? 'text',
                'content': map['content'] ?? '',
                'bg_color': map['bg_color'] ?? map['bgColor'] ?? '#1A0F2E',
                'caption': map['caption'] ?? '',
                'created_at': map['created_at'] ??
                    map['createdAt'] ??
                    raw['timestamp'] ??
                    DateTime.now().toIso8601String(),
              });
              if (item.id.isNotEmpty && item.username.isNotEmpty) {
                incoming.add(item);
              }
            }
          } catch (_) {}
        }
      }
    } catch (_) {}

    // 2) Dedicated status/stories endpoints
    for (final path in [
      '/api/status',
      '/chat/status',
      '/api/stories',
      '/api/status/list',
    ]) {
      try {
        final res = await http
            .get(Uri.parse('$_api$path'))
            .timeout(const Duration(seconds: 6));
        if (res.statusCode != 200) continue;
        dynamic decoded = jsonDecode(res.body);
        List list = [];
        if (decoded is List) {
          list = decoded;
        } else if (decoded is Map) {
          list = (decoded['status'] ??
                  decoded['statuses'] ??
                  decoded['stories'] ??
                  decoded['data'] ??
                  []) as List? ??
              [];
        }
        for (final e in list) {
          if (e is! Map) continue;
          final m = Map<String, dynamic>.from(e);
          final item = _StatusItem.fromJson({
            'id': m['id'] ?? '',
            'username': m['username'] ?? m['userId'] ?? m['owner'] ?? '',
            'type': m['type'] ?? 'text',
            'content': m['content'] ?? m['url'] ?? m['mediaUrl'] ?? '',
            'bg_color': m['bg_color'] ?? m['bgColor'] ?? '#1A0F2E',
            'caption': m['caption'] ?? '',
            'created_at': m['created_at'] ??
                m['createdAt'] ??
                DateTime.now().toIso8601String(),
          });
          if (item.id.isNotEmpty && item.username.isNotEmpty) {
            incoming.add(item);
          }
        }
      } catch (_) {}
    }

    if (incoming.isNotEmpty) {
      await _mergeLocal(incoming);
    }
  }
}

class _StatusComposerPage extends StatefulWidget {
  final String username;
  const _StatusComposerPage({required this.username});

  @override
  State<_StatusComposerPage> createState() => _StatusComposerPageState();
}

class _StatusComposerPageState extends State<_StatusComposerPage> {
  final _textCtrl = TextEditingController();
  final _captionCtrl = TextEditingController();
  String _bg = '#1A0F2E';
  String _type = 'text'; // text | image | video | voice
  File? _media;
  bool _posting = false;
  bool _recording = false;
  int _recSeconds = 0;
  Timer? _recTimer;
  final AudioRecorder _recorder = AudioRecorder();

  static const _colors = [
    '#1A0F2E',
    '#0D47A1',
    '#1B5E20',
    '#B71C1C',
    '#4A148C',
    '#E65100',
    '#006064',
    '#212121',
  ];

  Color _hex(String h) {
    try {
      return Color(int.parse('FF${h.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return _kPurpleDark;
    }
  }

  @override
  void dispose() {
    _recTimer?.cancel();
    _textCtrl.dispose();
    _captionCtrl.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final p = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (p != null) {
      setState(() {
        _media = File(p.path);
        _type = 'image';
      });
    }
  }

  Future<void> _pickVideo() async {
    final p = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (p != null) {
      setState(() {
        _media = File(p.path);
        _type = 'video';
      });
    }
  }

  Future<void> _takePhoto() async {
    final p = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );
    if (p != null) {
      setState(() {
        _media = File(p.path);
        _type = 'image';
      });
    }
  }

  Future<void> _toggleVoice() async {
    if (_recording) {
      final path = await _recorder.stop();
      _recTimer?.cancel();
      setState(() {
        _recording = false;
        if (path != null) {
          _media = File(path);
          _type = 'voice';
        }
      });
      return;
    }
    try {
      if (!await _recorder.hasPermission()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Izin mikrofon diperlukan')),
          );
        }
        return;
      }
      final dir = await getTemporaryDirectory();
      final path =
          '${dir.path}/status_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc),
        path: path,
      );
      setState(() {
        _recording = true;
        _recSeconds = 0;
        _media = null;
        _type = 'voice';
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSeconds++);
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal rekam: $e')),
        );
      }
    }
  }

  void _clearMedia() {
    setState(() {
      _media = null;
      _type = 'text';
      _recording = false;
      _recTimer?.cancel();
    });
  }

  Future<void> _post() async {
    if (_posting) return;
    if (_recording) {
      await _toggleVoice();
    }
    final hasText = _textCtrl.text.trim().isNotEmpty;
    final hasMedia = _media != null;
    if (!hasText && !hasMedia) return;

    setState(() => _posting = true);
    final type = hasMedia ? _type : 'text';
    final content = hasMedia ? _media!.path : _textCtrl.text.trim();
    final caption = hasMedia ? _captionCtrl.text.trim() : '';

    final item = _StatusItem(
      id: 'st_${DateTime.now().millisecondsSinceEpoch}',
      username: widget.username,
      type: type,
      content: content,
      bgColor: _bg,
      caption: caption,
      createdAt: DateTime.now(),
    );
    await _StatusStore.add(item);
    if (mounted) {
      setState(() => _posting = false);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMedia = _media != null || _recording;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          _type == 'image'
              ? 'Status foto'
              : _type == 'video'
                  ? 'Status video'
                  : _type == 'voice'
                      ? 'Status suara'
                      : 'Status teks',
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        actions: [
          if (isMedia)
            IconButton(
              icon: const Icon(Icons.close),
              tooltip: 'Hapus media',
              onPressed: _clearMedia,
            ),
          TextButton(
            onPressed: _posting ? null : _post,
            child: _posting
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Kirim',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _buildPreview(),
            ),
          ),
          // Caption field for media
          if (isMedia && !_recording)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: TextField(
                controller: _captionCtrl,
                style: const TextStyle(color: Colors.white),
                maxLines: 2,
                decoration: InputDecoration(
                  hintText: 'Tambahkan caption…',
                  hintStyle: const TextStyle(color: Colors.white54),
                  filled: true,
                  fillColor: Colors.white12,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
              ),
            ),
          // Media tools
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _toolBtn(Icons.photo_library, 'Galeri', _pickImage),
                _toolBtn(Icons.camera_alt, 'Kamera', _takePhoto),
                _toolBtn(Icons.videocam, 'Video', _pickVideo),
                _toolBtn(
                  _recording ? Icons.stop : Icons.mic,
                  _recording ? '${_recSeconds}s' : 'Suara',
                  _toggleVoice,
                  active: _recording,
                ),
              ],
            ),
          ),
          if (!isMedia)
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _colors.map((c) {
                  final sel = _bg == c;
                  return GestureDetector(
                    onTap: () => setState(() => _bg = c),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: _hex(c),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: sel ? Colors.white : Colors.transparent,
                          width: 2,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }

  Widget _toolBtn(IconData icon, String label, VoidCallback onTap,
      {bool active = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 22,
              backgroundColor:
                  active ? Colors.redAccent : Colors.white.withOpacity(0.12),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _buildPreview() {
    if (_recording) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.mic, color: Colors.redAccent, size: 72),
          const SizedBox(height: 16),
          Text(
            'Merekam… ${_recSeconds}s',
            style: const TextStyle(color: Colors.white, fontSize: 18),
          ),
          const SizedBox(height: 8),
          const Text('Ketuk stop untuk selesai',
              style: TextStyle(color: Colors.white54)),
        ],
      );
    }
    if (_media != null && _type == 'image') {
      return Padding(
        padding: const EdgeInsets.all(12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(_media!, fit: BoxFit.contain),
        ),
      );
    }
    if (_media != null && _type == 'video') {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.videocam, color: Colors.white70, size: 72),
          const SizedBox(height: 12),
          Text(
            _media!.path.split('/').last,
            style: const TextStyle(color: Colors.white70),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          const Text('Video siap dikirim',
              style: TextStyle(color: Colors.white54)),
        ],
      );
    }
    if (_media != null && _type == 'voice') {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.graphic_eq, color: Color(0xFF25D366), size: 72),
          const SizedBox(height: 12),
          const Text('Pesan suara siap',
              style: TextStyle(color: Colors.white, fontSize: 18)),
          Text('$_recSeconds detik',
              style: const TextStyle(color: Colors.white54)),
        ],
      );
    }
    // Text status
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: TextField(
        controller: _textCtrl,
        textAlign: TextAlign.center,
        maxLines: null,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 28,
          fontWeight: FontWeight.w600,
        ),
        decoration: const InputDecoration(
          border: InputBorder.none,
          hintText: 'Ketik status…',
          hintStyle: TextStyle(color: Colors.white54),
        ),
      ),
    );
  }
}

class _StatusViewerPage extends StatefulWidget {
  final List<_StatusItem> items;
  final int initialIndex;
  const _StatusViewerPage({required this.items, required this.initialIndex});

  @override
  State<_StatusViewerPage> createState() => _StatusViewerPageState();
}

class _StatusViewerPageState extends State<_StatusViewerPage>
    with SingleTickerProviderStateMixin {
  late int _i;
  late AnimationController _prog;
  VideoPlayerController? _videoCtrl;
  final AudioPlayer _audio = AudioPlayer();
  bool _audioPlaying = false;

  _StatusItem get s => widget.items[_i];

  @override
  void initState() {
    super.initState();
    _i = widget.initialIndex;
    _startProgress();
  }

  Duration _durationFor(String type) {
    switch (type) {
      case 'video':
        return const Duration(seconds: 15);
      case 'voice':
        return const Duration(seconds: 12);
      case 'image':
        return const Duration(seconds: 7);
      default:
        return const Duration(seconds: 5);
    }
  }

  void _startProgress() {
    _disposeMedia();
    final d = _durationFor(s.type);
    _prog = AnimationController(vsync: this, duration: d)
      ..forward().then((_) {
        if (mounted) _next();
      });
    if (s.type == 'video') {
      _initVideo();
    } else if (s.type == 'voice') {
      _initVoice();
    }
    setState(() {});
  }

  Future<void> _initVideo() async {
    try {
      final path = s.content;
      if (path.startsWith('http')) {
        _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(path));
      } else {
        _videoCtrl = VideoPlayerController.file(File(path));
      }
      await _videoCtrl!.initialize();
      await _videoCtrl!.setLooping(true);
      await _videoCtrl!.play();
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _initVoice() async {
    try {
      final path = s.content;
      if (path.startsWith('http')) {
        await _audio.play(UrlSource(path));
      } else {
        await _audio.play(DeviceFileSource(path));
      }
      setState(() => _audioPlaying = true);
    } catch (_) {}
  }

  void _disposeMedia() {
    _videoCtrl?.dispose();
    _videoCtrl = null;
    _audio.stop();
    _audioPlaying = false;
  }

  void _next() {
    if (_i < widget.items.length - 1) {
      setState(() => _i++);
      _prog.dispose();
      _startProgress();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_i > 0) {
      setState(() => _i--);
      _prog.dispose();
      _startProgress();
    } else {
      _prog
        ..reset()
        ..forward().then((_) {
          if (mounted) _next();
        });
    }
  }

  @override
  void dispose() {
    _prog.dispose();
    _disposeMedia();
    _audio.dispose();
    super.dispose();
  }

  Color _hex(String h) {
    try {
      return Color(int.parse('FF${h.replaceAll('#', '')}', radix: 16));
    } catch (_) {
      return Colors.black;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isText = s.type == 'text';
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        onTapUp: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.localPosition.dx < w * 0.3) {
            _prev();
          } else {
            _next();
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Content
            if (s.type == 'image')
              Center(
                child: s.content.startsWith('http')
                    ? Image.network(s.content, fit: BoxFit.contain)
                    : Image.file(File(s.content), fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => const Icon(
                            Icons.broken_image,
                            color: Colors.white54,
                            size: 64)),
              )
            else if (s.type == 'video')
              Center(
                child: _videoCtrl != null && _videoCtrl!.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _videoCtrl!.value.aspectRatio,
                        child: VideoPlayer(_videoCtrl!),
                      )
                    : const CircularProgressIndicator(color: Colors.white),
              )
            else if (s.type == 'voice')
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _audioPlaying ? Icons.graphic_eq : Icons.mic,
                      color: const Color(0xFF25D366),
                      size: 80,
                    ),
                    const SizedBox(height: 16),
                    VerifiedName(
                      username: s.username,
                      displayName: s.username,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                      badgeSize: 16,
                    ),
                    const SizedBox(height: 8),
                    const Text('Pesan suara',
                        style: TextStyle(color: Colors.white54)),
                  ],
                ),
              )
            else
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Text(
                    s.content,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),

            // Caption
            if (s.caption.isNotEmpty)
              Positioned(
                left: 16,
                right: 16,
                bottom: MediaQuery.of(context).padding.bottom + 48,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    s.caption,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 15),
                  ),
                ),
              ),

            // Top chrome
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 8,
              right: 8,
              child: Column(
                children: [
                  Row(
                    children: List.generate(
                      widget.items.length,
                      (i) => Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: AnimatedBuilder(
                            animation: _prog,
                            builder: (_, __) {
                              double v = 0;
                              if (i < _i) v = 1;
                              if (i == _i) v = _prog.value;
                              return LinearProgressIndicator(
                                value: v,
                                backgroundColor: Colors.white24,
                                color: Colors.white,
                                minHeight: 2,
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: _kPurple,
                        child: Text(
                          s.username.isNotEmpty
                              ? s.username[0].toUpperCase()
                              : '?',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 12),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            VerifiedName(
                              username: s.username,
                              displayName: s.username,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                              badgeSize: 14,
                            ),
                            Text(
                              s.type == 'image'
                                  ? 'Foto'
                                  : s.type == 'video'
                                      ? 'Video'
                                      : s.type == 'voice'
                                          ? 'Suara'
                                          : 'Teks',
                              style: const TextStyle(
                                  color: Colors.white54, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// CALL HISTORY + SESSION UI
// ═══════════════════════════════════════════════════════════════
class _CallEntry {
  final String peer, status;
  final bool isVideo, isOutgoing;
  final DateTime at;

  _CallEntry({
    required this.peer,
    required this.isVideo,
    required this.isOutgoing,
    required this.status,
    required this.at,
  });

  Map<String, dynamic> toJson() => {
        'peer': peer,
        'isVideo': isVideo,
        'isOutgoing': isOutgoing,
        'status': status,
        'at': at.toIso8601String(),
      };

  factory _CallEntry.fromJson(Map<String, dynamic> j) => _CallEntry(
        peer: j['peer']?.toString() ?? '',
        isVideo: j['isVideo'] == true,
        isOutgoing: j['isOutgoing'] == true,
        status: j['status']?.toString() ?? 'outgoing',
        at: DateTime.tryParse(j['at']?.toString() ?? '') ?? DateTime.now(),
      );
}

class _CallHistory {
  static const _key = 'wa_call_history_v1';

  static Future<List<_CallEntry>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final out = <_CallEntry>[];
    for (final s in raw) {
      try {
        out.add(_CallEntry.fromJson(jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {}
    }
    out.sort((a, b) => b.at.compareTo(a.at));
    return out;
  }

  static Future<void> add({
    required String peer,
    required bool isVideo,
    required bool isOutgoing,
    required String status,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final e = _CallEntry(
      peer: peer,
      isVideo: isVideo,
      isOutgoing: isOutgoing,
      status: status,
      at: DateTime.now(),
    );
    raw.insert(0, jsonEncode(e.toJson()));
    while (raw.length > 100) {
      raw.removeLast();
    }
    await prefs.setStringList(_key, raw);
  }
}

class _CallSessionPage extends StatefulWidget {
  final String peer;
  final bool isVideo;
  final bool isOutgoing;

  const _CallSessionPage({
    required this.peer,
    required this.isVideo,
    required this.isOutgoing,
  });

  @override
  State<_CallSessionPage> createState() => _CallSessionPageState();
}

class _CallSessionPageState extends State<_CallSessionPage> {
  bool _muted = false;
  bool _speaker = true;
  bool _camOff = false;
  int _seconds = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _seconds++);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _dur {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            CircleAvatar(
              radius: 48,
              backgroundColor: _kPurple,
              child: Text(
                widget.peer.isNotEmpty ? widget.peer[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontSize: 36),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              widget.peer,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.isVideo ? 'Panggilan video · $_dur' : 'Panggilan suara · $_dur',
              style: TextStyle(color: _kMuted),
            ),
            if (widget.isVideo) ...[
              const SizedBox(height: 24),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Icon(
                      _camOff ? Icons.videocam_off : Icons.person,
                      size: 80,
                      color: Colors.white24,
                    ),
                  ),
                ),
              ),
            ] else
              const Spacer(),
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _callBtn(
                    icon: _muted ? Icons.mic_off : Icons.mic,
                    label: 'Mute',
                    onTap: () => setState(() => _muted = !_muted),
                  ),
                  if (widget.isVideo)
                    _callBtn(
                      icon: _camOff ? Icons.videocam_off : Icons.videocam,
                      label: 'Kamera',
                      onTap: () => setState(() => _camOff = !_camOff),
                    ),
                  _callBtn(
                    icon: _speaker ? Icons.volume_up : Icons.volume_off,
                    label: 'Speaker',
                    onTap: () => setState(() => _speaker = !_speaker),
                  ),
                  _callBtn(
                    icon: Icons.call_end,
                    label: 'Akhiri',
                    color: Colors.red,
                    onTap: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _callBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
  }) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(32),
          child: CircleAvatar(
            radius: 28,
            backgroundColor: color ?? _kPurpleSoft,
            child: Icon(icon, color: Colors.white),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(color: _kMuted, fontSize: 11)),
      ],
    );
  }
}

// CommunityPage tetap di publik_chat.dart — dashboard memakai ChatPage dari file ini.
