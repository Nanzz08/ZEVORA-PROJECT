import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════
//  DYNAMIC COLORS — semua warna app
// ═══════════════════════════════════════════════════════════════
class DynamicColors {
  final Color bg, bgAlt, card, cardSoft;
  final Color ink, inkSoft;
  final Color gold, coral, blue, mint, violet, amber;
  final Color textPrimary, textSecondary, textMuted;

  const DynamicColors({
    required this.bg, required this.bgAlt, required this.card, required this.cardSoft,
    required this.ink, required this.inkSoft,
    required this.gold, required this.coral, required this.blue,
    required this.mint, required this.violet, required this.amber,
    required this.textPrimary, required this.textSecondary, required this.textMuted,
  });

  /// Generate warna berdasarkan seed color
  factory DynamicColors.fromSeed(Color seed) {
    return DynamicColors(
      bg: Color.lerp(seed, Colors.white, 0.92)!,
      bgAlt: Color.lerp(seed, Colors.white, 0.85)!,
      card: Colors.white,
      cardSoft: Color.lerp(seed, Colors.white, 0.96)!,
      ink: const Color(0xFF0E0E14),
      inkSoft: const Color(0xFF2A2A33),
      gold: seed,
      coral: Color.lerp(seed, const Color(0xFFFF1744), 0.45)!,
      blue: Color.lerp(seed, const Color(0xFF4F7DF3), 0.45)!,
      mint: Color.lerp(seed, const Color(0xFF2DCE89), 0.45)!,
      violet: Color.lerp(seed, const Color(0xFF8B5CF6), 0.45)!,
      amber: Color.lerp(seed, const Color(0xFFFF9F45), 0.45)!,
      textPrimary: const Color(0xFF0E0E14),
      textSecondary: const Color(0xFF5B5B66),
      textMuted: const Color(0xFF9A9AA6),
    );
  }

  static const DynamicColors defaultColors = DynamicColors(
    bg: Color(0xFFF5F1E8), bgAlt: Color(0xFFEDE7DA), card: Colors.white, cardSoft: Color(0xFFFFFBF2),
    ink: Color(0xFF0E0E14), inkSoft: Color(0xFF2A2A33),
    gold: Color(0xFFF5B700), coral: Color(0xFFFF5C7C), blue: Color(0xFF4F7DF3),
    mint: Color(0xFF2DCE89), violet: Color(0xFF8B5CF6), amber: Color(0xFFFF9F45),
    textPrimary: Color(0xFF0E0E14), textSecondary: Color(0xFF5B5B66), textMuted: Color(0xFF9A9AA6),
  );
}

// ═══════════════════════════════════════════════════════════════
//  BACKGROUND CONFIG
// ═══════════════════════════════════════════════════════════════
enum BackgroundType { color, photo, video }

class BackgroundConfig {
  final BackgroundType type;
  final Color? color;
  final String? path;

  const BackgroundConfig({required this.type, this.color, this.path});

  static const BackgroundConfig defaultConfig =
      BackgroundConfig(type: BackgroundType.color, color: Color(0xFFF5F1E8));
}

// ═══════════════════════════════════════════════════════════════
//  APP THEME MANAGER — singleton
// ═══════════════════════════════════════════════════════════════
class AppThemeManager extends ChangeNotifier {
  AppThemeManager._();
  static final AppThemeManager instance = AppThemeManager._();

  DynamicColors _colors = DynamicColors.defaultColors;
  BackgroundConfig _background = BackgroundConfig.defaultConfig;

  DynamicColors get colors => _colors;
  BackgroundConfig get background => _background;

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Load seed color
      final seedInt = prefs.getInt('theme_seed');
      if (seedInt != null) _colors = DynamicColors.fromSeed(Color(seedInt));

      // Load background
      final bgType = prefs.getString('bg_type') ?? 'color';
      if (bgType == 'photo' || bgType == 'video') {
        final p = prefs.getString('bg_path');
        if (p != null && File(p).existsSync()) {
          _background = BackgroundConfig(
            type: bgType == 'video' ? BackgroundType.video : BackgroundType.photo,
            path: p,
          );
        }
      } else {
        final colorInt = prefs.getInt('bg_color');
        _background = BackgroundConfig(
          type: BackgroundType.color,
          color: colorInt != null ? Color(colorInt) : const Color(0xFFF5F1E8),
        );
      }
      notifyListeners();
    } catch (_) {}
  }

  /// Ubah seed color → semua warna app ikut berubah
  Future<void> setSeedColor(Color color) async {
    _colors = DynamicColors.fromSeed(color);
    _background = BackgroundConfig(type: BackgroundType.color, color: color);
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_seed', color.value);
    await prefs.setString('bg_type', 'color');
    await prefs.setInt('bg_color', color.value);
  }

  Future<void> setPhotoBackground(String path) async {
    _background = BackgroundConfig(type: BackgroundType.photo, path: path);
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bg_type', 'photo');
    await prefs.setString('bg_path', path);
  }

  Future<void> setVideoBackground(String path) async {
    _background = BackgroundConfig(type: BackgroundType.video, path: path);
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('bg_type', 'video');
    await prefs.setString('bg_path', path);
  }

  Future<void> reset() async {
    _colors = DynamicColors.defaultColors;
    _background = BackgroundConfig.defaultConfig;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('theme_seed');
    await prefs.remove('bg_type');
    await prefs.remove('bg_path');
    await prefs.remove('bg_color');
  }
}