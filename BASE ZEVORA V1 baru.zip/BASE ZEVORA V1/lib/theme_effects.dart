// lib/theme_effects.dart
// Tema Salju (beku + kristal es) & Sakura (bunga di setiap kotak + hujan kelopak)

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════════
//  ENUM TEMA
// ═══════════════════════════════════════════════════════════════
enum FxTheme { none, snow, sakura }

// ═══════════════════════════════════════════════════════════════
//  STORAGE
// ═══════════════════════════════════════════════════════════════
class FxThemeStorage {
  static const _key = 'fx_theme';

  static Future<FxTheme> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(_key) ?? 'none';
    switch (s) {
      case 'snow': return FxTheme.snow;
      case 'sakura': return FxTheme.sakura;
      default: return FxTheme.none;
    }
  }

  static Future<void> save(FxTheme t) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, t.name);
  }
}

// ═══════════════════════════════════════════════════════════════
//  PARTIKEL
// ═══════════════════════════════════════════════════════════════
class _Particle {
  double x, y;
  double size;
  double speed;
  double drift;
  double phase;
  double rot;
  double rotSpeed;
  _Particle({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.drift,
    required this.phase,
    this.rot = 0,
    this.rotSpeed = 0,
  });
}

// ═══════════════════════════════════════════════════════════════
//  OVERLAY — hujan partikel
// ═══════════════════════════════════════════════════════════════
class FxOverlay extends StatefulWidget {
  final FxTheme theme;
  final Widget child;

  const FxOverlay({super.key, required this.theme, required this.child});

  @override
  State<FxOverlay> createState() => _FxOverlayState();
}

class _FxOverlayState extends State<FxOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final List<_Particle> _particles = [];
  final math.Random _rnd = math.Random();
  Size _size = Size.zero;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 16),
    )..addListener(_tick)..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _ensureParticles(Size size) {
    if (size == _size && _particles.isNotEmpty) return;
    _size = size;
    _particles.clear();

    if (widget.theme == FxTheme.none) return;

    final count = widget.theme == FxTheme.snow ? 65 : 40;
    for (int i = 0; i < count; i++) {
      _particles.add(_spawn(size, initial: true));
    }
  }

  _Particle _spawn(Size size, {bool initial = false}) {
    final isSnow = widget.theme == FxTheme.snow;
    return _Particle(
      x: _rnd.nextDouble() * size.width,
      y: initial ? _rnd.nextDouble() * size.height : -20,
      size: isSnow ? 3 + _rnd.nextDouble() * 6 : 10 + _rnd.nextDouble() * 9,
      speed: isSnow ? 0.4 + _rnd.nextDouble() * 0.8 : 0.7 + _rnd.nextDouble() * 1.1,
      drift: isSnow ? -0.3 + _rnd.nextDouble() * 0.6 : -0.9 + _rnd.nextDouble() * 1.8,
      phase: _rnd.nextDouble() * math.pi * 2,
      rot: _rnd.nextDouble() * math.pi * 2,
      rotSpeed: (_rnd.nextDouble() - 0.5) * 0.08,
    );
  }

  void _tick() {
    if (!mounted || _size == Size.zero || widget.theme == FxTheme.none) return;
    setState(() {
      for (int i = 0; i < _particles.length; i++) {
        final p = _particles[i];
        p.phase += 0.02;
        p.y += p.speed;
        p.x += p.drift + math.sin(p.phase) * 0.5;
        p.rot += p.rotSpeed;

        if (p.y > _size.height + 20 || p.x < -30 || p.x > _size.width + 30) {
          _particles[i] = _spawn(_size);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        _ensureParticles(size);

        return Stack(
          children: [
            widget.child,
            if (widget.theme != FxTheme.none)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _FxPainter(
                      particles: _particles,
                      theme: widget.theme,
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  PAINTER
// ═══════════════════════════════════════════════════════════════
class _FxPainter extends CustomPainter {
  final List<_Particle> particles;
  final FxTheme theme;

  _FxPainter({required this.particles, required this.theme});

  @override
  void paint(Canvas canvas, Size size) {
    if (theme == FxTheme.snow) {
      _paintSnow(canvas);
    } else if (theme == FxTheme.sakura) {
      _paintSakura(canvas);
    }
  }

  void _paintSnow(Canvas canvas) {
    for (final p in particles) {
      canvas.drawCircle(
        Offset(p.x, p.y),
        p.size * 1.6,
        Paint()
          ..color = Colors.white.withOpacity(0.15)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
      canvas.drawCircle(
        Offset(p.x, p.y),
        p.size,
        Paint()..color = Colors.white.withOpacity(0.9),
      );
    }
  }

  void _paintSakura(Canvas canvas) {
    for (final p in particles) {
      canvas.save();
      canvas.translate(p.x, p.y);
      canvas.rotate(p.rot);

      final paint = Paint()
        ..color = const Color(0xFFFFB7C5).withOpacity(0.85)
        ..style = PaintingStyle.fill;

      final path = Path();
      final s = p.size;
      for (int i = 0; i < 5; i++) {
        final angle = (i * 72) * math.pi / 180;
        final px = math.cos(angle) * s * 0.5;
        final py = math.sin(angle) * s * 0.5;
        path.addOval(Rect.fromCircle(
          center: Offset(px, py),
          radius: s * 0.4,
        ));
      }
      canvas.drawPath(path, paint);
      canvas.drawCircle(
        Offset.zero,
        s * 0.15,
        Paint()..color = const Color(0xFFFFF0B8),
      );

      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _FxPainter old) => true;
}

// ═══════════════════════════════════════════════════════════════
//  WRAPPER BACKGROUND
// ═══════════════════════════════════════════════════════════════
class ThemedBackground extends StatelessWidget {
  final FxTheme theme;
  final Widget child;

  const ThemedBackground({
    super.key,
    required this.theme,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (theme == FxTheme.snow)
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF0B1B2B), Color(0xFF1B3A54), Color(0xFF0B1B2B)],
                ),
              ),
            ),
          ),
        if (theme == FxTheme.sakura)
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF3A1A2E), Color(0xFF5A2A45), Color(0xFF2A0F1E)],
                ),
              ),
            ),
          ),
        Positioned.fill(
          child: FxOverlay(theme: theme, child: child),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  FROSTED BOX — efek beku untuk kotak (TEMA SALJU)
// ═══════════════════════════════════════════════════════════════
class FrostedBox extends StatelessWidget {
  final Widget child;
  final bool active;
  final double radius;

  const FrostedBox({
    super.key,
    required this.child,
    required this.active,
    this.radius = 14,
  });

  @override
  Widget build(BuildContext context) {
    if (!active) return child;

    return Stack(
      children: [
        Positioned.fill(
          child: IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(
                  color: const Color(0xFFB3E5FC).withOpacity(0.85),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF81D4FA).withOpacity(0.6),
                    blurRadius: 14,
                    spreadRadius: -2,
                  ),
                  BoxShadow(
                    color: const Color(0xFF4FC3F7).withOpacity(0.4),
                    blurRadius: 22,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: CustomPaint(painter: _FrostPainter()),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _FrostPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Corner frost haze
    final hazePaint = Paint();
    final corners = [
      const Offset(0, 0),
      Offset(w, 0),
      Offset(0, h),
      Offset(w, h),
    ];
    for (final c in corners) {
      hazePaint.shader = RadialGradient(
        colors: [
          Colors.white.withOpacity(0.35),
          Colors.white.withOpacity(0.0),
        ],
      ).createShader(Rect.fromCircle(center: c, radius: 55));
      canvas.drawCircle(c, 55, hazePaint);
    }

    // Top frost strip
    final topHaze = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.center,
        colors: [
          Colors.white.withOpacity(0.2),
          Colors.transparent,
        ],
      ).createShader(Rect.fromLTWH(0, 0, w, h * 0.4));
    canvas.drawRect(Rect.fromLTWH(0, 0, w, h * 0.4), topHaze);

    // Ice crystals in corners
    _drawCrystal(canvas, const Offset(16, 16), 11);
    _drawCrystal(canvas, Offset(w - 16, 16), 11);
    _drawCrystal(canvas, Offset(16, h - 16), 9);
    _drawCrystal(canvas, Offset(w - 16, h - 16), 9);

    // Ice dots at edges
    final dotPaint = Paint()..color = Colors.white.withOpacity(0.6);
    for (int i = 0; i < 5; i++) {
      final dx = 24 + i * (w - 48) / 4;
      canvas.drawCircle(Offset(dx, 5), 1.6, dotPaint);
      canvas.drawCircle(Offset(dx, h - 5), 1.6, dotPaint);
    }
  }

  void _drawCrystal(Canvas canvas, Offset center, double size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.85)
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < 3; i++) {
      final angle = i * math.pi / 3;
      canvas.drawLine(
        Offset(
          center.dx - size * math.cos(angle),
          center.dy - size * math.sin(angle),
        ),
        Offset(
          center.dx + size * math.cos(angle),
          center.dy + size * math.sin(angle),
        ),
        paint,
      );
    }

    canvas.drawCircle(center, 2, Paint()..color = Colors.white);

    final branchPaint = Paint()
      ..color = Colors.white.withOpacity(0.7)
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < 6; i++) {
      final angle = i * math.pi / 3;
      final tipX = center.dx + size * math.cos(angle);
      final tipY = center.dy + size * math.sin(angle);
      for (final branchAngle in [-0.65, 0.65]) {
        final bx = tipX + (size * 0.4) * math.cos(angle + branchAngle);
        final by = tipY + (size * 0.4) * math.sin(angle + branchAngle);
        canvas.drawLine(Offset(tipX, tipY), Offset(bx, by), branchPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _FrostPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════
//  SAKURA BOX — efek bunga di SETIAP kotak (TEMA SAKURA)
// ═══════════════════════════════════════════════════════════════
class SakuraBox extends StatelessWidget {
  final Widget child;
  final bool active;
  final double radius;

  const SakuraBox({
    super.key,
    required this.child,
    required this.active,
    this.radius = 14,
  });

  @override
  Widget build(BuildContext context) {
    if (!active) return child;

    return Stack(
      children: [
        Positioned.fill(
          child: IgnorePointer(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                border: Border.all(
                  color: const Color(0xFFFFB7C5).withOpacity(0.9),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFFF8FA8).withOpacity(0.65),
                    blurRadius: 16,
                    spreadRadius: -2,
                  ),
                  BoxShadow(
                    color: const Color(0xFFFF6E8A).withOpacity(0.4),
                    blurRadius: 24,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: CustomPaint(painter: _SakuraPainter()),
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _SakuraPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Pink glow di sudut
    final hazePaint = Paint();
    final corners = [
      const Offset(0, 0),
      Offset(w, 0),
      Offset(0, h),
      Offset(w, h),
    ];
    for (final c in corners) {
      hazePaint.shader = RadialGradient(
        colors: [
          const Color(0xFFFFB7C5).withOpacity(0.4),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: c, radius: 60));
      canvas.drawCircle(c, 60, hazePaint);
    }

    // ── BUNGA BESAR di 4 sudut (5 kelopak) ──
    _drawBigFlower(canvas, const Offset(18, 18), 11);
    _drawBigFlower(canvas, Offset(w - 18, 18), 11);
    _drawBigFlower(canvas, Offset(18, h - 18), 9);
    _drawBigFlower(canvas, Offset(w - 18, h - 18), 9);

    // ── KELOPAK KECIL di tepi atas & bawah (row of petals) ──
    for (int i = 0; i < 4; i++) {
      final dx = 50 + i * (w - 100) / 3;
      _drawPetal(canvas, Offset(dx, 8), 5, 0.6);
      _drawPetal(canvas, Offset(dx, h - 8), 5, 0.6);
    }

    // ── KELOPAK di tengah kiri & kanan ──
    if (h > 100) {
      _drawPetal(canvas, Offset(8, h / 2), 6, 0.5);
      _drawPetal(canvas, Offset(w - 8, h / 2), 6, 0.5);
    }

    // ── Kelopak terbang di dalam kotak (subtle) ──
    _drawPetal(canvas, Offset(w * 0.3, h * 0.4), 4, 0.35);
    _drawPetal(canvas, Offset(w * 0.7, h * 0.6), 4, 0.35);
  }

  void _drawBigFlower(Canvas canvas, Offset center, double size) {
    final petalPaint = Paint()
      ..color = const Color(0xFFFF8FA8).withOpacity(0.85)
      ..style = PaintingStyle.fill;

    final petalOutline = Paint()
      ..color = const Color(0xFFFFE0E8).withOpacity(0.95)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    // 5 kelopak bunga sakura
    for (int i = 0; i < 5; i++) {
      final angle = (i * 72 - 90) * math.pi / 180;
      final px = center.dx + math.cos(angle) * size * 0.55;
      final py = center.dy + math.sin(angle) * size * 0.55;

      // Tiap kelopak = oval dengan lekukan di ujung
      final rect = Rect.fromCenter(
        center: Offset(px, py),
        width: size * 0.85,
        height: size * 0.7,
      );

      canvas.save();
      canvas.translate(px, py);
      canvas.rotate(angle + math.pi / 2);
      canvas.translate(-px, -py);

      final path = Path()
        ..addOval(rect);
      canvas.drawPath(path, petalPaint);
      canvas.drawPath(path, petalOutline);

      canvas.restore();
    }

    // Pusat bunga (kuning)
    canvas.drawCircle(
      center,
      size * 0.28,
      Paint()..color = const Color(0xFFFFF0B8),
    );
    canvas.drawCircle(
      center,
      size * 0.15,
      Paint()..color = const Color(0xFFFFD54F),
    );
  }

  void _drawPetal(Canvas canvas, Offset center, double size, double opacity) {
    final paint = Paint()
      ..color = const Color(0xFFFFB7C5).withOpacity(opacity)
      ..style = PaintingStyle.fill;

    final path = Path();
    for (int i = 0; i < 5; i++) {
      final angle = (i * 72) * math.pi / 180;
      final px = center.dx + math.cos(angle) * size * 0.5;
      final py = center.dy + math.sin(angle) * size * 0.5;
      path.addOval(Rect.fromCircle(
        center: Offset(px, py),
        radius: size * 0.42,
      ));
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SakuraPainter old) => false;
}