import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

/// Berita & New Updates — terhubung ke Google News (RSS Indonesia).
class NewsPage extends StatefulWidget {
  const NewsPage({super.key});

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final Color _bg = const Color(0xFF050505);
  final Color _red = const Color(0xFFE11D48);
  final Color _card = const Color(0xFF0E0E0E);
  final Color _textSub = const Color(0xFF9A7A80);

  final List<_NewsCategory> _categories = const [
    _NewsCategory('Top', 'https://news.google.com/rss?hl=id&gl=ID&ceid=ID:id'),
    _NewsCategory(
        'Teknologi',
        'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=id&gl=ID&ceid=ID:id'),
    _NewsCategory(
        'Bisnis',
        'https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=id&gl=ID&ceid=ID:id'),
    _NewsCategory(
        'Olahraga',
        'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=id&gl=ID&ceid=ID:id'),
    _NewsCategory(
        'Hiburan',
        'https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=id&gl=ID&ceid=ID:id'),
    _NewsCategory(
        'Sains',
        'https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=id&gl=ID&ceid=ID:id'),
  ];

  final Map<int, List<_NewsItem>> _cache = {};
  final Map<int, bool> _loading = {};
  final Map<int, String?> _errors = {};

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: _categories.length, vsync: this);
    _tabCtrl.addListener(() {
      if (!_tabCtrl.indexIsChanging) _load(_tabCtrl.index);
    });
    _load(0);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load(int index, {bool force = false}) async {
    if (!force && _cache.containsKey(index) && _cache[index]!.isNotEmpty) return;
    setState(() {
      _loading[index] = true;
      _errors[index] = null;
    });
    try {
      final url = _categories[index].rssUrl;
      final res = await http.get(
        Uri.parse(url),
        headers: {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36',
          'Accept': 'application/rss+xml, application/xml, text/xml, */*',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        throw Exception('HTTP ${res.statusCode}');
      }

      final items = _parseRss(res.body);
      if (!mounted) return;
      setState(() {
        _cache[index] = items;
        _loading[index] = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading[index] = false;
        _errors[index] = 'Gagal memuat berita: $e';
      });
    }
  }

  List<_NewsItem> _parseRss(String xml) {
    final items = <_NewsItem>[];
    // Parse item blocks
    final itemRegex = RegExp(r'<item>([\s\S]*?)</item>', multiLine: true);
    for (final m in itemRegex.allMatches(xml)) {
      final block = m.group(1) ?? '';
      final title = _tag(block, 'title');
      final link = _tag(block, 'link');
      final pub = _tag(block, 'pubDate');
      final source = _tag(block, 'source');
      final desc = _stripHtml(_tag(block, 'description'));
      if (title.isEmpty) continue;
      items.add(_NewsItem(
        title: _decodeXml(title),
        link: link,
        pubDate: pub,
        source: source.isNotEmpty ? _decodeXml(source) : 'Google News',
        description: _decodeXml(desc),
      ));
      if (items.length >= 40) break;
    }
    return items;
  }

  String _tag(String block, String name) {
    final m = RegExp(
      '<$name(?:\\s[^>]*)?>([\\s\\S]*?)</$name>',
      multiLine: true,
    ).firstMatch(block);
    if (m != null) return m.group(1)?.trim() ?? '';
    // self-closing or CDATA
    final cdata = RegExp(
      '<$name(?:\\s[^>]*)?><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></$name>',
      multiLine: true,
    ).firstMatch(block);
    return cdata?.group(1)?.trim() ?? '';
  }

  String _stripHtml(String s) {
    return s
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  String _decodeXml(String s) {
    return s
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'")
        .replaceAll(RegExp(r'<!\[CDATA\['), '')
        .replaceAll(']]>', '');
  }

  Future<void> _open(String url) async {
    if (url.isEmpty) return;
    final u = Uri.tryParse(url);
    if (u == null) return;
    if (await canLaunchUrl(u)) {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    }
  }

  String _formatDate(String raw) {
    if (raw.isEmpty) return '';
    try {
      final dt = DateTime.tryParse(raw);
      if (dt != null) {
        final local = dt.toLocal();
        return '${local.day.toString().padLeft(2, '0')}/'
            '${local.month.toString().padLeft(2, '0')}/'
            '${local.year} '
            '${local.hour.toString().padLeft(2, '0')}:'
            '${local.minute.toString().padLeft(2, '0')}';
      }
    } catch (_) {}
    // RSS often: "Wed, 08 Oct 2026 01:00:00 GMT"
    return raw.length > 22 ? raw.substring(0, 22) : raw;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'BERITA & UPDATES',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: _red),
            onPressed: () => _load(_tabCtrl.index, force: true),
          ),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          isScrollable: true,
          labelColor: _red,
          unselectedLabelColor: _textSub,
          indicatorColor: _red,
          labelStyle: const TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
          tabs: _categories.map((c) => Tab(text: c.name)).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: List.generate(_categories.length, (i) => _buildList(i)),
      ),
    );
  }

  Widget _buildList(int index) {
    final loading = _loading[index] == true;
    final err = _errors[index];
    final items = _cache[index] ?? [];

    if (loading && items.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: _red, strokeWidth: 2.5),
            const SizedBox(height: 16),
            Text(
              'Memuat berita Google News...',
              style: TextStyle(color: _textSub, fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      );
    }

    if (err != null && items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded, color: _red, size: 48),
              const SizedBox(height: 12),
              Text(
                err,
                textAlign: TextAlign.center,
                style: TextStyle(color: _textSub, fontFamily: 'ShareTechMono'),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => _load(index, force: true),
                style: ElevatedButton.styleFrom(backgroundColor: _red),
                child: const Text('Coba Lagi'),
              ),
            ],
          ),
        ),
      );
    }

    if (items.isEmpty) {
      return Center(
        child: Text(
          'Tidak ada berita',
          style: TextStyle(color: _textSub, fontFamily: 'ShareTechMono'),
        ),
      );
    }

    return RefreshIndicator(
      color: _red,
      backgroundColor: _card,
      onRefresh: () => _load(index, force: true),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
        itemCount: items.length,
        itemBuilder: (_, i) {
          final n = items[i];
          return GestureDetector(
            onTap: () => _open(n.link),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _red.withOpacity(0.2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _red.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          n.source,
                          style: TextStyle(
                            color: _red,
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const Spacer(),
                      if (n.pubDate.isNotEmpty)
                        Text(
                          _formatDate(n.pubDate),
                          style: TextStyle(
                            color: _textSub.withOpacity(0.8),
                            fontSize: 10,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    n.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      height: 1.35,
                    ),
                  ),
                  if (n.description.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      n.description.length > 140
                          ? '${n.description.substring(0, 140)}…'
                          : n.description,
                      style: TextStyle(
                        color: _textSub,
                        fontSize: 12,
                        height: 1.4,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.open_in_new_rounded,
                          size: 12, color: _red.withOpacity(0.8)),
                      const SizedBox(width: 4),
                      Text(
                        'Baca di Google News',
                        style: TextStyle(
                          color: _red.withOpacity(0.9),
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _NewsCategory {
  final String name;
  final String rssUrl;
  const _NewsCategory(this.name, this.rssUrl);
}

class _NewsItem {
  final String title;
  final String link;
  final String pubDate;
  final String source;
  final String description;
  const _NewsItem({
    required this.title,
    required this.link,
    required this.pubDate,
    required this.source,
    required this.description,
  });
}
