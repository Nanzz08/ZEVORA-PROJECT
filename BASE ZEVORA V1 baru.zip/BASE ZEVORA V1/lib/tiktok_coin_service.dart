import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Saldo koin TikTok + pembayaran dari tabungan.
class TiktokCoinService {
  static String _coinKey(String username) => 'tt_coins_$username';
  static String _tabunganSaldoKey(String username) => 'tabungan_${username}_saldo';
  static String _tabunganKeluarKey(String username) => 'tabungan_${username}_keluar';
  static String _tabunganTxKey(String username) => 'tabungan_${username}_tx';

  static Future<int> getCoins(String username) async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_coinKey(username)) ?? 0;
  }

  static Future<void> setCoins(String username, int coins) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_coinKey(username), coins < 0 ? 0 : coins);
  }

  static Future<double> getTabunganSaldo(String username) async {
    final p = await SharedPreferences.getInstance();
    return p.getDouble(_tabunganSaldoKey(username)) ?? 0.0;
  }

  /// Paket beli koin (mirip screenshot).
  static const packages = <CoinPackage>[
    CoinPackage(coins: 5, price: 1000),
    CoinPackage(coins: 10, price: 3000),
    CoinPackage(coins: 25, price: 5000),
    CoinPackage(coins: 50, price: 9000),
    CoinPackage(coins: 100, price: 15000),
    CoinPackage(coins: 250, price: 30000),
    CoinPackage(coins: 500, price: 50000),
  ];

  /// Gift list (mirip screenshot live).
  static const gifts = <LiveGift>[
    LiveGift(id: 'rose', name: 'Rose', emoji: '🌹', cost: 1),
    LiveGift(id: 'love', name: 'Love', emoji: '❤️', cost: 3),
    LiveGift(id: 'fire', name: 'Fire', emoji: '🔥', cost: 5),
    LiveGift(id: 'diamond', name: 'Diamond', emoji: '💎', cost: 20),
    LiveGift(id: 'rocket', name: 'Rocket', emoji: '🚀', cost: 50),
  ];

  /// Beli koin pakai saldo tabungan saja.
  /// Return null jika sukses, atau pesan error.
  static Future<String?> buyWithTabungan({
    required String username,
    required CoinPackage pkg,
  }) async {
    final p = await SharedPreferences.getInstance();
    final saldo = p.getDouble(_tabunganSaldoKey(username)) ?? 0.0;
    if (saldo < pkg.price) {
      return 'Saldo tabungan tidak cukup.\nSaldo: Rp${_fmt(saldo)}\nHarga: Rp${_fmt(pkg.price)}';
    }

    final newSaldo = saldo - pkg.price;
    final keluar = (p.getDouble(_tabunganKeluarKey(username)) ?? 0.0) + pkg.price;
    await p.setDouble(_tabunganSaldoKey(username), newSaldo);
    await p.setDouble(_tabunganKeluarKey(username), keluar);

    // Catat transaksi tabungan
    final raw = p.getStringList(_tabunganTxKey(username)) ?? [];
    final tx = {
      'id': 'koin_${DateTime.now().millisecondsSinceEpoch}',
      'type': 'keluar',
      'amount': pkg.price,
      'note': 'Beli ${pkg.coins} Koin TikTok',
      'at': DateTime.now().toIso8601String(),
    };
    raw.insert(0, jsonEncode(tx));
    await p.setStringList(_tabunganTxKey(username), raw.take(100).toList());

    final coins = (p.getInt(_coinKey(username)) ?? 0) + pkg.coins;
    await p.setInt(_coinKey(username), coins);
    return null;
  }

  static Future<String?> spendCoins({
    required String username,
    required int cost,
  }) async {
    final coins = await getCoins(username);
    if (coins < cost) {
      return 'Koin tidak cukup. Saldo: $coins, butuh: $cost';
    }
    await setCoins(username, coins - cost);
    return null;
  }

  static String _fmt(double n) {
    final s = n.toStringAsFixed(0);
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}

class CoinPackage {
  final int coins;
  final double price;
  const CoinPackage({required this.coins, required this.price});
}

class LiveGift {
  final String id, name, emoji;
  final int cost;
  const LiveGift({
    required this.id,
    required this.name,
    required this.emoji,
    required this.cost,
  });
}

/// Live session store (lokal, shared antar user di device yang sama).
class TiktokLiveService {
  static const _livesKey = 'tt_lives_v1';
  static const _giftsPrefix = 'tt_live_gifts_';

  static Future<List<LiveSession>> activeLives() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_livesKey) ?? [];
    final list = <LiveSession>[];
    final now = DateTime.now();
    for (final s in raw) {
      try {
        final live = LiveSession.fromJson(jsonDecode(s) as Map<String, dynamic>);
        // Auto-expire lives > 6 jam
        if (live.active && now.difference(live.startedAt).inHours < 6) {
          list.add(live);
        }
      } catch (_) {}
    }
    list.sort((a, b) => b.startedAt.compareTo(a.startedAt));
    return list;
  }

  static Future<void> _saveAll(List<LiveSession> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      _livesKey,
      list.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  static Future<LiveSession> startLive({
    required String username,
    String title = '',
  }) async {
    final list = await activeLives();
    // Hentikan live user yang sama jika masih ada
    list.removeWhere((e) => e.username == username);
    final live = LiveSession(
      id: 'live_${username}_${DateTime.now().millisecondsSinceEpoch}',
      username: username,
      title: title.isEmpty ? 'LIVE @$username' : title,
      startedAt: DateTime.now(),
      viewers: 0,
      active: true,
    );
    list.insert(0, live);
    await _saveAll(list);
    return live;
  }

  static Future<void> endLive(String liveId) async {
    final list = await activeLives();
    final i = list.indexWhere((e) => e.id == liveId);
    if (i >= 0) {
      list[i] = list[i].copyWith(active: false);
      await _saveAll(list.where((e) => e.active).toList());
    }
    final p = await SharedPreferences.getInstance();
    await p.remove('$_giftsPrefix$liveId');
  }

  static Future<void> bumpViewers(String liveId, int delta) async {
    final list = await activeLives();
    final i = list.indexWhere((e) => e.id == liveId);
    if (i >= 0) {
      final v = (list[i].viewers + delta).clamp(0, 999999);
      list[i] = list[i].copyWith(viewers: v);
      await _saveAll(list);
    }
  }

  static Future<List<LiveGiftEvent>> giftsFor(String liveId) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('$_giftsPrefix$liveId') ?? [];
    final out = <LiveGiftEvent>[];
    for (final s in raw) {
      try {
        out.add(LiveGiftEvent.fromJson(jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {}
    }
    return out;
  }

  static Future<void> addGift(LiveGiftEvent event) async {
    final p = await SharedPreferences.getInstance();
    final key = '$_giftsPrefix${event.liveId}';
    final raw = p.getStringList(key) ?? [];
    raw.add(jsonEncode(event.toJson()));
    await p.setStringList(key, raw.take(200).toList());
  }
}

class LiveSession {
  final String id, username, title;
  final DateTime startedAt;
  final int viewers;
  final bool active;

  LiveSession({
    required this.id,
    required this.username,
    required this.title,
    required this.startedAt,
    required this.viewers,
    required this.active,
  });

  LiveSession copyWith({int? viewers, bool? active, String? title}) =>
      LiveSession(
        id: id,
        username: username,
        title: title ?? this.title,
        startedAt: startedAt,
        viewers: viewers ?? this.viewers,
        active: active ?? this.active,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'title': title,
        'startedAt': startedAt.toIso8601String(),
        'viewers': viewers,
        'active': active,
      };

  factory LiveSession.fromJson(Map<String, dynamic> j) => LiveSession(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        title: j['title']?.toString() ?? '',
        startedAt: DateTime.tryParse(j['startedAt']?.toString() ?? '') ??
            DateTime.now(),
        viewers: (j['viewers'] is num) ? (j['viewers'] as num).toInt() : 0,
        active: j['active'] == true,
      );
}

class LiveGiftEvent {
  final String liveId, fromUser, giftId, giftName, emoji;
  final int cost;
  final DateTime at;

  LiveGiftEvent({
    required this.liveId,
    required this.fromUser,
    required this.giftId,
    required this.giftName,
    required this.emoji,
    required this.cost,
    required this.at,
  });

  Map<String, dynamic> toJson() => {
        'liveId': liveId,
        'fromUser': fromUser,
        'giftId': giftId,
        'giftName': giftName,
        'emoji': emoji,
        'cost': cost,
        'at': at.toIso8601String(),
      };

  factory LiveGiftEvent.fromJson(Map<String, dynamic> j) => LiveGiftEvent(
        liveId: j['liveId']?.toString() ?? '',
        fromUser: j['fromUser']?.toString() ?? '',
        giftId: j['giftId']?.toString() ?? '',
        giftName: j['giftName']?.toString() ?? '',
        emoji: j['emoji']?.toString() ?? '🎁',
        cost: (j['cost'] is num) ? (j['cost'] as num).toInt() : 0,
        at: DateTime.tryParse(j['at']?.toString() ?? '') ?? DateTime.now(),
      );
}
