import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:fiona/Qaxer/api.dart';

final _baseUrl = Api.api;

/// Get Link GB — scan group dari nomor sender (nokos) lalu ambil invite link.
class GetLinkGbPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const GetLinkGbPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<GetLinkGbPage> createState() => _GetLinkGbPageState();
}

class _GetLinkGbPageState extends State<GetLinkGbPage> {
  static const _bg = Color(0xFF080808);
  static const _card = Color(0xFF121212);
  static const _border = Color(0xFF4A1A1A);
  static const _red = Color(0xFFE11D48);
  static const _redBright = Color(0xFFFF2D55);
  static const _text = Color(0xFFF9E2E2);
  static const _textSub = Color(0xFFBF7A7A);
  static const _green = Color(0xFF22C55E);

  // Step: 0 = pilih sender, 1 = pilih group, 2 = hasil link
  int _step = 0;

  bool _loadingSenders = true;
  bool _loadingGroups = false;
  bool _loadingLinks = false;
  String? _error;

  List<Map<String, dynamic>> _senders = [];
  Map<String, dynamic>? _selectedSender;

  List<_GroupItem> _groups = [];
  final Set<String> _selectedGroupIds = {};

  List<_LinkResult> _results = [];

  @override
  void initState() {
    super.initState();
    _loadSenders();
  }

  String _senderId(Map<String, dynamic> s) =>
      (s['id'] ?? s['sessionId'] ?? s['sessionName'] ?? '').toString();

  String _senderLabel(Map<String, dynamic> s) {
    final name = (s['sessionName'] ?? s['number'] ?? s['phone'] ?? s['id'] ?? 'Sender')
        .toString();
    final mode = (s['senderMode'] ?? s['scope'] ?? s['type'] ?? '').toString();
    if (mode.toLowerCase() == 'global') return '$name · GLOBAL';
    return name;
  }

  Future<void> _loadSenders() async {
    setState(() {
      _loadingSenders = true;
      _error = null;
    });
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/mySender?key=${widget.sessionKey}'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        setState(() => _error = 'Server error: ${res.statusCode}');
        return;
      }
      final data = jsonDecode(res.body);
      if (data['valid'] != true) {
        setState(() => _error = data['message']?.toString() ?? 'Gagal ambil sender');
        return;
      }
      final list = (data['connections'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      setState(() {
        _senders = list;
        if (list.length == 1) {
          _selectedSender = list.first;
        }
      });
      // Jika hanya 1 sender, langsung lanjut scan group
      if (list.length == 1) {
        await _scanGroups(list.first);
      }
    } catch (e) {
      setState(() => _error = 'Koneksi gagal: $e');
    } finally {
      if (mounted) setState(() => _loadingSenders = false);
    }
  }

  Future<void> _scanGroups(Map<String, dynamic> sender) async {
    setState(() {
      _selectedSender = sender;
      _loadingGroups = true;
      _error = null;
      _groups = [];
      _selectedGroupIds.clear();
      _step = 1;
    });

    final id = _senderId(sender);
    final endpoints = [
      '$_baseUrl/getGroups?key=${widget.sessionKey}&id=$id',
      '$_baseUrl/listGroups?key=${widget.sessionKey}&id=$id',
      '$_baseUrl/getGroups?key=${widget.sessionKey}&senderId=$id',
      '$_baseUrl/groups?key=${widget.sessionKey}&id=$id',
      '$_baseUrl/myGroups?key=${widget.sessionKey}&id=$id',
      '$_baseUrl/getGroupList?key=${widget.sessionKey}&id=$id',
    ];

    String? lastErr;
    for (final url in endpoints) {
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          final res = await http
              .get(Uri.parse(url), headers: {'Content-Type': 'application/json'})
              .timeout(const Duration(seconds: 20));
          if (res.statusCode == 429) {
            lastErr = 'HTTP 429 — rate limit, mencoba lagi...';
            await Future.delayed(Duration(milliseconds: 900 * (attempt + 1)));
            continue;
          }
          if (res.statusCode != 200) {
            lastErr = 'HTTP ${res.statusCode}';
            break;
          }
          final data = jsonDecode(res.body);
          final parsed = _parseGroups(data);
          if (parsed.isNotEmpty) {
            setState(() {
              _groups = parsed;
              _loadingGroups = false;
            });
            return;
          }
          if (data is Map && data['valid'] == false) {
            lastErr = data['message']?.toString() ?? 'Tidak ada group';
          } else {
            lastErr = 'Respon tidak berisi group';
          }
          break;
        } catch (e) {
          lastErr = e.toString();
          if (attempt < 2) {
            await Future.delayed(Duration(milliseconds: 500 * (attempt + 1)));
          }
        }
      }
    }

    setState(() {
      _loadingGroups = false;
      _error = lastErr ??
          'Tidak bisa mengambil daftar group. Pastikan sender online & API getGroups tersedia di server.';
    });
  }

  List<_GroupItem> _parseGroups(dynamic data) {
    List list = [];
    if (data is List) {
      list = data;
    } else if (data is Map) {
      for (final key in [
        'groups',
        'data',
        'list',
        'chats',
        'result',
        'items',
      ]) {
        if (data[key] is List) {
          list = data[key] as List;
          break;
        }
      }
    }
    final out = <_GroupItem>[];
    for (final raw in list) {
      if (raw is! Map) continue;
      final m = Map<String, dynamic>.from(raw);
      final id = (m['id'] ??
              m['jid'] ??
              m['groupId'] ??
              m['gid'] ??
              m['_id'] ??
              '')
          .toString();
      if (id.isEmpty) continue;
      // Skip non-group if flagged
      final isGroup = m['isGroup'] ?? m['group'] ?? true;
      if (isGroup == false) continue;
      final name = (m['subject'] ??
              m['name'] ??
              m['groupName'] ??
              m['title'] ??
              id)
          .toString();
      final participants = m['participants'] ??
          m['size'] ??
          m['memberCount'] ??
          m['members'];
      int? count;
      if (participants is int) {
        count = participants;
      } else if (participants is List) {
        count = participants.length;
      } else if (participants != null) {
        count = int.tryParse(participants.toString());
      }
      out.add(_GroupItem(id: id, name: name, memberCount: count));
    }
    return out;
  }

  Future<void> _getLinks() async {
    if (_selectedSender == null || _selectedGroupIds.isEmpty) return;
    setState(() {
      _loadingLinks = true;
      _error = null;
      _results = [];
      _step = 2;
    });

    final senderId = _senderId(_selectedSender!);
    final results = <_LinkResult>[];

    for (var i = 0; i < _selectedGroupIds.length; i++) {
      final gid = _selectedGroupIds.elementAt(i);
      final g = _groups.firstWhere((e) => e.id == gid, orElse: () => _GroupItem(id: gid, name: gid));
      final link = await _fetchInviteLink(senderId, gid);
      results.add(_LinkResult(
        groupId: gid,
        groupName: g.name,
        link: link,
        ok: link != null && link.startsWith('http'),
      ));
      if (mounted) setState(() => _results = List.from(results));
      // Jeda antar group agar tidak kena rate-limit 429
      if (i < _selectedGroupIds.length - 1) {
        await Future.delayed(const Duration(milliseconds: 600));
      }
    }

    if (mounted) setState(() => _loadingLinks = false);
  }

  Future<String?> _fetchInviteLink(String senderId, String groupId) async {
    final encodedGid = Uri.encodeComponent(groupId);
    final endpoints = [
      '$_baseUrl/getInviteCode?key=${widget.sessionKey}&id=$senderId&jid=$encodedGid',
      '$_baseUrl/getGroupInvite?key=${widget.sessionKey}&id=$senderId&groupId=$encodedGid',
      '$_baseUrl/groupInvite?key=${widget.sessionKey}&id=$senderId&jid=$encodedGid',
      '$_baseUrl/getGroupLink?key=${widget.sessionKey}&id=$senderId&groupId=$encodedGid',
      '$_baseUrl/inviteCode?key=${widget.sessionKey}&id=$senderId&jid=$encodedGid',
      '$_baseUrl/getInviteCode?key=${widget.sessionKey}&senderId=$senderId&groupId=$encodedGid',
    ];

    for (final url in endpoints) {
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          final res = await http
              .get(Uri.parse(url), headers: {'Content-Type': 'application/json'})
              .timeout(const Duration(seconds: 18));
          // Rate limit (429): tunggu lalu coba lagi
          if (res.statusCode == 429) {
            await Future.delayed(Duration(milliseconds: 800 * (attempt + 1)));
            continue;
          }
          if (res.statusCode != 200) break;
          final data = jsonDecode(res.body);
          final link = _extractLink(data);
          if (link != null) return link;
          break;
        } catch (_) {
          if (attempt < 2) {
            await Future.delayed(Duration(milliseconds: 500 * (attempt + 1)));
          }
        }
      }
    }

    // POST fallback dengan retry 429
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final res = await http
            .post(
              Uri.parse('$_baseUrl/getGroupLink'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'key': widget.sessionKey,
                'id': senderId,
                'groupId': groupId,
                'jid': groupId,
              }),
            )
            .timeout(const Duration(seconds: 18));
        if (res.statusCode == 429) {
          await Future.delayed(Duration(milliseconds: 800 * (attempt + 1)));
          continue;
        }
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final link = _extractLink(data);
          if (link != null) return link;
        }
        break;
      } catch (_) {
        if (attempt < 2) {
          await Future.delayed(Duration(milliseconds: 500 * (attempt + 1)));
        }
      }
    }

    return null;
  }

  String? _extractLink(dynamic data) {
    if (data == null) return null;
    if (data is String) {
      final s = data.trim();
      if (s.contains('chat.whatsapp.com')) {
        return s.startsWith('http') ? s : 'https://chat.whatsapp.com/$s';
      }
      if (RegExp(r'^[A-Za-z0-9_-]{10,}$').hasMatch(s)) {
        return 'https://chat.whatsapp.com/$s';
      }
      return null;
    }
    if (data is Map) {
      for (final key in [
        'link',
        'invite',
        'inviteLink',
        'groupLink',
        'url',
        'code',
        'inviteCode',
        'data',
        'result',
      ]) {
        final v = data[key];
        final link = _extractLink(v);
        if (link != null) return link;
      }
    }
    return null;
  }

  void _toggleGroup(String id) {
    setState(() {
      if (_selectedGroupIds.contains(id)) {
        _selectedGroupIds.remove(id);
      } else {
        _selectedGroupIds.add(id);
      }
    });
  }

  void _selectAllGroups() {
    setState(() {
      if (_selectedGroupIds.length == _groups.length) {
        _selectedGroupIds.clear();
      } else {
        _selectedGroupIds
          ..clear()
          ..addAll(_groups.map((e) => e.id));
      }
    });
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Disalin ke clipboard'),
        backgroundColor: _red.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  void _copyAllOk() {
    final lines = _results
        .where((r) => r.ok && r.link != null)
        .map((r) => '${r.groupName}\n${r.link}')
        .join('\n\n');
    if (lines.isEmpty) return;
    _copy(lines);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        title: const Text(
          'Get Link GB',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            letterSpacing: 1,
            fontSize: 16,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loadingSenders || _loadingGroups
                ? null
                : () {
                    if (_step == 0) {
                      _loadSenders();
                    } else if (_selectedSender != null) {
                      _scanGroups(_selectedSender!);
                    }
                  },
          ),
        ],
      ),
      body: Column(
        children: [
          _buildStepper(),
          Expanded(child: _buildBody()),
          _buildBottomBar(),
        ],
      ),
    );
  }

  Widget _buildStepper() {
    Widget chip(int i, String label) {
      final active = _step == i;
      final done = _step > i;
      return Expanded(
        child: Column(
          children: [
            Container(
              height: 3,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: done || active ? _red : Colors.white12,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: active ? _redBright : (done ? _text : _textSub),
                fontSize: 11,
                fontWeight: active ? FontWeight.w800 : FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Row(
        children: [
          chip(0, '1. Sender'),
          chip(1, '2. Group'),
          chip(2, '3. Link'),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loadingSenders) {
      return const Center(
        child: CircularProgressIndicator(color: _red),
      );
    }
    if (_error != null && _senders.isEmpty && _step == 0) {
      return _errorView(_error!, onRetry: _loadSenders);
    }

    switch (_step) {
      case 0:
        return _buildSenderStep();
      case 1:
        return _buildGroupStep();
      case 2:
        return _buildResultStep();
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _errorView(String msg, {VoidCallback? onRetry}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, color: _redBright, size: 42),
            const SizedBox(height: 12),
            Text(
              msg,
              textAlign: TextAlign.center,
              style: const TextStyle(color: _textSub, fontSize: 13, height: 1.4),
            ),
            if (onRetry != null) ...[
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Coba lagi'),
                style: TextButton.styleFrom(foregroundColor: _redBright),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSenderStep() {
    if (_senders.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.phone_android_rounded, color: _textSub, size: 48),
              const SizedBox(height: 12),
              const Text(
                'Belum ada sender / nokos.\nTambah sender dulu di Manage Sender.',
                textAlign: TextAlign.center,
                style: TextStyle(color: _textSub, height: 1.45),
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      children: [
        const Text(
          'Pilih nomor sender (nokos)',
          style: TextStyle(
            color: _text,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'Group akan di-scan otomatis dari nomor yang dipilih.',
          style: TextStyle(color: _textSub.withOpacity(0.9), fontSize: 12),
        ),
        const SizedBox(height: 14),
        ..._senders.map((s) {
          final id = _senderId(s);
          final selected = _selectedSender != null && _senderId(_selectedSender!) == id;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Material(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => _selectedSender = s),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: selected ? _red : _border,
                      width: selected ? 1.5 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _red.withOpacity(0.15),
                          border: Border.all(color: _red.withOpacity(0.4)),
                        ),
                        child: const Icon(Icons.smartphone_rounded,
                            color: _redBright, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _senderLabel(s),
                              style: const TextStyle(
                                color: _text,
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              'ID: $id',
                              style: TextStyle(
                                color: _textSub.withOpacity(0.85),
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        selected
                            ? Icons.radio_button_checked
                            : Icons.radio_button_off,
                        color: selected ? _redBright : _textSub,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildGroupStep() {
    if (_loadingGroups) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: _red),
            const SizedBox(height: 16),
            Text(
              'Memindai group di ${_senderLabel(_selectedSender ?? {})}...',
              style: const TextStyle(color: _textSub, fontSize: 13),
            ),
          ],
        ),
      );
    }
    if (_error != null && _groups.isEmpty) {
      return _errorView(
        _error!,
        onRetry: () {
          if (_selectedSender != null) _scanGroups(_selectedSender!);
        },
      );
    }
    if (_groups.isEmpty) {
      return _errorView(
        'Tidak ada group di nomor ini.',
        onRetry: () {
          if (_selectedSender != null) _scanGroups(_selectedSender!);
        },
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '${_groups.length} group · ${_selectedGroupIds.length} dipilih',
                  style: const TextStyle(
                    color: _text,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
              TextButton(
                onPressed: _selectAllGroups,
                style: TextButton.styleFrom(foregroundColor: _redBright),
                child: Text(
                  _selectedGroupIds.length == _groups.length
                      ? 'Batal semua'
                      : 'Pilih semua',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
            itemCount: _groups.length,
            itemBuilder: (_, i) {
              final g = _groups[i];
              final sel = _selectedGroupIds.contains(g.id);
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: _card,
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => _toggleGroup(g.id),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: sel ? _red : _border,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            sel
                                ? Icons.check_box_rounded
                                : Icons.check_box_outline_blank_rounded,
                            color: sel ? _redBright : _textSub,
                            size: 22,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  g.name,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: _text,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  g.memberCount != null
                                      ? '${g.memberCount} anggota · ${g.id}'
                                      : g.id,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: _textSub.withOpacity(0.85),
                                    fontSize: 10,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildResultStep() {
    if (_loadingLinks && _results.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: _red),
            SizedBox(height: 14),
            Text('Mengambil invite link...',
                style: TextStyle(color: _textSub, fontSize: 13)),
          ],
        ),
      );
    }

    final okCount = _results.where((r) => r.ok).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '$okCount / ${_results.length} link berhasil',
                style: const TextStyle(
                  color: _text,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
            if (okCount > 0)
              TextButton.icon(
                onPressed: _copyAllOk,
                icon: const Icon(Icons.copy_all_rounded, size: 16),
                label: const Text('Salin semua'),
                style: TextButton.styleFrom(foregroundColor: _redBright),
              ),
          ],
        ),
        if (_loadingLinks)
          const Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: LinearProgressIndicator(
              color: _red,
              backgroundColor: Colors.white12,
            ),
          ),
        ..._results.map((r) {
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: r.ok ? _green.withOpacity(0.45) : _border,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      r.ok ? Icons.check_circle : Icons.cancel,
                      size: 16,
                      color: r.ok ? _green : _redBright,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        r.groupName,
                        style: const TextStyle(
                          color: _text,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    if (r.ok)
                      IconButton(
                        icon: const Icon(Icons.copy_rounded, size: 18),
                        color: _redBright,
                        onPressed: () => _copy(r.link!),
                        visualDensity: VisualDensity.compact,
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                SelectableText(
                  r.ok ? r.link! : 'Gagal mengambil link (sender offline / bukan admin / API tidak tersedia)',
                  style: TextStyle(
                    color: r.ok ? _textSub : _redBright.withOpacity(0.85),
                    fontSize: 12,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildBottomBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
        decoration: BoxDecoration(
          color: _bg,
          border: Border(top: BorderSide(color: _border.withOpacity(0.6))),
        ),
        child: Row(
          children: [
            if (_step > 0)
              Expanded(
                child: OutlinedButton(
                  onPressed: _loadingGroups || _loadingLinks
                      ? null
                      : () {
                          setState(() {
                            if (_step == 2) {
                              _step = 1;
                            } else if (_step == 1) {
                              _step = 0;
                              _groups = [];
                              _selectedGroupIds.clear();
                              _error = null;
                            }
                          });
                        },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _text,
                    side: const BorderSide(color: _border),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Kembali'),
                ),
              ),
            if (_step > 0) const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: ElevatedButton(
                onPressed: _loadingGroups || _loadingLinks || _loadingSenders
                    ? null
                    : () {
                        if (_step == 0) {
                          if (_selectedSender == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Pilih sender dulu'),
                                backgroundColor: _red,
                              ),
                            );
                            return;
                          }
                          _scanGroups(_selectedSender!);
                        } else if (_step == 1) {
                          if (_selectedGroupIds.isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Pilih minimal 1 group'),
                                backgroundColor: _red,
                              ),
                            );
                            return;
                          }
                          _getLinks();
                        } else {
                          // step 2 → ulangi
                          setState(() {
                            _step = 0;
                            _results = [];
                            _groups = [];
                            _selectedGroupIds.clear();
                          });
                          _loadSenders();
                        }
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _red,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: _red.withOpacity(0.4),
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  _step == 0
                      ? 'Scan Group'
                      : _step == 1
                          ? 'Get Link (${_selectedGroupIds.length})'
                          : 'Mulai Lagi',
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupItem {
  final String id;
  final String name;
  final int? memberCount;
  const _GroupItem({required this.id, required this.name, this.memberCount});
}

class _LinkResult {
  final String groupId;
  final String groupName;
  final String? link;
  final bool ok;
  const _LinkResult({
    required this.groupId,
    required this.groupName,
    required this.link,
    required this.ok,
  });
}
