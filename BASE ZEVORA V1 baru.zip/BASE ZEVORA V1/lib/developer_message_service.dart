import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:fiona/Qaxer/api.dart';

/// Pesan dari developer (Send Notification / FCM).
class DeveloperMessage {
  final String id;
  final String title;
  final String message;
  final String from;
  final String type;
  final int ts;
  final int extraCount;

  const DeveloperMessage({
    required this.id,
    required this.title,
    required this.message,
    required this.from,
    required this.type,
    required this.ts,
    this.extraCount = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'message': message,
        'from': from,
        'type': type,
        'ts': ts,
        'extraCount': extraCount,
      };

  factory DeveloperMessage.fromJson(Map<String, dynamic> j) => DeveloperMessage(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? 'Pesan Developer').toString(),
        message: (j['message'] ?? j['body'] ?? '').toString(),
        from: (j['from'] ?? j['sender'] ?? 'Developer').toString(),
        type: (j['type'] ?? 'info').toString(),
        ts: int.tryParse('${j['ts'] ?? 0}') ?? 0,
        extraCount: int.tryParse('${j['extraCount'] ?? 0}') ?? 0,
      );

  DateTime get date => DateTime.fromMillisecondsSinceEpoch(ts);
}

class DeveloperMessageService {
  static final DeveloperMessageService instance = DeveloperMessageService._();
  DeveloperMessageService._();

  static const _kLatest = 'dev_msg_latest_v2';
  static const _kReadIds = 'dev_msg_read_ids_v2';
  static const _kQueue = 'dev_msg_queue_v2';

  final ValueNotifier<DeveloperMessage?> latest = ValueNotifier(null);
  final ValueNotifier<List<DeveloperMessage>> history = ValueNotifier(const []);
  Timer? _poll;

  Future<void> init() async {
    await refresh();
    _poll?.cancel();
    _poll = Timer.periodic(const Duration(seconds: 20), (_) => refresh());
    _listenFcm();
  }

  void dispose() => _poll?.cancel();

  void _listenFcm() {
    try {
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        ingestFcm(
          title: message.notification?.title ?? message.data['title'],
          body: message.notification?.body ?? message.data['body'],
          data: message.data,
        );
      });
      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        ingestFcm(
          title: message.notification?.title ?? message.data['title'],
          body: message.notification?.body ?? message.data['body'],
          data: message.data,
        );
      });
      FirebaseMessaging.instance.getInitialMessage().then((message) {
        if (message == null) return;
        ingestFcm(
          title: message.notification?.title ?? message.data['title'],
          body: message.notification?.body ?? message.data['body'],
          data: message.data,
        );
      });
    } catch (e) {
      debugPrint('FCM listen: $e');
    }
  }

  Future<Set<String>> _readIds(SharedPreferences prefs) async {
    final raw = prefs.getStringList(_kReadIds) ?? [];
    return raw.toSet();
  }

  Future<void> refresh() async {
    final prefs = await SharedPreferences.getInstance();
    await _loadHistory(prefs);

    final raw = prefs.getString(_kLatest);
    if (raw != null && raw.isNotEmpty) {
      try {
        final msg = DeveloperMessage.fromJson(
            Map<String, dynamic>.from(jsonDecode(raw)));
        final read = await _readIds(prefs);
        latest.value = read.contains(msg.id) ? null : msg;
      } catch (_) {}
    }

    try {
      final base = Api.api.replaceFirst(RegExp(r'/+$'), '');
      for (final path in [
        '$base/api/latest-notification',
        '$base/api/developer-message',
        '$base/api/announcement',
      ]) {
        try {
          final res = await http
              .get(Uri.parse(path))
              .timeout(const Duration(seconds: 8));
          if (res.statusCode != 200) continue;
          final body = jsonDecode(res.body);
          Map<String, dynamic>? data;
          if (body is Map) {
            if (body['data'] is Map) {
              data = Map<String, dynamic>.from(body['data']);
            } else if (body['title'] != null || body['message'] != null) {
              data = Map<String, dynamic>.from(body);
            } else if (body['data'] is List &&
                (body['data'] as List).isNotEmpty) {
              final first = (body['data'] as List).first;
              if (first is Map) data = Map<String, dynamic>.from(first);
            }
          }
          if (data == null) continue;
          final msg = DeveloperMessage(
            id: (data['id'] ??
                    '${data['ts'] ?? data['title']}_${data['message']}')
                .toString(),
            title: (data['title'] ?? 'Pesan Developer').toString(),
            message: (data['message'] ?? data['body'] ?? '').toString(),
            from: (data['from'] ?? data['sender'] ?? 'Developer').toString(),
            type: (data['type'] ?? 'info').toString(),
            ts: int.tryParse(
                    '${data['ts'] ?? DateTime.now().millisecondsSinceEpoch}') ??
                DateTime.now().millisecondsSinceEpoch,
          );
          if (msg.message.isEmpty && msg.title.isEmpty) continue;
          await saveIncoming(msg);
          break;
        } catch (_) {}
      }
    } catch (_) {}
  }

  Future<void> _loadHistory(SharedPreferences prefs) async {
    try {
      final qRaw = prefs.getString(_kQueue);
      if (qRaw == null) {
        history.value = const [];
        return;
      }
      final decoded = jsonDecode(qRaw);
      if (decoded is! List) {
        history.value = const [];
        return;
      }
      final list = decoded
          .whereType<Map>()
          .map((e) => DeveloperMessage.fromJson(Map<String, dynamic>.from(e)))
          .toList()
        ..sort((a, b) => b.ts.compareTo(a.ts));
      history.value = list;
    } catch (_) {
      history.value = const [];
    }
  }

  Future<void> saveIncoming(DeveloperMessage msg) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLatest, jsonEncode(msg.toJson()));

    try {
      final qRaw = prefs.getString(_kQueue);
      final list = <Map<String, dynamic>>[];
      if (qRaw != null) {
        final decoded = jsonDecode(qRaw);
        if (decoded is List) {
          for (final e in decoded) {
            if (e is Map) list.add(Map<String, dynamic>.from(e));
          }
        }
      }
      list.removeWhere((e) => '${e['id']}' == msg.id);
      list.insert(0, msg.toJson());
      if (list.length > 50) list.removeRange(50, list.length);
      await prefs.setString(_kQueue, jsonEncode(list));
    } catch (_) {}

    await _loadHistory(prefs);
    final read = await _readIds(prefs);
    if (!read.contains(msg.id)) {
      latest.value = msg;
    }
  }

  Future<void> publishFromSender({
    required String title,
    required String message,
    required String type,
    required String from,
    String? sessionKey,
  }) async {
    final id =
        'dev_${DateTime.now().millisecondsSinceEpoch}_${title.hashCode}';
    final msg = DeveloperMessage(
      id: id,
      title: title,
      message: message,
      from: from,
      type: type,
      ts: DateTime.now().millisecondsSinceEpoch,
    );
    await saveIncoming(msg);

    try {
      final base = Api.api.replaceFirst(RegExp(r'/+$'), '');
      final payload = {
        if (sessionKey != null) 'key': sessionKey,
        'title': title,
        'message': message,
        'type': type,
        'from': from,
        'id': id,
        'ts': msg.ts,
      };
      for (final path in [
        '$base/api/developer-message',
        '$base/api/announcement',
        '$base/api/save-notification',
      ]) {
        try {
          await http
              .post(
                Uri.parse(path),
                headers: {'Content-Type': 'application/json'},
                body: jsonEncode(payload),
              )
              .timeout(const Duration(seconds: 8));
        } catch (_) {}
      }
    } catch (_) {}
  }

  Future<void> ingestFcm({
    String? title,
    String? body,
    Map<String, dynamic>? data,
  }) async {
    final t = title ?? data?['title']?.toString() ?? 'Pesan Developer';
    final m = body ??
        data?['message']?.toString() ??
        data?['body']?.toString() ??
        '';
    if (m.isEmpty && (title == null || title.isEmpty)) return;
    final from = data?['from']?.toString() ??
        data?['sender']?.toString() ??
        'Developer';
    final type = data?['type']?.toString() ?? 'info';
    final id = (data?['id'] ??
            'fcm_${DateTime.now().millisecondsSinceEpoch}_${t.hashCode}')
        .toString();
    await saveIncoming(DeveloperMessage(
      id: id,
      title: t,
      message: m,
      from: from,
      type: type,
      ts: DateTime.now().millisecondsSinceEpoch,
    ));
  }

  /// Hanya setelah user membuka pesan lalu menutupnya.
  Future<void> markOpenedAndClosed(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final ids = prefs.getStringList(_kReadIds) ?? [];
    if (!ids.contains(id)) {
      ids.add(id);
      if (ids.length > 100) ids.removeRange(0, ids.length - 100);
      await prefs.setStringList(_kReadIds, ids);
    }
    if (latest.value?.id == id) {
      latest.value = null;
    }
    final read = ids.toSet();
    for (final m in history.value) {
      if (!read.contains(m.id)) {
        latest.value = m;
        await prefs.setString(_kLatest, jsonEncode(m.toJson()));
        break;
      }
    }
  }

  Future<bool> isRead(String id) async {
    final prefs = await SharedPreferences.getInstance();
    return (await _readIds(prefs)).contains(id);
  }

  Future<int> unreadCount() async {
    final prefs = await SharedPreferences.getInstance();
    final read = await _readIds(prefs);
    return history.value.where((m) => !read.contains(m.id)).length;
  }

  Future<int> extraCount(String currentId) async {
    final prefs = await SharedPreferences.getInstance();
    final read = await _readIds(prefs);
    return history.value
        .where((m) => m.id != currentId && !read.contains(m.id))
        .length
        .clamp(0, 99);
  }
}
