import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class ThemeSettingsPage extends StatelessWidget {
  const ThemeSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Theme & Warna')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Preset warna', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                const SizedBox(height: 14),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 2.6),
                  itemCount: ThemeProvider.colorPresets.length,
                  itemBuilder: (_, i) {
                    final preset = ThemeProvider.colorPresets[i];
                    final active = theme.isActivePreset(preset);
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => theme.applyPreset(preset),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          gradient: LinearGradient(colors: [preset.primary, preset.accent]),
                          border: Border.all(color: active ? Colors.white : preset.primary.withOpacity(.35), width: active ? 2.5 : 1),
                        ),
                        alignment: Alignment.center,
                        child: Text(preset.name, style: TextStyle(color: ThemeData.estimateBrightnessForColor(preset.primary) == Brightness.dark ? Colors.white : Colors.black, fontWeight: FontWeight.w900)),
                      ),
                    );
                  },
                ),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Column(children: [
              SwitchListTile.adaptive(
                title: const Text('Mode gelap'),
                subtitle: const Text('Gunakan tampilan gelap untuk seluruh aplikasi'),
                value: theme.isDarkMode,
                onChanged: theme.setDarkMode,
              ),
              ListTile(
                leading: CircleAvatar(backgroundColor: scheme.primary, child: const Icon(Icons.palette, color: Colors.white)),
                title: const Text('Warna aktif'),
                subtitle: Text('Primary: #${theme.primaryColor.value.toRadixString(16).substring(2).toUpperCase()}\nAccent: #${theme.accentColor.value.toRadixString(16).substring(2).toUpperCase()}'),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Background custom', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                const SizedBox(height: 12),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  for (final c in const [Color(0xFF08050D), Color(0xFF101828), Color(0xFF0A1628), Color(0xFF1A1025), Color(0xFFF5F5F5)])
                    GestureDetector(
                      onTap: () => theme.setBackgroundColor(c),
                      child: CircleAvatar(radius: 24, backgroundColor: c, child: theme.backgroundColor.value == c.value ? const Icon(Icons.check, color: Colors.white) : null),
                    ),
                ]),
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: theme.resetBackground, icon: const Icon(Icons.refresh), label: const Text('Pakai background otomatis')),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: theme.resetToDefault, icon: const Icon(Icons.restart_alt), label: const Text('Reset ke Purple Default')),
        ],
      ),
    );
  }
}
