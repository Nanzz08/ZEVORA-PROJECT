import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Simulated crypto trading page (BTCUSDT style) — fully interactive paper trade.
class TradePage extends StatefulWidget {
  final String username;
  const TradePage({super.key, this.username = 'Trader'});

  @override
  State<TradePage> createState() => _TradePageState();
}

class _TradePageState extends State<TradePage> {
  static const _red = Color(0xFFE53935);
  static const _green = Color(0xFF22C55E);
  static const _bg = Color(0xFF0A0A0F);

  double _price = 78563.77;
  double _open = 78567.28;
  double _high = 78570.28;
  double _low = 78524.00;
  double _balance = 10000.0;
  double _btcHoldings = 0.0;
  double _change = -3.51;

  final List<_Candle> _candles = [];
  final List<double> _ma7 = [];
  final List<double> _ma25 = [];
  Timer? _tick;
  String _interval = '1m';
  bool _auto = true;

  @override
  void initState() {
    super.initState();
    _seedCandles();
    _loadBalance();
    _tick = Timer.periodic(const Duration(milliseconds: 900), (_) {
      if (!_auto || !mounted) return;
      _tickPrice();
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  Future<void> _loadBalance() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _balance = p.getDouble('trade_balance_usdt') ?? 10000.0;
      _btcHoldings = p.getDouble('trade_btc') ?? 0.0;
    });
  }

  Future<void> _saveBalance() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('trade_balance_usdt', _balance);
    await p.setDouble('trade_btc', _btcHoldings);
  }

  void _seedCandles() {
    final rng = math.Random(42);
    double p = 78200;
    _candles.clear();
    for (int i = 0; i < 48; i++) {
      final o = p;
      final c = o + (rng.nextDouble() - 0.48) * 80;
      final h = math.max(o, c) + rng.nextDouble() * 30;
      final l = math.min(o, c) - rng.nextDouble() * 30;
      _candles.add(_Candle(o, h, l, c));
      p = c;
    }
    _price = _candles.last.close;
    _open = _candles.last.open;
    _high = _candles.map((e) => e.high).reduce(math.max);
    _low = _candles.map((e) => e.low).reduce(math.min);
    _recalcMa();
  }

  void _recalcMa() {
    _ma7.clear();
    _ma25.clear();
    for (int i = 0; i < _candles.length; i++) {
      if (i >= 6) {
        double s = 0;
        for (int j = i - 6; j <= i; j++) {
          s += _candles[j].close;
        }
        _ma7.add(s / 7);
      } else {
        _ma7.add(_candles[i].close);
      }
      if (i >= 24) {
        double s = 0;
        for (int j = i - 24; j <= i; j++) {
          s += _candles[j].close;
        }
        _ma25.add(s / 25);
      } else {
        _ma25.add(_candles[i].close);
      }
    }
  }

  void _tickPrice() {
    final rng = math.Random();
    final delta = (rng.nextDouble() - 0.5) * 28;
    final prev = _price;
    _price = (_price + delta).clamp(70000.0, 90000.0);
    _change = _price - _open;
    if (_price > _high) _high = _price;
    if (_price < _low) _low = _price;

    // update last candle
    final last = _candles.last;
    _candles[_candles.length - 1] = _Candle(
      last.open,
      math.max(last.high, _price),
      math.min(last.low, _price),
      _price,
    );

    // new candle occasionally
    if (rng.nextDouble() < 0.12) {
      _candles.add(_Candle(_price, _price, _price, _price));
      if (_candles.length > 60) _candles.removeAt(0);
      _recalcMa();
    }
    setState(() {});
  }

  void _buy() {
    const amountUsdt = 500.0;
    if (_balance < amountUsdt) {
      _toast('Saldo USDT tidak cukup', false);
      return;
    }
    final btc = amountUsdt / _price;
    setState(() {
      _balance -= amountUsdt;
      _btcHoldings += btc;
    });
    _saveBalance();
    HapticFeedback.mediumImpact();
    _toast('BUY ${btc.toStringAsFixed(6)} BTC @ ${_price.toStringAsFixed(2)}', true);
  }

  void _sell() {
    if (_btcHoldings <= 0) {
      _toast('Tidak ada BTC untuk dijual', false);
      return;
    }
    final sellBtc = math.min(_btcHoldings, 500.0 / _price);
    final usdt = sellBtc * _price;
    setState(() {
      _btcHoldings -= sellBtc;
      _balance += usdt;
    });
    _saveBalance();
    HapticFeedback.mediumImpact();
    _toast('SELL ${sellBtc.toStringAsFixed(6)} BTC @ ${_price.toStringAsFixed(2)}', true);
  }

  void _toast(String msg, bool ok) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: ok ? _green : _red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final chgColor = _change >= 0 ? _green : _red;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new,
                        color: Colors.white70, size: 18),
                    onPressed: () => Navigator.pop(context),
                  ),
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: _red.withOpacity(0.2),
                    child: Text(
                      widget.username.isNotEmpty
                          ? widget.username[0].toUpperCase()
                          : 'T',
                      style: const TextStyle(
                          color: _red, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        widget.username,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13),
                      ),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: _red.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text('OWNER',
                                style: TextStyle(
                                    color: Color(0xFFFFCDD2),
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(width: 8),
                  Icon(Icons.headphones, color: _red.withOpacity(0.8), size: 22),
                ],
              ),
            ),

            // Pair header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  const Text('Trading',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Icon(Icons.candlestick_chart, color: Colors.white38, size: 20),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Text('BTCUSDT',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w800)),
                  const Icon(Icons.arrow_drop_down, color: Colors.white54),
                  const SizedBox(width: 8),
                  Text(
                    _price.toStringAsFixed(4),
                    style: TextStyle(
                      color: chgColor,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Row(
                children: [
                  _ohlc('O', _open),
                  _ohlc('H', _high),
                  _ohlc('L', _low),
                  _ohlc('C', _price),
                  Text(
                    'Chg ${_change >= 0 ? '+' : ''}${_change.toStringAsFixed(2)}',
                    style: TextStyle(
                        color: chgColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),

            // Interval
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text(_interval,
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(width: 8),
                  const Text('BTCUSDT',
                      style: TextStyle(color: Colors.white38, fontSize: 12)),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => setState(() => _auto = !_auto),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _auto
                            ? const Color(0xFF1E3A5F)
                            : Colors.white10,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _auto ? 'Auto' : 'Pause',
                        style: TextStyle(
                          color: _auto ? Colors.lightBlueAccent : Colors.white54,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Chart
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                child: CustomPaint(
                  painter: _ChartPainter(
                    candles: List.from(_candles),
                    ma7: List.from(_ma7),
                    ma25: List.from(_ma25),
                    lastPrice: _price,
                  ),
                  child: const SizedBox.expand(),
                ),
              ),
            ),

            // Balance
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  Text(
                    'Balance: ${_balance.toStringAsFixed(2)} USDT',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const Spacer(),
                  Text(
                    'BTC: ${_btcHoldings.toStringAsFixed(6)}',
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),

            // Buy / Sell
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _buy,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Buy',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 16)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _sell,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _red,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Sell',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _ohlc(String k, double v) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Text(
        '$k ${v.toStringAsFixed(2)}',
        style: const TextStyle(color: Colors.white38, fontSize: 10),
      ),
    );
  }
}

class _Candle {
  final double open, high, low, close;
  _Candle(this.open, this.high, this.low, this.close);
}

class _ChartPainter extends CustomPainter {
  final List<_Candle> candles;
  final List<double> ma7;
  final List<double> ma25;
  final double lastPrice;

  _ChartPainter({
    required this.candles,
    required this.ma7,
    required this.ma25,
    required this.lastPrice,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (candles.isEmpty) return;
    double minP = candles.map((c) => c.low).reduce(math.min);
    double maxP = candles.map((c) => c.high).reduce(math.max);
    final pad = (maxP - minP) * 0.08;
    minP -= pad;
    maxP += pad;
    final range = (maxP - minP).clamp(1.0, double.infinity);
    final chartH = size.height * 0.72;
    final volH = size.height * 0.22;
    final cw = size.width / candles.length;

    // grid
    final grid = Paint()
      ..color = Colors.white.withOpacity(0.04)
      ..strokeWidth = 1;
    for (int i = 0; i < 5; i++) {
      final y = chartH * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // MA lines
    void drawMa(List<double> ma, Color color) {
      if (ma.length < 2) return;
      final p = Paint()
        ..color = color
        ..strokeWidth = 1.4
        ..style = PaintingStyle.stroke;
      final path = Path();
      for (int i = 0; i < ma.length; i++) {
        final x = i * cw + cw / 2;
        final y = chartH * (1 - (ma[i] - minP) / range);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(path, p);
    }

    drawMa(ma25, const Color(0xFF60A5FA));
    drawMa(ma7, const Color(0xFF34D399));

    // candles + volume
    for (int i = 0; i < candles.length; i++) {
      final c = candles[i];
      final up = c.close >= c.open;
      final col = up ? const Color(0xFF22C55E) : const Color(0xFFE53935);
      final x = i * cw + cw / 2;
      final yH = chartH * (1 - (c.high - minP) / range);
      final yL = chartH * (1 - (c.low - minP) / range);
      final yO = chartH * (1 - (c.open - minP) / range);
      final yC = chartH * (1 - (c.close - minP) / range);
      final wick = Paint()
        ..color = col
        ..strokeWidth = 1.2;
      canvas.drawLine(Offset(x, yH), Offset(x, yL), wick);
      final bodyTop = math.min(yO, yC);
      final bodyBot = math.max(yO, yC);
      final body = Paint()..color = col;
      final bw = math.max(cw * 0.55, 2.0);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTRB(x - bw / 2, bodyTop, x + bw / 2, bodyBot + 0.5),
          const Radius.circular(1),
        ),
        body,
      );
      // volume
      final vol = (c.high - c.low) / range;
      final vh = volH * vol.clamp(0.1, 1.0);
      canvas.drawRect(
        Rect.fromLTWH(x - bw / 2, size.height - vh, bw, vh),
        Paint()..color = col.withOpacity(0.45),
      );
    }

    // price tag
    final py = chartH * (1 - (lastPrice - minP) / range);
    final tagPaint = Paint()..color = const Color(0xFFE53935);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width - 72, py - 10, 70, 20),
        const Radius.circular(4),
      ),
      tagPaint,
    );
    final tp = TextPainter(
      text: TextSpan(
        text: lastPrice.toStringAsFixed(2),
        style: const TextStyle(
            color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(size.width - 68, py - 7));
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) => true;
}
