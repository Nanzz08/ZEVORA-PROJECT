import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:fiona/Qaxer/api.dart';

final _baseUrl = Api.api;

class OwnerUtamaPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerUtamaPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerUtamaPage> createState() => _OwnerUtamaPageState();
}

class _OwnerUtamaPageState extends State<OwnerUtamaPage> with TickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['owner_utama', 'owner', 'partner', 'admin', 'vip', 'reseller', 'member', 'DEVELOPER', 'petinggi assist', 'assist', 'staff', 'creator'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _headerAnimController;
  late Animation<double> _headerAnim;

  // ===========================
  // MONOCHROME (HITAM PUTIH) THEME
  // ===========================
  final Color bgDark = const Color(0xFF000000); // Hitam pekat
  final Color surface = const Color(0xFF000000);
  final Color surface2 = const Color(0xFF121212); // Hitam keabuan
  final Color primaryWhite = const Color(0xFFFFFFFF); // Putih bersih
  final Color textGrey = const Color(0xFF9E9E9E); // Abu-abu teks
  final Color cardGlass = const Color(0xFF1A1A1A); // Latar kartu abu gelap
  final Color borderGlass = const Color(0xFF333333); // Garis border abu gelap
  final Color accentWhite = const Color(0xFFE0E0E0); // Aksen putih keabuan

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _headerAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _headerAnim = CurvedAnimation(
      parent: _headerAnimController,
      curve: Curves.easeOutCubic,
    );
    _headerAnimController.forward();
    _fetchUsers();
  }

  @override
  void dispose() {
    _headerAnimController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  int _countByRole(String role) {
    return fullUserList.where((u) => u['role'] == role).length;
  }

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_baseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$_baseUrl/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: surface2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: borderGlass),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: primaryWhite),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite, fontFamily: 'Roboto')),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey, fontFamily: 'Roboto')),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: borderGlass),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  "OK",
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontFamily: 'Roboto'),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== PREMIUM WIDGETS =====

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite, fontFamily: 'Roboto'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: textGrey, fontFamily: 'Roboto'),
          prefixIcon: Icon(icon, color: primaryWhite),
          filled: true,
          fillColor: bgDark,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: primaryWhite, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? accentColor,
  }) {
    final accent = accentColor ?? primaryWhite;
    return Container(
      margin: const EdgeInsets.only(bottom: 22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: cardGlass.withOpacity(0.85),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: borderGlass),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  cardGlass.withOpacity(0.9),
                  surface2.withOpacity(0.7),
                ],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderGlass),
                      ),
                      child: Icon(icon, color: accent, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: borderGlass),
                      ),
                      child: Text(
                        "OWNER SYSTEM",
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(
                  height: 28,
                  color: Color(0xFF333333),
                  thickness: 0.5,
                ),
                ...children,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildButton({
    required String text,
    required IconData icon,
    required VoidCallback onTap,
    bool loading = false,
    List<Color>? gradientColors,
  }) {
    // Karena tema hitam putih, kita buat solid color
    return Container(
      height: 54,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: primaryWhite,
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ElevatedButton.icon(
        onPressed: loading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        icon: loading
            ? SizedBox(
                height: 18,
                width: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: bgDark, // Loading berwarna hitam
                ),
              )
            : Icon(icon, color: bgDark, size: 18), // Icon hitam
        label: Text(
          text,
          style: TextStyle(
            color: bgDark, // Teks tombol hitam
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            fontFamily: 'Roboto',
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required String label,
    required int count,
    required IconData icon,
    required Color color, // Parameter color akan diabaikan demi monokrom
  }) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: cardGlass,
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: surface2,
                shape: BoxShape.circle,
                border: Border.all(color: borderGlass),
              ),
              child: Icon(icon, color: primaryWhite, size: 16),
            ),
            const SizedBox(height: 8),
            Text(
              "$count",
              style: TextStyle(
                color: primaryWhite,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: 'Roboto',
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: textGrey,
                fontSize: 10,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w600,
                fontFamily: 'Roboto',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    // Semua role diseragamkan jadi hitam putih (putih dengan outline abu)
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: primaryWhite.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, color: primaryWhite, size: 6),
          const SizedBox(width: 4),
          Text(
            role.toUpperCase(),
            style: TextStyle(
              color: primaryWhite,
              fontSize: 9,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
              fontFamily: 'Roboto',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: surface2,
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: bgDark,
              shape: BoxShape.circle,
              border: Border.all(color: borderGlass),
            ),
            child: Icon(Icons.person, color: primaryWhite, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        user['username'] ?? '-',
                        style: TextStyle(
                          color: primaryWhite,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ),
                    _buildRoleBadge(user['role'] ?? 'member'),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.event, color: textGrey, size: 11),
                    const SizedBox(width: 4),
                    Text(
                      "EXP: ${user['expiredDate'] ?? '-'}",
                      style: TextStyle(color: textGrey, fontSize: 11, fontFamily: 'Roboto'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              color: Colors.transparent,
              shape: BoxShape.circle,
              border: Border.all(color: borderGlass),
            ),
            child: IconButton(
              icon: const Icon(Icons.delete_outline, color: primaryWhite, size: 18),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: surface2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: borderGlass),
                    ),
                    title: Text("Konfirmasi", style: TextStyle(color: primaryWhite, fontFamily: 'Roboto')),
                    content: Text("Hapus user ini?", style: TextStyle(color: textGrey, fontFamily: 'Roboto')),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: Text("Batal", style: TextStyle(color: textGrey, fontFamily: 'Roboto')),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: Text("Hapus", style: TextStyle(color: primaryWhite, fontFamily: 'Roboto', fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  deleteController.text = user['username'];
                  _deleteUser();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 6,
        runSpacing: 6,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isActive ? primaryWhite : Colors.transparent,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isActive ? primaryWhite : borderGlass,
                ),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.1),
                          blurRadius: 8,
                        )
                      ]
                    : [],
              ),
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive ? bgDark : textGrey, // Teks hitam jika aktif, abu jika tidak
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Roboto',
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildOwnerUtamaHeader() {
    return FadeTransition(
      opacity: _headerAnim,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.1),
          end: Offset.zero,
        ).animate(_headerAnim),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(26),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            color: surface2,
            border: Border.all(color: borderGlass),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 86,
                    height: 86,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: primaryWhite,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(.2),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bgDark,
                      border: Border.all(color: primaryWhite, width: 2),
                    ),
                    child: Icon(
                      Icons.admin_panel_settings, 
                      color: primaryWhite,
                      size: 36,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                "OWNER UTAMA",
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 4,
                  fontFamily: 'Roboto',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "SUPREME ACCESS",
                style: TextStyle(
                  color: textGrey,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 6,
                  fontFamily: 'Roboto',
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: borderGlass),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.security, color: primaryWhite, size: 12),
                    const SizedBox(width: 6),
                    Text(
                      "ABSOLUTE CONTROL",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: bgDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          dropdownColor: surface2,
          isExpanded: true,
          style: TextStyle(color: primaryWhite, fontSize: 14, fontFamily: 'Roboto'),
          icon: Icon(Icons.keyboard_arrow_down, color: primaryWhite),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(Icons.circle, color: primaryWhite, size: 6),
                  const SizedBox(width: 10),
                  Text(role.toUpperCase()),
                ],
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Topbar
              Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(Icons.arrow_back_ios, color: primaryWhite, size: 18),
                  ),
                  Expanded(
                    child: Text(
                      "OWNER UTAMA PANEL",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3,
                        fontFamily: 'Roboto',
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderGlass),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.verified_user, color: primaryWhite, size: 12),
                        const SizedBox(width: 6),
                        Text(
                          "ONLINE",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // Header
              _buildOwnerUtamaHeader(),

              const SizedBox(height: 22),

              // Stats Dashboard
              Row(
                children: [
                  _buildStatCard(
                    label: "TOTAL",
                    count: fullUserList.length,
                    icon: Icons.groups,
                    color: primaryWhite, 
                  ),
                  _buildStatCard(
                    label: "OWNER",
                    count: _countByRole('owner'),
                    icon: Icons.workspace_premium,
                    color: primaryWhite,
                  ),
                  _buildStatCard(
                    label: "VIP",
                    count: _countByRole('vip'),
                    icon: Icons.star,
                    color: primaryWhite,
                  ),
                  _buildStatCard(
                    label: "MEMBER",
                    count: _countByRole('member'),
                    icon: Icons.person,
                    color: primaryWhite,
                  ),
                ],
              ),

              const SizedBox(height: 22),

              // SECTION 1: DELETE USER
              _buildGlassCard(
                title: "DELETE USER",
                icon: FontAwesomeIcons.userSlash,
                children: [
                  _buildInput(
                    label: "Username Target",
                    controller: deleteController,
                    icon: FontAwesomeIcons.user,
                  ),
                  const SizedBox(height: 6),
                  _buildButton(
                    text: "DELETE ACCOUNT",
                    icon: Icons.delete_forever,
                    onTap: _deleteUser,
                    loading: isLoading,
                  ),
                ],
              ),

              // SECTION 2: CREATE ACCOUNT
              _buildGlassCard(
                title: "CREATE ACCOUNT",
                icon: FontAwesomeIcons.userPlus,
                children: [
                  _buildInput(
                    label: "Username",
                    controller: createUsernameController,
                    icon: FontAwesomeIcons.user,
                  ),
                  _buildInput(
                    label: "Password",
                    controller: createPasswordController,
                    icon: FontAwesomeIcons.lock,
                  ),
                  _buildInput(
                    label: "Durasi (Hari)",
                    controller: createDayController,
                    icon: FontAwesomeIcons.calendarDay,
                    type: TextInputType.number,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "PILIH ROLE",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 11,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Roboto',
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildDropdown(
                    value: newUserRole,
                    onChanged: (val) =>
                        setState(() => newUserRole = val ?? 'member'),
                  ),
                  const SizedBox(height: 16),
                  _buildButton(
                    text: "CREATE ACCOUNT",
                    icon: Icons.rocket_launch,
                    onTap: _createAccount,
                    loading: isLoading,
                  ),
                ],
              ),

              // SECTION 3: EXTEND DURATION
              _buildGlassCard(
                title: "EXTEND DURATION",
                icon: FontAwesomeIcons.clock,
                children: [
                  _buildInput(
                    label: "Username Target",
                    controller: editUsernameController,
                    icon: FontAwesomeIcons.userEdit,
                  ),
                  _buildInput(
                    label: "Tambah Hari",
                    controller: editDayController,
                    icon: FontAwesomeIcons.calendarPlus,
                    type: TextInputType.number,
                  ),
                  const SizedBox(height: 6),
                  _buildButton(
                    text: "ADD DAYS",
                    icon: Icons.update,
                    onTap: _editUser,
                    loading: isLoading,
                  ),
                ],
              ),

              // SECTION 4: USER LIST
              _buildGlassCard(
                title: "USER LIST",
                icon: FontAwesomeIcons.users,
                children: [
                  Text(
                    "FILTER BY ROLE",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 11,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Roboto',
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildDropdown(
                    value: selectedRole,
                    onChanged: (val) {
                      if (val != null) {
                        selectedRole = val;
                        _filterAndPaginate();
                      }
                    },
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: borderGlass),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.list_alt, color: primaryWhite, size: 14),
                        const SizedBox(width: 8),
                        Text(
                          "Menampilkan ${filteredList.length} user",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  isLoading
                      ? Container(
                          padding: const EdgeInsets.all(30),
                          child: Center(
                            child: CircularProgressIndicator(
                              color: primaryWhite,
                            ),
                          ),
                        )
                      : filteredList.isEmpty
                          ? Container(
                              padding: const EdgeInsets.all(30),
                              child: Column(
                                children: [
                                  Icon(
                                    Icons.inbox,
                                    color: textGrey,
                                    size: 40,
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    "Tidak ada user pada role ini",
                                    style: TextStyle(color: textGrey, fontFamily: 'Roboto'),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              children: [
                                ..._getCurrentPageData()
                                    .map((u) => _buildUserItem(u))
                                    .toList(),
                                const SizedBox(height: 14),
                                _buildPagination(),
                              ],
                            ),
                ],
              ),
              const SizedBox(height: 30),
              Center(
                child: Text(
                  "© ZEVORA PROJECT TEAM • OWNER UTAMA",
                  style: TextStyle(
                    color: textGrey.withOpacity(0.6),
                    fontSize: 10,
                    letterSpacing: 2,
                    fontFamily: 'Roboto',
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}