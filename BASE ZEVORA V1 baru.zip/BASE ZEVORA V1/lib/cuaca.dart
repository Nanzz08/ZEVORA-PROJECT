import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'location_service.dart';

/// Widget cuaca otomatis untuk Dashboard.
/// Deteksi lokasi GPS → IP → fallback Jakarta, lalu Open-Meteo.
class CuacaDashboardCard extends StatefulWidget {
  final VoidCallback? onOpen;
  const CuacaDashboardCard({super.key, this.onOpen});

  @override
  State<CuacaDashboardCard> createState() => _CuacaDashboardCardState();
}

class _CuacaDashboardCardState extends State<CuacaDashboardCard> {
  Map<String, dynamic>? _data;
  bool _loading = true;
  String? _error;
  Timer? _timer;
  String _source = '';

  @override
  void initState() {
    super.initState();
    _loadWeather();
    _timer = Timer.periodic(const Duration(minutes: 15), (_) => _loadWeather());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadWeather({bool force = false}) async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final loc = await LocationService.I.getLocation(forceRefresh: force);
      _source = loc.source;

      final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
        'latitude': loc.lat.toString(),
        'longitude': loc.lon.toString(),
        'current':
            'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,surface_pressure',
        'daily': 'weather_code,temperature_2m_max,temperature_2m_min',
        'timezone': 'auto',
        'forecast_days': '6',
      });
      final weatherResponse =
          await http.get(uri).timeout(const Duration(seconds: 10));
      if (weatherResponse.statusCode != 200) {
        throw Exception('Server cuaca tidak merespons');
      }

      final weather = jsonDecode(weatherResponse.body) as Map<String, dynamic>;
      final label = loc.source == 'fallback'
          ? '${loc.city} (fallback)'
          : (loc.source == 'gps' ? '${loc.city} · GPS' : '${loc.city} · IP');
      weather['_location'] = label;
      weather['_country'] = loc.country;
      weather['_source'] = loc.source;

      if (!mounted) return;
      setState(() {
        _data = weather;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Gagal memuat cuaca';
      });
    }
  }

  String _weatherLabel(int code) {
    if (code == 0) return 'Cerah';
    if ([1, 2].contains(code)) return 'Cerah Berawan';
    if (code == 3) return 'Berawan';
    if ([45, 48].contains(code)) return 'Berkabut';
    if ([51, 53, 55, 56, 57].contains(code)) return 'Gerimis';
    if ([61, 63, 65, 66, 67, 80, 81, 82].contains(code)) return 'Hujan';
    if ([71, 73, 75, 77, 85, 86].contains(code)) return 'Salju';
    if ([95, 96, 99].contains(code)) return 'Badai';
    return 'Mendung';
  }

  IconData _weatherIcon(int code) {
    if (code == 0) return Icons.wb_sunny_rounded;
    if ([1, 2, 3].contains(code)) return Icons.cloud_rounded;
    if ([45, 48].contains(code)) return Icons.foggy;
    if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].contains(code)) {
      return Icons.water_drop_rounded;
    }
    if ([95, 96, 99].contains(code)) return Icons.thunderstorm_rounded;
    return Icons.cloud_rounded;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _data == null) {
      return Container(
        height: 220,
        decoration: BoxDecoration(
          color: const Color(0xFF141018),
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Center(child: CircularProgressIndicator(color: Color(0xFFE45B45))),
      );
    }

    if (_error != null && _data == null) {
      return Container(
        height: 160,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF141018),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_error!, style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 10),
            TextButton.icon(
              onPressed: () => _loadWeather(force: true),
              icon: const Icon(Icons.refresh, color: Colors.white),
              label: const Text('Coba lagi', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    }

    final current = _data?['current'] as Map<String, dynamic>? ?? {};
    final daily = _data?['daily'] as Map<String, dynamic>? ?? {};
    final temp = (current['temperature_2m'] as num?)?.round() ?? '--';
    final humidity = (current['relative_humidity_2m'] as num?)?.round() ?? '--';
    final wind = (current['wind_speed_10m'] as num?)?.toStringAsFixed(1) ?? '--';
    final pressure = (current['surface_pressure'] as num?)?.round() ?? '--';
    final code = (current['weather_code'] as num?)?.toInt() ?? 3;
    final location = _data?['_location'] ?? 'Lokasi saat ini';
    final condition = _weatherLabel(code);

    final days = (daily['time'] as List?) ?? [];
    final maxT = (daily['temperature_2m_max'] as List?) ?? [];
    final minT = (daily['temperature_2m_min'] as List?) ?? [];
    final codes = (daily['weather_code'] as List?) ?? [];

    final dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];

    return GestureDetector(
      onTap: () => _loadWeather(force: true),
      onLongPress: widget.onOpen,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF141018),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withOpacity(.06)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF8E2430).withOpacity(.12),
              blurRadius: 18,
              spreadRadius: 1,
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.wb_sunny_outlined, color: Color(0xFFFFB74D), size: 18),
                const SizedBox(width: 8),
                const Text(
                  'CUACA',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    letterSpacing: 1.2,
                  ),
                ),
                const Spacer(),
                const Icon(Icons.location_on_rounded, color: Color(0xFFE45B45), size: 15),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    location.toString(),
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_weatherIcon(code), color: Colors.white, size: 42),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$temp°C',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.w800,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(condition, style: const TextStyle(color: Colors.white60, fontSize: 13)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _Metric(icon: Icons.water_drop_outlined, label: 'Humidity', value: '$humidity%'),
                    const SizedBox(height: 6),
                    _Metric(icon: Icons.speed, label: 'Pressure', value: '$pressure hPa'),
                    const SizedBox(height: 6),
                    _Metric(icon: Icons.air, label: 'Wind', value: '$wind km/h'),
                    const SizedBox(height: 6),
                    _Metric(icon: Icons.cloud_outlined, label: 'Condition', value: condition),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (days.isNotEmpty)
              SizedBox(
                height: 78,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: days.length.clamp(0, 6),
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final dateStr = days[i].toString();
                    DateTime? dt;
                    try {
                      dt = DateTime.parse(dateStr);
                    } catch (_) {}
                    final name = i == 0
                        ? 'Hari ini'
                        : (dt != null ? dayNames[dt.weekday % 7] : '—');
                    final mx = i < maxT.length ? (maxT[i] as num).round() : '-';
                    final mn = i < minT.length ? (minT[i] as num).round() : '-';
                    final c = i < codes.length ? (codes[i] as num).toInt() : 3;
                    return Container(
                      width: 64,
                      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.04),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(name, style: const TextStyle(color: Colors.white60, fontSize: 10)),
                          Icon(_forecastIcon(c), color: const Color(0xFFE45B45), size: 16),
                          Text('$mx° $mn°', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                          Text(
                            _weatherLabel(c),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: Colors.white.withOpacity(.45), fontSize: 9),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                'Tap untuk memperbarui · otomatis 15 menit',
                style: TextStyle(color: Colors.white.withOpacity(.35), fontSize: 10),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _forecastIcon(int code) {
    if (code == 0) return Icons.wb_sunny_rounded;
    if ([1, 2, 3].contains(code)) return Icons.cloud_rounded;
    if ([95, 96, 99].contains(code)) return Icons.thunderstorm_rounded;
    return Icons.water_drop_rounded;
  }
}

class _Metric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _Metric({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.white38, size: 12),
        const SizedBox(width: 4),
        Text('$label  ', style: const TextStyle(color: Colors.white38, fontSize: 10)),
        Text(value, style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

/// Halaman penuh jika cuaca dibuka dari menu lain.
class CuacaPage extends StatelessWidget {
  const CuacaPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        foregroundColor: Colors.white,
        title: const Text('Cuaca', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 20),
        children: const [CuacaDashboardCard()],
      ),
    );
  }
}
