import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'developer_message_service.dart';

/// Riwayat pesan developer — tampilan mewah hitam + emas/merah.
class DeveloperMessageHistoryPage extends StatefulWidget {
  final String? focusId;
  const DeveloperMessageHistoryPage({super.key, this.focusId});

  @override
  State<DeveloperMessageHistoryPage> createState() =>
      _DeveloperMessageHistoryPageState();
}

class _DeveloperMessageHistoryPageState
    extends State<DeveloperMessageHistoryPage> {
  static const _bg = Color(0xFF070707);
  static const _card = Color(0xFF121212);
  static const _gold = Color(0xFFD4AF37);
  static const _goldSoft = Color(0xFFF5E6B8);
  static const _red = Color(0xFFE53935);

  final Set<String> _readCache = {};
  String? _openedId;

  @override
  void initState() {
    super.initState();
    _hydrateRead();
    if (widget.focusId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _openDetailById(widget.focusId!);
      });
    }
  }

  Future<void> _hydrateRead() async {
    final list = DeveloperMessageService.instance.history.value;
    for (final m in list) {
      if (await DeveloperMessageService.instance.isRead(m.id)) {
        _readCache.add(m.id);
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _openDetailById(String id) async {
    final list = DeveloperMessageService.instance.history.value;
    final msg = list.cast<DeveloperMessage?>().firstWhere(
          (m) => m?.id == id,
          orElse: () => DeveloperMessageService.instance.latest.value,
        );
    if (msg != null) await _openDetail(msg);
  }

  Future<void> _openDetail(DeveloperMessage msg) async {
    _openedId = msg.id;
    HapticFeedback.lightImpact();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black87,
      builder: (_) => _MessageDetailSheet(message: msg),
    );
    // Hanya setelah dibuka lalu ditutup → tandai read & hilangkan banner
    await DeveloperMessageService.instance.markOpenedAndClosed(msg.id);
    _readCache.add(msg.id);
    _openedId = null;
    if (mounted) setState(() {});
  }

  Color _typeColor(String type) {
    switch (type) {
      case 'warning':
        return const Color(0xFFFF9800);
      case 'success':
        return const Color(0xFF43A047);
      case 'error':
        return _red;
      case 'announcement':
        return const Color(0xFFAB47BC);
      default:
        return const Color(0xFF1E88E5);
    }
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'warning':
        return 'PERINGATAN';
      case 'success':
        return 'SUKSES';
      case 'error':
        return 'ERROR';
      case 'announcement':
        return 'PENGUMUMAN';
      default:
        return 'INFORMASI';
    }
  }

  String _fmt(DateTime d) {
    final now = DateTime.now();
    final diff = now.difference(d);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes} mnt lalu';
    if (diff.inDays < 1) return '${diff.inHours} jam lalu';
    if (diff.inDays < 7) return '${diff.inDays} hari lalu';
    return '${d.day}/${d.month}/${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // ambient glow
          Positioned(
            top: -80,
            right: -40,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _gold.withOpacity(0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 40,
            left: -60,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _red.withOpacity(0.1),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: ValueListenableBuilder<List<DeveloperMessage>>(
                    valueListenable: DeveloperMessageService.instance.history,
                    builder: (context, list, _) {
                      if (list.isEmpty) {
                        return _emptyState();
                      }
                      return ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                        itemCount: list.length,
                        itemBuilder: (_, i) {
                          final m = list[i];
                          final read = _readCache.contains(m.id);
                          return _historyCard(m, read, i == 0);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white70, size: 18),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [_goldSoft, _gold, Color(0xFFB8860B)],
                  ).createShader(b),
                  child: const Text(
                    'Pesan Developer',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),
                Text(
                  'Riwayat pengumuman resmi',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.45),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _gold.withOpacity(0.25),
                  _gold.withOpacity(0.08),
                ],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _gold.withOpacity(0.4)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.workspace_premium_rounded,
                    color: _gold, size: 14),
                const SizedBox(width: 5),
                Text(
                  'OFFICIAL',
                  style: TextStyle(
                    color: _goldSoft,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _card,
              border: Border.all(color: _gold.withOpacity(0.3)),
            ),
            child: Icon(Icons.mail_outline_rounded,
                color: _gold.withOpacity(0.7), size: 32),
          ),
          const SizedBox(height: 16),
          Text(
            'Belum ada pesan',
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Pesan dari developer akan muncul di sini',
            style: TextStyle(
              color: Colors.white.withOpacity(0.4),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _historyCard(DeveloperMessage m, bool read, bool isTop) {
    final accent = _typeColor(m.type);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _openDetail(m),
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFF161616),
                  Color.lerp(const Color(0xFF0E0E0E), accent, 0.06)!,
                ],
              ),
              border: Border.all(
                color: read
                    ? Colors.white.withOpacity(0.06)
                    : accent.withOpacity(0.45),
                width: read ? 1 : 1.3,
              ),
              boxShadow: [
                if (!read)
                  BoxShadow(
                    color: accent.withOpacity(0.18),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // avatar ring
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          accent,
                          accent.withOpacity(0.4),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(2),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF121212),
                      ),
                      child: Icon(Icons.mail_rounded, color: accent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: accent.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                                border:
                                    Border.all(color: accent.withOpacity(0.35)),
                              ),
                              child: Text(
                                _typeLabel(m.type),
                                style: TextStyle(
                                  color: accent,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            if (!read)
                              Container(
                                width: 7,
                                height: 7,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: accent,
                                  boxShadow: [
                                    BoxShadow(
                                      color: accent.withOpacity(0.6),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                            const Spacer(),
                            Text(
                              _fmt(m.date),
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.35),
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        Text(
                          m.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: read
                                ? Colors.white.withOpacity(0.7)
                                : Colors.white,
                            fontSize: 14.5,
                            fontWeight:
                                read ? FontWeight.w600 : FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          m.message.isEmpty ? '—' : m.message,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 12.5,
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(Icons.person_outline_rounded,
                                size: 13,
                                color: Colors.white.withOpacity(0.35)),
                            const SizedBox(width: 4),
                            Text(
                              m.from,
                              style: TextStyle(
                                color: _gold.withOpacity(0.85),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              read ? 'Dibaca' : 'Ketuk untuk buka',
                              style: TextStyle(
                                color: read
                                    ? Colors.white.withOpacity(0.3)
                                    : accent.withOpacity(0.9),
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(width: 2),
                            Icon(
                              Icons.chevron_right_rounded,
                              size: 16,
                              color: read
                                  ? Colors.white24
                                  : accent.withOpacity(0.9),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Detail sheet ────────────────────────────────────────────────────────────
class _MessageDetailSheet extends StatelessWidget {
  final DeveloperMessage message;
  const _MessageDetailSheet({required this.message});

  Color _typeColor(String type) {
    switch (type) {
      case 'warning':
        return const Color(0xFFFF9800);
      case 'success':
        return const Color(0xFF43A047);
      case 'error':
        return const Color(0xFFE53935);
      case 'announcement':
        return const Color(0xFFAB47BC);
      default:
        return const Color(0xFF1E88E5);
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = _typeColor(message.type);
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    final d = message.date;
    final dateStr =
        '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}  ·  ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.82,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF0C0C0C),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          // header gradient bar
          Container(
            margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  accent.withOpacity(0.9),
                  accent.withOpacity(0.55),
                  const Color(0xFF1A1A1A),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.mail_rounded,
                      color: Colors.white, size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'PESAN DEVELOPER',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        message.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'dari ${message.from}  ·  $dateStr',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF141414),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.white.withOpacity(0.06)),
                ),
                child: Text(
                  message.message.isEmpty
                      ? '(Tidak ada isi pesan)'
                      : message.message,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 15,
                    height: 1.55,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(20, 8, 20, 12 + bottom),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text(
                  'Tutup',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
