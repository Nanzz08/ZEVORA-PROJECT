import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Halaman Ganti Warna & Tema (mirip video)
class ThemePage extends StatefulWidget {
  final VoidCallback? onThemeChanged;

  const ThemePage({super.key, this.onThemeChanged});

  @override
  State<ThemePage> createState() => _ThemePageState();
}

class _ThemePageState extends State<ThemePage> {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppTheme.I.themeId,
      builder: (context, id, _) {
        final t = AppTheme.I;
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios_new, color: t.accent, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(
              'Ganti Warna & Tema',
              style: TextStyle(
                color: t.text,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.refresh, color: t.accent),
                tooltip: 'Reset ke Navy',
                onPressed: () async {
                  await AppTheme.I.setTheme('navy');
                  widget.onThemeChanged?.call();
                  setState(() {});
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            children: [
              // Preview banner
              Container(
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: t.current.tileGrad,
                  boxShadow: [
                    BoxShadow(
                      color: t.accent.withOpacity(0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(20),
                alignment: Alignment.centerLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'DARK LIGHT',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.95),
                        fontWeight: FontWeight.w800,
                        fontSize: 22,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      t.current.name,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Tema cepat',
                style: TextStyle(
                  color: t.text,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Pilih satu warna atau kombinasi. Perubahan hanya berlaku pada akun kamu.',
                style: TextStyle(color: t.textSub, fontSize: 12, height: 1.35),
              ),
              const SizedBox(height: 16),
              // Grid 2 kolom
              LayoutBuilder(
                builder: (context, constraints) {
                  final presets = AppTheme.presets;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: presets.map((p) {
                      final selected = p.id == id;
                      final w = (constraints.maxWidth - 10) / 2;
                      return SizedBox(
                        width: w,
                        child: _ThemeTile(
                          preset: p,
                          selected: selected,
                          onTap: () async {
                            await AppTheme.I.setTheme(p.id);
                            widget.onThemeChanged?.call();
                            setState(() {});
                          },
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ThemeTile extends StatelessWidget {
  final ThemePreset preset;
  final bool selected;
  final VoidCallback onTap;

  const _ThemeTile({
    required this.preset,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: preset.tileGrad,
            border: Border.all(
              color: selected ? Colors.white : Colors.white24,
              width: selected ? 2.2 : 1,
            ),
            boxShadow: selected
                ? [
                    BoxShadow(
                      color: preset.accent.withOpacity(0.45),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.2),
                  border: Border.all(color: Colors.white38),
                ),
                child: selected
                    ? const Icon(Icons.check, color: Colors.white, size: 16)
                    : Icon(Icons.palette_outlined,
                        color: Colors.white.withOpacity(0.85), size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  preset.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
