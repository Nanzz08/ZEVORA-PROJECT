import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Tools Galau — kumpulan kata-kata patah hati / galau
/// UI dark + pink/red, mirip referensi GALAU
class GalauPage extends StatefulWidget {
  const GalauPage({super.key});

  @override
  State<GalauPage> createState() => _GalauPageState();
}

class _GalauPageState extends State<GalauPage> {
  static const _bg = Color(0xFF0A0508);
  static const _card = Color(0xFF1A0A10);
  static const _accent = Color(0xFFE91E63);
  static const _accentDim = Color(0xFFAD1457);
  static const _text = Color(0xFFF5E6EC);
  static const _textSub = Color(0xFFB88A9A);

  int _index = 0;
  final PageController _pageCtrl = PageController();

  // Banyak kata-kata galau (40+)
  static const List<String> _quotes = [
    'Mencintai seseorang yang tidak mencintaimu itu seperti memeluk kaktus. Semakin erat, semakin sakit.',
    'Aku bukan menunggu kamu kembali. Aku hanya belum bisa melupakan bagaimana rasanya dicintai olehmu.',
    'Yang paling menyakitkan bukan perpisahan, tapi kenangan yang tak bisa dihapus.',
    'Kamu pergi tanpa pamit, aku tinggal dengan seribu tanya yang tak pernah terjawab.',
    'Aku belajar bahwa cinta tidak selalu tentang memiliki. Kadang, cinta adalah tentang melepaskan.',
    'Kenapa harus ada perpisahan kalau pertemuan itu indah? Kenapa harus ada luka kalau cinta itu tulus?',
    'Aku bukan takut kehilanganmu. Aku takut kehilangan diriku sendiri karena terlalu mencintaimu.',
    'Setiap malam aku menangis, bukan karena lemah, tapi karena lelah berpura-pura tegar.',
    'Kamu adalah alasan aku tersenyum, dan juga alasan aku menangis. Cinta memang aneh, ya?',
    'Aku masih mencintaimu, tapi aku sudah lelah memperjuangkan sesuatu yang tak kunjung pasti.',
    'Cinta itu buta, tapi yang membuat kita sakit adalah hati yang terlalu berharap.',
    'Ada rindu yang tak pernah tersampaikan, ada cinta yang tak pernah dimengerti, dan ada aku yang tak pernah dimiliki.',
    'Kalau memang takdir kita bersama, kenapa harus ada perpisahan yang menyakitkan ini?',
    'Aku sudah mencoba melupakanmu, tapi hatiku keras kepala untuk tetap mengingatmu.',
    'Yang paling berat itu bukan saat kamu pergi, tapi saat aku harus terbiasa tanpamu.',
    'Mungkin aku salah karena terlalu mencintaimu. Tapi aku tak pernah menyesal pernah mencintaimu.',
    'Cinta itu sederhana. Yang rumit adalah ketika kita mencintai orang yang salah.',
    'Aku menyimpan semua kenangan tentangmu di sudut hati yang paling dalam, meski itu yang paling menyakitkan.',
    'Kadang aku bertanya, apakah kamu juga merindukanku seperti aku merindukanmu?',
    'Hati ini lelah, tapi masih sulit untuk berhenti mencintaimu.',
    'Kamu pergi meninggalkan jejak luka yang tak bisa sembuh hanya dengan waktu.',
    'Aku ingin marah padamu, tapi yang ada hanya rindu yang tak kunjung reda.',
    'Mencintaimu adalah keputusan terbaik dan terburuk yang pernah kulakukan.',
    'Di antara senyum yang kupaksakan, ada air mata yang tak pernah berhenti mengalir untukmu.',
    'Aku menunggu, meski tahu kamu tak akan kembali. Bodoh, tapi itulah cinta.',
    'Setiap lagu tentang perpisahan selalu mengingatkanku pada dirimu.',
    'Aku bukan yang terbaik untukmu, tapi aku yang paling tulus mencintaimu.',
    'Kalau hati bisa bicara, pasti dia akan bilang betapa lelahnya mencintaimu sendirian.',
    'Kamu adalah halaman favorit dalam buku hidupku, meski cerita itu berakhir tragis.',
    'Aku sudah mencoba menghapusmu dari pikiranku, tapi kamu selalu kembali di mimpiku.',
    'Cinta yang tak berbalas itu seperti hujan di musim kemarau — indah tapi sia-sia.',
    'Aku tersenyum di depan orang lain, tapi menangis setiap kali mengingatmu.',
    'Yang tersisa hanyalah kenangan dan pertanyaan: kenapa harus berakhir seperti ini?',
    'Aku rela menunggu selamanya, asalkan kamu pernah bilang kamu juga mencintaiku.',
    'Hati yang patah tidak bisa diperbaiki dengan kata-kata, hanya dengan waktu dan keikhlasan.',
    'Kamu mengajarkanku arti cinta, sekaligus arti kehilangan.',
    'Aku bukan menyesal mencintaimu. Aku menyesal karena terlalu berharap.',
    'Di keheningan malam, aku masih membisikkan namamu dalam doa.',
    'Cinta sejati bukan tentang memiliki, tapi tentang melepaskan dengan ikhlas.',
    'Aku sudah cukup kuat untuk pergi, tapi belum cukup kuat untuk melupakan.',
    'Setiap detik tanpamu terasa seperti tahun yang panjang dan sepi.',
    'Kamu adalah rumah yang pernah kutinggali, kini hanya tinggal puing-puing kenangan.',
    'Aku mencintaimu dalam diam, dan melepaskanmu dengan air mata.',
    'Mungkin suatu hari nanti aku akan bertemu seseorang yang lebih baik. Tapi hari ini, hatiku masih milikmu.',
    'Terima kasih sudah pernah ada. Meski perpisahan ini menyakitkan, kenanganmu tetap berharga.',
    'Aku belajar melepaskan, meski setiap langkah terasa seperti mengoyak hati.',
    'Cinta yang pergi meninggalkan jejak yang tak bisa dihapus oleh hujan maupun waktu.',
    'Aku masih di sini, menunggu keajaiban yang mungkin tak akan datang.',
    'Yang paling indah dan paling menyakitkan dalam hidupku adalah kamu.',
    'Akhirnya aku mengerti: tidak semua yang kita cintai ditakdirkan untuk tinggal.',
  ];

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  void _next() {
    if (_index < _quotes.length - 1) {
      _pageCtrl.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void _prev() {
    if (_index > 0) {
      _pageCtrl.previousPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    }
  }

  void _copyQuote() {
    Clipboard.setData(ClipboardData(text: _quotes[_index]));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Kata-kata disalin'),
        backgroundColor: _accentDim,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            // AppBar
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 12, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: _text, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Expanded(
                    child: Text(
                      'GALAU',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _text,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: _accent, size: 22),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Banner TEMAN GALAU
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _accent.withOpacity(0.25),
                      _accentDim.withOpacity(0.15),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _accent.withOpacity(0.35)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: _accent.withOpacity(0.3),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.favorite_rounded,
                          color: _accent, size: 16),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'TEMAN GALAU',
                            style: TextStyle(
                              color: _text,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                          Text(
                            'Buat kamu yang lagi patah hati 💔',
                            style: TextStyle(color: _textSub, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.amber.shade700,
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        icon: const Icon(Icons.more_horiz, color: Colors.white, size: 18),
                        onPressed: _copyQuote,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Quote card
            Expanded(
              child: PageView.builder(
                controller: _pageCtrl,
                itemCount: _quotes.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (context, i) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: _card,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: _accent.withOpacity(0.25)),
                        boxShadow: [
                          BoxShadow(
                            color: _accent.withOpacity(0.08),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          // Quote mark
                          Positioned(
                            top: 24,
                            left: 0,
                            right: 0,
                            child: Icon(
                              Icons.format_quote_rounded,
                              color: _accent.withOpacity(0.35),
                              size: 40,
                            ),
                          ),
                          // Text
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(28, 60, 28, 80),
                              child: Text(
                                _quotes[i],
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: _text,
                                  fontSize: 16,
                                  height: 1.55,
                                  fontWeight: FontWeight.w400,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ),
                          ),
                          // Author + counter
                          Positioned(
                            bottom: 28,
                            left: 0,
                            right: 0,
                            child: Column(
                              children: [
                                Text(
                                  '— Anonim',
                                  style: TextStyle(
                                    color: _accent.withOpacity(0.9),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '${i + 1} / ${_quotes.length}',
                                  style: const TextStyle(
                                    color: _textSub,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            // Dots indicator
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  (_quotes.length > 8 ? 8 : _quotes.length),
                  (i) {
                    final active = (_index % 8) == i;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: active ? 18 : 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: active ? _accent : _accent.withOpacity(0.25),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    );
                  },
                ),
              ),
            ),
            // Bottom buttons
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _index > 0 ? _prev : null,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: _text,
                        side: BorderSide(color: _textSub.withOpacity(0.4)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        '< SEBELUM',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: _card,
                      shape: BoxShape.circle,
                      border: Border.all(color: _accent.withOpacity(0.4)),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: _accent, size: 20),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _index < _quotes.length - 1 ? _next : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accent,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor: _accent.withOpacity(0.3),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        'LANJUT >',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
