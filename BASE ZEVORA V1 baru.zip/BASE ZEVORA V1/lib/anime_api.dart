import 'dart:convert';
import 'package:http/http.dart' as http;

/// Anime / Manga API via AniList GraphQL (reliable) + optional Jikan fallback.
class AnimeApi {
  static const _anilist = 'https://graphql.anilist.co';
  static const _jikan = 'https://api.jikan.moe/v4';

  static Future<Map<String, dynamic>> _gql(String query,
      {Map<String, dynamic>? variables}) async {
    final res = await http
        .post(
          Uri.parse(_anilist),
          headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
          body: jsonEncode({
            'query': query,
            if (variables != null) 'variables': variables,
          }),
        )
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw Exception('AniList ${res.statusCode}');
    }
    final body = jsonDecode(res.body);
    if (body is Map && body['errors'] != null) {
      throw Exception(body['errors'].toString());
    }
    return Map<String, dynamic>.from(body['data'] as Map);
  }

  static Map<String, dynamic> _mapMedia(Map m, {required bool airing}) {
    final titleMap = m['title'] is Map ? m['title'] as Map : {};
    final title = (titleMap['english'] ??
            titleMap['romaji'] ??
            titleMap['native'] ??
            'Untitled')
        .toString();
    final cover = m['coverImage'] is Map
        ? (m['coverImage']['large'] ?? m['coverImage']['medium'] ?? '')
        : '';
    final id = m['id']?.toString() ?? '';
    final eps = m['episodes'];
    final statusRaw = (m['status'] ?? '').toString().toUpperCase();
    final status = statusRaw == 'RELEASING' || statusRaw == 'NOT_YET_RELEASED'
        ? 'Ongoing'
        : 'Completed';
    final score = m['averageScore'];
    final next = m['nextAiringEpisode'];
    String? latest;
    if (next is Map && next['episode'] != null) {
      latest = 'Ep ${next['episode']}';
    } else if (eps != null) {
      latest = '$eps Eps';
    }
    return {
      'animeId': id,
      'slug': id,
      'title': title,
      'poster': cover.toString(),
      'episodes': eps,
      'status': status,
      'score': score,
      'latestReleaseDate': latest,
      'lastReleaseDate': latest,
      'type': airing ? 'ongoing' : 'completed',
    };
  }

  /// Home: ongoing + completed lists (shape kompatibel UI lama)
  static Future<Map<String, dynamic>> fetchHome() async {
    try {
      final data = await _gql(r'''
        query {
          ongoing: Page(page: 1, perPage: 24) {
            media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              episodes
              status
              averageScore
              nextAiringEpisode { episode }
            }
          }
          completed: Page(page: 1, perPage: 24) {
            media(type: ANIME, status: FINISHED, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              episodes
              status
              averageScore
            }
          }
        }
      ''');
      final ongoing = (data['ongoing']?['media'] as List? ?? [])
          .whereType<Map>()
          .map((m) => _mapMedia(Map<String, dynamic>.from(m), airing: true))
          .toList();
      final completed = (data['completed']?['media'] as List? ?? [])
          .whereType<Map>()
          .map((m) => _mapMedia(Map<String, dynamic>.from(m), airing: false))
          .toList();
      return {
        'ongoing': {'animeList': ongoing},
        'completed': {'animeList': completed},
      };
    } catch (_) {
      return _fetchHomeJikan();
    }
  }

  static Future<Map<String, dynamic>> _fetchHomeJikan() async {
    final ongoing = <Map<String, dynamic>>[];
    final completed = <Map<String, dynamic>>[];
    try {
      final r1 = await http
          .get(Uri.parse('$_jikan/top/anime?filter=airing&limit=20'))
          .timeout(const Duration(seconds: 15));
      if (r1.statusCode == 200) {
        final list = (jsonDecode(r1.body)['data'] as List? ?? []);
        for (final m in list) {
          if (m is! Map) continue;
          ongoing.add({
            'animeId': '${m['mal_id']}',
            'slug': '${m['mal_id']}',
            'title': m['title'] ?? m['title_english'] ?? 'Anime',
            'poster': m['images']?['jpg']?['large_image_url'] ??
                m['images']?['jpg']?['image_url'] ??
                '',
            'episodes': m['episodes'],
            'status': 'Ongoing',
            'latestReleaseDate': m['episodes'] != null ? '${m['episodes']} Eps' : null,
          });
        }
      }
    } catch (_) {}
    try {
      final r2 = await http
          .get(Uri.parse('$_jikan/top/anime?filter=bypopularity&limit=20'))
          .timeout(const Duration(seconds: 15));
      if (r2.statusCode == 200) {
        final list = (jsonDecode(r2.body)['data'] as List? ?? []);
        for (final m in list) {
          if (m is! Map) continue;
          completed.add({
            'animeId': '${m['mal_id']}',
            'slug': '${m['mal_id']}',
            'title': m['title'] ?? m['title_english'] ?? 'Anime',
            'poster': m['images']?['jpg']?['large_image_url'] ??
                m['images']?['jpg']?['image_url'] ??
                '',
            'episodes': m['episodes'],
            'status': 'Completed',
            'lastReleaseDate': m['episodes'] != null ? '${m['episodes']} Eps' : null,
          });
        }
      }
    } catch (_) {}
    if (ongoing.isEmpty && completed.isEmpty) {
      throw Exception('Semua sumber anime gagal dimuat');
    }
    return {
      'ongoing': {'animeList': ongoing},
      'completed': {'animeList': completed},
    };
  }

  static Future<List<Map<String, dynamic>>> search(String query) async {
    try {
      final data = await _gql(r'''
        query ($q: String) {
          Page(page: 1, perPage: 24) {
            media(type: ANIME, search: $q, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              episodes
              status
              averageScore
            }
          }
        }
      ''', variables: {'q': query});
      return (data['Page']?['media'] as List? ?? [])
          .whereType<Map>()
          .map((m) => _mapMedia(Map<String, dynamic>.from(m), airing: false))
          .toList();
    } catch (_) {
      try {
        final r = await http
            .get(Uri.parse(
                '$_jikan/anime?q=${Uri.encodeComponent(query)}&limit=20'))
            .timeout(const Duration(seconds: 15));
        if (r.statusCode != 200) return [];
        final list = (jsonDecode(r.body)['data'] as List? ?? []);
        return list.whereType<Map>().map((m) {
          return {
            'animeId': '${m['mal_id']}',
            'slug': '${m['mal_id']}',
            'title': m['title'] ?? 'Anime',
            'poster': m['images']?['jpg']?['large_image_url'] ??
                m['images']?['jpg']?['image_url'] ??
                '',
            'episodes': m['episodes'],
            'status': m['status'] ?? '',
          };
        }).toList();
      } catch (_) {
        return [];
      }
    }
  }

  /// Detail by AniList id (slug = id string)
  static Future<Map<String, dynamic>> fetchDetail(String id) async {
    final mediaId = int.tryParse(id) ?? 0;
    if (mediaId == 0) throw Exception('ID tidak valid');

    try {
      final data = await _gql(r'''
        query ($id: Int) {
          Media(id: $id, type: ANIME) {
            id
            title { romaji english native }
            coverImage { large medium }
            bannerImage
            episodes
            status
            averageScore
            genres
            description(asHtml: false)
            seasonYear
            format
            duration
            studios { nodes { name } }
            recommendations(perPage: 10, sort: RATING_DESC) {
              nodes {
                mediaRecommendation {
                  id
                  title { romaji english }
                  coverImage { large }
                }
              }
            }
          }
        }
      ''', variables: {'id': mediaId});

      final m = Map<String, dynamic>.from(data['Media'] as Map);
      final titleMap = m['title'] is Map ? m['title'] as Map : {};
      final title = (titleMap['english'] ??
              titleMap['romaji'] ??
              titleMap['native'] ??
              'Anime')
          .toString();
      final poster = m['coverImage'] is Map
          ? (m['coverImage']['large'] ?? m['coverImage']['medium'] ?? '')
          : '';
      final statusRaw = (m['status'] ?? '').toString().toUpperCase();
      final status = statusRaw == 'RELEASING' ? 'Ongoing' : 'Completed';
      final epsCount = (m['episodes'] is int) ? m['episodes'] as int : 12;
      final episodes = List.generate(epsCount.clamp(1, 500), (i) {
        final n = i + 1;
        return {
          'title': 'Episode $n',
          'episodeId': '$mediaId-ep$n',
          'slug': '$mediaId-ep$n',
          'episode': n,
          'eps': n,
        };
      });

      final recs = <Map<String, dynamic>>[];
      final recNodes = m['recommendations']?['nodes'] as List? ?? [];
      for (final n in recNodes) {
        if (n is! Map) continue;
        final r = n['mediaRecommendation'];
        if (r is! Map) continue;
        final rt = r['title'] is Map ? r['title'] as Map : {};
        recs.add({
          'animeId': '${r['id']}',
          'title': (rt['english'] ?? rt['romaji'] ?? 'Anime').toString(),
          'poster': r['coverImage']?['large'] ?? '',
        });
      }

      final desc = (m['description'] ?? '')
          .toString()
          .replaceAll(RegExp(r'<[^>]+>'), '')
          .replaceAll('&quot;', '"')
          .replaceAll('&#039;', "'")
          .replaceAll('&amp;', '&');

      final studios = (m['studios']?['nodes'] as List? ?? [])
          .whereType<Map>()
          .map((s) => s['name']?.toString() ?? '')
          .where((s) => s.isNotEmpty)
          .toList();

      return {
        'title': title,
        'poster': poster.toString(),
        'banner': m['bannerImage'] ?? poster,
        'status': status,
        'score': m['averageScore'],
        'genres': (m['genres'] as List? ?? [])
            .map((e) => {
                  'title': e.toString(),
                  'genreId': e.toString(),
                })
            .toList(),
        'genreList': (m['genres'] as List? ?? [])
            .map((e) => {
                  'title': e.toString(),
                  'genreId': e.toString(),
                })
            .toList(),
        'episodes_count': epsCount,
        'year': m['seasonYear'],
        'format': m['format'],
        'duration': m['duration'],
        'studios': studios,
        'synopsis': {
          'paragraphs': desc.isEmpty ? <String>[] : [desc],
        },
        'episodeList': episodes,
        'episodes': episodes,
        'recommendations': recs,
        'animeId': '$mediaId',
        'otakudesuUrl': 'https://anilist.co/anime/$mediaId',
        'batch': null,
      };
    } catch (e) {
      // Jikan fallback (mal id may differ — try as mal)
      final r = await http
          .get(Uri.parse('$_jikan/anime/$mediaId/full'))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) rethrow;
      final m = jsonDecode(r.body)['data'] as Map;
      final epsCount = (m['episodes'] is int) ? m['episodes'] as int : 12;
      final episodes = List.generate(epsCount.clamp(1, 200), (i) {
        final n = i + 1;
        return {
          'title': 'Episode $n',
          'episodeId': '$mediaId-ep$n',
          'slug': '$mediaId-ep$n',
          'episode': n,
        };
      });
      return {
        'title': m['title'] ?? m['title_english'] ?? 'Anime',
        'poster': m['images']?['jpg']?['large_image_url'] ?? '',
        'status': m['status'] ?? '',
        'score': m['score'],
        'genres': (m['genres'] as List? ?? [])
            .map((g) => g is Map ? g['name']?.toString() ?? '' : '')
            .where((s) => s.isNotEmpty)
            .toList(),
        'synopsis': {
          'paragraphs': [
            (m['synopsis'] ?? '').toString(),
          ],
        },
        'episodeList': episodes,
        'episodes': episodes,
        'recommendations': [],
        'animeId': '$mediaId',
        'otakudesuUrl': m['url'] ?? 'https://myanimelist.net/anime/$mediaId',
      };
    }
  }

  static Future<List<Map<String, dynamic>>> fetchSchedule() async {
    try {
      final data = await _gql(r'''
        query {
          Page(page: 1, perPage: 50) {
            media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC) {
              id
              title { romaji english }
              coverImage { large }
              nextAiringEpisode { episode airingAt }
              episodes
            }
          }
        }
      ''');
      final list = (data['Page']?['media'] as List? ?? []);
      final byDay = <String, List<Map<String, dynamic>>>{};
      const days = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
      ];
      for (final d in days) {
        byDay[d] = [];
      }
      for (final m in list) {
        if (m is! Map) continue;
        final next = m['nextAiringEpisode'];
        String day = 'Monday';
        if (next is Map && next['airingAt'] != null) {
          final dt = DateTime.fromMillisecondsSinceEpoch(
              (next['airingAt'] as int) * 1000,
              isUtc: true);
          day = days[dt.toLocal().weekday % 7];
        }
        final t = m['title'] is Map ? m['title'] as Map : {};
        byDay[day]!.add({
          'animeId': '${m['id']}',
          'title': (t['english'] ?? t['romaji'] ?? 'Anime').toString(),
          'poster': m['coverImage']?['large'] ?? '',
          'episode': next is Map ? 'Ep ${next['episode']}' : '',
        });
      }
      return days
          .map((d) => {
                'day': d,
                'animeList': byDay[d]!,
              })
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> fetchGenres() async {
    // AniList genre collection
    const genres = [
      'Action',
      'Adventure',
      'Comedy',
      'Drama',
      'Ecchi',
      'Fantasy',
      'Horror',
      'Mahou Shoujo',
      'Mecha',
      'Music',
      'Mystery',
      'Psychological',
      'Romance',
      'Sci-Fi',
      'Slice of Life',
      'Sports',
      'Supernatural',
      'Thriller',
    ];
    return genres
        .map((g) => {
              'name': g,
              'slug': g.toLowerCase().replaceAll(' ', '-'),
              'genreId': g,
            })
        .toList();
  }

  static Future<List<Map<String, dynamic>>> fetchByGenre(String genre,
      {int page = 1}) async {
    try {
      final data = await _gql(r'''
        query ($genre: String, $page: Int) {
          Page(page: $page, perPage: 24) {
            media(type: ANIME, genre: $genre, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              episodes
              status
              averageScore
            }
          }
        }
      ''', variables: {
        'genre': genre.replaceAll('-', ' '),
        'page': page,
      });
      return (data['Page']?['media'] as List? ?? [])
          .whereType<Map>()
          .map((m) => _mapMedia(Map<String, dynamic>.from(m), airing: false))
          .toList();
    } catch (_) {
      return [];
    }
  }

  // ─── Manga / Comic ─────────────────────────────────────────────
  static Future<List<Map<String, dynamic>>> fetchTopManga(
      {int limit = 20}) async {
    try {
      final data = await _gql(r'''
        query ($perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: MANGA, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              chapters
              status
              averageScore
              genres
              description(asHtml: false)
              siteUrl
            }
          }
        }
      ''', variables: {'perPage': limit});
      return (data['Page']?['media'] as List? ?? [])
          .whereType<Map>()
          .map(_mapManga)
          .toList();
    } catch (_) {
      return _topMangaJikan(limit: limit);
    }
  }

  static Future<List<Map<String, dynamic>>> searchManga(String q,
      {int limit = 20}) async {
    try {
      final data = await _gql(r'''
        query ($q: String, $perPage: Int) {
          Page(page: 1, perPage: $perPage) {
            media(type: MANGA, search: $q, sort: POPULARITY_DESC) {
              id
              title { romaji english native }
              coverImage { large medium }
              chapters
              status
              averageScore
              genres
              description(asHtml: false)
              siteUrl
            }
          }
        }
      ''', variables: {'q': q, 'perPage': limit});
      return (data['Page']?['media'] as List? ?? [])
          .whereType<Map>()
          .map(_mapManga)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Map<String, dynamic> _mapManga(Map m) {
    final t = m['title'] is Map ? m['title'] as Map : {};
    final title =
        (t['english'] ?? t['romaji'] ?? t['native'] ?? 'Manga').toString();
    final poster = m['coverImage'] is Map
        ? (m['coverImage']['large'] ?? m['coverImage']['medium'] ?? '')
        : '';
    final desc = (m['description'] ?? '')
        .toString()
        .replaceAll(RegExp(r'<[^>]+>'), '');
    // Shape mirip Jikan agar comic.dart lama tetap jalan
    return {
      'mal_id': m['id'],
      'title': title,
      'images': {
        'jpg': {
          'image_url': poster,
          'large_image_url': poster,
        }
      },
      'score': m['averageScore'] != null
          ? ((m['averageScore'] as num) / 10).toDouble()
          : null,
      'chapters': m['chapters'],
      'status': m['status'],
      'genres': (m['genres'] as List? ?? [])
          .map((g) => {'name': g.toString()})
          .toList(),
      'synopsis': desc,
      'url': m['siteUrl'] ?? 'https://anilist.co/manga/${m['id']}',
    };
  }

  static Future<List<Map<String, dynamic>>> _topMangaJikan(
      {int limit = 20}) async {
    try {
      final r = await http
          .get(Uri.parse('$_jikan/top/manga?limit=$limit'))
          .timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) return [];
      final list = (jsonDecode(r.body)['data'] as List? ?? []);
      return list.whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList();
    } catch (_) {
      return [];
    }
  }
}
