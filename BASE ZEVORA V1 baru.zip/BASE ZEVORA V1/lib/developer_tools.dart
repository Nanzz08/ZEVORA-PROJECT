import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fiona/Qaxer/api.dart';

import 'premium_service.dart';
import 'tiktok_coin_service.dart';

/// Developer Tools — hanya role developer.
/// Fitur: tambah/set saldo tabungan, koin TikTok, grant centang biru.
class DeveloperToolsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const DeveloperToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<DeveloperToolsPage> createState() => _DeveloperToolsPageState();
}

class _DeveloperToolsPageState extends State<DeveloperToolsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  final _targetUserCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  final _coinsCtrl = TextEditingController();

  bool _busy = false;
  String? _statusMsg;
  bool _statusOk = false;

  PremiumPackage? _selectedPkg = PremiumService.packages.last;

  final Color _bg = const Color(0xFF0D0D0D);
  final Color _card = const Color(0xFF1A1A1A);
  final Color _accent = const Color(0xFFD32F2F);
  final Color _green = const Color(0xFF00C853);

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);

    final role = widget.role.trim().toLowerCase();
    if (role != 'developer') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Access denied. Hanya Developer.'),
            backgroundColor: Colors.red,
          ),
        );
      });
    }
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _targetUserCtrl.dispose();
    _amountCtrl.dispose();
    _coinsCtrl.dispose();
    super.dispose();
  }

  String get _target => _targetUserCtrl.text.trim();

  void _snack(String msg, {bool ok = false}) {
    setState(() {
      _statusMsg = msg;
      _statusOk = ok;
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: ok ? _green : Colors.redAccent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ─── TABUNGAN ───────────────────────────────────────────────
  Future<void> _addTabungan({bool setExact = false}) async {
    final user = _target;
    if (user.isEmpty) {
      _snack('Isi username target');
      return;
    }
    final raw = _amountCtrl.text.trim().replaceAll('.', '').replaceAll(',', '');
    final amount = double.tryParse(raw);
    if (amount == null || amount < 0) {
      _snack('Nominal tidak valid');
      return;
    }

    setState(() => _busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'tabungan_$user';
      final current = prefs.getDouble('${key}_saldo') ?? 0.0;
      final newSaldo = setExact ? amount : current + amount;
      final masuk = (prefs.getDouble('${key}_masuk') ?? current) +
          (setExact ? (amount > current ? amount - current : 0) : amount);

      await prefs.setDouble('${key}_saldo', newSaldo);
      await prefs.setDouble('${key}_masuk', masuk);

      final rawTx = prefs.getStringList('${key}_tx') ?? [];
      rawTx.insert(
        0,
        jsonEncode({
          'id': 'dev_${DateTime.now().millisecondsSinceEpoch}',
          'type': 'masuk',
          'amount': setExact ? amount : amount,
          'note': setExact
              ? 'Set saldo oleh Developer (${widget.username})'
              : 'Tambah saldo oleh Developer (${widget.username})',
          'at': DateTime.now().toIso8601String(),
        }),
      );
      await prefs.setStringList('${key}_tx', rawTx.take(100).toList());

      // Coba sync ke server
      try {
        await http
            .post(
              Uri.parse('${Api.api}/saveTabungan'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'key': widget.sessionKey,
                'username': user,
                'total': newSaldo,
                'saldo': newSaldo,
                'total_masuk': masuk,
              }),
            )
            .timeout(const Duration(seconds: 8));
      } catch (_) {}

      _snack(
        setExact
            ? 'Saldo $user diset ke Rp${_fmt(newSaldo)}'
            : 'Berhasil +Rp${_fmt(amount)} ke $user (total Rp${_fmt(newSaldo)})',
        ok: true,
      );
      _amountCtrl.clear();
    } catch (e) {
      _snack('Gagal: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ─── KOIN ───────────────────────────────────────────────────
  Future<void> _addCoins({bool setExact = false}) async {
    final user = _target;
    if (user.isEmpty) {
      _snack('Isi username target');
      return;
    }
    final coins = int.tryParse(_coinsCtrl.text.trim());
    if (coins == null || coins < 0) {
      _snack('Jumlah koin tidak valid');
      return;
    }

    setState(() => _busy = true);
    try {
      final current = await TiktokCoinService.getCoins(user);
      final next = setExact ? coins : current + coins;
      await TiktokCoinService.setCoins(user, next);
      _snack(
        setExact
            ? 'Koin $user diset ke $next'
            : 'Berhasil +$coins koin ke $user (total $next)',
        ok: true,
      );
      _coinsCtrl.clear();
    } catch (e) {
      _snack('Gagal: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ─── CENTANG BIRU ───────────────────────────────────────────
  Future<void> _grantCentang() async {
    final user = _target;
    if (user.isEmpty) {
      _snack('Isi username target');
      return;
    }
    if (_selectedPkg == null) {
      _snack('Pilih paket');
      return;
    }

    setState(() => _busy = true);
    try {
      final err = await PremiumService.grantPremium(
        username: user,
        pkg: _selectedPkg!,
      );
      if (err != null) {
        _snack(err);
      } else {
        _snack(
          'Centang biru ${_selectedPkg!.label} diberikan ke $user',
          ok: true,
        );
      }
    } catch (e) {
      _snack('Gagal: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _revokeCentang() async {
    final user = _target;
    if (user.isEmpty) {
      _snack('Isi username target');
      return;
    }
    setState(() => _busy = true);
    try {
      await PremiumService.revokePremium(user);
      _snack('Centang biru $user dicabut', ok: true);
    } catch (e) {
      _snack('Gagal: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _previewStatus() async {
    final user = _target;
    if (user.isEmpty) {
      _snack('Isi username target');
      return;
    }
    setState(() => _busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final saldo = prefs.getDouble('tabungan_${user}_saldo') ?? 0.0;
      final coins = await TiktokCoinService.getCoins(user);
      final prem = await PremiumService.statusOf(user);
      final premText = prem.active
          ? (prem.permanent
              ? 'Permanen'
              : 'Aktif s/d ${prem.expiresAt?.toLocal().toString().split('.').first ?? '-'}')
          : 'Tidak aktif';
      _snack(
        '[$user]\nSaldo: Rp${_fmt(saldo)}\nKoin: $coins\nCentang Biru: $premText',
        ok: true,
      );
    } catch (e) {
      _snack('Gagal baca status: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _fmt(double n) {
    final s = n.toStringAsFixed(0);
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          'Developer Tools',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_accent.withOpacity(0.85), Colors.transparent],
            ),
          ),
        ),
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: _accent,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.grey,
          tabs: const [
            Tab(text: 'Tabungan', icon: Icon(Icons.account_balance_wallet, size: 18)),
            Tab(text: 'Koin', icon: Icon(Icons.monetization_on, size: 18)),
            Tab(text: 'Centang Biru', icon: Icon(Icons.verified, size: 18)),
          ],
        ),
      ),
      body: Column(
        children: [
          // Target username + status
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(
              children: [
                TextField(
                  controller: _targetUserCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Username target',
                    labelStyle: TextStyle(color: Colors.grey.shade400),
                    prefixIcon: const Icon(Icons.person, color: Colors.white54),
                    filled: true,
                    fillColor: _card,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    suffixIcon: IconButton(
                      tooltip: 'Cek status',
                      icon: const Icon(Icons.search, color: Colors.white70),
                      onPressed: _busy ? null : _previewStatus,
                    ),
                  ),
                ),
                if (_statusMsg != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: (_statusOk ? _green : Colors.red).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: (_statusOk ? _green : Colors.red).withOpacity(0.4),
                      ),
                    ),
                    child: Text(
                      _statusMsg!,
                      style: TextStyle(
                        color: _statusOk ? _green : Colors.redAccent,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _buildTabunganTab(),
                _buildKoinTab(),
                _buildCentangTab(),
              ],
            ),
          ),
          if (_busy)
            const LinearProgressIndicator(
              minHeight: 2,
              backgroundColor: Colors.transparent,
              color: Color(0xFFD32F2F),
            ),
        ],
      ),
    );
  }

  Widget _buildTabunganTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard(
          title: 'Tambah / Set Saldo Tabungan',
          child: Column(
            children: [
              TextField(
                controller: _amountCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: const TextStyle(color: Colors.white),
                decoration: _inputDeco('Nominal (Rp)', Icons.payments),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : () => _addTabungan(setExact: false),
                      icon: const Icon(Icons.add),
                      label: const Text('Tambah'),
                      style: _btnStyle(_green),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : () => _addTabungan(setExact: true),
                      icon: const Icon(Icons.edit),
                      label: const Text('Set Exact'),
                      style: _btnStyle(_accent),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Saldo disimpan lokal + dicoba sync ke server via /saveTabungan.',
                style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildKoinTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard(
          title: 'Tambah / Set Koin TikTok',
          child: Column(
            children: [
              TextField(
                controller: _coinsCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: const TextStyle(color: Colors.white),
                decoration: _inputDeco('Jumlah koin', Icons.monetization_on),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : () => _addCoins(setExact: false),
                      icon: const Icon(Icons.add),
                      label: const Text('Tambah'),
                      style: _btnStyle(_green),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : () => _addCoins(setExact: true),
                      icon: const Icon(Icons.edit),
                      label: const Text('Set Exact'),
                      style: _btnStyle(_accent),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCentangTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard(
          title: 'Grant Centang Biru',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Pilih paket',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: PremiumService.packages.map((pkg) {
                  final selected = _selectedPkg?.id == pkg.id;
                  return ChoiceChip(
                    label: Text(pkg.label),
                    selected: selected,
                    onSelected: (_) => setState(() => _selectedPkg = pkg),
                    selectedColor: _accent.withOpacity(0.35),
                    backgroundColor: _card,
                    labelStyle: TextStyle(
                      color: selected ? Colors.white : Colors.grey.shade400,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                    ),
                    side: BorderSide(
                      color: selected ? _accent : Colors.grey.shade700,
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _busy ? null : _grantCentang,
                  icon: const Icon(Icons.verified),
                  label: const Text('Grant Centang Biru'),
                  style: _btnStyle(_green),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _revokeCentang,
                  icon: const Icon(Icons.remove_circle_outline, color: Colors.redAccent),
                  label: const Text(
                    'Cabut Centang Biru',
                    style: TextStyle(color: Colors.redAccent),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.redAccent),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Grant tidak memotong saldo tabungan user.',
                style: TextStyle(color: Colors.grey.shade500, fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _sectionCard({required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputDeco(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: Colors.grey.shade400),
      prefixIcon: Icon(icon, color: Colors.white54),
      filled: true,
      fillColor: const Color(0xFF121212),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  ButtonStyle _btnStyle(Color color) {
    return ElevatedButton.styleFrom(
      backgroundColor: color,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}
