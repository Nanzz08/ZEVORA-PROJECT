import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Qaxer/api.dart';

class EmailOsintPage extends StatefulWidget {
  const EmailOsintPage({super.key});

  @override
  State<EmailOsintPage> createState() => _EmailOsintPageState();
}

class _EmailOsintPageState extends State<EmailOsintPage> {
  static const Color primary = Color(0xFFE03030);
  static const Color bgDark = Color(0xFF080204);
  static const Color textWhite = Color(0xFFF5EAEA);
  static const Color textWhite70 = Color(0xA6F5EAEA);
  static const Color textWhite54 = Color(0x66F5EAEA);
  static const Color amber = Color(0xFFFBBF24);
  static const Color green = Color(0xFF4ADE80);
  static const Color red = Color(0xFFEF4444);

  final TextEditingController _emailController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _data;
  String? _searchedEmail;

  String _username = '-';
  String _expired = '-';

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    try {
      final response = await http.get(
        Uri.parse('${Api.api}/api/user-data'),
        headers: {'Cache-Control': 'no-cache'},
      );

      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;

      setState(() {
        _username = data['username']?.toString() ?? '-';

        final expired = data['expired'];
        if (expired != null && expired.toString().isNotEmpty) {
          final date = DateTime.tryParse(expired.toString());
          _expired = date == null ? expired.toString() : _formatDate(date);
        } else {
          _expired = '-';
        }
      });
    } catch (_) {
      // Sama seperti HTML asli: kegagalan user-data diabaikan.
    }
  }

  String _formatDate(DateTime date) {
    final local = date.toLocal();
    final dd = local.day.toString().padLeft(2, '0');
    final mm = local.month.toString().padLeft(2, '0');
    final yyyy = local.year.toString();
    return '$dd/$mm/$yyyy';
  }

  Future<void> _lookupEmail() async {
    final email = _emailController.text.trim();
    if (email.isEmpty || _loading) return;

    setState(() {
      _loading = true;
      _error = null;
      _data = null;
      _searchedEmail = null;
    });

    try {
      final uri = Uri.https(
        'api.eva.pingutil.com',
        '/email',
        {'email': email},
      );

      final response = await http.get(uri);
      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (!mounted) return;

      setState(() => _loading = false);

      if (data['status'] == 'success' && data['data'] is Map) {
        setState(() {
          _data = Map<String, dynamic>.from(data['data'] as Map);
          _searchedEmail = email;
        });
      } else {
        setState(() {
          _error = 'Error: ${data['message'] ?? 'Invalid email or lookup failed'}';
        });
      }
    } catch (_) {
      if (!mounted) return;

      // Fallback sesuai implementasi HTML asli.
      setState(() {
        _loading = false;
        _data = _fallbackData(email);
        _searchedEmail = email;
      });
    }
  }

  Map<String, dynamic> _fallbackData(String email) {
    final parts = email.split('@');
    final username = parts.isNotEmpty ? parts.first : '';
    final domain = parts.length > 1 ? parts.sublist(1).join('@') : '';

    final validFormat =
        RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(email);

    const disposableDomains = [
      'guerrillamail.com',
      'tempmail.com',
      'throwaway.email',
      'mailinator.com',
      'yopmail.com',
      'sharklasers.com',
      'guerrillamailblock.com',
      'grr.la',
      'dispostable.com',
      'maildrop.cc',
    ];

    final lowerDomain = domain.toLowerCase();
    final disposable = disposableDomains.any(
      (item) => lowerDomain.contains(item),
    );

    return {
      'username': username,
      'valid_format': validFormat,
      'deliverable': null,
      'disposable': disposable,
      'webmail': null,
      'spam': null,
      'mx_records': <String>[],
      'dns_records': <String>[],
      '_fallback': true,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.transparent,
      drawer: _buildDrawer(),
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: primary),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              Navigator.pushNamed(context, '/tools');
            }
          },
        ),
        title: Image.network(
          'https://files.catbox.moe/rvo5hy.png',
          height: 50,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) =>
              const Icon(Icons.alternate_email, color: primary),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: primary),
            onPressed: () => Navigator.pushNamed(context, '/logout'),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0C0202),
              Color(0xFF080204),
              Color(0xFF0A0203),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: _buildContent(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: const [
            Icon(Icons.alternate_email, color: amber, size: 22),
            SizedBox(width: 10),
            Text(
              'Email OSINT',
              style: TextStyle(
                color: textWhite,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                fontFamily: 'monospace',
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        const Text(
          'Gather intelligence about an email address',
          style: TextStyle(
            color: textWhite54,
            fontSize: 12,
            fontFamily: 'monospace',
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Email Address',
          style: TextStyle(
            color: textWhite70,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: _emailController,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _lookupEmail(),
          style: const TextStyle(
            color: textWhite,
            fontSize: 13,
            fontFamily: 'monospace',
          ),
          decoration: InputDecoration(
            hintText: 'user@example.com',
            hintStyle: const TextStyle(color: textWhite54),
            filled: true,
            fillColor: const Color(0x0FFBBF24),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0x4DFBBF24)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: amber),
            ),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _loading ? null : _lookupEmail,
            icon: const Icon(Icons.search, size: 18),
            label: const Text('Lookup Email'),
            style: ElevatedButton.styleFrom(
              foregroundColor: amber,
              backgroundColor: const Color(0x40FBBF24),
              disabledForegroundColor: textWhite54,
              disabledBackgroundColor: const Color(0x1AFBBF24),
              elevation: 0,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: const BorderSide(color: Color(0x4DFBBF24)),
              ),
              textStyle: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ),
        if (_loading) ...[
          const SizedBox(height: 30),
          const Center(
            child: Column(
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: amber,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Looking up email...',
                  style: TextStyle(
                    color: textWhite54,
                    fontSize: 13,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
        ],
        if (_error != null) ...[
          const SizedBox(height: 16),
          _buildError(_error!),
        ],
        if (_data != null && _searchedEmail != null) ...[
          const SizedBox(height: 20),
          _buildResults(_data!, _searchedEmail!),
        ],
      ],
    );
  }

  Widget _buildError(String message) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: const Color(0x1AE03030),
        border: Border.all(color: const Color(0x33E03030)),
      ),
      child: Text(
        message,
        style: const TextStyle(
          color: Color(0xFFFF6B6B),
          fontSize: 12,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  Widget _buildResults(Map<String, dynamic> data, String email) {
    final domain = email.contains('@') ? email.split('@').last : '';
    final isFallback = data['_fallback'] == true;

    final statuses = <_Status>[
      _Status(
        'Format',
        data['valid_format'] == true,
        data['valid_format'] == true ? 'Valid' : 'Invalid',
      ),
      _Status(
        'DNS',
        data['deliverable'] == true,
        data['deliverable'] == true
            ? 'Deliverable'
            : (data['dns_check'] == true ? 'DNS OK' : 'DNS Fail'),
      ),
      _Status(
        'Disposable',
        data['disposable'] != true,
        data['disposable'] == true ? 'Disposable' : 'Not Disposable',
      ),
    ];

    if (data.containsKey('webmail') && data['webmail'] != null) {
      statuses.add(_Status(
        'Webmail',
        true,
        data['webmail'] == true ? 'Yes' : 'No',
      ));
    }

    if (data.containsKey('spam') && data['spam'] != null) {
      statuses.add(_Status(
        'Spam',
        data['spam'] != true,
        data['spam'] == true ? 'Flagged' : 'Clean',
      ));
    }

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0x33FBBF24)),
            gradient: const LinearGradient(
              colors: [Color(0x14FBBF24), Color(0x80080202)],
            ),
          ),
          child: Column(
            children: [
              Text(
                email,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: amber,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Domain: $domain',
                style: const TextStyle(
                  color: textWhite54,
                  fontSize: 12,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
        ),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: statuses.map(_buildStatus).toList(),
        ),
        const SizedBox(height: 16),
        _buildEmailInfoCard(data, domain),
        _buildRecordCard(
          title: 'MX Records',
          icon: Icons.dns,
          records: _stringList(data['mx_records']),
        ),
        _buildRecordCard(
          title: 'DNS Records',
          icon: Icons.public,
          records: _stringList(data['dns_records']),
        ),
        if (isFallback)
          const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'Note: API unavailable, showing basic analysis only',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: textWhite54,
                fontSize: 10,
                fontFamily: 'monospace',
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildStatus(_Status status) {
    final color = status.valid ? green : red;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.30)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            status.valid ? Icons.check_circle : Icons.cancel,
            color: color,
            size: 14,
          ),
          const SizedBox(width: 6),
          Text(
            '${status.label}: ${status.text}',
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmailInfoCard(Map<String, dynamic> data, String domain) {
    return _buildCard(
      title: 'Email Information',
      icon: Icons.email,
      child: Column(
        children: [
          _row('Username', data['username']?.toString() ?? '-'),
          _row('Domain', domain),
          _row('Format Valid', data['valid_format'] == true ? 'Yes' : 'No'),
          _row(
            'Deliverable',
            data['deliverable'] == null
                ? 'Unknown'
                : (data['deliverable'] == true ? 'Yes' : 'No'),
          ),
          _row('Disposable', data['disposable'] == true ? 'Yes' : 'No'),
          _row(
            'Webmail',
            data['webmail'] == null
                ? 'Unknown'
                : (data['webmail'] == true ? 'Yes' : 'No'),
          ),
          _row(
            'Spam',
            data['spam'] == null
                ? 'Unknown'
                : (data['spam'] == true ? 'Flagged' : 'Clean'),
          ),
        ],
      ),
    );
  }

  Widget _buildRecordCard({
    required String title,
    required IconData icon,
    required List<String> records,
  }) {
    if (records.isEmpty) return const SizedBox.shrink();

    return _buildCard(
      title: title,
      icon: icon,
      child: Column(
        children: records
            .map(
              (record) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.circle, color: amber, size: 7),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        record,
                        style: const TextStyle(
                          color: textWhite,
                          fontSize: 11,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildCard({
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: const Color(0x0AFBBF24),
        border: Border.all(color: const Color(0x26FBBF24)),
      ),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0x1AFBBF24)),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: amber, size: 14),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    color: textWhite70,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: child,
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0x0FFBBF24)),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                color: textWhite54,
                fontSize: 11,
                fontFamily: 'monospace',
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              textAlign: TextAlign.right,
              softWrap: true,
              style: const TextStyle(
                color: textWhite,
                fontSize: 11,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<String> _stringList(dynamic value) {
    if (value is! List) return [];
    return value.map((e) => e.toString()).toList();
  }

  Drawer _buildDrawer() {
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            SizedBox(
              height: 200,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.network(
                      'https://files.catbox.moe/xl24wa.png',
                      height: 110,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.shield,
                        color: primary,
                        size: 70,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _infoCard(Icons.person, 'USER', _username),
                    const SizedBox(height: 5),
                    _infoCard(Icons.access_time, 'EXPIRED', _expired),
                  ],
                ),
              ),
            ),
            _drawerItem(Icons.home, 'Dashboard', '/dashboard'),
            _drawerItem(Icons.build, 'Tools', '/tools'),
            _drawerItem(Icons.bug_report, 'Bug Attack', '/execution'),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0x0FFBBF24),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x38E03030)),
      ),
      child: Row(
        children: [
          Icon(icon, color: primary, size: 18),
          const SizedBox(width: 10),
          Text(
            label,
            style: const TextStyle(
              color: textWhite70,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'monospace',
            ),
          ),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: textWhite,
                fontSize: 13,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, String route) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      leading: Icon(icon, color: primary, size: 19),
      title: Text(
        title,
        style: const TextStyle(
          color: textWhite70,
          fontSize: 15,
          fontFamily: 'monospace',
        ),
      ),
      onTap: () {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
    );
  }
}

class _Status {
  final String label;
  final bool valid;
  final String text;

  const _Status(this.label, this.valid, this.text);
}
