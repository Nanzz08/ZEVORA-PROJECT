import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:fiona/Qaxer/api.dart';
import 'spam_pair.dart';

final _baseUrl = Api.api;

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final String role;
  final String expiredDate;
  final VoidCallback? onBackToDashboard;
  final String? initialMode;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.role,
    required this.expiredDate,
    this.onBackToDashboard,
    this.initialMode,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // Palette (dari home new)
  static const Color _bg = Color(0xFF080D16);
  static const Color _panel = Color(0xFF111B29);
  static const Color _line = Color(0xFF26384D);
  static const Color _muted = Color(0xFF91A2B8);
  static const Color _cyan = Color(0xFF69D5F5);
  static const Color _blue = Color(0xFF648CF5);
  static const Color _green = Color(0xFF56D6A3);
  static const Color _violet = Color(0xFFB09AFF);
  static const Color _amber = Color(0xFFF59E0B);
  static const Color _redSoft = Color(0xFFFF7B82);

  final TextEditingController targetCtrl = TextEditingController();
  final TextEditingController loopCtrl = TextEditingController();
  final TextEditingController codeCtrl = TextEditingController();
  late final TabController _tabController;
  late final PageController _payloadController;

  int _modeIndex = 0;
  String selectedBugId = '';
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMsg;
  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  String _displayMode = 'orbit';
  bool _showDisplayPicker = false;

  // Hold & send progress
  double _holdProgress = 0.0;
  bool _holding = false;
  DateTime? _holdStart;
  double _sendProgress = 0.0;
  bool _sendProgressRunning = false;

  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  String get _mode => const ['number', 'group', 'testfunc'][_modeIndex];
  Color get _accent => [_cyan, _violet, _green][_modeIndex];
  String get _role =>
      widget.role.trim().isEmpty ? 'MEMBER' : widget.role.toUpperCase();

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' ||
        r == 'admin' ||
        r == 'moderator' ||
        r == 'partner' ||
        r == 'developer' ||
        r == 'vip';
  }

  @override
  void initState() {
    super.initState();
    final requested = widget.initialMode;
    _modeIndex =
        requested == 'group' ? 1 : requested == 'testfunc' ? 2 : 0;
    _tabController =
        TabController(length: 3, vsync: this, initialIndex: _modeIndex);
    _tabController.addListener(_onTabChanged);
    _payloadController = PageController();
    _resultCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade =
        CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(
            begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _resultCtrl, curve: Curves.easeOutCubic));
    _updateSelectedBug();
    _loadGlobalSenders();
  }

  void _onTabChanged() {
    if (_tabController.indexIsChanging) return;
    if (_modeIndex != _tabController.index) {
      setState(() {
        _modeIndex = _tabController.index;
        _responseMsg = null;
        _holdProgress = 0;
        _holding = false;
        _updateSelectedBug();
      });
    }
  }

  void _updateSelectedBug() {
    final bugs =
        _mode == 'group' ? widget.listBugGroup : widget.listBug;
    selectedBugId = bugs.isNotEmpty
        ? bugs.first['bug_id'].toString()
        : '';
  }

  @override
  void dispose() {
    _tabController.removeListener(_onTabChanged);
    _tabController.dispose();
    _payloadController.dispose();
    _resultCtrl.dispose();
    targetCtrl.dispose();
    loopCtrl.dispose();
    codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final uri = Uri.parse('$_baseUrl/getActiveSenders')
          .replace(queryParameters: {'key': widget.sessionKey});
      final res =
          await http.get(uri).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) {
          setState(() =>
              _globalSenders = List<String>.from(data['senders']));
        }
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool isValidGroupLink(String s) =>
      s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  // ── Send bug (logika lama dipertahankan penuh) ───────────────────────────
  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (rawInput.isEmpty) {
      setState(() {
        _holdProgress = 0;
        _holding = false;
      });
      _showAlert('Input Kosong', 'Target tidak boleh kosong.');
      return;
    }

    if (_mode == 'testfunc') {
      final loop = loopCtrl.text.trim();
      final code = codeCtrl.text.trim();
      if (loop.isEmpty ||
          int.tryParse(loop) == null ||
          int.parse(loop) <= 0) {
        setState(() {
          _holdProgress = 0;
          _holding = false;
        });
        _showAlert('Loop Tidak Valid',
            'Masukkan jumlah loop yang benar (angka).');
        return;
      }
      if (code.isEmpty || !code.contains('async function')) {
        setState(() {
          _holdProgress = 0;
          _holding = false;
        });
        _showAlert('Kode Tidak Valid',
            'Paste kode JS yang valid (harus ada async function).');
        return;
      }
    } else {
      if (_mode == 'number') {
        if (formatPhone(rawInput) == null) {
          setState(() {
            _holdProgress = 0;
            _holding = false;
          });
          _showAlert('Nomor Tidak Valid',
              'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
          return;
        }
      } else {
        if (!isValidGroupLink(rawInput)) {
          setState(() {
            _holdProgress = 0;
            _holding = false;
          });
          _showAlert('Link Tidak Valid',
              'Masukkan link grup WhatsApp yang valid.');
          return;
        }
      }
      if (_senderType == 'global' && !canAccessGlobalSender) {
        setState(() {
          _holdProgress = 0;
          _holding = false;
        });
        _showAlert('Akses Ditolak',
            'Sender Global hanya untuk role tertentu!');
        return;
      }
      if (selectedBugId.isEmpty) {
        setState(() {
          _holdProgress = 0;
          _holding = false;
        });
        _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.');
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMsg = null;
      _holdProgress = 1.0;
      _sendProgress = 0.0;
      _sendProgressRunning = true;
    });
    _resultCtrl.reset();

    final sendAnim = _runSendProgressAnim();

    try {
      if (_mode == 'testfunc') {
        final loop = loopCtrl.text.trim();
        final code = codeCtrl.text.trim();

        final res = await http
            .post(
              Uri.parse('$_baseUrl/api/testFunction'),
              headers: {'Content-Type': 'application/json'},
              body: json.encode({
                'key': key,
                'target': rawInput,
                'loop': loop,
                'code': code,
              }),
            )
            .timeout(const Duration(seconds: 15));

        final data = jsonDecode(res.body);
        await sendAnim;
        if (data['valid'] == true && data['success'] == true) {
          _setResponse(
              'success', data['message'] ?? 'Berhasil mengirim bug!');
        } else {
          _setResponse('error',
              data['error'] ?? 'Gagal mengeksekusi function.');
        }
      } else {
        final encodedTarget = Uri.encodeComponent(rawInput);
        final url = Uri.parse(
          '$_baseUrl/sendBug'
          '?key=$key'
          '&target=$encodedTarget'
          '&bug=$selectedBugId'
          '${_senderType == 'global' ? '&senderMode=global' : ''}',
        );
        final res =
            await http.get(url).timeout(const Duration(seconds: 15));
        final data = jsonDecode(res.body);
        await sendAnim;

        if (data['valid'] == false) {
          _setResponse('error',
              'Session key tidak valid. Silakan login ulang.');
        } else if (data['cooldown'] == true) {
          final wait = data['wait'] ?? 0;
          _setResponse(
              'warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
        } else if (data['sended'] == true) {
          final label = _mode == 'group' ? 'grup target' : rawInput;
          final role = data['role'] ?? widget.role;
          _setResponse('success',
              'Berhasil mengirim bug ke $label! [$role]');
          targetCtrl.clear();
        } else {
          _setResponse('error',
              'Gagal mengirim. Server sedang maintenance.');
        }
      }
    } on Exception catch (e) {
      await sendAnim;
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error',
            'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error',
            'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          _holdProgress = 0.0;
          _holding = false;
          _sendProgress = 0.0;
          _sendProgressRunning = false;
        });
      }
    }
  }

  Future<void> _runSendProgressAnim() async {
    const totalMs = 1600;
    const stepMs = 40;
    final steps = totalMs ~/ stepMs;
    for (var i = 1; i <= steps; i++) {
      if (!mounted || !_sendProgressRunning) break;
      await Future.delayed(const Duration(milliseconds: stepMs));
      if (!mounted || !_sendProgressRunning) break;
      setState(() => _sendProgress = (i / steps).clamp(0.0, 1.0));
    }
    if (mounted) setState(() => _sendProgress = 1.0);
  }

  void _onHoldStart() {
    if (_isSending) return;
    _holding = true;
    _holdStart = DateTime.now();
    _tickHold();
  }

  void _tickHold() {
    if (!_holding || !mounted) return;
    final elapsed =
        DateTime.now().difference(_holdStart!).inMilliseconds;
    final p = (elapsed / 1800).clamp(0.0, 1.0);
    setState(() => _holdProgress = p);
    if (p >= 1.0) {
      _holding = false;
      _sendBug();
    } else {
      Future.delayed(const Duration(milliseconds: 40), _tickHold);
    }
  }

  void _onHoldEnd() {
    if (_isSending) return;
    _holding = false;
    if (_holdProgress < 1.0) {
      setState(() => _holdProgress = 0.0);
    }
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(
            parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _panel,
            borderRadius: BorderRadius.circular(22),
            border:
                Border.all(color: _amber.withOpacity(0.35), width: 1.4),
            boxShadow: [
              BoxShadow(
                  color: _amber.withOpacity(0.12), blurRadius: 40)
            ],
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _amber.withOpacity(0.1),
                  border:
                      Border.all(color: _amber.withOpacity(0.3)),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: _amber, size: 26),
              ),
              const SizedBox(height: 14),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _muted, fontSize: 13, height: 1.5)),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(ctx),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _amber,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                  child: const Text('OK',
                      style: TextStyle(
                          fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _resetForm() {
    targetCtrl.clear();
    loopCtrl.clear();
    codeCtrl.clear();
    setState(() {
      _responseMsg = null;
      _holdProgress = 0;
      _holding = false;
    });
    _resultCtrl.reset();
  }

  void _back() {
    if (widget.onBackToDashboard != null) {
      widget.onBackToDashboard!.call();
    }
    Navigator.maybePop(context);
  }

  Future<void> _openSpamPair() async {
    final goDashboard = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => SpamPairPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        ),
      ),
    );
    if (goDashboard == true && mounted) {
      widget.onBackToDashboard?.call();
    }
  }

  // ── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          const Positioned.fill(child: _AmbientBackground()),
          SafeArea(
            child: Column(
              children: [
                _buildTopBar(),
                _buildModeTabs(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding:
                        const EdgeInsets.fromLTRB(18, 18, 18, 34),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildWelcomeCard(),
                        const SizedBox(height: 18),
                        _buildStatsRow(),
                        const SizedBox(height: 16),
                        _buildWorkspaceOverview(),
                        const SizedBox(height: 22),
                        _buildSenderPanel(),
                        const SizedBox(height: 24),
                        _buildSectionHeading(),
                        const SizedBox(height: 12),
                        _buildModeForm(),
                        if (_responseMsg != null) ...[
                          const SizedBox(height: 16),
                          _buildResultCard(),
                        ],
                        const SizedBox(height: 22),
                        _buildSessionInfo(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_isSending)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.72),
                child: Center(
                  child: Container(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 32),
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _panel,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: _accent.withOpacity(0.55),
                          width: 1.5),
                      boxShadow: [
                        BoxShadow(
                            color: _accent.withOpacity(0.3),
                            blurRadius: 28),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: _accent, width: 2),
                          ),
                          child: Icon(Icons.bolt_rounded,
                              color: _accent, size: 28),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          '${(_sendProgress * 100).round()}%',
                          style: TextStyle(
                            color: _accent,
                            fontWeight: FontWeight.w900,
                            fontSize: 28,
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value:
                                _sendProgress.clamp(0.0, 1.0),
                            minHeight: 8,
                            backgroundColor: Colors.white12,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(
                                    _accent),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          (_sendProgress * 100).round() >= 100
                              ? 'MENGIRIM 100%'
                              : 'MENGIRIM ${(_sendProgress * 100).round()}%',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 1.2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Mohon tunggu hingga proses selesai',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
      child: Row(
        children: [
          _GlassIconButton(
              icon: Icons.arrow_back_rounded, onTap: _back),
          const SizedBox(width: 13),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("ZEVORA WORKSPACE',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4)),
                SizedBox(height: 3),
                Text('Unified tools center',
                    style: TextStyle(
                        color: _muted,
                        fontSize: 11,
                        letterSpacing: .25)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: _green.withOpacity(.10),
              borderRadius: BorderRadius.circular(30),
              border:
                  Border.all(color: _green.withOpacity(.28)),
            ),
            child: Row(children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                    color: _green, shape: BoxShape.circle),
              ),
              const SizedBox(width: 7),
              const Text('READY',
                  style: TextStyle(
                      color: _green,
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1)),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _buildModeTabs() {
    final modes = [
      ('NUMBER', Icons.phone_iphone_rounded, _cyan),
      ('GROUP', Icons.groups_2_rounded, _violet),
      ('TEST FUNC', Icons.terminal_rounded, _green),
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: const Color(0x99131D2B),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: _line.withOpacity(.8)),
      ),
      child: Row(
        children: List.generate(modes.length, (i) {
          final selected = _modeIndex == i;
          final item = modes[i];
          return Expanded(
            child: GestureDetector(
              onTap: () => _tabController.animateTo(i,
                  duration: const Duration(milliseconds: 220)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                padding: const EdgeInsets.symmetric(
                    vertical: 12, horizontal: 5),
                decoration: BoxDecoration(
                  color: selected
                      ? item.$3.withOpacity(.14)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: selected
                          ? item.$3.withOpacity(.42)
                          : Colors.transparent),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.$2,
                        size: 15,
                        color: selected ? item.$3 : _muted),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(item.$1,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: selected
                                  ? Colors.white
                                  : _muted,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .45)),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    final title = _mode == 'group'
        ? 'Group Link Workspace'
        : _mode == 'testfunc'
            ? 'Test function lab'
            : 'Number workspace';
    final subtitle = _mode == 'group'
        ? 'Kirim bug ke grup WhatsApp melalui sender terpilih.'
        : _mode == 'testfunc'
            ? 'Eksekusi function JS custom via Private Sender.'
            : 'Kirim bug ke nomor WhatsApp dengan payload pilihan.';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(23),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            _accent.withOpacity(.20),
            const Color(0xFF172235),
            const Color(0xFF101925),
          ],
        ),
        border: Border.all(color: _accent.withOpacity(.35)),
        boxShadow: [
          BoxShadow(
              color: _accent.withOpacity(.08),
              blurRadius: 28,
              offset: const Offset(0, 12)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 43,
              height: 43,
              decoration: BoxDecoration(
                color: _accent.withOpacity(.16),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: _accent.withOpacity(.3)),
              ),
              child: Icon(
                  _mode == 'group'
                      ? Icons.groups_rounded
                      : _mode == 'testfunc'
                          ? Icons.code_rounded
                          : Icons.phone_android_rounded,
                  color: _accent,
                  size: 22),
            ),
            const Spacer(),
            Text('ZEVORA / 0${_modeIndex + 1}',
                style: TextStyle(
                    color: _accent,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2)),
          ]),
          const SizedBox(height: 17),
          Text('Halo, ${widget.username}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.5)),
          const SizedBox(height: 7),
          Text(subtitle,
              style: TextStyle(
                  color: Colors.white.withOpacity(.68),
                  fontSize: 12,
                  height: 1.5)),
        ],
      ),
    );
  }

  Widget _buildStatsRow() {
    return Row(children: [
      Expanded(
          child: _MiniStat(
              icon: Icons.bug_report_rounded,
              label: 'NUMBER LIST',
              value: '${widget.listBug.length}',
              color: _cyan)),
      const SizedBox(width: 9),
      Expanded(
          child: _MiniStat(
              icon: Icons.groups_rounded,
              label: 'GROUP LIST',
              value: '${widget.listBugGroup.length}',
              color: _violet)),
      const SizedBox(width: 9),
      Expanded(
          child: _MiniStat(
              icon: Icons.devices_rounded,
              label: 'SENDERS',
              value: _isLoadingSenders
                  ? '...'
                  : '${_globalSenders.length}',
              color: _green)),
    ]);
  }

  Widget _buildWorkspaceOverview() {
    final items = <(String, String, IconData, Color)>[
      ('NUMBER', 'Kirim bug ke nomor',
          Icons.phone_iphone_rounded, _cyan),
      ('GROUP', 'Kirim bug ke grup',
          Icons.groups_2_rounded, _violet),
      ('TEST FUNC', 'Eksekusi JS custom',
          Icons.terminal_rounded, _green),
      ('SPAM PAIR', 'Spam kode pairing',
          Icons.link_rounded, _blue),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('WORKSPACE MODULES',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.1)),
            ),
            Text('04 MODULES',
                style: TextStyle(
                    color: _muted,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .8)),
          ],
        ),
        const SizedBox(height: 11),
        SizedBox(
          height: 105,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, index) {
              final item = items[index];
              final isSpam = index == 3;
              final active = !isSpam && _modeIndex == index;
              return GestureDetector(
                onTap: () {
                  if (isSpam) {
                    _openSpamPair();
                  } else {
                    _tabController.animateTo(index,
                        duration:
                            const Duration(milliseconds: 240));
                  }
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: 154,
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: active
                        ? item.$4.withOpacity(.13)
                        : const Color(0xFF111B29),
                    borderRadius: BorderRadius.circular(17),
                    border: Border.all(
                      color: active
                          ? item.$4.withOpacity(.65)
                          : _line.withOpacity(.9),
                      width: active ? 1.3 : 1,
                    ),
                    boxShadow: active
                        ? [
                            BoxShadow(
                                color: item.$4.withOpacity(.09),
                                blurRadius: 18,
                                offset: const Offset(0, 7)),
                          ]
                        : const [],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(item.$3, color: item.$4, size: 19),
                          const Spacer(),
                          if (active)
                            Icon(Icons.check_circle_rounded,
                                color: item.$4, size: 14)
                          else if (isSpam)
                            Icon(Icons.arrow_forward_rounded,
                                color: item.$4, size: 14),
                        ],
                      ),
                      Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(item.$1,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: .65)),
                          const SizedBox(height: 3),
                          Text(item.$2,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: _muted, fontSize: 9)),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSenderPanel() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF111B29).withOpacity(.92),
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: _line.withOpacity(.95)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: _green.withOpacity(.12),
                  borderRadius: BorderRadius.circular(11),
                  border:
                      Border.all(color: _green.withOpacity(.25)),
                ),
                child: const Icon(Icons.devices_rounded,
                    color: _green, size: 17),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('SENDER TYPE',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .75)),
                    SizedBox(height: 3),
                    Text('Pilih sumber nomor pengirim',
                        style: TextStyle(
                            color: _muted, fontSize: 9)),
                  ],
                ),
              ),
              if (_isLoadingSenders)
                const SizedBox(
                  width: 15,
                  height: 15,
                  child: CircularProgressIndicator(
                      strokeWidth: 1.7, color: _green),
                )
              else
                GestureDetector(
                  onTap: _loadGlobalSenders,
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: _panel,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _line),
                    ),
                    child: const Icon(Icons.refresh_rounded,
                        color: _muted, size: 14),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 13),
          if (_mode != 'testfunc') ...[
            Row(children: [
              Expanded(
                child: _SenderToggle(
                  icon: Icons.public_rounded,
                  label: 'Global',
                  sub: _isLoadingSenders
                      ? 'Loading...'
                      : '${_globalSenders.length} sender',
                  selected: _senderType == 'global',
                  locked: !canAccessGlobalSender,
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert(
                          'Akses Ditolak',
                          'Sender Global hanya untuk Acces OWNER! Buy owner? upgrade Ke @NanzzPrime');
                      return;
                    }
                    setState(() => _senderType = 'global');
                    _loadGlobalSenders();
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SenderToggle(
                  icon: Icons.person_rounded,
                  label: 'Private',
                  sub: 'Session lu sendiri',
                  selected: _senderType == 'private',
                  locked: false,
                  onTap: () =>
                      setState(() => _senderType = 'private'),
                ),
              ),
            ]),
            if (_senderType == 'global' &&
                _globalSenders.isNotEmpty) ...[
              const SizedBox(height: 11),
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: _green.withOpacity(.07),
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(
                      color: _green.withOpacity(.18)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Container(
                        width: 5,
                        height: 5,
                        decoration: const BoxDecoration(
                            color: _green,
                            shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 6),
                      Text(
                          '${_globalSenders.length} sender aktif',
                          style: const TextStyle(
                              color: _green,
                              fontSize: 10,
                              fontWeight: FontWeight.w700)),
                    ]),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children:
                          _globalSenders.take(6).map((s) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 5),
                          decoration: BoxDecoration(
                            color: _panel,
                            borderRadius:
                                BorderRadius.circular(8),
                            border: Border.all(
                                color: _line.withOpacity(.8)),
                          ),
                          child: Text(s,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'monospace')),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ],
          ] else ...[
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                color: _green.withOpacity(.07),
                borderRadius: BorderRadius.circular(11),
                border:
                    Border.all(color: _green.withOpacity(.18)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.shield_outlined,
                      color: _green, size: 15),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Test Function hanya menggunakan Private Sender (session sendiri).',
                      style: TextStyle(
                          color: Colors.white.withOpacity(.68),
                          fontSize: 10.5,
                          height: 1.45),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSectionHeading() {
    final heading = _mode == 'group'
        ? 'Group Bug Sender'
        : _mode == 'testfunc'
            ? 'Function executor'
            : 'Number bug sender';
    final caption =
        _mode == 'testfunc' ? 'Private sender only' : 'Hold to send';
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(heading,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(caption,
                  style:
                      TextStyle(color: _muted, fontSize: 11)),
            ],
          ),
        ),
        TextButton.icon(
          onPressed: _resetForm,
          icon: const Icon(Icons.refresh_rounded, size: 15),
          label: const Text('RESET'),
          style: TextButton.styleFrom(
              foregroundColor: _muted,
              textStyle: const TextStyle(
                  fontSize: 10, fontWeight: FontWeight.w800)),
        ),
      ],
    );
  }

  Widget _buildModeForm() {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: _panel.withOpacity(.94),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _line),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.16),
              blurRadius: 22,
              offset: const Offset(0, 10)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_mode == 'testfunc') ...[
            _fieldLabel('TARGET NUMBER'),
            const SizedBox(height: 8),
            TextField(
              controller: targetCtrl,
              keyboardType: TextInputType.phone,
              style: const TextStyle(
                  color: Colors.white, fontSize: 13),
              decoration: _inputDecoration(
                  '62812xxxxxxxx', Icons.phone_rounded),
            ),
            const SizedBox(height: 15),
            _fieldLabel('ITERATION LIMIT'),
            const SizedBox(height: 8),
            TextField(
              controller: loopCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(
                  color: Colors.white, fontSize: 13),
              decoration: _inputDecoration(
                  'Contoh: 10', Icons.repeat_rounded),
            ),
            const SizedBox(height: 17),
            Row(children: [
              _fieldLabel('JAVASCRIPT SOURCE'),
              const Spacer(),
              Text('${codeCtrl.text.length}/20000',
                  style:
                      TextStyle(color: _muted, fontSize: 10)),
            ]),
            const SizedBox(height: 8),
            TextField(
              controller: codeCtrl,
              minLines: 8,
              maxLines: 14,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(
                  color: Color(0xFFD7E8F7),
                  fontFamily: 'monospace',
                  fontSize: 11.5,
                  height: 1.5),
              decoration: _inputDecoration(
                      'async function myFunc(sock, target) {\n  // paste your bug code here\n}',
                      Icons.code_rounded)
                  .copyWith(alignLabelWithHint: true),
            ),
            const SizedBox(height: 9),
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                color: _green.withOpacity(.07),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: _green.withOpacity(.18)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.shield_outlined,
                      color: _green, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Kode harus mengandung async function. Dieksekusi melalui endpoint /api/testFunction.',
                      style: TextStyle(
                          color: Colors.white.withOpacity(.68),
                          fontSize: 10.5,
                          height: 1.45),
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            _fieldLabel(_mode == 'group'
                ? 'WHATSAPP GROUP INVITE LINK'
                : 'PHONE NUMBER'),
            const SizedBox(height: 8),
            TextField(
              controller: targetCtrl,
              keyboardType: _mode == 'group'
                  ? TextInputType.url
                  : TextInputType.phone,
              textInputAction: TextInputAction.done,
              style: const TextStyle(
                  color: Colors.white, fontSize: 13),
              decoration: _inputDecoration(
                _mode == 'group'
                    ? 'https://chat.whatsapp.com/...'
                    : '+62812xxxxxxxx',
                _mode == 'group'
                    ? Icons.link_rounded
                    : Icons.phone_rounded,
              ),
              onChanged: (_) {
                if (_responseMsg != null) {
                  setState(() => _responseMsg = null);
                }
              },
            ),
            const SizedBox(height: 14),
            _buildBugSelector(),
          ],
          const SizedBox(height: 18),
          _buildSendButton(),
        ],
      ),
    );
  }

  Widget _buildBugSelector() {
    final bugs =
        _mode == 'group' ? widget.listBugGroup : widget.listBug;
    String? activeName;
    for (final b in bugs) {
      if (b['bug_id'].toString() == selectedBugId) {
        activeName = b['bug_name']?.toString();
        break;
      }
    }

    Widget body;
    switch (_displayMode) {
      case 'scroll':
      case 'simple':
        body = GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: bugs.length,
          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.42,
          ),
          itemBuilder: (_, i) =>
              _bugCard(bugs[i], width: double.infinity),
        );
        break;
      case 'geser':
        body = SizedBox(
          height: 130,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: bugs.length,
            separatorBuilder: (_, __) =>
                const SizedBox(width: 10),
            itemBuilder: (_, i) => _bugCard(bugs[i], width: 170),
          ),
        );
        break;
      case 'orbit':
      default:
        final pageCount = (bugs.length / 4).ceil();
        body = SizedBox(
          height: 300,
          child: PageView.builder(
            controller: _payloadController,
            physics: const PageScrollPhysics(),
            itemCount: pageCount,
            itemBuilder: (context, page) {
              final firstIndex = page * 4;
              final endIndex =
                  math.min(firstIndex + 4, bugs.length);
              final pageBugs =
                  bugs.sublist(firstIndex, endIndex);
              return GridView.builder(
                padding: const EdgeInsets.symmetric(
                    horizontal: 2, vertical: 4),
                physics: const NeverScrollableScrollPhysics(),
                itemCount: pageBugs.length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 1.42,
                ),
                itemBuilder: (context, localIndex) {
                  final bug = pageBugs[localIndex];
                  return _bugCard(bug, width: double.infinity);
                },
              );
            },
          ),
        );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            _fieldLabel('PAYLOAD BUG'),
            const Spacer(),
            GestureDetector(
              onTap: () => setState(
                  () => _showDisplayPicker = !_showDisplayPicker),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 9, vertical: 5),
                decoration: BoxDecoration(
                  color: _panel,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _line),
                ),
                child: Row(children: [
                  Icon(Icons.grid_view_rounded,
                      color: _muted, size: 12),
                  const SizedBox(width: 5),
                  Text(_displayMode.toUpperCase(),
                      style: const TextStyle(
                          color: _muted,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: .5)),
                ]),
              ),
            ),
          ],
        ),
        if (_showDisplayPicker) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _panel,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _line),
            ),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                ('scroll', 'SCROLL', Icons.view_list_rounded),
                ('geser', 'GESER', Icons.swipe_rounded),
                ('orbit', 'ORBIT', Icons.threed_rotation),
                ('simple', 'SIMPLE', Icons.grid_view_rounded),
              ].map((o) {
                final sel = _displayMode == o.$1;
                return GestureDetector(
                  onTap: () => setState(() {
                    _displayMode = o.$1;
                    _showDisplayPicker = false;
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 9, vertical: 6),
                    decoration: BoxDecoration(
                      color: sel
                          ? _accent.withOpacity(.18)
                          : _bg,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color:
                              sel ? _accent : _line),
                    ),
                    child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(o.$3,
                              color: sel ? _accent : _muted,
                              size: 12),
                          const SizedBox(width: 5),
                          Text(o.$2,
                              style: TextStyle(
                                  color: sel
                                      ? _accent
                                      : _muted,
                                  fontSize: 9,
                                  fontWeight:
                                      FontWeight.w800)),
                        ]),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
        const SizedBox(height: 8),
        body,
        if (activeName != null && activeName.isNotEmpty) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 11, vertical: 8),
            decoration: BoxDecoration(
              color: _accent.withOpacity(.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: _accent.withOpacity(.35)),
            ),
            child: Row(children: [
              Icon(Icons.shield_outlined,
                  color: _accent, size: 14),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  'Payload aktif: $activeName',
                  style: TextStyle(
                      color: _accent,
                      fontSize: 11,
                      fontWeight: FontWeight.w700),
                ),
              ),
            ]),
          ),
        ],
      ],
    );
  }

  Widget _bugCard(Map bug,
      {double width = 180, double height = 130}) {
    final selected =
        selectedBugId == bug['bug_id'].toString();
    return GestureDetector(
      onTap: () => setState(
          () => selectedBugId = bug['bug_id'].toString()),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: width,
        height: height,
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? _accent.withOpacity(.85)
                : _line.withOpacity(.7),
            width: selected ? 1.5 : 1,
          ),
          color: selected
              ? _accent.withOpacity(.14)
              : _bg,
          boxShadow: selected
              ? [
                  BoxShadow(
                      color: _accent.withOpacity(.18),
                      blurRadius: 14,
                      offset: const Offset(0, 4))
                ]
              : const [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9),
                  color: _accent.withOpacity(.18),
                  border: Border.all(
                      color: _accent.withOpacity(.35)),
                ),
                child: Icon(Icons.security_rounded,
                    color: _accent, size: 15),
              ),
              const Spacer(),
              if (selected)
                Icon(Icons.check_circle_rounded,
                    color: _accent, size: 16),
            ]),
            const Spacer(),
            Text('${bug["bug_name"] ?? "Bug"}',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 11.5)),
            const SizedBox(height: 2),
            Text('#${bug["bug_id"] ?? ""}',
                style: TextStyle(
                    color: _muted, fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    final fillFactor = _isSending
        ? _sendProgress.clamp(0.0, 1.0)
        : _holdProgress.clamp(0.0, 1.0);
    final holdingUi =
        _holding || (_holdProgress > 0 && _holdProgress < 1);
    final holdPct = (_holdProgress * 100).round();
    final sendPct = (_sendProgress * 100).round();

    return Listener(
      onPointerDown: (_) => _onHoldStart(),
      onPointerUp: (_) => _onHoldEnd(),
      onPointerCancel: (_) => _onHoldEnd(),
      child: Container(
        height: 54,
        width: double.infinity,
        decoration: BoxDecoration(
          color: _accent.withOpacity(.15),
          borderRadius: BorderRadius.circular(14),
          border:
              Border.all(color: _accent.withOpacity(.5), width: 1.3),
          boxShadow: [
            BoxShadow(
                color: _accent.withOpacity(.18),
                blurRadius: 18,
                offset: const Offset(0, 6)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (holdingUi || _isSending)
                Align(
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: fillFactor <= 0 ? 0.001 : fillFactor,
                    child: Container(
                        color: _accent.withOpacity(.55)),
                  ),
                ),
              Center(
                child: _isSending
                    ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2.2,
                                color: Colors.white),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            sendPct >= 100
                                ? 'MENGIRIM 100%'
                                : 'MENGIRIM $sendPct%',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 12,
                                letterSpacing: .9),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                              _mode == 'testfunc'
                                  ? Icons.code_rounded
                                  : Icons.bug_report_rounded,
                              color: Colors.white,
                              size: 18),
                          const SizedBox(width: 9),
                          Text(
                            holdingUi
                                ? (holdPct >= 100
                                    ? 'TAHAN 100%'
                                    : 'TAHAN $holdPct%')
                                : 'TAHAN UNTUK KIRIM',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 12,
                                letterSpacing: .9),
                          ),
                          const SizedBox(width: 9),
                          const Icon(Icons.fingerprint,
                              color: Colors.white70, size: 18),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = _green;
        icon = Icons.check_circle_rounded;
        title = 'Berhasil';
        break;
      case 'warning':
        color = _amber;
        icon = Icons.warning_rounded;
        title = 'Peringatan';
        break;
      default:
        color = _redSoft;
        icon = Icons.error_rounded;
        title = 'Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: color.withOpacity(.08),
            borderRadius: BorderRadius.circular(17),
            border:
                Border.all(color: color.withOpacity(.35)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: TextStyle(
                            color: color,
                            fontSize: 12,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    Text(msg,
                        style: TextStyle(
                            color: Colors.white.withOpacity(.78),
                            fontSize: 11.5,
                            height: 1.5)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() => _responseMsg = null);
                  _resultCtrl.reset();
                },
                child: Icon(Icons.close_rounded,
                    color: _muted, size: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSessionInfo() {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.035),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: _line.withOpacity(.75)),
      ),
      child: Row(children: [
        Container(
          width: 37,
          height: 37,
          decoration: BoxDecoration(
            color: _blue.withOpacity(.13),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.verified_user_rounded,
              color: _blue, size: 19),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${widget.username}  •  $_role',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('Masa aktif: ${widget.expiredDate}',
                  style:
                      TextStyle(color: _muted, fontSize: 10)),
            ],
          ),
        ),
        const Icon(Icons.shield_moon_outlined,
            color: _green, size: 18),
      ]),
    );
  }

  Widget _fieldLabel(String value) => Text(value,
      style: TextStyle(
          color: _muted,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.05));

  InputDecoration _inputDecoration(String hint, IconData icon) =>
      InputDecoration(
        hintText: hint,
        hintStyle:
            TextStyle(color: _muted.withOpacity(.65), fontSize: 12),
        prefixIcon: Icon(icon, color: _accent, size: 18),
        filled: true,
        fillColor: const Color(0xFF09121E),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: BorderSide(color: _line.withOpacity(.9))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: BorderSide(
                color: _accent.withOpacity(.75), width: 1.3)),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13)),
      );
}

// ─── Helper Widgets ──────────────────────────────────────────────────────
class _AmbientBackground extends StatelessWidget {
  const _AmbientBackground();
  @override
  Widget build(BuildContext context) =>
      CustomPaint(painter: _AmbientPainter(), child: const SizedBox.expand());
}

class _AmbientPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 65);
    p.color = const Color(0xFF3A83B8).withOpacity(.15);
    canvas.drawCircle(
        Offset(size.width * .92, size.height * .08), 115, p);
    p.color = const Color(0xFF7663D8).withOpacity(.10);
    canvas.drawCircle(
        Offset(size.width * .02, size.height * .54), 130, p);
    p.color = const Color(0xFF35B98B).withOpacity(.08);
    canvas.drawCircle(
        Offset(size.width * .85, size.height * .88), 105, p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _GlassIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _GlassIconButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Material(
            color: Colors.white.withOpacity(.055),
            child: InkWell(
              onTap: onTap,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(
                      color: Colors.white.withOpacity(.10)),
                ),
                child: Icon(icon, color: Colors.white, size: 19),
              ),
            ),
          ),
        ),
      );
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });
  @override
  Widget build(BuildContext context) => Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF111B29),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: color.withOpacity(.22)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(height: 10),
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: _HomePageState._muted,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .3)),
          ],
        ),
      );
}

class _SenderToggle extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sub;
  final bool selected;
  final bool locked;
  final VoidCallback onTap;
  const _SenderToggle({
    required this.icon,
    required this.label,
    required this.sub,
    required this.selected,
    required this.locked,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    final color = selected
        ? _HomePageState._green
        : _HomePageState._muted;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding:
            const EdgeInsets.symmetric(vertical: 12, horizontal: 11),
        decoration: BoxDecoration(
          color: selected
              ? _HomePageState._green.withOpacity(.08)
              : _HomePageState._panel,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
            color: selected
                ? _HomePageState._green.withOpacity(.4)
                : _HomePageState._line,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(clipBehavior: Clip.none, children: [
              Icon(icon, color: color, size: 18),
              if (locked)
                Positioned(
                  right: -4,
                  top: -4,
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _HomePageState._amber,
                      border: Border.all(
                          color: _HomePageState._panel,
                          width: 1.5),
                    ),
                    child: const Icon(Icons.lock_rounded,
                        color: Colors.white, size: 7),
                  ),
                ),
            ]),
            const SizedBox(height: 7),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 3),
            Text(sub,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: _HomePageState._muted,
                    fontSize: 9,
                    height: 1.3)),
            if (selected) ...[
              const SizedBox(height: 5),
              Container(
                width: 18,
                height: 3,
                decoration: BoxDecoration(
                    color: _HomePageState._green,
                    borderRadius: BorderRadius.circular(2)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
