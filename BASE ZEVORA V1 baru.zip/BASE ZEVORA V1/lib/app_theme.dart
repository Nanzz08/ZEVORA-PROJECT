import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Model warna untuk kompatibilitas halaman pemilih tema.
class AppThemeData {
  final String id;
  final String name;
  final Color bg;
  final Color accent;
  final Color card;
  final Color cardBorder;

  const AppThemeData({
    required this.id,
    required this.name,
    required this.bg,
    required this.accent,
    required this.card,
    required this.cardBorder,
  });
}

/// Sistem tema utama ZEVORA PROJECT.
///
/// Mendukung API lama:
/// - AppTheme.I
/// - AppTheme.I.themeId
/// - AppTheme.I.current
/// - AppTheme.I.accent
/// - AppTheme.I.setTheme()
///
/// Dan API yang dipakai theme_picker_page.dart:
/// - AppTheme()
/// - AppTheme.allThemes
/// - AppTheme().currentThemeId
/// - AppTheme().colors
/// - AppTheme().addListener()
class AppTheme extends ChangeNotifier {
  AppTheme._() {
    themeId.addListener(_handleThemeIdChanged);
  }

  factory AppTheme() => I;

  static final AppTheme I = AppTheme._();

  static const String _prefKey = 'app_theme_id_v1';

  final ValueNotifier<String> themeId = ValueNotifier<String>('navy');

  void _handleThemeIdChanged() {
    notifyListeners();
  }

  String get currentThemeId => themeId.value;

  /// Semua preset warna yang dipakai halaman Ganti Tema.
  static final List<ThemePreset> presets = [
    ThemePreset('putih', 'Putih', const Color(0xFFE8E8E8), const Color(0xFFBDBDBD)),
    ThemePreset('merah', 'Merah', const Color(0xFFC52222), const Color(0xFF8B1515)),
    ThemePreset('oranye', 'Oranye', const Color(0xFFFF6D00), const Color(0xFFE65100)),
    ThemePreset('kuning', 'Kuning', const Color(0xFFFFB300), const Color(0xFFF57C00)),
    ThemePreset('lime', 'Lime', const Color(0xFFC0CA33), const Color(0xFF9E9D24)),
    ThemePreset('hijau', 'Hijau', const Color(0xFF43A047), const Color(0xFF2E7D32)),
    ThemePreset('teal', 'Teal', const Color(0xFF00897B), const Color(0xFF00695C)),
    ThemePreset('cyan', 'Cyan', const Color(0xFF00BCD4), const Color(0xFF0097A7)),
    ThemePreset('biru', 'Biru', const Color(0xFF1E88E5), const Color(0xFF1565C0)),
    ThemePreset('indigo', 'Indigo', const Color(0xFF5C6BC0), const Color(0xFF3949AB)),
    ThemePreset('ungu', 'Ungu', const Color(0xFF8E24AA), const Color(0xFF6A1B9A)),
    ThemePreset('deep_purple', 'Deep Purple', const Color(0xFF7C4DFF), const Color(0xFF5E35B1)),
    ThemePreset('pink', 'Pink', const Color(0xFFEC407A), const Color(0xFFC2185B)),
    ThemePreset('magenta', 'Magenta', const Color(0xFFD500F9), const Color(0xFFAA00FF)),
    ThemePreset('rose', 'Rose', const Color(0xFFE91E63), const Color(0xFFC2185B)),
    ThemePreset('coklat', 'Coklat', const Color(0xFF8D6E63), const Color(0xFF6D4C41)),
    ThemePreset('gold', 'Gold', const Color(0xFFFFC107), const Color(0xFFFFA000)),
    ThemePreset('silver', 'Silver', const Color(0xFFB0BEC5), const Color(0xFF78909C)),
    ThemePreset('hitam', 'Hitam', const Color(0xFF424242), const Color(0xFF212121)),
    ThemePreset('merah_pink', 'Merah + Pink', const Color(0xFFE91E63), const Color(0xFFC52222)),
    ThemePreset('oranye_pink', 'Oranye + Pink', const Color(0xFFFF6D00), const Color(0xFFEC407A)),
    ThemePreset('kuning_merah', 'Kuning + Merah', const Color(0xFFFFB300), const Color(0xFFC52222)),

    ThemePreset('blue_ice', 'Blue Ice', const Color(0xFF38BDF8), const Color(0xFF0284C7)),
    ThemePreset('sky', 'Sky Blue', const Color(0xFF0EA5E9), const Color(0xFF0369A1)),
    ThemePreset('royal_blue', 'Royal Blue', const Color(0xFF2563EB), const Color(0xFF1E40AF)),
    ThemePreset('electric_blue', 'Electric Blue', const Color(0xFF2979FF), const Color(0xFF0D47A1)),
    ThemePreset('navy', 'Navy', const Color(0xFF3B82F6), const Color(0xFF172554)),
    ThemePreset('aqua', 'Aqua', const Color(0xFF00E5FF), const Color(0xFF00838F)),
    ThemePreset('turquoise', 'Turquoise', const Color(0xFF14B8A6), const Color(0xFF0F766E)),
    ThemePreset('emerald', 'Emerald', const Color(0xFF10B981), const Color(0xFF047857)),
    ThemePreset('mint', 'Mint', const Color(0xFF34D399), const Color(0xFF059669)),
    ThemePreset('forest', 'Forest', const Color(0xFF22C55E), const Color(0xFF166534)),
    ThemePreset('neon_green', 'Neon Green', const Color(0xFF84CC16), const Color(0xFF3F6212)),
    ThemePreset('spring', 'Spring', const Color(0xFF65A30D), const Color(0xFF365314)),
    ThemePreset('lemon', 'Lemon', const Color(0xFFEAB308), const Color(0xFFA16207)),
    ThemePreset('amber', 'Amber', const Color(0xFFF59E0B), const Color(0xFFB45309)),
    ThemePreset('sunset', 'Sunset', const Color(0xFFF97316), const Color(0xFFC2410C)),
    ThemePreset('coral', 'Coral', const Color(0xFFFF7043), const Color(0xFFD84315)),
    ThemePreset('crimson', 'Crimson', const Color(0xFFDC2626), const Color(0xFF991B1B)),
    ThemePreset('ruby', 'Ruby', const Color(0xFFE11D48), const Color(0xFF9F1239)),
    ThemePreset('hot_pink', 'Hot Pink', const Color(0xFFF43F5E), const Color(0xFFBE123C)),
    ThemePreset('fuchsia', 'Fuchsia', const Color(0xFFD946EF), const Color(0xFFA21CAF)),
    ThemePreset('violet', 'Violet', const Color(0xFF8B5CF6), const Color(0xFF6D28D9)),
    ThemePreset('purple', 'Purple', const Color(0xFFA855F7), const Color(0xFF7E22CE)),
    ThemePreset('lavender', 'Lavender', const Color(0xFFC084FC), const Color(0xFF9333EA)),
    ThemePreset('indigo_blue', 'Indigo Blue', const Color(0xFF6366F1), const Color(0xFF3730A3)),
    ThemePreset('periwinkle', 'Periwinkle', const Color(0xFF818CF8), const Color(0xFF4338CA)),
    ThemePreset('plum', 'Plum', const Color(0xFFA855F7), const Color(0xFF581C87)),
    ThemePreset('grape', 'Grape', const Color(0xFF7C3AED), const Color(0xFF4C1D95)),
    ThemePreset('copper', 'Copper', const Color(0xFFB87333), const Color(0xFF7C2D12)),
    ThemePreset('bronze', 'Bronze', const Color(0xFFCD7F32), const Color(0xFF78350F)),
    ThemePreset('champagne', 'Champagne', const Color(0xFFF1D18A), const Color(0xFF9A7B2F)),
    ThemePreset('white_blue', 'White + Blue', const Color(0xFF90CAF9), const Color(0xFF1565C0)),
    ThemePreset('white_red', 'White + Red', const Color(0xFFFF8A80), const Color(0xFFC62828)),
    ThemePreset('white_purple', 'White + Purple', const Color(0xFFCE93D8), const Color(0xFF7B1FA2)),
    ThemePreset('blue_purple', 'Blue + Purple', const Color(0xFF7C4DFF), const Color(0xFF1565C0)),
    ThemePreset('cyan_purple', 'Cyan + Purple', const Color(0xFF00BCD4), const Color(0xFF7C4DFF)),
    ThemePreset('green_blue', 'Green + Blue', const Color(0xFF00C853), const Color(0xFF1565C0)),
    ThemePreset('teal_blue', 'Teal + Blue', const Color(0xFF00BFA5), const Color(0xFF1976D2)),
    ThemePreset('orange_blue', 'Orange + Blue', const Color(0xFFFF9800), const Color(0xFF1565C0)),
    ThemePreset('red_blue', 'Red + Blue', const Color(0xFFEF4444), const Color(0xFF2563EB)),
    ThemePreset('pink_blue', 'Pink + Blue', const Color(0xFFEC4899), const Color(0xFF2563EB)),
    ThemePreset('gold_black', 'Gold + Black', const Color(0xFFFFD54F), const Color(0xFF8D6E00)),
    ThemePreset('silver_blue', 'Silver + Blue', const Color(0xFFB0BEC5), const Color(0xFF546E7A)),
    ThemePreset('ice_violet', 'Ice + Violet', const Color(0xFF67E8F9), const Color(0xFF7C3AED)),
    ThemePreset('neon_purple', 'Neon Purple', const Color(0xFFB026FF), const Color(0xFF6A00FF)),
    ThemePreset('neon_red', 'Neon Red', const Color(0xFFFF1744), const Color(0xFFB71C1C)),
    ThemePreset('neon_orange', 'Neon Orange', const Color(0xFFFF6D00), const Color(0xFFE65100)),
    ThemePreset('neon_cyan', 'Neon Cyan', const Color(0xFF00FFFF), const Color(0xFF008B8B)),

    // Tema tambahan yang sudah dipakai halaman ThemePickerPage.
    ThemePreset('black_shadow', 'Black Shadow', const Color(0xFFC8C8CE), const Color(0xFF24242A)),
    ThemePreset('obsidian', 'Obsidian Glass', const Color(0xFFBFC5D2), const Color(0xFF17191F)),
    ThemePreset('silver_mist', 'Silver Mist', const Color(0xFFD7D9E0), const Color(0xFF30343A)),
    ThemePreset('graphite', 'Soft Graphite', const Color(0xFFAEB4BC), const Color(0xFF34383E)),
    ThemePreset('midnight_steel', 'Midnight Steel', const Color(0xFFB6C8D8), const Color(0xFF263746)),
  ];

  /// Data tema untuk halaman ThemePickerPage.
  static final List<AppThemeData> allThemes = presets.map((preset) {
    final darkAccent = preset.accentDark;
    return AppThemeData(
      id: preset.id,
      name: preset.name,
      bg: const Color(0xFF090D14),
      accent: preset.accent,
      card: Color.lerp(const Color(0xFF182130), darkAccent, 0.08) ??
          const Color(0xFF182130),
      cardBorder: Color.lerp(
            const Color(0xFF3A485B),
            preset.accent,
            0.24,
          ) ??
          const Color(0xFF3A485B),
    );
  }).toList(growable: false);

  ThemePreset get current {
    return presets.firstWhere(
      (preset) => preset.id == themeId.value,
      orElse: () => presets.firstWhere((preset) => preset.id == 'navy'),
    );
  }

  AppThemeData get colors {
    return allThemes.firstWhere(
      (theme) => theme.id == themeId.value,
      orElse: () => allThemes.first,
    );
  }

  Color get accent => current.accent;
  Color get accentDark => current.accentDark;

  Color get accentMid =>
      Color.lerp(current.accentDark, current.accent, 0.45) ??
      current.accent;

  Color get accentSoft => accent.withOpacity(0.18);

  Color get accentFrost =>
      Color.lerp(accent, Colors.white, 0.45) ?? accent;

  Color get bg =>
      Color.lerp(const Color(0xFF090D14), accentDark, 0.07) ??
      const Color(0xFF090D14);

  Color get surface =>
      Color.lerp(const Color(0xFF111722), accentDark, 0.06) ??
      const Color(0xFF111722);

  Color get card =>
      Color.lerp(const Color(0xFF182130), accentDark, 0.07) ??
      const Color(0xFF182130);

  Color get border =>
      Color.lerp(const Color(0xFF293547), accent, 0.22) ??
      const Color(0xFF293547);

  Color get borderLit =>
      Color.lerp(const Color(0xFF3A485B), accent, 0.28) ??
      const Color(0xFF3A485B);

  Color get text => Colors.white;

  Color get textSub =>
      Color.lerp(Colors.white70, accent, 0.15) ?? Colors.white70;

  Color get textDim => Colors.white38;

  LinearGradient get btnGrad => LinearGradient(
        colors: [accentDark, accent],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedId = prefs.getString(_prefKey);

      if (savedId != null && presets.any((preset) => preset.id == savedId)) {
        themeId.value = savedId;
      }
    } catch (_) {
      // Tema default tetap bisa digunakan jika penyimpanan gagal.
    }
  }

  Future<void> setTheme(String id) async {
    if (!presets.any((preset) => preset.id == id)) return;

    if (themeId.value != id) {
      themeId.value = id;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefKey, id);
    } catch (_) {
      // Perubahan tema tetap berlaku selama aplikasi berjalan.
    }
  }

  ThemePreset? byId(String id) {
    for (final preset in presets) {
      if (preset.id == id) return preset;
    }
    return null;
  }

  @override
  void dispose() {
    themeId.removeListener(_handleThemeIdChanged);
    themeId.dispose();
    super.dispose();
  }
}

class ThemePreset {
  final String id;
  final String name;
  final Color accent;
  final Color accentDark;

  const ThemePreset(
    this.id,
    this.name,
    this.accent,
    this.accentDark,
  );

  LinearGradient get tileGrad => LinearGradient(
        colors: [
          Color.lerp(accent, Colors.black, 0.35) ?? accentDark,
          accent,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
}