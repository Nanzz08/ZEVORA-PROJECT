import 'dart:ui';

import 'package:flutter/material.dart';

import 'app_theme.dart';

/// Reusable Liquid Glass primitives shared by application screens.
/// These widgets are presentation-only and leave page state and callbacks intact.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final double blur;
  final double opacity;
  final Color? tint;
  final VoidCallback? onTap;

  const GlassPanel({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.radius = 22,
    this.blur = 12,
    this.opacity = 0.075,
    this.tint,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    final base = tint ?? theme.card;
    final glassOpacity = opacity.clamp(.025, .16).toDouble();
    final panel = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.lerp(base, Colors.white, .10)!.withOpacity((glassOpacity + .035).clamp(0, 1).toDouble()),
                base.withOpacity(glassOpacity),
                Color.lerp(base, theme.accentDark, .10)!.withOpacity((glassOpacity + .015).clamp(0, 1).toDouble()),
              ],
            ),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: Colors.white.withOpacity(.13), width: .8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.17),
                blurRadius: 20,
                spreadRadius: -4,
                offset: const Offset(0, 9),
              ),
              BoxShadow(
                color: theme.accent.withOpacity(.045),
                blurRadius: 18,
                spreadRadius: -8,
              ),
            ],
          ),
          child: Padding(padding: padding ?? EdgeInsets.zero, child: child),
        ),
      ),
    );

    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: onTap == null
          ? panel
          : PressScale(onTap: onTap, child: panel),
    );
  }
}

/// Thin translucent outline for custom cards and controls.
class LiquidBorder extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry? padding;
  final Color? accent;
  final double opacity;

  const LiquidBorder({
    super.key,
    required this.child,
    this.radius = 18,
    this.padding,
    this.accent,
    this.opacity = .16,
  });

  @override
  Widget build(BuildContext context) {
    final color = accent ?? AppTheme.I.accent;
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Colors.white.withOpacity(.11), width: .7),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            color.withOpacity(opacity),
            Colors.white.withOpacity(.025),
            color.withOpacity(opacity * .35),
          ],
        ),
      ),
      child: child,
    );
  }
}

/// Consistent glass action button. The caller retains ownership of the action.
class GlassButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onPressed;
  final EdgeInsetsGeometry padding;
  final double radius;
  final bool primary;

  const GlassButton({
    super.key,
    required this.child,
    required this.onPressed,
    this.padding = const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
    this.radius = 15,
    this.primary = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 160),
      opacity: onPressed == null ? .48 : 1,
      child: Material(
        color: primary ? theme.accent.withOpacity(.82) : Colors.white.withOpacity(.055),
        borderRadius: BorderRadius.circular(radius),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(radius),
          child: Ink(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: primary ? theme.accentFrost.withOpacity(.45) : Colors.white.withOpacity(.14),
                width: .8,
              ),
            ),
            child: Center(child: child),
          ),
        ),
      ),
    );
  }
}

/// Smooth press feedback without changing the original tap callback.
class PressScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const PressScale({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
  });

  @override
  State<PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<PressScale> {
  bool _down = false;

  void _set(bool value) {
    if (mounted && _down != value) setState(() => _down = value);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => _set(true),
      onTapCancel: () => _set(false),
      onTapUp: (_) => _set(false),
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _down ? .975 : 1,
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

/// Shared atmospheric background used behind the app Navigator.
class GlassBackdrop extends StatelessWidget {
  final Widget child;
  const GlassBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color.lerp(theme.bg, theme.accentDark, .12) ?? theme.bg,
            theme.bg,
            const Color(0xFF05070C),
          ],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Positioned(
            top: -110,
            right: -90,
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: theme.accent.withOpacity(.10), blurRadius: 110, spreadRadius: 35),
                  ],
                ),
                child: const SizedBox(width: 180, height: 180),
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}

/// Compact icon badge used by landing, authentication and splash surfaces.
class GlassIconBadge extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final double size;
  final double radius;

  const GlassIconBadge({
    super.key,
    required this.icon,
    this.color,
    this.size = 42,
    this.radius = 14,
  });

  @override
  Widget build(BuildContext context) {
    final accent = color ?? AppTheme.I.accentFrost;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accent.withOpacity(.22),
            Colors.white.withOpacity(.045),
          ],
        ),
        border: Border.all(color: Colors.white.withOpacity(.16), width: .8),
        boxShadow: [
          BoxShadow(color: accent.withOpacity(.13), blurRadius: 16, spreadRadius: -5),
        ],
      ),
      child: Icon(icon, color: accent, size: size * .48),
    );
  }
}

/// A reusable heading row with a glass icon and optional trailing content.
class GlassSectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Widget? trailing;

  const GlassSectionHeader({
    super.key,
    required this.title,
    required this.icon,
    this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GlassIconBadge(icon: icon, size: 40),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: .35)),
              if (subtitle != null) ...[
                const SizedBox(height: 3),
                Text(subtitle!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppTheme.I.textSub)),
              ],
            ],
          ),
        ),
        if (trailing != null) trailing!,
      ],
    );
  }
}
