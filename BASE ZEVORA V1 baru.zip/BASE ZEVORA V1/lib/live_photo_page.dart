import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';

/// Live Photo tool — pick a short video, preview, and save to gallery.
class LivePhotoPage extends StatefulWidget {
  const LivePhotoPage({super.key});

  @override
  State<LivePhotoPage> createState() => _LivePhotoPageState();
}

class _LivePhotoPageState extends State<LivePhotoPage> {
  static const _red = Color(0xFFE53935);
  static const _green = Color(0xFF16A34A);
  static const _bg = Color(0xFF050508);

  File? _video;
  VideoPlayerController? _ctrl;
  bool _ready = false;
  bool _saving = false;
  String? _fileName;
  double? _sizeMb;
  Duration _duration = Duration.zero;

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  Future<void> _pickVideo() async {
    final x = await ImagePicker().pickVideo(
      source: ImageSource.gallery,
      maxDuration: const Duration(seconds: 15),
    );
    if (x == null) return;
    await _loadVideo(File(x.path));
  }

  Future<void> _loadVideo(File f) async {
    await _ctrl?.dispose();
    final c = VideoPlayerController.file(f);
    await c.initialize();
    await c.setLooping(true);
    await c.play();
    final len = await f.length();
    if (!mounted) return;
    setState(() {
      _video = f;
      _ctrl = c;
      _ready = true;
      _fileName = f.path.split(Platform.pathSeparator).last;
      _sizeMb = len / (1024 * 1024);
      _duration = c.value.duration;
    });
  }

  Future<void> _remake() async {
    await _ctrl?.dispose();
    setState(() {
      _video = null;
      _ctrl = null;
      _ready = false;
      _fileName = null;
      _sizeMb = null;
      _duration = Duration.zero;
    });
    await _pickVideo();
  }

  Future<void> _save() async {
    if (_video == null || _saving) return;
    setState(() => _saving = true);
    try {
      // Copy to app docs then save to gallery
      final dir = await getApplicationDocumentsDirectory();
      final name =
          'ORTAX_LIVE_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final dest = File('${dir.path}/$name');
      await _video!.copy(dest.path);
      final ok = await GallerySaver.saveVideo(dest.path) ?? false;
      if (!mounted) return;
      HapticFeedback.mediumImpact();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(ok
              ? 'Live Photo disimpan ke galeri'
              : 'Gagal menyimpan. Cek izin penyimpanan.'),
          backgroundColor: ok ? _green : _red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: _red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            // App bar
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 12, 6),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new,
                        color: Colors.white70, size: 18),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Expanded(
                    child: Text(
                      'LIVE PHOTO',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _red,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.build_rounded,
                        color: Colors.white54, size: 20),
                    onPressed: _pickVideo,
                  ),
                ],
              ),
            ),
            // Red accent line
            Container(
              height: 3,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_red.withOpacity(0.2), _red, _red.withOpacity(0.2)],
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),

            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    // Selected video card
                    GestureDetector(
                      onTap: _pickVideo,
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: const Color(0xFF121218),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _red.withOpacity(0.45)),
                          boxShadow: [
                            BoxShadow(
                              color: _red.withOpacity(0.15),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    color: _red,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: _red.withOpacity(0.5),
                                        blurRadius: 12,
                                      ),
                                    ],
                                  ),
                                  child: Icon(
                                    _ready
                                        ? Icons.check_rounded
                                        : Icons.videocam_rounded,
                                    color: Colors.white,
                                    size: 26,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        _ready
                                            ? 'VIDEO TERPILIH'
                                            : 'PILIH VIDEO',
                                        style: TextStyle(
                                          color: _red.withOpacity(0.9),
                                          fontSize: 11,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 1,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        _fileName ??
                                            'Tap untuk pilih video dari galeri',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            if (!_ready) ...[
                              const SizedBox(height: 16),
                              Text(
                                'Tap untuk ganti video',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.35),
                                  fontSize: 12,
                                ),
                              ),
                            ] else ...[
                              const SizedBox(height: 12),
                              Text(
                                'Tap untuk ganti video',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.35),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Actions
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _ready ? _remake : null,
                            icon: const Icon(Icons.refresh_rounded, size: 18),
                            label: const Text('Buat Ulang',
                                style: TextStyle(fontWeight: FontWeight.w700)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _red,
                              foregroundColor: Colors.white,
                              disabledBackgroundColor: _red.withOpacity(0.3),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: _ready && !_saving ? _save : null,
                            icon: _saving
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2, color: Colors.white),
                                  )
                                : const Icon(Icons.download_rounded, size: 18),
                            label: Text(_saving ? 'Menyimpan...' : 'Simpan',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _green,
                              foregroundColor: Colors.white,
                              disabledBackgroundColor: _green.withOpacity(0.3),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14)),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 18),

                    // Preview card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0E0E14),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: _ready
                              ? _green.withOpacity(0.45)
                              : Colors.white10,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                _ready
                                    ? Icons.check_circle
                                    : Icons.hourglass_empty,
                                color: _ready ? _green : Colors.white38,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _ready ? 'LIVE PHOTO SIAP' : 'BELUM ADA VIDEO',
                                style: TextStyle(
                                  color: _ready ? Colors.white : Colors.white54,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 13,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const Spacer(),
                              if (_ready)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: _green.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                        color: _green.withOpacity(0.5)),
                                  ),
                                  child: const Text(
                                    'READY',
                                    style: TextStyle(
                                      color: _green,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: AspectRatio(
                              aspectRatio: 16 / 10,
                              child: _ctrl != null && _ctrl!.value.isInitialized
                                  ? Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        VideoPlayer(_ctrl!),
                                        Positioned(
                                          top: 10,
                                          left: 10,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: Colors.black54,
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                              border: Border.all(
                                                  color: _red.withOpacity(0.7)),
                                            ),
                                            child: const Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(Icons.circle,
                                                    color: _red, size: 8),
                                                SizedBox(width: 4),
                                                Text(
                                                  'LIVE',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w800,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    )
                                  : Container(
                                      color: const Color(0xFF1A1A22),
                                      child: Center(
                                        child: Icon(Icons.movie_creation_outlined,
                                            color: Colors.white24, size: 48),
                                      ),
                                    ),
                            ),
                          ),
                          if (_ready) ...[
                            const SizedBox(height: 14),
                            Row(
                              children: [
                                _stat(
                                  Icons.timer_outlined,
                                  'Durasi',
                                  '${(_duration.inMilliseconds / 1000).toStringAsFixed(2)}s',
                                ),
                                const SizedBox(width: 8),
                                _stat(
                                  Icons.insert_drive_file_outlined,
                                  'Ukuran',
                                  '${_sizeMb!.toStringAsFixed(2)} MB',
                                ),
                                const SizedBox(width: 8),
                                _stat(
                                  Icons.check_circle_outline,
                                  'Status',
                                  'OK',
                                  valueColor: _green,
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(IconData icon, String label, String value,
      {Color valueColor = Colors.white}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white38, size: 16),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(color: Colors.white38, fontSize: 10)),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                color: valueColor,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
