import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatAIPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const ChatAIPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<ChatAIPage> createState() => _ChatAIPageState();
}

class _ChatAIPageState extends State<ChatAIPage> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = false;
  String _activeProvider = 'ZEVORA PROJECT AI';
  bool _showWelcome = true;

  // Keys can be set via --dart-define or SharedPreferences
  static const String _envOpenAi =
      String.fromEnvironment('OPENAI_API_KEY', defaultValue: '');
  static const String _envGemini =
      String.fromEnvironment('GEMINI_API_KEY', defaultValue: '');

  String _openAiKey = '';
  String _geminiKey = '';

  // Black-Red theme colors matching the request
  static const Color _bg = Color(0xFF0A0A0A);
  static const Color _surface = Color(0xFF141414);
  static const Color _card = Color(0xFF1A1A1A);
  static const Color _accent = Color(0xFFE11D48); // bright red
  static const Color _accentDark = Color(0xFF9F1239);
  static const Color _inputBg = Color(0xFF1F0A0F); // dark red-ish
  static const Color _chipBg = Color(0xFF1F1F1F);
  static const Color _textSub = Color(0xFF9CA3AF);

  final String _systemPrompt = """Anda adalah asisten AI yang ramah, cerdas, dan membantu bernama "ZEVORA PROJECT AI". 
Anda dibuat oleh tim ZEVORA PROJECT untuk membantu user dengan berbagai pertanyaan.
Gunakan bahasa Indonesia yang baik dan benar.
Berikan jawaban yang informatif, akurat, dan membantu.
Jika ada pertanyaan tentang MLBB atau Free Fire, berikan tips dan trik yang berguna.
Jika ditanya tentang fitur aplikasi ZEVORA PROJECT, jelaskan: Dashboard, Bug Sender, ENJOY PLAY (musik), Tools, RAT, Bubble Bug.
Jangan pernah memberikan informasi berbahaya atau ilegal.
Bersikap profesional namun tetap ramah.""";

  // Suggestion chips matching the reference UI
  static const List<String> _suggestions = [
    'What is Flutter?',
    'Explain AI',
    'Write a poem',
    'Tell me a joke',
    'Help with code',
    'Latest technology',
    'What is Gemini?',
    'Programming tips',
  ];

  @override
  void initState() {
    super.initState();
    _loadKeys();
    // Start with empty messages so welcome screen shows.
    // Welcome greeting is handled by the centered UI.
  }

  Future<void> _loadKeys() async {
    final prefs = await SharedPreferences.getInstance();
    _openAiKey = prefs.getString('ai_openai_key') ?? _envOpenAi;
    _geminiKey = prefs.getString('ai_gemini_key') ?? _envGemini;
    if (_openAiKey.isEmpty) {
      _openAiKey = prefs.getString('openai_api_key') ?? '';
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── Offline fallback ─────────────────────────────────────
  String? _offlineReply(String input) {
    final q = input.toLowerCase().trim();
    if (q.isEmpty) return null;

    if (RegExp(r'^(hai|halo|hello|hi|hey|pagi|siang|sore|malam)\b').hasMatch(q) ||
        q.contains('halo ai') ||
        q == 'halo' ||
        q == 'hai') {
      return 'Halo ${widget.username}! 👋 Senang bisa membantu.\n\n'
          'Kamu bisa tanya tentang:\n'
          '• Tips MLBB / Free Fire\n'
          '• Coding & debugging\n'
          '• Fitur aplikasi ZEVORA PROJECT\n'
          '• Pertanyaan umum lainnya\n\n'
          'Ada yang ingin ditanyakan?';
    }

    if (q.contains('mlbb') ||
        q.contains('mobile legend') ||
        q.contains('mobile legends')) {
      return '🎮 **Tips MLBB cepat:**\n\n'
          '1. Pelajari rotation jungle & lane sesuai role\n'
          '2. Jangan solo push tanpa vision\n'
          '3. Prioritaskan objective (Turtle/Lord) daripada kill\n'
          '4. Build item lawan komposisi musuh\n'
          '5. Komunikasi tim > hero op\n\n'
          'Mau tips hero tertentu? Sebutkan namanya!';
    }

    if (q.contains('free fire') || q.contains('freefire') || q == 'ff') {
      return '🔥 **Tips Free Fire:**\n\n'
          '1. Landing di tempat aman dulu, loot cepat\n'
          '2. Jaga audio — footstep musuh penting\n'
          '3. Gunakan cover, jangan stand di open field\n'
          '4. Combine SMG + AR sesuai jarak\n'
          '5. Latihan aim di training mode rutin\n\n'
          'Mau tips ranked atau character tertentu?';
    }

    if (q.contains('ortax') ||
        q.contains('fitur') ||
        q.contains('cara pakai') ||
        q.contains('bantuan') ||
        q.contains('help')) {
      return '📱 **Fitur ZEVORA PROJECT singkat:**\n\n'
          '• **Dashboard** — beranda utama\n'
          '• **Bug Sender** / **Bubble Bug** — kirim via sender WA\n'
          '• **ENJOY PLAY** — musik (search, favorit, library)\n'
          '• **Tools** — scanner, OSINT, browser, dll\n'
          '• **RAT** — panel remote\n'
          '• **Tema** — ganti tampilan\n\n'
          'Gunakan menu Dashboard untuk mengakses fitur dan pintasan aplikasi.';
    }

    if (q.contains('coding') ||
        q.contains('flutter') ||
        q.contains('dart') ||
        q.contains('program')) {
      return '💻 Siap bantu coding!\n\n'
          'Jelaskan masalahmu (error message, bahasa, atau cuplikan kode). '
          'Contoh: "Flutter setState tidak update UI" atau "cara HTTP POST di Dart".';
    }

    if (q.contains('terima kasih') || q.contains('makasih') || q == 'thanks') {
      return 'Sama-sama! 😊 Kalau butuh bantuan lagi, tinggal chat ya.';
    }

    if (q.contains('gemini') || q.contains('what is gemini')) {
      return 'Gemini adalah model AI generatif dari Google. '
          'Saya (ZEVORA PROJECT AI) dapat menggunakan Gemini sebagai salah satu provider backend '
          'untuk memberikan jawaban yang cerdas dan cepat.';
    }

    if (q.contains('joke') || q.contains('lelucon') || q.contains('humor')) {
      return 'Kenapa programmer selalu bingung dengan Natal?\n\n'
          'Karena dia tidak suka "null" (noël) 😄';
    }

    if (q.contains('poem') || q.contains('puisi')) {
      return 'Di layar gelap, kode mengalir,\n'
          'Bug bersembunyi, debug menanti.\n'
          'Satu commit, satu harapan,\n'
          'Aplikasi hidup, dunia pun terang. ✨';
    }

    if (q.length < 40) {
      return 'Aku terima pesanmu: "$input"\n\n'
          'Saat ini mode offline/local aktif (API cloud sedang terbatas). '
          'Coba tanya lebih spesifik, misalnya:\n'
          '• "tips mlbb assassin"\n'
          '• "cara pakai enjoy play"\n'
          '• "bantuan coding flutter"\n\n'
          'Atau atur API key Gemini/OpenAI di menu ⋮ → Set API Key.';
    }

    return null;
  }

  Future<String> _callGemini(List<Map<String, String>> history) async {
    final key = _geminiKey.trim();
    if (key.isEmpty) throw Exception('no_gemini_key');

    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$key',
    );

    final contents = <Map<String, dynamic>>[];
    for (final m in history) {
      if (m['role'] == 'system') continue;
      contents.add({
        'role': m['role'] == 'assistant' ? 'model' : 'user',
        'parts': [
          {'text': m['content']}
        ],
      });
    }

    final body = {
      'system_instruction': {
        'parts': [
          {'text': _systemPrompt}
        ]
      },
      'contents': contents,
      'generationConfig': {
        'maxOutputTokens': 1024,
        'temperature': 0.7,
      },
    };

    final res = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 45));

    if (res.statusCode == 429) throw Exception('rate_limit_gemini');
    if (res.statusCode == 401 || res.statusCode == 403) {
      throw Exception('auth_gemini');
    }
    if (res.statusCode != 200) throw Exception('gemini_${res.statusCode}');

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final candidates = data['candidates'];
    if (candidates is List && candidates.isNotEmpty) {
      final content = candidates.first['content'];
      if (content is Map) {
        final parts = content['parts'];
        if (parts is List && parts.isNotEmpty) {
          final text = parts.first['text']?.toString() ?? '';
          if (text.trim().isNotEmpty) return text.trim();
        }
      }
    }
    throw Exception('gemini_empty');
  }

  Future<String> _callOpenAI(List<Map<String, String>> history) async {
    final key = _openAiKey.trim();
    if (key.isEmpty) throw Exception('no_openai_key');

    final uri = Uri.parse('https://api.openai.com/v1/chat/completions');

    final messages = history
        .map((m) => {
              'role': m['role'],
              'content': m['content'],
            })
        .toList();

    Future<http.Response> doPost() {
      return http
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $key',
            },
            body: jsonEncode({
              'model': 'gpt-4o-mini',
              'messages': messages,
              'max_tokens': 1000,
              'temperature': 0.7,
            }),
          )
          .timeout(const Duration(seconds: 45));
    }

    http.Response? res;
    for (var attempt = 0; attempt < 3; attempt++) {
      res = await doPost();
      if (res.statusCode != 429) break;
      await Future.delayed(Duration(seconds: 2 * (attempt + 1)));
    }

    if (res == null) throw Exception('openai_null');
    if (res.statusCode == 429) throw Exception('rate_limit_openai');
    if (res.statusCode == 401) throw Exception('auth_openai');
    if (res.statusCode != 200) throw Exception('openai_${res.statusCode}');

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final choices = data['choices'];
    if (choices is List && choices.isNotEmpty) {
      final msg = choices.first['message'];
      if (msg is Map) {
        final content = msg['content']?.toString() ?? '';
        if (content.trim().isNotEmpty) return content.trim();
      }
    }
    throw Exception('openai_empty');
  }

  Future<void> _sendMessage([String? preset]) async {
    final text = (preset ?? _messageController.text).trim();
    if (text.isEmpty || _isLoading) return;

    setState(() {
      _showWelcome = false;
      _messages.add({
        'role': 'user',
        'content': text,
        'timestamp': DateTime.now(),
      });
      _isLoading = true;
      _messageController.clear();
    });
    _scrollToBottom();

    final userMessage = text;

    try {
      final chatHistory = <Map<String, String>>[
        {'role': 'system', 'content': _systemPrompt},
      ];
      final start = _messages.length > 12 ? _messages.length - 12 : 0;
      for (var i = start; i < _messages.length; i++) {
        final role = _messages[i]['role']?.toString() ?? 'user';
        if (role == 'system') continue;
        chatHistory.add({
          'role': role,
          'content': _messages[i]['content']?.toString() ?? '',
        });
      }

      String? reply;
      String provider = 'Offline';

      // 1) Gemini
      try {
        if (_geminiKey.trim().isNotEmpty) {
          reply = await _callGemini(chatHistory);
          provider = 'Gemini';
        }
      } catch (e) {
        debugPrint('Gemini fail: $e');
      }

      // 2) OpenAI
      if (reply == null || reply.isEmpty) {
        try {
          if (_openAiKey.trim().isNotEmpty) {
            reply = await _callOpenAI(chatHistory);
            provider = 'OpenAI';
          }
        } catch (e) {
          debugPrint('OpenAI fail: $e');
        }
      }

      // 3) Offline fallback
      if (reply == null || reply.isEmpty) {
        reply = _offlineReply(userMessage);
        provider = 'Offline';
      }

      if (reply == null || reply.isEmpty) {
        reply =
            'Maaf, semua provider AI sedang sibuk atau belum dikonfigurasi.\n\n'
            'Solusi:\n'
            '1. Buka menu ⋮ → **Set API Key**\n'
            '2. Isi Gemini API key (gratis di Google AI Studio)\n'
            '3. Atau coba lagi dalam beberapa detik\n\n'
            'Sementara kamu masih bisa tanya tips MLBB, Free Fire, atau fitur ZEVORA PROJECT.';
        provider = 'Fallback';
      }

      if (mounted) {
        setState(() {
          _activeProvider = provider == 'Offline' || provider == 'Fallback'
              ? 'ZEVORA PROJECT AI (local)'
              : 'ZEVORA PROJECT AI · $provider';
          _messages.add({
            'role': 'assistant',
            'content': reply,
            'timestamp': DateTime.now(),
          });
        });
      }
    } catch (e) {
      final offline = _offlineReply(userMessage);
      if (mounted) {
        setState(() {
          _messages.add({
            'role': 'assistant',
            'content': offline ??
                '⚠️ Gagal terhubung. Coba lagi atau atur API key di menu ⋮.\n\nDetail: $e',
            'timestamp': DateTime.now(),
          });
        });
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
        _scrollToBottom();
      }
    }
  }

  void _clearChat() {
    setState(() {
      _messages.clear();
      _showWelcome = true;
      _activeProvider = 'ZEVORA PROJECT AI';
    });
  }

  void _showSetApiKey() {
    final geminiCtrl = TextEditingController(text: _geminiKey);
    final openAiCtrl = TextEditingController(text: _openAiKey);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        title: const Text('Set API Key', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: geminiCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Gemini API Key',
                  labelStyle: const TextStyle(color: _textSub),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _accent.withOpacity(0.4)),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: _accent),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: openAiCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'OpenAI API Key (opsional)',
                  labelStyle: const TextStyle(color: _textSub),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _accent.withOpacity(0.4)),
                  ),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: _accent),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: _textSub)),
          ),
          TextButton(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('ai_gemini_key', geminiCtrl.text.trim());
              await prefs.setString('ai_openai_key', openAiCtrl.text.trim());
              _geminiKey = geminiCtrl.text.trim();
              _openAiKey = openAiCtrl.text.trim();
              if (mounted) {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('API key disimpan'),
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: _accentDark,
                  ),
                );
              }
            },
            child: const Text('Simpan', style: TextStyle(color: _accent)),
          ),
        ],
      ),
    );
  }

  void _showAttachMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo, color: _accent),
              title: const Text('Foto', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                _attachImage();
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: _accent),
              title: const Text('Video', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                _attachVideo();
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file, color: _accent),
              title: const Text('Dokumen / File',
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                _attachFile();
              },
            ),
            ListTile(
              leading: const Icon(Icons.audiotrack, color: _accent),
              title: const Text('Musik / Lagu',
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(ctx);
                _attachAudio();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _attachImage() async {
    final p = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (p == null) return;
    setState(() {
      _showWelcome = false;
      _messages.add({
        'role': 'user',
        'content': '📷 [Foto] ${p.name}',
        'timestamp': DateTime.now(),
      });
    });
    _scrollToBottom();
    _messageController.text =
        'Saya mengirim foto. Tolong bantu analisis atau deskripsikan.';
  }

  Future<void> _attachVideo() async {
    final p = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (p == null) return;
    setState(() {
      _showWelcome = false;
      _messages.add({
        'role': 'user',
        'content': '🎬 [Video] ${p.name}',
        'timestamp': DateTime.now(),
      });
    });
    _scrollToBottom();
  }

  Future<void> _attachFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    setState(() {
      _showWelcome = false;
      _messages.add({
        'role': 'user',
        'content': '📄 [File] ${f.name}',
        'timestamp': DateTime.now(),
      });
    });
    _scrollToBottom();
  }

  Future<void> _attachAudio() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    setState(() {
      _showWelcome = false;
      _messages.add({
        'role': 'user',
        'content': '🎵 [Audio] ${f.name}',
        'timestamp': DateTime.now(),
      });
    });
    _scrollToBottom();
  }

  // ─── Welcome Screen (matches reference photo) ─────────────
  Widget _buildWelcome() {
    return Expanded(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Column(
          children: [
            const SizedBox(height: 40),
            // Central logo circle
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _card,
                border: Border.all(color: _accent.withOpacity(0.5), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _accent.withOpacity(0.25),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Center(
                child: Text(
                  'O',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    letterSpacing: -1,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 28),
            const Text(
              'ZEVORA PROJECT AI ASSISTANT',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Ask me anything',
              style: TextStyle(
                color: _textSub,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 36),
            // Suggestion chips
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: _suggestions.map((s) {
                return GestureDetector(
                  onTap: () => _sendMessage(s),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: _chipBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.08),
                      ),
                    ),
                    child: Text(
                      s,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  // ─── Message list ─────────────────────────────────────────
  Widget _buildMessageList() {
    return Expanded(
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        itemCount: _messages.length + (_isLoading ? 1 : 0),
        itemBuilder: (context, index) {
          if (_isLoading && index == _messages.length) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _card,
                      border: Border.all(color: _accent.withOpacity(0.4)),
                    ),
                    child: const Center(
                      child: Text('O',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _accent,
                    ),
                  ),
                ],
              ),
            );
          }

          final message = _messages[index];
          final isUser = message['role'] == 'user';
          final content = message['content']?.toString() ?? '';

          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Row(
              mainAxisAlignment:
                  isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (!isUser) ...[
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _card,
                      border: Border.all(color: _accent.withOpacity(0.5)),
                    ),
                    child: const Center(
                      child: Text('O',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14)),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isUser ? _accentDark : _card,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: Radius.circular(isUser ? 16 : 4),
                        bottomRight: Radius.circular(isUser ? 4 : 16),
                      ),
                      border: isUser
                          ? null
                          : Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Text(
                      content,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14.5,
                        height: 1.4,
                      ),
                    ),
                  ),
                ),
                if (isUser) const SizedBox(width: 4),
              ],
            ),
          );
        },
      ),
    );
  }

  // ─── Top header bar (matches photo) ───────────────────────
  Widget _buildHeader() {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: _surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
          ),
          child: Row(
            children: [
              // Logo circle
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _card,
                  border: Border.all(color: _accent.withOpacity(0.6)),
                ),
                child: const Center(
                  child: Text(
                    'O',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ZEVORA PROJECT Ai',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        letterSpacing: 0.3,
                      ),
                    ),
                    Text(
                      'Powered by ZEVORA PROJECT',
                      style: TextStyle(
                        color: _textSub,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              // Menu
              PopupMenuButton<String>(
                icon: Icon(Icons.more_vert, color: Colors.white.withOpacity(0.7)),
                color: _card,
                onSelected: (v) {
                  if (v == 'key') _showSetApiKey();
                  if (v == 'clear') _clearChat();
                  if (v == 'about') {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        backgroundColor: _card,
                        title: const Text('About',
                            style: TextStyle(color: Colors.white)),
                        content: const Text(
                          'ZEVORA PROJECT AI Assistant\nMulti-provider: Gemini → OpenAI → Offline fallback.\nTema hitam-merah.',
                          style: TextStyle(color: Colors.grey),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('OK',
                                style: TextStyle(color: _accent)),
                          ),
                        ],
                      ),
                    );
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(
                    value: 'key',
                    child: Row(
                      children: [
                        Icon(Icons.vpn_key, size: 18, color: Colors.white70),
                        SizedBox(width: 10),
                        Text('Set API Key',
                            style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'clear',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline,
                            size: 18, color: Colors.white70),
                        SizedBox(width: 10),
                        Text('Clear Chat',
                            style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'about',
                    child: Row(
                      children: [
                        Icon(Icons.info_outline,
                            size: 18, color: Colors.white70),
                        SizedBox(width: 10),
                        Text('About', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Bottom input bar (matches photo) ─────────────────────
  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(
        12,
        8,
        12,
        MediaQuery.of(context).padding.bottom + 10,
      ),
      color: _bg,
      child: Row(
        children: [
          // Attach button
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: _showAttachMenu,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _surface,
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Icon(Icons.add, color: Colors.white.withOpacity(0.7), size: 22),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Text field with red-ish background
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _inputBg,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _accent.withOpacity(0.35)),
              ),
              child: TextField(
                controller: _messageController,
                style: const TextStyle(color: Colors.white, fontSize: 15),
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendMessage(),
                maxLines: 4,
                minLines: 1,
                decoration: InputDecoration(
                  hintText: 'Type your message...',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.35)),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 18, vertical: 12),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Send button
          Material(
            color: _accent,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: _isLoading ? null : () => _sendMessage(),
              child: const Padding(
                padding: EdgeInsets.all(11),
                child: Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          _buildHeader(),
          if (_showWelcome && _messages.isEmpty)
            _buildWelcome()
          else
            _buildMessageList(),
          _buildInputBar(),
        ],
      ),
    );
  }
}
