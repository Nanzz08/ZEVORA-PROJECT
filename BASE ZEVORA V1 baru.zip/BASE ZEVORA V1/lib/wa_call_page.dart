import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// WhatsApp-style voice / video call UI
/// (local simulation — full WebRTC needs signaling server)
class WaCallPage extends StatefulWidget {
  final String peerName;
  final String? peerAvatarUrl;
  final bool isVideo;
  final bool isOutgoing;

  const WaCallPage({
    super.key,
    required this.peerName,
    this.peerAvatarUrl,
    required this.isVideo,
    this.isOutgoing = true,
  });

  @override
  State<WaCallPage> createState() => _WaCallPageState();
}

enum _CallPhase { ringing, connecting, connected, ended }

class _WaCallPageState extends State<WaCallPage>
    with TickerProviderStateMixin {
  static const _waGreen = Color(0xFF25D366);
  static const _waDark = Color(0xFF0B141A);
  static const _waSurface = Color(0xFF1F2C34);

  bool _muted = false;
  bool _speaker = true;
  bool _camOff = false;
  bool _frontCam = true;
  _CallPhase _phase = _CallPhase.ringing;
  int _seconds = 0;
  Timer? _timer;
  Timer? _connectTimer;

  late AnimationController _pulse;
  late AnimationController _ring;

  bool _noAnswer = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _ring = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    // Real call semantics: keep ringing until peer answers.
    // Without a signaling/WebRTC backend we cannot know if the peer
    // actually picked up — so we NEVER auto-connect. After a timeout
    // we report the user as offline / not answering.
    if (widget.isOutgoing) {
      _connectTimer = Timer(const Duration(seconds: 25), () {
        if (!mounted || _phase == _CallPhase.ended) return;
        setState(() {
          _noAnswer = true;
          _phase = _CallPhase.ended;
        });
        Future.delayed(const Duration(milliseconds: 1800), () {
          if (mounted) Navigator.pop(context);
        });
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _connectTimer?.cancel();
    _pulse.dispose();
    _ring.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  String get _duration {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String get _statusText {
    switch (_phase) {
      case _CallPhase.ringing:
        return widget.isOutgoing ? 'Memanggil…' : 'Panggilan masuk…';
      case _CallPhase.connecting:
        return 'Menghubungkan…';
      case _CallPhase.connected:
        return _duration;
      case _CallPhase.ended:
        return _noAnswer
            ? 'User tidak sedang online'
            : 'Panggilan berakhir';
    }
  }

  void _endCall() {
    _timer?.cancel();
    _connectTimer?.cancel();
    setState(() => _phase = _CallPhase.ended);
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: widget.isVideo ? _buildVideoLayout() : _buildVoiceLayout(),
    );
  }

  // ─── VOICE ────────────────────────────────────────────────
  Widget _buildVoiceLayout() {
    return SafeArea(
      child: Column(
        children: [
          const SizedBox(height: 48),
          Text(
            widget.isVideo ? 'Panggilan video' : 'Panggilan suara WhatsApp',
            style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 13),
          ),
          const SizedBox(height: 28),
          // Pulsing avatar
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) {
              final scale = 1.0 + (_pulse.value * 0.06);
              return Transform.scale(
                scale: scale,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (_phase == _CallPhase.ringing ||
                        _phase == _CallPhase.connecting)
                      AnimatedBuilder(
                        animation: _ring,
                        builder: (_, __) {
                          final t = _ring.value;
                          return Container(
                            width: 140 + t * 40,
                            height: 140 + t * 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: _waGreen.withOpacity(0.35 * (1 - t)),
                                width: 2,
                              ),
                            ),
                          );
                        },
                      ),
                    _avatar(64),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 28),
          Text(
            widget.peerName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 10),
          Text(
            _statusText,
            style: TextStyle(
              color: _mutedOrGreen(),
              fontSize: 15,
            ),
          ),
          if (_muted && _phase == _CallPhase.connected) ...[
            const SizedBox(height: 8),
            const Text(
              'Mikrofon dimatikan',
              style: TextStyle(color: Colors.orangeAccent, fontSize: 13),
            ),
          ],
          const Spacer(),
          _controlsRow(voice: true),
          const SizedBox(height: 48),
        ],
      ),
    );
  }

  // ─── VIDEO ────────────────────────────────────────────────
  Widget _buildVideoLayout() {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Remote "video" area
        Container(
          color: Colors.black,
          child: _camOff
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _avatar(48),
                      const SizedBox(height: 12),
                      Text(
                        widget.peerName,
                        style: const TextStyle(color: Colors.white70, fontSize: 18),
                      ),
                      const SizedBox(height: 6),
                      Text(_statusText,
                          style: TextStyle(color: _mutedOrGreen())),
                    ],
                  ),
                )
              : CustomPaint(
                  painter: _VideoNoisePainter(
                    seed: _seconds,
                    accent: _waGreen,
                  ),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.person,
                            size: 96, color: Colors.white.withOpacity(0.15)),
                        const SizedBox(height: 8),
                        Text(
                          widget.peerName,
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ),
        ),

        // Top bar
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  const Icon(Icons.lock, color: Colors.white54, size: 14),
                  const SizedBox(width: 6),
                  Text(
                    'End-to-end encrypted',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.55), fontSize: 12),
                  ),
                  const Spacer(),
                  Text(
                    _statusText,
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Self PiP
        Positioned(
          top: MediaQuery.of(context).padding.top + 48,
          right: 16,
          child: GestureDetector(
            onTap: () => setState(() => _frontCam = !_frontCam),
            child: Container(
              width: 110,
              height: 160,
              decoration: BoxDecoration(
                color: _waSurface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: _camOff
                  ? const Center(
                      child: Icon(Icons.videocam_off,
                          color: Colors.white54, size: 32),
                    )
                  : Stack(
                      fit: StackFit.expand,
                      children: [
                        CustomPaint(
                          painter: _VideoNoisePainter(
                            seed: _seconds + 7,
                            accent: Colors.blueAccent,
                          ),
                        ),
                        const Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: EdgeInsets.all(6),
                            child: Text('Anda',
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 11)),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),

        // Bottom controls
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).padding.bottom + 24,
              top: 20,
            ),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(0.75),
                ],
              ),
            ),
            child: _controlsRow(voice: false),
          ),
        ),
      ],
    );
  }

  Color _mutedOrGreen() {
    if (_phase == _CallPhase.connected) return _waGreen;
    return Colors.white60;
  }

  Widget _avatar(double radius) {
    final letter =
        widget.peerName.isNotEmpty ? widget.peerName[0].toUpperCase() : '?';
    if (widget.peerAvatarUrl != null && widget.peerAvatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: NetworkImage(widget.peerAvatarUrl!),
        onBackgroundImageError: (_, __) {},
        child: null,
      );
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: const Color(0xFF2A3942),
      child: Text(
        letter,
        style: TextStyle(
          color: Colors.white,
          fontSize: radius * 0.7,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _controlsRow({required bool voice}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _btn(
            icon: _muted ? Icons.mic_off : Icons.mic,
            label: _muted ? 'Unmute' : 'Mute',
            active: _muted,
            activeColor: Colors.white,
            onTap: () => setState(() => _muted = !_muted),
          ),
          if (!voice)
            _btn(
              icon: _camOff ? Icons.videocam_off : Icons.videocam,
              label: _camOff ? 'Kamera on' : 'Kamera off',
              active: _camOff,
              activeColor: Colors.white,
              onTap: () => setState(() => _camOff = !_camOff),
            ),
          if (!voice)
            _btn(
              icon: Icons.cameraswitch,
              label: 'Balik',
              onTap: () => setState(() => _frontCam = !_frontCam),
            ),
          if (voice)
            _btn(
              icon: _speaker ? Icons.volume_up : Icons.volume_off,
              label: _speaker ? 'Speaker' : 'Earpiece',
              active: _speaker,
              activeColor: _waGreen,
              onTap: () => setState(() => _speaker = !_speaker),
            ),
          if (voice)
            _btn(
              icon: Icons.person_add_alt_1,
              label: 'Tambah',
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Tambah peserta segera hadir'),
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
          _btn(
            icon: Icons.call_end,
            label: 'Akhiri',
            color: const Color(0xFFE11D48),
            iconColor: Colors.white,
            onTap: _endCall,
          ),
        ],
      ),
    );
  }

  Widget _btn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
    Color? iconColor,
    bool active = false,
    Color activeColor = Colors.white,
  }) {
    final bg = color ??
        (active ? activeColor.withOpacity(0.95) : _waSurface);
    final ic = iconColor ??
        (active && color == null ? Colors.black87 : Colors.white);
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: bg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(
              width: 58,
              height: 58,
              child: Icon(icon, color: ic, size: 26),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.75),
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

/// Soft animated background for video simulation
class _VideoNoisePainter extends CustomPainter {
  final int seed;
  final Color accent;

  _VideoNoisePainter({required this.seed, required this.accent});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    final rnd = math.Random(seed);
    // gradient base
    final rect = Offset.zero & size;
    paint.shader = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        const Color(0xFF1A2332),
        Color.lerp(const Color(0xFF0B141A), accent, 0.15)!,
        const Color(0xFF111B21),
      ],
    ).createShader(rect);
    canvas.drawRect(rect, paint);

    paint.shader = null;
    for (var i = 0; i < 18; i++) {
      paint.color = accent.withOpacity(0.03 + rnd.nextDouble() * 0.04);
      canvas.drawCircle(
        Offset(rnd.nextDouble() * size.width, rnd.nextDouble() * size.height),
        20 + rnd.nextDouble() * 60,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _VideoNoisePainter old) => old.seed != seed;
}
