import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// WhatsApp-style profile editor
class WaProfilePage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const WaProfilePage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<WaProfilePage> createState() => _WaProfilePageState();
}

class _WaProfilePageState extends State<WaProfilePage> {
  static const _green = Color(0xFF25D366);
  static const _bg = Color(0xFFFFFFFF);
  static const _text = Color(0xFF111B21);
  static const _muted = Color(0xFF667781);
  static const _hint = Color(0xFF008069);

  File? _photo;
  String? _photoPath;
  final _nameCtrl = TextEditingController();
  final _aboutCtrl = TextEditingController();
  final _handleCtrl = TextEditingController(); // username with #
  final _roleCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _roleCtrl.text = widget.role;
    _handleCtrl.text = widget.username;
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final u = widget.username;
    setState(() {
      _nameCtrl.text = p.getString('wa_name_$u') ?? widget.username;
      _aboutCtrl.text = p.getString('wa_about_$u') ?? '';
      _handleCtrl.text = p.getString('wa_handle_$u') ?? widget.username;
      _roleCtrl.text = p.getString('wa_role_$u') ?? widget.role;
      _photoPath = p.getString('profile_image_$u') ??
          p.getString('wa_photo_$u');
      if (_photoPath != null && File(_photoPath!).existsSync()) {
        _photo = File(_photoPath!);
      }
    });
  }

  Future<void> _saveField(String key, String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, value);
  }

  Future<void> _pickPhoto() async {
    final x = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (x == null) return;
    final file = File(x.path);
    final p = await SharedPreferences.getInstance();
    await p.setString('profile_image_${widget.username}', x.path);
    await p.setString('wa_photo_${widget.username}', x.path);
    setState(() {
      _photo = file;
      _photoPath = x.path;
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Foto profil diperbarui'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _editText({
    required String title,
    required TextEditingController ctrl,
    required String prefKey,
    String? hint,
    int maxLines = 1,
    int? maxLength,
  }) async {
    final temp = TextEditingController(text: ctrl.text);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: temp,
          maxLines: maxLines,
          maxLength: maxLength,
          autofocus: true,
          decoration: InputDecoration(
            hintText: hint,
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Simpan', style: TextStyle(color: _green)),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => ctrl.text = temp.text.trim());
      await _saveField(prefKey, ctrl.text);
    }
  }

  Widget _tile({
    required IconData icon,
    required String title,
    required String value,
    required VoidCallback onTap,
    String? placeholder,
  }) {
    final empty = value.isEmpty;
    return ListTile(
      leading: Icon(icon, color: _muted),
      title: Text(title, style: const TextStyle(color: _muted, fontSize: 13)),
      subtitle: Text(
        empty ? (placeholder ?? '') : value,
        style: TextStyle(
          color: empty ? _hint : _text,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
    );
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _aboutCtrl.dispose();
    _handleCtrl.dispose();
    _roleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.username;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _text),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Profil', style: TextStyle(color: _text)),
      ),
      body: ListView(
        children: [
          const SizedBox(height: 12),
          // Avatar
          Center(
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 64,
                  backgroundColor: const Color(0xFFDFE5E7),
                  backgroundImage: _photo != null ? FileImage(_photo!) : null,
                  child: _photo == null
                      ? const Icon(Icons.person, size: 72, color: Colors.white)
                      : null,
                ),
                Positioned(
                  right: 4,
                  bottom: 4,
                  child: GestureDetector(
                    onTap: _pickPhoto,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: const BoxDecoration(
                        color: _green,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.camera_alt,
                          color: Colors.white, size: 20),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Banner tips
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFE7FCE3),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.lightbulb_outline, color: _green, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Nama, foto, dan tentang terlihat oleh pengguna lain sesuai pengaturan privasi Anda.',
                    style: TextStyle(color: Colors.green.shade900, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),

          _tile(
            icon: Icons.person_outline,
            title: 'Nama',
            value: _nameCtrl.text,
            placeholder: 'Atur nama samaran',
            onTap: () => _editText(
              title: 'Nama',
              ctrl: _nameCtrl,
              prefKey: 'wa_name_$u',
              hint: 'Nama yang ditampilkan',
              maxLength: 40,
            ),
          ),
          const Divider(height: 1),
          _tile(
            icon: Icons.info_outline,
            title: 'Tentang',
            value: _aboutCtrl.text,
            placeholder: 'Atur isi Tentang',
            onTap: () => _editText(
              title: 'Tentang',
              ctrl: _aboutCtrl,
              prefKey: 'wa_about_$u',
              hint: 'Bio / status singkat',
              maxLines: 3,
              maxLength: 139,
            ),
          ),
          const Divider(height: 1),
          _tile(
            icon: Icons.alternate_email,
            title: 'Nama pengguna',
            value: _handleCtrl.text.isEmpty
                ? ''
                : (_handleCtrl.text.startsWith('#')
                    ? _handleCtrl.text
                    : '#${_handleCtrl.text}'),
            placeholder: 'Pesan nama pengguna (#hashtag)',
            onTap: () async {
              await _editText(
                title: 'Nama pengguna',
                ctrl: _handleCtrl,
                prefKey: 'wa_handle_$u',
                hint: 'contoh: rizz atau #rizz',
                maxLength: 24,
              );
              // normalize hashtag
              var h = _handleCtrl.text.trim().replaceAll(' ', '');
              if (h.isNotEmpty && !h.startsWith('#')) h = '#$h';
              setState(() => _handleCtrl.text = h);
              await _saveField('wa_handle_$u', h);
            },
          ),
          const Divider(height: 1),
          _tile(
            icon: Icons.badge_outlined,
            title: 'Role',
            value: _roleCtrl.text,
            placeholder: 'Atur role',
            onTap: () => _editText(
              title: 'Role',
              ctrl: _roleCtrl,
              prefKey: 'wa_role_$u',
              hint: 'contoh: DEVELOPER, MEMBER',
              maxLength: 30,
            ),
          ),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              'Username login: ${widget.username}\nSession: ${widget.sessionKey.length > 8 ? '${widget.sessionKey.substring(0, 8)}…' : widget.sessionKey}',
              style: const TextStyle(color: _muted, fontSize: 12),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
