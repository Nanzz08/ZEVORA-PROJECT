import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:chewie/chewie.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fiona/Qaxer/api.dart';
import 'premium_service.dart';
import 'wa_call_page.dart';
import 'typing_indicator.dart';
import 'message_actions.dart';
import 'app_theme.dart';

final baseUrl = Api.api;

// ==========================================================
// HELPER FUNCTIONS
// ==========================================================
String _getWsUrl() {
  String url = Api.api;
  if (url.startsWith('https')) return 'wss://${url.substring(8)}';
  if (url.startsWith('http')) return 'ws://${url.substring(7)}';
  return 'ws://amelcantik.rexypediaa.biz.id:25566';
}

bool _isImageUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  final lower = url.toLowerCase();
  return lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.png') || lower.endsWith('.gif') || lower.endsWith('.webp');
}

bool _isVideoUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  final lower = url.toLowerCase().split('?').first;
  if (lower.endsWith('.mp4') ||
      lower.endsWith('.mov') ||
      lower.endsWith('.avi') ||
      lower.endsWith('.webm') ||
      lower.endsWith('.mkv') ||
      lower.endsWith('.3gp') ||
      lower.endsWith('.m4v')) {
    return true;
  }
  // Path tanpa ekstensi tapi jelas video (upload-video / type=video)
  if (lower.contains('/upload-video') ||
      lower.contains('/videos/') ||
      lower.contains('type=video')) {
    return true;
  }
  return false;
}

bool _isAudioUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  if (url.startsWith('__VN__') || url.startsWith('[VN]') || url.startsWith('voice://')) {
    return true;
  }
  final lower = url.toLowerCase().split('?').first;
  return lower.endsWith('.m4a') ||
      lower.endsWith('.mp3') ||
      lower.endsWith('.aac') ||
      lower.endsWith('.wav') ||
      lower.endsWith('.ogg') ||
      lower.endsWith('.opus') ||
      lower.endsWith('.3gp');
}

/// Voice note tersimpan sebagai base64 di field message (karena static /uploads server 404).
bool _isVoicePayload(String? text) {
  if (text == null || text.isEmpty) return false;
  return text.startsWith('__VN__') || text.startsWith('[VN]') || text.startsWith('voice://');
}

String? _extractVoiceBase64(String text) {
  if (text.startsWith('__VN__')) return text.substring(6);
  if (text.startsWith('[VN]')) return text.substring(4);
  if (text.startsWith('voice://')) return text.substring(8);
  return null;
}


bool _isDocumentUrl(String? url) {
  if (url == null || url.isEmpty) return false;
  final lower = url.toLowerCase().split('?').first;
  const exts = [
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    '.txt', '.csv', '.zip', '.rar', '.7z', '.apk', '.json', '.xml',
  ];
  return exts.any(lower.endsWith);
}

String _formatBytes(int? bytes) {
  if (bytes == null || bytes <= 0) return '';
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
}

String _mimeFromExtension(String extension) {
  final ext = extension.toLowerCase().replaceFirst('.', '');
  const map = <String, String>{
    'pdf': 'application/pdf', 'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt': 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt': 'text/plain', 'csv': 'text/csv', 'json': 'application/json',
    'zip': 'application/zip', 'rar': 'application/vnd.rar', '7z': 'application/x-7z-compressed',
    'apk': 'application/vnd.android.package-archive',
    'mp3': 'audio/mpeg', 'm4a': 'audio/mp4', 'aac': 'audio/aac',
    'wav': 'audio/wav', 'ogg': 'audio/ogg', 'opus': 'audio/opus', '3gp': 'audio/3gpp',
  };
  return map[ext] ?? 'application/octet-stream';
}

String _resolveMediaUrl(String url) {
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  if (url.startsWith('/')) return '$baseUrl$url';
  return '$baseUrl/$url';
}

String _formatTime(String? timestamp) {
  if (timestamp == null || timestamp.isEmpty) return '';
  try {
    final dt = DateTime.parse(timestamp);
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  } catch (_) {
    return '';
  }
}

// ==========================================================
// MODELS
// ==========================================================
class ChatMessage {
  final String id, userId, username, displayName, role, timestamp, avatarUrl;
  final String? message, imageUrl, voiceUrl, videoUrl, audioUrl, documentUrl, documentName, mimeType, profileImageUrl;
  final int? fileSize;
  final bool isDeleted;
  /// Room isolasi: 'global' atau 'group:nama'. Pesan tanpa room dianggap global (legacy).
  final String room;
  final String? replyToId;
  final String? replyToText;
  final String? replyToAuthor;
  final Map<String, int> reactions;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.displayName,
    required this.role,
    required this.timestamp,
    required this.avatarUrl,
    required this.isDeleted,
    this.room = 'global',
    this.message,
    this.imageUrl,
    this.voiceUrl,
    this.videoUrl,
    this.audioUrl,
    this.documentUrl,
    this.documentName,
    this.mimeType,
    this.fileSize,
    this.profileImageUrl,
    this.replyToId,
    this.replyToText,
    this.replyToAuthor,
    this.reactions = const {},
  });

  /// Unique key for local delete / star / reaction tracking.
  /// Prefer server id; otherwise build a stable composite so one delete
  /// never marks every message with empty/shared id or timestamp.
  /// Room ikut di-key agar delete di global tidak memengaruhi group (dan sebaliknya).
  String get uniqueKey {
    if (id.isNotEmpty) return 'id:$id';
    final m = message ?? '';
    final media = imageUrl ?? voiceUrl ?? videoUrl ?? audioUrl ?? documentUrl ?? '';
    final r = room.isEmpty ? 'global' : room;
    return 'c:$r|${userId}|${timestamp}|${m.hashCode}|${media.hashCode}';
  }

  ChatMessage copyWith({
    bool? isDeleted,
    Map<String, int>? reactions,
    String? replyToId,
    String? replyToText,
    String? replyToAuthor,
    String? room,
  }) {
    return ChatMessage(
      id: id,
      userId: userId,
      username: username,
      displayName: displayName,
      role: role,
      timestamp: timestamp,
      avatarUrl: avatarUrl,
      isDeleted: isDeleted ?? this.isDeleted,
      room: room ?? this.room,
      message: message,
      imageUrl: imageUrl,
      voiceUrl: voiceUrl,
      videoUrl: videoUrl,
      audioUrl: audioUrl,
      documentUrl: documentUrl,
      documentName: documentName,
      mimeType: mimeType,
      fileSize: fileSize,
      profileImageUrl: profileImageUrl,
      replyToId: replyToId ?? this.replyToId,
      replyToText: replyToText ?? this.replyToText,
      replyToAuthor: replyToAuthor ?? this.replyToAuthor,
      reactions: reactions ?? this.reactions,
    );
  }

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    Map<String, int> rx = {};
    final rawRx = json['reactions'];
    if (rawRx is Map) {
      rawRx.forEach((k, v) {
        rx[k.toString()] = (v is num) ? v.toInt() : int.tryParse(v.toString()) ?? 1;
      });
    }
    // room / roomId / chatRoom — pesan lama tanpa field = 'global'
    final rawRoom = (json['room'] ?? json['roomId'] ?? json['chatRoom'] ?? 'global')
        .toString()
        .trim();
    final room = rawRoom.isEmpty ? 'global' : rawRoom;
    return ChatMessage(
      id: json['id']?.toString() ?? '',
      userId: json['userId']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      displayName: json['displayName']?.toString() ?? json['username']?.toString() ?? 'Unknown',
      role: json['role']?.toString() ?? 'Member',
      message: json['message']?.toString(),
      imageUrl: json['imageUrl']?.toString(),
      voiceUrl: json['voiceUrl']?.toString(),
      videoUrl: json['videoUrl']?.toString(),
      audioUrl: json['audioUrl']?.toString() ?? json['audio']?.toString(),
      documentUrl: json['documentUrl']?.toString() ?? json['fileUrl']?.toString() ?? json['document']?.toString(),
      documentName: json['documentName']?.toString() ?? json['fileName']?.toString() ?? json['name']?.toString(),
      mimeType: json['mimeType']?.toString(),
      fileSize: int.tryParse(json['fileSize']?.toString() ?? ''),
      timestamp: json['timestamp']?.toString() ?? DateTime.now().toIso8601String(),
      avatarUrl: json['avatarUrl']?.toString() ?? 'assets/images/logo.jpg',
      profileImageUrl: json['profileImageUrl']?.toString(),
      isDeleted: json['isDeleted'] == true,
      room: room,
      replyToId: json['replyToId']?.toString() ?? json['replyTo']?.toString(),
      replyToText: json['replyToText']?.toString(),
      replyToAuthor: json['replyToAuthor']?.toString(),
      reactions: rx,
    );
  }
}

class UserModel {
  final String username;
  final String displayName;
  final String role;
  final String? profileImageUrl;

  UserModel({
    required this.username,
    required this.displayName,
    required this.role,
    this.profileImageUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      username: json['username']?.toString() ?? '',
      displayName: json['displayName']?.toString() ?? json['username']?.toString() ?? 'Unknown',
      role: json['role']?.toString() ?? 'Member',
      profileImageUrl: json['profileImageUrl']?.toString(),
    );
  }
}

// ==========================================================
// MAIN COMMUNITY PAGE
// ==========================================================
/// Redirect ke ChatPage (WhatsApp-style). Implementasi di chat_page.dart.
class CommunityPage extends StatelessWidget {
  final String username, role, sessionKey;
  const CommunityPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  Widget build(BuildContext context) {
    // Lazy import via Navigator push replacement pattern avoided —
    // dashboard should open ChatPage. Fallback: show global+private tabs.
    return _LegacyCommunityShell(
      username: username,
      role: role,
      sessionKey: sessionKey,
    );
  }
}

class _LegacyCommunityShell extends StatefulWidget {
  final String username, role, sessionKey;
  const _LegacyCommunityShell({
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<_LegacyCommunityShell> createState() => _LegacyCommunityShellState();
}

class _LegacyCommunityShellState extends State<_LegacyCommunityShell>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final Color accent = const Color(0xFF7C4DFF);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: accent),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Chats',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: accent,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(text: 'GLOBAL'),
            Tab(text: 'PRIVATE'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          GlobalChatTab(username: widget.username, role: widget.role),
          PrivateChatTab(
              username: widget.username, sessionKey: widget.sessionKey),
        ],
      ),
    );
  }
}

// ==========================================================
// GLOBAL CHAT TAB
// ==========================================================
class GlobalChatTab extends StatefulWidget {
  final String username, role;
  /// Room id for typing presence (global / group:name)
  final String typingRoomId;
  const GlobalChatTab({
    super.key,
    required this.username,
    required this.role,
    this.typingRoomId = 'global',
  });

  @override
  State<GlobalChatTab> createState() => _GlobalChatTabState();
}

class _GlobalChatTabState extends State<GlobalChatTab> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final ImagePicker _picker = ImagePicker();
  final AudioRecorder _voiceRecorder = AudioRecorder();
  final AudioPlayer _voicePlayer = AudioPlayer();
  Color get accent => AppTheme.I.accent;

  bool _isRecordingVoice = false;
  DateTime? _voiceStartedAt;
  Timer? _voiceTimer;
  int _voiceSeconds = 0;
  String? _playingVoiceUrl;
  bool _isVoicePlaying = false;
  final Map<String, String> _voiceLocalCache = {};

  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  bool _hasError = false;
  Timer? _timer;
  TypingController? _typing;
  List<String> _typingUsers = [];
  ChatMessage? _replyTo;
  final Map<String, Map<String, int>> _reactions = {};
  final Set<String> _deletedIds = {};
  final Set<String> _starredIds = {};
  String get _msgRoom => widget.typingRoomId;

  @override
  void initState() {
    super.initState();
    _voicePlayer.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() {
        _isVoicePlaying = state == PlayerState.playing;
        if (state == PlayerState.completed || state == PlayerState.stopped) {
          _playingVoiceUrl = null;
          _isVoicePlaying = false;
        }
      });
    });
    _loadMessages();
    _loadMsgLocal();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _loadMessages(isBackground: true));
    _typing = TypingController(
      roomId: widget.typingRoomId,
      myUsername: widget.username,
      onChanged: (users) {
        if (mounted) setState(() => _typingUsers = users);
      },
    )..start();
  }

  Future<void> _loadMsgLocal() async {
    final rx = await MessageLocalStore.loadReactions(_msgRoom);
    final del = await MessageLocalStore.loadDeleted(_msgRoom);
    final star = await MessageLocalStore.loadStarred(_msgRoom);
    if (!mounted) return;
    setState(() {
      _reactions
        ..clear()
        ..addAll(rx);
      _deletedIds
        ..clear()
        ..addAll(del);
      _starredIds
        ..clear()
        ..addAll(star);
    });
  }

  @override
  void dispose() {
    _typing?.dispose();
    _timer?.cancel();
    _voiceTimer?.cancel();
    _voiceRecorder.dispose();
    _voicePlayer.dispose();
    _scrollCtrl.dispose();
    _msgCtrl.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  Future<void> _loadMessages({bool isBackground = false}) async {
    if (!isBackground) {
      setState(() {
        _isLoading = true;
        _hasError = false;
      });
    }

    try {
      // Selalu minta pesan untuk room aktif (global / group:xxx).
      // Server yang belum support param tetap mengembalikan semua — kita filter client-side.
      final room = _msgRoom;
      final uri = Uri.parse('$baseUrl/chat/messages').replace(
        queryParameters: {'room': room, 'roomId': room},
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      
      if (res.statusCode == 200 && mounted) {
        dynamic decoded = json.decode(res.body);
        List<dynamic> data = [];
        
        // Deep parser biar ga error walau format server beda
        if (decoded is List) {
          data = decoded;
        } else if (decoded is Map) {
          if (decoded.containsKey('messages') && decoded['messages'] is List) {
            data = decoded['messages'];
          } else if (decoded.containsKey('data') && decoded['data'] is List) {
            data = decoded['data'];
          } else if (decoded.containsKey('success') && decoded['success'] == true) {
            if (decoded.containsKey('messages') && decoded['messages'] is List) {
              data = decoded['messages'];
            }
          }
        }

        // Payload status internal (__STATUS__{...}) → simpan ke status store, jangan tampil di chat
        for (final raw in data) {
          if (raw is! Map) continue;
          final msgStr = raw['message']?.toString() ?? '';
          if (msgStr.startsWith('__STATUS__')) {
            try {
              final jsonStr = msgStr.substring('__STATUS__'.length);
              final map = jsonDecode(jsonStr);
              if (map is Map<String, dynamic>) {
                // ignore: unawaited_futures
                _ingestRemoteStatus(map);
              }
            } catch (_) {}
          }
        }

        setState(() {
          // Filter ketat per room:
          // - room == _msgRoom → tampil
          // - pesan legacy tanpa room (dianggap 'global') → hanya tampil di Chat Global
          // - group:xxx tidak pernah menampilkan pesan global / group lain
          _messages = data
              .map((m) => ChatMessage.fromJson(m as Map<String, dynamic>))
              .where((m) {
                final msg = (m.message ?? '').trim();
                if (msg.startsWith('__STORY__')) return false;
                if (msg.startsWith('__STATUS__')) return false;
                final r = m.room.isEmpty ? 'global' : m.room;
                return r == room;
              })
              .toList();
          _isLoading = false;
          _hasError = false;
        });
        _scrollToBottom();
      } else {
        if (mounted && !isBackground) setState(() => _hasError = true);
      }
    } catch (e) {
      if (mounted && !isBackground) setState(() => _hasError = true);
    } finally {
      if (mounted && !isBackground) setState(() => _isLoading = false);
    }
  }

  /// Simpan status remote (dari payload __STATUS__) ke store lokal, dedupe by id
  Future<void> _ingestRemoteStatus(Map<String, dynamic> map) async {
    try {
      final id = map['id']?.toString() ?? '';
      if (id.isEmpty) return;
      final prefs = await SharedPreferences.getInstance();
      const key = 'wa_status_v1';
      final raw = prefs.getStringList(key) ?? [];
      // skip jika id sudah ada
      for (final s in raw) {
        try {
          final existing = jsonDecode(s);
          if (existing is Map && existing['id']?.toString() == id) return;
        } catch (_) {}
      }
      // normalisasi field
      final entry = {
        'id': id,
        'username': map['username']?.toString() ?? '',
        'type': map['type']?.toString() ?? 'text',
        'content': map['content']?.toString() ?? '',
        'bg_color': map['bg_color']?.toString() ?? map['bgColor']?.toString() ?? '#1A0F2E',
        'caption': map['caption']?.toString() ?? '',
        'created_at': map['created_at']?.toString() ??
            map['createdAt']?.toString() ??
            DateTime.now().toIso8601String(),
      };
      raw.insert(0, jsonEncode(entry));
      while (raw.length > 100) {
        raw.removeLast();
      }
      await prefs.setStringList(key, raw);
    } catch (_) {}
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _sendText() async {
    var text = _msgCtrl.text.trim();
    if (text.isEmpty || _isSending) return;
    if (_replyTo != null) {
      final a = _replyTo!.displayName;
      final q = (_replyTo!.message ?? 'Media');
      text = '↪ $a: ${q.length > 40 ? '${q.substring(0, 40)}…' : q}\n$text';
      setState(() => _replyTo = null);
    }

    _msgCtrl.clear();
    _typing?.onLocalSend();
    setState(() => _isSending = true);

    try {
      final clientId = '${DateTime.now().millisecondsSinceEpoch}_${widget.username}';
      final ts = DateTime.now().toIso8601String();
      final room = _msgRoom;
      final response = await http.post(
        Uri.parse('$baseUrl/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id': clientId,
          'userId': widget.username,
          'username': widget.username,
          'role': widget.role,
          'message': text,
          'timestamp': ts,
          'room': room,
          'roomId': room,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        _loadMessages(isBackground: true);
      } else {
        _showError("Gagal mengirim pesan (${response.statusCode})");
      }
    } catch (e) {
      _showError("Error jaringan: $e");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _sendMedia(bool isVideo) async {
    try {
      final XFile? picked = isVideo
          ? await _picker.pickVideo(source: ImageSource.gallery)
          : await _picker.pickImage(source: ImageSource.gallery);

      if (picked == null) return;

      final file = File(picked.path);
      if (!await file.exists()) {
        _showError('File tidak ditemukan.');
        return;
      }

      final size = await file.length();
      // Video bisa besar — longgarkan limit (max ~80 MB)
      if (size > 80 * 1024 * 1024) {
        _showError('Ukuran ${isVideo ? 'video' : 'foto'} maksimal 80 MB.');
        return;
      }

      setState(() => _isSending = true);

      final fileName = picked.name.isNotEmpty
          ? picked.name
          : (isVideo ? 'video.mp4' : 'image.jpg');
      final type = isVideo ? 'video' : 'image';
      final endpointCandidates = isVideo
          ? <String>[
              '/chat/upload-video',
              '/chat/upload-file',
              '/chat/upload-media',
              '/chat/upload-image',
            ]
          : <String>[
              '/chat/upload-image',
              '/chat/upload-file',
              '/chat/upload-media',
            ];
      final fieldCandidates = isVideo
          ? <String>['video', 'file', 'media', 'image']
          : <String>['image', 'file', 'media', 'photo'];

      String lastError = 'Server menolak upload';
      bool ok = false;

      for (final endpoint in endpointCandidates) {
        for (final field in fieldCandidates) {
          try {
            final request = http.MultipartRequest(
              'POST',
              Uri.parse('$baseUrl$endpoint'),
            );
            request.files.add(await http.MultipartFile.fromPath(
              field,
              file.path,
              filename: fileName,
            ));
            request.fields.addAll({
              'userId': widget.username,
              'username': widget.username,
              'role': widget.role,
              'type': type,
              'fileName': fileName,
              'room': _msgRoom,
              'roomId': _msgRoom,
            });

            final response = await request.send().timeout(
              isVideo
                  ? const Duration(minutes: 3)
                  : const Duration(seconds: 60),
            );
            final body = await response.stream.bytesToString();

            if (response.statusCode == 200 ||
                response.statusCode == 201 ||
                response.statusCode == 204) {
              ok = true;
              break;
            }

            // Multer unexpected field → coba field lain
            if (body.contains('Unexpected file') ||
                body.contains('MulterError')) {
              lastError = '($response.statusCode) field salah, mencoba lagi…';
              continue;
            }
            lastError = _extractUploadError(body, response.statusCode);
            if (response.statusCode == 404 || response.statusCode == 405) {
              break; // coba endpoint berikutnya
            }
          } catch (e) {
            lastError = e.toString();
          }
        }
        if (ok) break;
      }

      if (ok) {
        await _loadMessages(isBackground: true);
      } else {
        _showError('Gagal upload $type: $lastError');
      }
    } catch (e) {
      _showError('Error upload: $e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }


  Future<void> _sendDocument() async {
    if (_isSending) return;
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;
      final picked = result.files.single;
      if (picked.path == null || picked.path!.isEmpty) {
        _showError('File tidak bisa diakses. Coba pilih file lain.');
        return;
      }
      final file = File(picked.path!);
      final exists = await file.exists();
      if (!exists) {
        _showError('File tidak ditemukan.');
        return;
      }
      final size = await file.length();
      if (size > 50 * 1024 * 1024) {
        _showError('Ukuran file maksimal 50 MB.');
        return;
      }
      await _uploadChatFile(
        file: file,
        endpointCandidates: const ['/chat/upload-document', '/chat/upload-file', '/chat/upload-video', '/chat/upload-image'],
        type: 'document',
        fileName: picked.name,
        mimeType: _mimeFromExtension(picked.extension ?? ''),
      );
    } catch (e) {
      _showError('Gagal memilih file: $e');
    }
  }

  Future<void> _sendAudioFile() async {
    if (_isSending) return;
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;
      final picked = result.files.single;
      if (picked.path == null || picked.path!.isEmpty) {
        _showError('Audio tidak bisa diakses. Coba pilih file lain.');
        return;
      }
      final file = File(picked.path!);
      if (!await file.exists()) {
        _showError('File audio tidak ditemukan.');
        return;
      }
      final size = await file.length();
      if (size > 50 * 1024 * 1024) {
        _showError('Ukuran audio maksimal 50 MB.');
        return;
      }
      await _uploadChatFile(
        file: file,
        endpointCandidates: const ['/chat/upload-audio', '/chat/upload-file', '/chat/upload-video', '/chat/upload-image'],
        type: 'audio',
        fileName: picked.name,
        mimeType: _mimeFromExtension(picked.extension ?? ''),
      );
    } catch (e) {
      _showError('Gagal memilih audio: $e');
    }
  }

  Future<void> _uploadChatFile({
    required File file,
    required String fileName,
    required String mimeType,
    required List<String> endpointCandidates,
    required String type,
  }) async {
    if (_isSending) return;
    setState(() => _isSending = true);

    // Field names yang dicoba per endpoint (server pakai multer.single('video'|'image'|...))
    final fieldCandidates = type == 'document'
        ? <String>['video', 'image', 'file', 'document', 'media']
        : type == 'audio'
            ? <String>['video', 'audio', 'file', 'voice', 'media']
            : <String>['file', 'video', 'image', 'media'];

    String lastError = 'Server menolak upload';
    try {
      for (final endpoint in endpointCandidates) {
        for (final field in fieldCandidates) {
          try {
            final request = http.MultipartRequest('POST', Uri.parse('$baseUrl$endpoint'));
            request.files.add(await http.MultipartFile.fromPath(
              field,
              file.path,
              filename: fileName,
            ));
            request.fields.addAll({
              'userId': widget.username,
              'username': widget.username,
              'role': widget.role,
              'type': type,
              'fileName': fileName,
              'mimeType': mimeType,
              'room': _msgRoom,
              'roomId': _msgRoom,
            });

            final response = await request.send().timeout(const Duration(seconds: 120));
            final body = await response.stream.bytesToString();
            if (response.statusCode == 200 ||
                response.statusCode == 201 ||
                response.statusCode == 204) {
              await _loadMessages(isBackground: true);
              return;
            }
            lastError = _extractUploadError(body, response.statusCode);
            // Multer unexpected field -> try next field name
            if (response.statusCode == 500 && body.contains('Unexpected file')) {
              continue;
            }
            if (response.statusCode != 404 && response.statusCode != 405) {
              // non-missing-route error with wrong field: keep trying fields
              if (body.contains('Unexpected file') || body.contains('MulterError')) {
                continue;
              }
            }
          } catch (e) {
            lastError = e.toString();
          }
        }
      }
      _showError('Gagal mengirim $type: $lastError');
    } catch (e) {
      _showError('Error upload $type: $e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  String _extractUploadError(String body, int statusCode) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map) {
        final value = decoded['message'] ?? decoded['error'] ?? decoded['detail'];
        if (value != null && value.toString().trim().isNotEmpty) {
          return '($statusCode): ${value.toString()}';
        }
      }
    } catch (_) {}
    return '($statusCode)';
  }

  Future<void> _openDocument(String url, String name) async {
    try {
      final resolved = _resolveMediaUrl(url);
      final response = await http.get(Uri.parse(resolved)).timeout(const Duration(seconds: 60));
      if (response.statusCode != 200) {
        _showError('Gagal mengunduh dokumen (${response.statusCode})');
        return;
      }
      final dir = await getTemporaryDirectory();
      final safeName = name.replaceAll(RegExp(r'[\/:*?"<>|]'), '_');
      final path = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$safeName';
      final file = File(path);
      await file.writeAsBytes(response.bodyBytes, flush: true);
      final result = await OpenFilex.open(file.path);
      if (result.type != ResultType.done && mounted) {
        _showError(result.message.isNotEmpty ? result.message : 'Tidak ada aplikasi yang bisa membuka file ini.');
      }
    } catch (e) {
      _showError('Gagal membuka dokumen: $e');
    }
  }

  String _formatVoiceDuration(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _startVoiceRecording() async {
    if (_isSending || _isRecordingVoice) return;

    try {
      final hasPermission = await _voiceRecorder.hasPermission();
      if (!hasPermission) {
        _showError('Izin mikrofon diperlukan untuk merekam voice note.');
        return;
      }

      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _voiceRecorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
          echoCancel: true,
          noiseSuppress: true,
          autoGain: true,
        ),
        path: path,
      );

      if (!mounted) return;
      setState(() {
        _isRecordingVoice = true;
        _voiceStartedAt = DateTime.now();
        _voiceSeconds = 0;
      });

      _voiceTimer?.cancel();
      _voiceTimer = Timer.periodic(const Duration(seconds: 1), (_) async {
        if (!mounted || !_isRecordingVoice || _voiceStartedAt == null) return;
        final seconds = DateTime.now().difference(_voiceStartedAt!).inSeconds;
        if (seconds >= 120) {
          await _stopVoiceRecording();
          return;
        }
        setState(() => _voiceSeconds = seconds);
      });
    } catch (e) {
      _voiceTimer?.cancel();
      if (mounted) setState(() => _isRecordingVoice = false);
      _showError('Gagal memulai rekaman: $e');
    }
  }

  Future<void> _stopVoiceRecording() async {
    if (!_isRecordingVoice) return;

    _voiceTimer?.cancel();
    _voiceTimer = null;
    final recordedSeconds = _voiceSeconds;

    try {
      final path = await _voiceRecorder.stop();
      if (mounted) {
        setState(() {
          _isRecordingVoice = false;
          _voiceStartedAt = null;
          _voiceSeconds = 0;
        });
      }

      if (path == null || path.isEmpty) {
        _showError('Rekaman voice note kosong.');
        return;
      }

      final file = File(path);
      if (!await file.exists() || await file.length() == 0) {
        _showError('File voice note tidak berhasil dibuat.');
        return;
      }

      if (recordedSeconds < 1) {
        try { await file.delete(); } catch (_) {}
        _showError('Voice note terlalu singkat. Tahan minimal 1 detik.');
        return;
      }

      await _uploadVoice(file, recordedSeconds);
    } catch (e) {
      if (mounted) {
        setState(() {
          _isRecordingVoice = false;
          _voiceStartedAt = null;
          _voiceSeconds = 0;
        });
      }
      _showError('Gagal menghentikan rekaman: $e');
    }
  }

  Future<void> _cancelVoiceRecording() async {
    if (!_isRecordingVoice) return;
    _voiceTimer?.cancel();
    _voiceTimer = null;
    try {
      await _voiceRecorder.cancel();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _isRecordingVoice = false;
        _voiceStartedAt = null;
        _voiceSeconds = 0;
      });
    }
  }

  Future<void> _uploadVoice(File file, int durationSeconds) async {
    if (_isSending) return;
    setState(() => _isSending = true);

    try {
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) {
        _showError('Rekaman voice note kosong.');
        return;
      }
      // Batas aman ~400KB base64 (~300KB file) agar tidak membebani chat
      if (bytes.length > 350 * 1024) {
        _showError('Voice note terlalu panjang. Maksimal sekitar 30–40 detik.');
        return;
      }

      final b64 = base64Encode(bytes);
      final payload = '__VN__$b64';

      // Simpan cache lokal agar bisa diputar segera
      final dir = await getTemporaryDirectory();
      final cachePath = '${dir.path}/vn_cache_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await File(cachePath).writeAsBytes(bytes, flush: true);
      _voiceLocalCache[payload] = cachePath;
      _voiceLocalCache[cachePath] = cachePath;

      final clientId = '${DateTime.now().millisecondsSinceEpoch}_${widget.username}';
      final room = _msgRoom;
      final response = await http.post(
        Uri.parse('$baseUrl/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id': clientId,
          'userId': widget.username,
          'username': widget.username,
          'role': widget.role,
          'message': payload,
          'timestamp': DateTime.now().toIso8601String(),
          'duration': durationSeconds,
          'type': 'voice',
          'room': room,
          'roomId': room,
        }),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 || response.statusCode == 201) {
        await _loadMessages(isBackground: true);
        return;
      }
      _showError('Gagal mengirim voice note (${response.statusCode})');
    } catch (e) {
      _showError('Error upload voice note: $e');
    } finally {
      try { await file.delete(); } catch (_) {}
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _toggleVoicePlayback(String url) async {
    final key = url;
    try {
      if (_playingVoiceUrl == key && _isVoicePlaying) {
        await _voicePlayer.pause();
        if (mounted) setState(() => _isVoicePlaying = false);
        return;
      }

      if (_playingVoiceUrl == key && !_isVoicePlaying) {
        await _voicePlayer.resume();
        if (mounted) setState(() => _isVoicePlaying = true);
        return;
      }

      await _voicePlayer.stop();

      // 1) Cache lokal
      String? localPath = _voiceLocalCache[key];

      // 2) Payload base64 di message
      if (localPath == null && _isVoicePayload(key)) {
        final b64 = _extractVoiceBase64(key);
        if (b64 != null && b64.isNotEmpty) {
          try {
            final bytes = base64Decode(b64);
            final dir = await getTemporaryDirectory();
            localPath = '${dir.path}/vn_play_${DateTime.now().millisecondsSinceEpoch}.m4a';
            await File(localPath!).writeAsBytes(bytes, flush: true);
            _voiceLocalCache[key] = localPath!;
          } catch (e) {
            _showError('Data voice note rusak.');
            return;
          }
        }
      }

      // 3) Download remote URL ke file lokal (UrlSource sering gagal di Android)
      if (localPath == null) {
        final resolved = _resolveMediaUrl(key);
        try {
          final res = await http.get(Uri.parse(resolved)).timeout(const Duration(seconds: 20));
          if (res.statusCode == 200 && res.bodyBytes.isNotEmpty) {
            final dir = await getTemporaryDirectory();
            final ext = resolved.toLowerCase().contains('.mp3')
                ? 'mp3'
                : resolved.toLowerCase().contains('.wav')
                    ? 'wav'
                    : 'm4a';
            localPath = '${dir.path}/vn_dl_${DateTime.now().millisecondsSinceEpoch}.$ext';
            await File(localPath!).writeAsBytes(res.bodyBytes, flush: true);
            _voiceLocalCache[key] = localPath!;
          } else {
            _showError(
              'File voice tidak tersedia di server (${res.statusCode}). '
              'Server /uploads mengembalikan error — minta admin aktifkan static file.',
            );
            return;
          }
        } catch (e) {
          _showError(
            'Tidak bisa mengunduh voice note. '
            'Pastikan server menyajikan file di folder /uploads.',
          );
          return;
        }
      }

      final pathToPlay = localPath;
      if (pathToPlay == null || !await File(pathToPlay).exists()) {
        _showError('File voice note tidak ditemukan.');
        return;
      }

      await _voicePlayer.setReleaseMode(ReleaseMode.stop);
      await _voicePlayer.play(DeviceFileSource(pathToPlay));
      if (mounted) {
        setState(() {
          _playingVoiceUrl = key;
          _isVoicePlaying = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _playingVoiceUrl = null;
          _isVoicePlaying = false;
        });
      }
      _showError('Gagal memutar voice note: $e');
    }
  }

Future<void> _saveMedia(String url, bool isVideo) async {
    try {
      final res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}.${isVideo ? 'mp4' : 'jpg'}');
        await file.writeAsBytes(res.bodyBytes);
        if (isVideo) {
          await GallerySaver.saveVideo(file.path);
        } else {
          await GallerySaver.saveImage(file.path);
        }
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${isVideo ? 'Video' : 'Foto'} berhasil disimpan'),
              backgroundColor: accent,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal menyimpan media'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Widget _buildLoadingShimmer() {
    return ListView.builder(
      itemCount: 10,
      itemBuilder: (_, __) {
        bool isMe = __ % 2 == 0;
        return Align(
          alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
            width: MediaQuery.of(context).size.width * 0.6,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        );
      },
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.cloud_off, color: Colors.white30, size: 60),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat pesan",
            style: TextStyle(color: Colors.white54, fontSize: 16),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _loadMessages(),
            icon: const Icon(Icons.refresh),
            label: const Text("Coba Lagi"),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.forum_rounded, color: accent.withOpacity(0.3), size: 60),
          const SizedBox(height: 16),
          const Text(
            "Belum ada pesan",
            style: TextStyle(color: Colors.white54, fontSize: 16),
          ),
          const SizedBox(height: 8),
          const Text(
            "Mulai percakapan sekarang!",
            style: TextStyle(color: Colors.white30, fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    Color c = role.toLowerCase() == 'developer'
        ? Colors.purple
        : role.toLowerCase() == 'owner'
            ? Colors.orange
            : role.toLowerCase() == 'admin'
                ? Colors.red
                : Colors.grey;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: c.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: c.withOpacity(0.5)),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(color: c, fontSize: 8, fontWeight: FontWeight.bold),
      ),
    );
  }

  Future<void> _handleMsgAction(ChatMessage msg) async {
    final isMe = msg.userId == widget.username;
    final preview = msg.message ??
        (msg.imageUrl != null
            ? '📷 Foto'
            : msg.videoUrl != null
                ? '🎬 Video'
                : msg.voiceUrl != null
                    ? '🎤 Pesan suara'
                    : 'Pesan');
    final result = await showMessageActionsSheet(
      context: context,
      isMe: isMe,
      previewText: preview,
    );
    if (result == null || !mounted) return;
    switch (result.action) {
      case MsgAction.reply:
        setState(() => _replyTo = msg);
        break;
      case MsgAction.copy:
        copyToClipboard(context, msg.message ?? '');
        break;
      case MsgAction.react:
        if (result.emoji == null) break;
        final id = msg.uniqueKey;
        final map = Map<String, int>.from(_reactions[id] ?? {});
        map[result.emoji!] = (map[result.emoji!] ?? 0) + 1;
        setState(() => _reactions[id] = map);
        await MessageLocalStore.saveReactions(_msgRoom, _reactions);
        break;
      case MsgAction.forward:
        final target = await showForwardSheet(
          context,
          ['Chat Global', 'Chat Privat', widget.username],
        );
        if (target != null && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Pesan diteruskan ke $target'),
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        break;
      case MsgAction.deleteMe:
        // Hapus untuk saya: cukup tandai lokal (key unik, tidak menimpa pesan lain)
        final idMe = msg.uniqueKey;
        setState(() => _deletedIds.add(idMe));
        await MessageLocalStore.saveDeleted(_msgRoom, _deletedIds);
        break;
      case MsgAction.deleteEveryone:
        // Hapus untuk semua: tandai lokal + coba minta server (jika endpoint tersedia)
        final idAll = msg.uniqueKey;
        setState(() => _deletedIds.add(idAll));
        await MessageLocalStore.saveDeleted(_msgRoom, _deletedIds);
        // Best-effort server delete (abaikan error jika endpoint belum ada)
        if (msg.id.isNotEmpty || msg.timestamp.isNotEmpty) {
          try {
            await http.post(
              Uri.parse('$baseUrl/chat/delete'),
              headers: {'Content-Type': 'application/json'},
              body: json.encode({
                'id': msg.id.isNotEmpty ? msg.id : null,
                'timestamp': msg.timestamp,
                'userId': widget.username,
                'forEveryone': true,
                'room': _msgRoom,
                'roomId': _msgRoom,
              }),
            ).timeout(const Duration(seconds: 5));
          } catch (_) {}
        }
        break;
      case MsgAction.star:
        final id = msg.uniqueKey;
        setState(() {
          if (_starredIds.contains(id)) {
            _starredIds.remove(id);
          } else {
            _starredIds.add(id);
          }
        });
        await MessageLocalStore.saveStarred(_msgRoom, _starredIds);
        break;
      case MsgAction.info:
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF1F2C34),
            title: const Text('Info pesan', style: TextStyle(color: Colors.white)),
            content: Text(
              'Dari: ${msg.displayName}\nWaktu: ${_formatTime(msg.timestamp)}\nID: ${msg.id}',
              style: const TextStyle(color: Colors.white70),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        break;
    }
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    // Jangan render payload internal status/story
    final rawMsg = (msg.message ?? '').trim();
    if (rawMsg.startsWith('__STATUS__') || rawMsg.startsWith('__STORY__')) {
      return const SizedBox.shrink();
    }
    final isMe = msg.userId == widget.username;
    final msgKey = msg.uniqueKey;
    final effectiveDeleted = msg.isDeleted || _deletedIds.contains(msgKey);
    final mediaCandidates = <String?>[
      msg.voiceUrl,
      msg.audioUrl,
      msg.videoUrl,
      msg.imageUrl,
      msg.documentUrl,
      msg.message,
    ].whereType<String>().where((u) => u.isNotEmpty).toList();

    String? _firstWhereUrl(bool Function(String) test) {
      for (final u in mediaCandidates) {
        if (test(u)) return u;
      }
      return null;
    }

    final voiceUrl = _firstWhereUrl(_isAudioUrl);
    final documentUrl = _firstWhereUrl(_isDocumentUrl);
    final hasVoice = voiceUrl != null;
    final hasDocument = documentUrl != null;
    // Jangan treat audio/document URL sebagai image/video
    final hasImage = !hasVoice && !hasDocument && (
      (msg.imageUrl != null && msg.imageUrl!.isNotEmpty && !_isAudioUrl(msg.imageUrl) && !_isDocumentUrl(msg.imageUrl)) ||
      _isImageUrl(msg.message)
    );
    final hasVideo = !hasVoice && !hasDocument && !hasImage && (
      (msg.videoUrl != null && msg.videoUrl!.isNotEmpty && !_isAudioUrl(msg.videoUrl) && !_isDocumentUrl(msg.videoUrl)) ||
      _isVideoUrl(msg.message)
    );
    final hasAudioFile = hasVoice; // reuse voice player UI
    final audioUrl = voiceUrl;
    final rawMediaUrl = hasImage
        ? (msg.imageUrl ?? msg.message)
        : hasVideo
            ? (msg.videoUrl ?? msg.message)
            : null;
    final mediaUrl = rawMediaUrl != null && rawMediaUrl.isNotEmpty
        ? _resolveMediaUrl(rawMediaUrl)
        : null;
    final documentName = (msg.documentName != null && msg.documentName!.isNotEmpty) ? msg.documentName! : 'Dokumen';

    if (effectiveDeleted) {
      return Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.delete_outline, color: Colors.grey.shade600, size: 16),
              const SizedBox(width: 8),
              Text(
                "Pesan ini dihapus",
                style: TextStyle(color: Colors.grey.shade600, fontStyle: FontStyle.italic, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }

    final rxMap = {
      ...msg.reactions,
      ...?_reactions[msgKey],
    };

    return GestureDetector(
      onLongPress: () => _handleMsgAction(msg),
      onDoubleTap: () async {
        // double-tap = ❤️ like WhatsApp
        final map = Map<String, int>.from(_reactions[msgKey] ?? {});
        map['❤️'] = (map['❤️'] ?? 0) + 1;
        setState(() => _reactions[msgKey] = map);
        await MessageLocalStore.saveReactions(_msgRoom, _reactions);
      },
      child: Container(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe)
            Container(
              width: 36,
              height: 36,
              margin: const EdgeInsets.only(right: 8, bottom: 4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [AppTheme.I.accent, AppTheme.I.accentDark]),
                border: Border.all(color: Colors.white.withOpacity(0.2)),
              ),
              child: ClipOval(
                child: msg.profileImageUrl != null && msg.profileImageUrl!.isNotEmpty
                    ? Image.network(
                        msg.profileImageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white, size: 18),
                      )
                    : const Icon(Icons.person, color: Colors.white, size: 18),
              ),
            ),
          Flexible(
            child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: isMe
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppTheme.I.accent, AppTheme.I.accentDark],
                )
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.10),
                    Colors.white.withOpacity(0.05),
                  ],
                ),
          border: Border.all(
            color: Colors.white.withOpacity(isMe ? 0.14 : 0.08),
          ),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isMe ? 20 : 6),
                  bottomRight: Radius.circular(isMe ? 6 : 20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: VerifiedName(
                              username: msg.username,
                              displayName: msg.displayName.isNotEmpty
                                  ? msg.displayName
                                  : msg.username,
                              style: TextStyle(
                                color: AppTheme.I.accentFrost,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                              badgeSize: 14,
                            ),
                          ),
                          const SizedBox(width: 6),
                          _buildRoleBadge(msg.role),
                        ],
                      ),
                    ),
                  if (hasVoice && voiceUrl != null) ...[
                    VoiceNoteBubble(
                      durationText: '',
                      isPlaying: _playingVoiceUrl == voiceUrl && _isVoicePlaying,
                      onTap: () => _toggleVoicePlayback(voiceUrl!),
                    ),
                  ] else if (hasAudioFile && audioUrl != null) ...[
                    VoiceNoteBubble(
                      durationText: 'Audio',
                      isPlaying: _playingVoiceUrl == audioUrl && _isVoicePlaying,
                      onTap: () => _toggleVoicePlayback(audioUrl!),
                    ),
                  ] else if (hasDocument && documentUrl != null) ...[
                    InkWell(
                      onTap: () => _openDocument(documentUrl!, documentName),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        constraints: const BoxConstraints(minWidth: 210, maxWidth: 260),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.08)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 42, height: 42,
                              decoration: BoxDecoration(color: accent.withOpacity(0.18), borderRadius: BorderRadius.circular(10)),
                              child: const Icon(Icons.insert_drive_file_rounded, color: Colors.white, size: 23),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(documentName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                                  const SizedBox(height: 3),
                                  Text('${msg.mimeType ?? 'File'}${msg.fileSize != null ? ' • ${_formatBytes(msg.fileSize)}' : ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 10)),
                                  const SizedBox(height: 2),
                                  const Text('Ketuk untuk membuka', style: TextStyle(color: Colors.white38, fontSize: 10)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ] else if (hasImage && mediaUrl != null) ...[
                    GestureDetector(
                      onTap: () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          backgroundColor: Colors.transparent,
                          child: Stack(
                            children: [
                              InteractiveViewer(child: Image.network(mediaUrl, fit: BoxFit.contain)),
                              Positioned(
                                top: 8,
                                right: 8,
                                child: IconButton(
                                  icon: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: const BoxDecoration(
                                      color: Colors.black54,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.download, color: Colors.white),
                                  ),
                                  onPressed: () => _saveMedia(mediaUrl, false),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          mediaUrl,
                          width: 200,
                          height: 200,
                          fit: BoxFit.cover,
                          loadingBuilder: (_, child, p) => p == null
                              ? child
                              : const SizedBox(
                                  height: 200,
                                  width: 200,
                                  child: Center(child: CircularProgressIndicator(color: Colors.white)),
                                ),
                        ),
                      ),
                    ),
                  ] else if (hasVideo && mediaUrl != null) ...[
                    GestureDetector(
                      onTap: () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          backgroundColor: Colors.transparent,
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width * 0.9,
                            height: MediaQuery.of(context).size.height * 0.7,
                            child: VideoPlayerWidget(videoUrl: mediaUrl, onSave: () => _saveMedia(mediaUrl, true)),
                          ),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Container(
                          width: 200,
                          height: 150,
                          color: Colors.black54,
                          child: const Center(
                            child: Icon(Icons.play_circle_filled, color: Colors.white, size: 40),
                          ),
                        ),
                      ),
                    ),
                  ] else if (msg.message != null &&
                      msg.message!.isNotEmpty &&
                      !_isVoicePayload(msg.message)) ...[
                    SelectableText(
                      msg.message!,
                      style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.3),
                    ),
                  ],
                  if (msg.replyToText != null && msg.replyToText!.isNotEmpty)
                    QuotedReply(
                      author: msg.replyToAuthor ?? 'User',
                      text: msg.replyToText!,
                      accent: accent,
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_starredIds.contains(msgKey)) ...[
                          const Icon(Icons.star, size: 12, color: Colors.amber),
                          const SizedBox(width: 4),
                        ],
                        Text(
                          _formatTime(msg.timestamp),
                          style: TextStyle(
                            color: isMe ? Colors.white70 : Colors.white54,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (rxMap.isNotEmpty)
                    ReactionChips(reactions: rxMap),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget _buildInputBar() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_replyTo != null)
          ReplyBar(
            author: _replyTo!.displayName,
            preview: _replyTo!.message ?? 'Media',
            onClose: () => setState(() => _replyTo = null),
            accent: accent,
          ),
        Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xEB0B0F17),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.image_rounded, color: accent),
            onPressed: _isSending ? null : () => _sendMedia(false),
          ),
          IconButton(
            icon: Icon(Icons.videocam_rounded, color: accent),
            onPressed: _isSending ? null : () => _sendMedia(true),
          ),
          IconButton(
            tooltip: 'Kirim file / dokumen',
            icon: Icon(Icons.attach_file_rounded, color: accent),
            onPressed: _isSending ? null : _sendDocument,
          ),
          IconButton(
            tooltip: 'Kirim audio',
            icon: Icon(Icons.library_music_rounded, color: accent),
            onPressed: _isSending ? null : _sendAudioFile,
          ),
          if (_isRecordingVoice)
            Expanded(
              child: GestureDetector(
                onTap: _stopVoiceRecording,
                onLongPressCancel: _cancelVoiceRecording,
                child: Container(
                  height: 44,
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: accent.withOpacity(0.45)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.mic, color: accent, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Merekam ${_formatVoiceDuration(_voiceSeconds)} • ketuk untuk kirim',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                      ),
                      IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                        onPressed: _cancelVoiceRecording,
                        icon: const Icon(Icons.close, color: Colors.white54, size: 18),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else ...[
            Expanded(
              child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Type a message...',
                hintStyle: TextStyle(color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
                onChanged: (t) => _typing?.onLocalTextChanged(t),
                onSubmitted: (_) => _sendText(),
              ),
            ),
            IconButton(
              tooltip: 'Voice note',
              icon: Icon(Icons.mic_none_rounded, color: accent),
              onPressed: _isSending ? null : _startVoiceRecording,
            ),
          ],
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [AppTheme.I.accent, AppTheme.I.accentDark]),
            ),
            child: IconButton(
              icon: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Icon(
                      _isRecordingVoice ? Icons.stop_rounded : Icons.send_rounded,
                      color: Colors.white,
                    ),
              onPressed: _isSending ? null : (_isRecordingVoice ? _stopVoiceRecording : _sendText),
            ),
          ),
        ],
      ),
    ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            color: accent,
            backgroundColor: const Color(0xFF080808),
            onRefresh: () => _loadMessages(),
            child: _isLoading
                ? _buildLoadingShimmer()
                : _hasError
                    ? _buildErrorState()
                    : (_messages.isEmpty && _typingUsers.isEmpty)
                        ? _buildEmptyState()
                        : ListView.builder(
                            controller: _scrollCtrl,
                            padding: const EdgeInsets.only(bottom: 20, top: 10),
                            itemCount:
                                _messages.length + (_typingUsers.isNotEmpty ? 1 : 0),
                            itemBuilder: (_, i) {
                              if (i < _messages.length) {
                                return _buildMessageBubble(_messages[i]);
                              }
                              final names = _typingUsers.join(', ');
                              return TypingBubble(
                                label: _typingUsers.length == 1
                                    ? '$names sedang mengetik'
                                    : '$names sedang mengetik',
                                accent: accent,
                              );
                            },
                          ),
          ),
        ),
        _buildInputBar(),
      ],
    );
  }
}

class VoiceNoteBubble extends StatelessWidget {
  final bool isPlaying;
  final VoidCallback onTap;
  final String durationText;

  const VoiceNoteBubble({
    super.key,
    required this.isPlaying,
    required this.onTap,
    this.durationText = '',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 210,
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: onTap,
            tooltip: isPlaying ? 'Jeda' : 'Putar',
            icon: Icon(
              isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
              color: Colors.white,
              size: 34,
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: List.generate(22, (i) {
                    final h = 5.0 + ((i * 7) % 13);
                    return Container(
                      width: 2.2,
                      height: h,
                      margin: const EdgeInsets.symmetric(horizontal: 1.2),
                      decoration: BoxDecoration(
                        color: isPlaying ? Colors.redAccent : Colors.white38,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    );
                  }),
                ),
                if (durationText.isNotEmpty)
                  Text(durationText, style: const TextStyle(color: Colors.white54, fontSize: 9)),
              ],
            ),
          ),
          const Icon(Icons.mic, color: Colors.white54, size: 16),
        ],
      ),
    );
  }
}

// ==========================================================
// PRIVATE CHAT TAB (SEARCH + LIST)
// ==========================================================
class PrivateChatTab extends StatefulWidget {
  final String username, sessionKey;
  const PrivateChatTab({super.key, required this.username, required this.sessionKey});

  @override
  State<PrivateChatTab> createState() => _PrivateChatTabState();
}

class _PrivateChatTabState extends State<PrivateChatTab> {
  List<UserModel> _users = [];
  List<UserModel> _filtered = [];
  bool _isLoading = true;
  final TextEditingController _searchCtrl = TextEditingController();
  Color get accent => AppTheme.I.accent;

  @override
  void initState() {
    super.initState();
    _fetchUsers();
    _searchCtrl.addListener(() {
      setState(() {
        _filtered = _users
            .where((u) =>
                u.username.toLowerCase().contains(_searchCtrl.text.toLowerCase()) ||
                u.displayName.toLowerCase().contains(_searchCtrl.text.toLowerCase()))
            .toList();
      });
    });
  }

  Future<void> _fetchUsers() async {
    try {
      final res = await http.get(Uri.parse('$baseUrl/api/chatUsers')).timeout(const Duration(seconds: 10));
      final decoded = jsonDecode(res.body);

      if (decoded['success'] == true && mounted) {
        List<dynamic> usersJson = decoded['users'] ?? [];
        setState(() {
          _users = usersJson
              .map((u) => UserModel.fromJson(u as Map<String, dynamic>))
              .where((u) => u.username != widget.username)
              .toList();
          _filtered = _users;
          _isLoading = false;
        });
      } else {
        if (mounted) setState(() => _isLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Center(child: CircularProgressIndicator(color: accent));
    }

    return Column(
      children: [
        Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF080808),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: TextField(
            controller: _searchCtrl,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search, color: Colors.white54),
              hintText: 'Cari username...',
              hintStyle: TextStyle(color: Colors.white38),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
            ),
          ),
        ),
        Expanded(
          child: _filtered.isEmpty
              ? const Center(
                  child: Text(
                    "User tidak ditemukan",
                    style: TextStyle(color: Colors.white54),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) {
                    final u = _filtered[i];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF080808),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        leading: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: [AppTheme.I.accent, AppTheme.I.accentDark]),
                          ),
                          child: ClipOval(
                            child: u.profileImageUrl != null && u.profileImageUrl!.isNotEmpty
                                ? Image.network(
                                    u.profileImageUrl!,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white),
                                  )
                                : const Icon(Icons.person, color: Colors.white),
                          ),
                        ),
                        title: VerifiedName(
                          username: u.username,
                          displayName: u.displayName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 15,
                          ),
                          badgeSize: 15,
                        ),
                        subtitle: Text(
                          "@${u.username} • ${u.role.toUpperCase()}",
                          style: const TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PrivateChatRoom(
                              myUsername: widget.username,
                              targetUsername: u.username,
                              targetDisplayName: u.displayName,
                              targetProfileUrl: u.profileImageUrl,
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// ==========================================================
// PRIVATE CHAT ROOM (MEDIA + WS)
// ==========================================================
class PrivateChatRoom extends StatefulWidget {
  final String myUsername, targetUsername, targetDisplayName, sessionKey;
  final String? targetProfileUrl;

  const PrivateChatRoom({
    super.key,
    required this.myUsername,
    required this.targetUsername,
    required this.targetDisplayName,
    required this.sessionKey,
    this.targetProfileUrl,
  });

  @override
  State<PrivateChatRoom> createState() => _PrivateChatRoomState();
}

class _PrivateChatRoomState extends State<PrivateChatRoom> {
  final TextEditingController _msgCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final ImagePicker _picker = ImagePicker();
  late WebSocketChannel _channel;
  List<Map<String, dynamic>> _messages = [];
  bool _isConnected = false;
  bool _isSending = false;
  Color get accent => AppTheme.I.accent;
  /// Fingerprint pesan yang baru saja diterima/dikirim (cegah double dari server).
  final Map<String, DateTime> _seenFingerprints = {};
  TypingController? _typing;
  List<String> _typingUsers = [];
  Map<String, dynamic>? _replyToMsg;
  final Map<String, Map<String, int>> _reactions = {};
  final Set<String> _deletedIds = {};
  final Set<String> _starredIds = {};

  String get _privateRoomId {
    final a = widget.myUsername;
    final b = widget.targetUsername;
    final pair = [a, b]..sort();
    return 'private:${pair[0]}_${pair[1]}';
  }

  String _msgKey(Map<String, dynamic> msg) {
    final id = msg['id'] ?? msg['_id'] ?? msg['messageId'];
    if (id != null && id.toString().isNotEmpty) return id.toString();
    return '${msg['from']}_${msg['timestamp']}_${msg['message']}';
  }

  @override
  void initState() {
    super.initState();
    _connectWs();
    _loadPrivateLocal();
    _typing = TypingController(
      roomId: _privateRoomId,
      myUsername: widget.myUsername,
      onChanged: (users) {
        if (mounted) setState(() => _typingUsers = users);
      },
    )..start();
  }

  Future<void> _loadPrivateLocal() async {
    final rx = await MessageLocalStore.loadReactions(_privateRoomId);
    final del = await MessageLocalStore.loadDeleted(_privateRoomId);
    final star = await MessageLocalStore.loadStarred(_privateRoomId);
    if (!mounted) return;
    setState(() {
      _reactions
        ..clear()
        ..addAll(rx);
      _deletedIds
        ..clear()
        ..addAll(del);
      _starredIds
        ..clear()
        ..addAll(star);
    });
  }

  Future<void> _handlePrivateMsgAction(Map<String, dynamic> msg) async {
    final isMe = msg['from'] == widget.myUsername;
    final content = msg['message']?.toString() ?? '';
    final result = await showMessageActionsSheet(
      context: context,
      isMe: isMe,
      previewText: content.isEmpty ? 'Media' : content,
    );
    if (result == null || !mounted) return;
    final key = _msgKey(msg);
    switch (result.action) {
      case MsgAction.reply:
        setState(() => _replyToMsg = msg);
        break;
      case MsgAction.copy:
        copyToClipboard(context, content);
        break;
      case MsgAction.react:
        if (result.emoji == null) break;
        final map = Map<String, int>.from(_reactions[key] ?? {});
        map[result.emoji!] = (map[result.emoji!] ?? 0) + 1;
        setState(() => _reactions[key] = map);
        await MessageLocalStore.saveReactions(_privateRoomId, _reactions);
        break;
      case MsgAction.forward:
        final target = await showForwardSheet(
          context,
          ['Chat Global', widget.targetDisplayName, 'Saya'],
        );
        if (target != null && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Pesan diteruskan ke $target'),
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
        break;
      case MsgAction.deleteMe:
      case MsgAction.deleteEveryone:
        setState(() => _deletedIds.add(key));
        await MessageLocalStore.saveDeleted(_privateRoomId, _deletedIds);
        break;
      case MsgAction.star:
        setState(() {
          if (_starredIds.contains(key)) {
            _starredIds.remove(key);
          } else {
            _starredIds.add(key);
          }
        });
        await MessageLocalStore.saveStarred(_privateRoomId, _starredIds);
        break;
      case MsgAction.info:
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF1F2C34),
            title: const Text('Info pesan', style: TextStyle(color: Colors.white)),
            content: Text(
              'Dari: ${msg['from']}\nWaktu: ${msg['timestamp'] ?? '-'}\nKey: $key',
              style: const TextStyle(color: Colors.white70),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        break;
    }
  }

  void _connectWs() {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(_getWsUrl()));
      _channel.sink.add(jsonEncode({'type': 'auth', 'key': widget.sessionKey}));
      _channel.sink.add(jsonEncode({'type': 'getMessages', 'with': widget.targetUsername}));

      _channel.stream.listen(
        (event) {
          final data = jsonDecode(event);
          if (data['type'] == 'messages') {
            final incoming = List<Map<String, dynamic>>.from(
              (data['messages'] ?? []).whereType<Map>().map((m) => Map<String, dynamic>.from(m)),
            );
            final unique = <String, Map<String, dynamic>>{};
            for (final msg in incoming) {
              final key = _privateMessageKey(msg);
              unique[key] = msg;
              _markSeen(key);
            }
            if (!mounted) return;
            setState(() {
              _messages = unique.values.toList();
              _isConnected = true;
            });
            _scrollToBottom();
          } else if (data['type'] == 'chat' ||
              data['type'] == 'newMessage' ||
              data['type'] == 'message') {
            Map<String, dynamic> msg;
            final raw = data['message'];
            if (raw is Map) {
              msg = Map<String, dynamic>.from(raw);
            } else if (data['from'] != null || data['to'] != null) {
              msg = Map<String, dynamic>.from(data as Map);
            } else {
              return;
            }

            final from = msg['from']?.toString() ?? '';
            final to = msg['to']?.toString() ?? '';
            final isRelevant =
                (from == widget.targetUsername && to == widget.myUsername) ||
                (from == widget.myUsername && to == widget.targetUsername);
            if (!isRelevant || !mounted) return;

            final key = _privateMessageKey(msg);
            final contentFp = _contentFingerprint(msg);
            if (_hasSeen(key) || _hasSeen(contentFp)) return;
            if (_messages.any((m) =>
                _privateMessageKey(m) == key ||
                _contentFingerprint(m) == contentFp)) {
              _markSeen(key);
              _markSeen(contentFp);
              return;
            }
            _markSeen(key);
            _markSeen(contentFp);
            setState(() {
              _messages.add(msg);
            });
            _scrollToBottom();
          }
        },
        onError: (_) {
          if (mounted) setState(() => _isConnected = false);
        },
        onDone: () {
          if (mounted) setState(() => _isConnected = false);
        },
      );
    } catch (_) {
      setState(() => _isConnected = false);
    }
  }

  String _privateMessageKey(Map<String, dynamic> msg) {
    final id = msg['id'] ?? msg['_id'] ?? msg['messageId'];
    if (id != null && id.toString().trim().isNotEmpty) {
      return 'id:${id.toString()}';
    }
    return _contentFingerprint(msg);
  }

  /// Fingerprint berbasis konten (tanpa id) — menekan double emit server
  /// yang memberi id berbeda untuk pesan yang sama.
  String _contentFingerprint(Map<String, dynamic> msg) {
    final from = msg['from']?.toString() ?? '';
    final to = msg['to']?.toString() ?? '';
    final message = (msg['message']?.toString() ?? '').trim();
    final mediaType = msg['mediaType']?.toString() ?? 'text';
    // Bucket waktu 5 detik agar pesan identik yang sengaja dikirim ulang tetap bisa masuk.
    final tsRaw = msg['time']?.toString() ?? msg['timestamp']?.toString() ?? '';
    final ts = DateTime.tryParse(tsRaw) ?? DateTime.now();
    final bucket = ts.millisecondsSinceEpoch ~/ 5000;
    return 'fp:$from|$to|$mediaType|$message|$bucket';
  }

  bool _hasSeen(String key) {
    final t = _seenFingerprints[key];
    if (t == null) return false;
    if (DateTime.now().difference(t).inSeconds > 30) {
      _seenFingerprints.remove(key);
      return false;
    }
    return true;
  }

  void _markSeen(String key) {
    _seenFingerprints[key] = DateTime.now();
    // bersihkan yang sudah lama
    if (_seenFingerprints.length > 200) {
      final cutoff = DateTime.now().subtract(const Duration(seconds: 30));
      _seenFingerprints.removeWhere((_, t) => t.isBefore(cutoff));
    }
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _sendMedia(bool isVideo) async {
    try {
      final XFile? picked = isVideo
          ? await _picker.pickVideo(source: ImageSource.gallery)
          : await _picker.pickImage(source: ImageSource.gallery);

      if (picked == null) return;
      final file = File(picked.path);
      if (!await file.exists()) {
        _showError('File tidak ditemukan.');
        return;
      }
      final size = await file.length();
      if (size > 80 * 1024 * 1024) {
        _showError('Ukuran ${isVideo ? 'video' : 'foto'} maksimal 80 MB.');
        return;
      }

      setState(() => _isSending = true);

      final fileName = picked.name.isNotEmpty
          ? picked.name
          : (isVideo ? 'video.mp4' : 'image.jpg');
      final endpoints = <String>[
        '/background/upload-${isVideo ? 'video' : 'image'}',
        '/chat/upload-${isVideo ? 'video' : 'image'}',
        '/chat/upload-file',
      ];
      final fields = isVideo
          ? <String>['video', 'file', 'media']
          : <String>['image', 'file', 'media'];

      String? mediaUrl;
      String lastError = 'Gagal upload media private';

      for (final ep in endpoints) {
        for (final field in fields) {
          try {
            final request = http.MultipartRequest(
              'POST',
              Uri.parse('$baseUrl$ep'),
            );
            request.files.add(await http.MultipartFile.fromPath(
              field,
              file.path,
              filename: fileName,
            ));
            request.fields.addAll({
              'userId': widget.myUsername,
              'username': widget.myUsername,
              'role': 'user',
              'type': isVideo ? 'video' : 'image',
              'fileName': fileName,
            });

            final response = await request.send().timeout(
              isVideo
                  ? const Duration(minutes: 3)
                  : const Duration(seconds: 60),
            );
            final body = await response.stream.bytesToString();

            if (response.statusCode >= 200 && response.statusCode < 300) {
              try {
                final json = jsonDecode(body);
                if (json is Map) {
                  final candidates = <dynamic>[
                    json['data'] is Map ? (json['data'] as Map)['value'] : null,
                    json['data'] is Map ? (json['data'] as Map)['url'] : null,
                    json['url'],
                    json['file'],
                    json['path'],
                    json['media'],
                    json['video'],
                    json['image'],
                  ];
                  for (final c in candidates) {
                    if (c is String && c.trim().isNotEmpty) {
                      mediaUrl = c.trim();
                      break;
                    }
                  }
                }
              } catch (_) {}
              // Kalau body langsung URL string
              if (mediaUrl == null &&
                  body.trim().startsWith('http') &&
                  body.trim().length < 500) {
                mediaUrl = body.trim();
              }
              if (mediaUrl != null) break;
              // Sukses tapi URL tidak ada — tetap anggap ok, biar server-side message muncul
              if (response.statusCode == 200 || response.statusCode == 201) {
                mediaUrl = '';
                break;
              }
            } else if (body.contains('Unexpected file') ||
                body.contains('MulterError')) {
              continue;
            } else {
              lastError = '($response.statusCode)';
            }
          } catch (e) {
            lastError = e.toString();
          }
        }
        if (mediaUrl != null) break;
      }

      if (mediaUrl != null && _isConnected) {
        if (mediaUrl.isNotEmpty) {
          final resolved = _resolveMediaUrl(mediaUrl);
          _channel.sink.add(jsonEncode({
            'type': 'chat',
            'to': widget.targetUsername,
            'message': resolved,
            'mediaType': isVideo ? 'video' : 'image',
          }));
        } else {
          // Upload ok tapi URL kosong — reload nanti
        }
      } else if (mediaUrl == null) {
        _showError(lastError);
      }
    } catch (e) {
      _showError('Error: $e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _sendText() {
    var text = _msgCtrl.text.trim();
    if (text.isEmpty || !_isConnected || _isSending) return;
    if (_replyToMsg != null) {
      final a = _replyToMsg!['from']?.toString() ?? 'User';
      final q = _replyToMsg!['message']?.toString() ?? 'Media';
      text = '↪ $a: ${q.length > 40 ? '${q.substring(0, 40)}…' : q}\n$text';
      setState(() => _replyToMsg = null);
    }

    setState(() => _isSending = true);

    final pending = <String, dynamic>{
      'from': widget.myUsername,
      'to': widget.targetUsername,
      'message': text,
      'mediaType': 'text',
      'timestamp': DateTime.now().toIso8601String(),
    };
    final fp = _contentFingerprint(pending);
    _markSeen(fp);

    // Tampilkan sekali secara lokal; echo server akan di-skip via fingerprint.
    setState(() => _messages.add(pending));

    try {
      _channel.sink.add(jsonEncode({
        'type': 'chat',
        'to': widget.targetUsername,
        'message': text,
        'mediaType': 'text',
      }));
    } catch (e) {
      _seenFingerprints.remove(fp);
      if (mounted) {
        setState(() {
          _messages.removeWhere((m) => identical(m, pending) || _contentFingerprint(m) == fp);
          _isSending = false;
        });
        _showError('Gagal mengirim: $e');
      }
      return;
    }

    _msgCtrl.clear();
    _typing?.onLocalSend();
    _scrollToBottom();

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) setState(() => _isSending = false);
    });
  }

  @override
  void dispose() {
    _typing?.dispose();
    try {
      _channel.sink.close();
    } catch (_) {}
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Widget _buildBubble(Map<String, dynamic> msg) {
    final isMe = msg['from'] == widget.myUsername;
    final key = _msgKey(msg);
    if (_deletedIds.contains(key)) {
      return Align(
        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.delete_outline, color: Colors.grey.shade600, size: 16),
              const SizedBox(width: 8),
              Text(
                'Pesan ini dihapus',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontStyle: FontStyle.italic,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      );
    }
    String content = msg['message']?.toString() ?? '';
    String mediaType = msg['mediaType']?.toString() ?? 'text';

    if (mediaType == 'text') {
      if (_isImageUrl(content)) mediaType = 'image';
      else if (_isVideoUrl(content)) mediaType = 'video';
    }

    final rxMap = _reactions[key] ?? {};

    return GestureDetector(
      onLongPress: () => _handlePrivateMsgAction(msg),
      onDoubleTap: () async {
        final map = Map<String, int>.from(_reactions[key] ?? {});
        map['❤️'] = (map['❤️'] ?? 0) + 1;
        setState(() => _reactions[key] = map);
        await MessageLocalStore.saveReactions(_privateRoomId, _reactions);
      },
      child: Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          gradient: isMe
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppTheme.I.accent, AppTheme.I.accentDark],
                )
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.10),
                    Colors.white.withOpacity(0.05),
                  ],
                ),
          border: Border.all(
            color: Colors.white.withOpacity(isMe ? 0.14 : 0.08),
          ),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(isMe ? 20 : 6),
            bottomRight: Radius.circular(isMe ? 6 : 20),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (mediaType == 'image') ...[
              GestureDetector(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    backgroundColor: Colors.transparent,
                    child: InteractiveViewer(child: Image.network(content, fit: BoxFit.contain)),
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    content,
                    width: 180,
                    height: 180,
                    fit: BoxFit.cover,
                    loadingBuilder: (_, child, p) => p == null
                        ? child
                        : const SizedBox(
                            height: 180,
                            width: 180,
                            child: Center(child: CircularProgressIndicator(color: Colors.white)),
                          ),
                  ),
                ),
              ),
            ] else if (mediaType == 'video') ...[
              GestureDetector(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => Dialog(
                    backgroundColor: Colors.transparent,
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.9,
                      height: MediaQuery.of(context).size.height * 0.7,
                      child: VideoPlayerWidget(videoUrl: content, onSave: () {}),
                    ),
                  ),
                ),
                child: Container(
                  width: 180,
                  height: 150,
                  color: Colors.black54,
                  child: const Center(
                    child: Icon(Icons.play_circle_filled, color: Colors.white, size: 40),
                  ),
                ),
              ),
            ] else ...[
              Text(
                content,
                style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.3),
              ),
            ],
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_starredIds.contains(key)) ...[
                  const Icon(Icons.star, size: 12, color: Colors.amber),
                  const SizedBox(width: 4),
                ],
                Text(
                  _formatTime(msg['time']?.toString() ?? msg['timestamp']?.toString()),
                  style: TextStyle(color: isMe ? Colors.white70 : Colors.white54, fontSize: 10),
                ),
              ],
            ),
            if (rxMap.isNotEmpty) ReactionChips(reactions: rxMap),
          ],
        ),
      ),
    ),
    );
  }

  Widget _buildInputBar() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_replyToMsg != null)
          ReplyBar(
            author: _replyToMsg!['from']?.toString() ?? 'User',
            preview: _replyToMsg!['message']?.toString() ?? 'Media',
            onClose: () => setState(() => _replyToMsg = null),
            accent: accent,
          ),
        Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xEB0B0F17),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.image_rounded, color: accent),
            onPressed: _isSending ? null : () => _sendMedia(false),
          ),
          IconButton(
            icon: Icon(Icons.videocam_rounded, color: accent),
            onPressed: _isSending ? null : () => _sendMedia(true),
          ),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Type a message...',
                hintStyle: TextStyle(color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
              onChanged: (t) => _typing?.onLocalTextChanged(t),
              onSubmitted: (_) => _sendText(),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [AppTheme.I.accent, AppTheme.I.accentDark]),
            ),
            child: IconButton(
              icon: _isSending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(
                      Icons.send_rounded,
                      color: Colors.white,
                    ),
              onPressed: _isSending ? null : _sendText,
            ),
          ),
        ],
      ),
    ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [AppTheme.I.accent, AppTheme.I.accentDark]),
              ),
              child: ClipOval(
                child: widget.targetProfileUrl != null && widget.targetProfileUrl!.isNotEmpty
                    ? Image.network(
                        widget.targetProfileUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.person, color: Colors.white),
                      )
                    : const Icon(Icons.person, color: Colors.white),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  VerifiedName(
                    username: widget.targetUsername,
                    displayName: widget.targetDisplayName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                    badgeSize: 16,
                  ),
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isConnected ? accent : Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _isConnected ? 'Online' : 'Offline',
                        style: TextStyle(
                          color: _isConnected ? accent : Colors.white54,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.videocam, color: Colors.white),
            tooltip: 'Panggilan video',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaCallPage(
                    peerName: widget.targetDisplayName.isNotEmpty
                        ? widget.targetDisplayName
                        : widget.targetUsername,
                    peerAvatarUrl: widget.targetProfileUrl,
                    isVideo: true,
                    isOutgoing: true,
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.call, color: Colors.white),
            tooltip: 'Panggilan suara',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaCallPage(
                    peerName: widget.targetDisplayName.isNotEmpty
                        ? widget.targetDisplayName
                        : widget.targetUsername,
                    peerAvatarUrl: widget.targetProfileUrl,
                    isVideo: false,
                    isOutgoing: true,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _messages.isEmpty && _typingUsers.isEmpty
                ? Center(
                    child: Text(
                      "Mulai chat dengan ${widget.targetDisplayName}",
                      style: const TextStyle(color: Colors.white30),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.only(top: 16, bottom: 16),
                    itemCount: _messages.length + (_typingUsers.isNotEmpty ? 1 : 0),
                    itemBuilder: (_, i) {
                      if (i < _messages.length) {
                        return _buildBubble(_messages[i]);
                      }
                      final names = _typingUsers.join(', ');
                      return TypingBubble(
                        label: _typingUsers.length == 1
                            ? '$names sedang mengetik'
                            : '$names sedang mengetik',
                        accent: accent,
                      );
                    },
                  ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }
}

// ==========================================================
// VIDEO PLAYER WIDGET
// ==========================================================
class VideoPlayerWidget extends StatefulWidget {
  final String videoUrl;
  final VoidCallback? onSave;

  const VideoPlayerWidget({
    super.key,
    required this.videoUrl,
    this.onSave,
  });

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  VideoPlayerController? _ctrl;
  ChewieController? _chewie;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  List<String> _urlCandidates(String raw) {
    final out = <String>[];
    void add(String u) {
      final t = u.trim();
      if (t.isEmpty) return;
      if (!out.contains(t)) out.add(t);
    }

    add(raw);
    final resolved = _resolveMediaUrl(raw);
    add(resolved);

    // Variasi path uploads yang sering dipakai server
    if (raw.startsWith('/')) {
      add('$baseUrl$raw');
      add('$baseUrl/uploads${raw.startsWith('/uploads') ? raw.substring(8) : raw}');
    } else if (!raw.startsWith('http')) {
      add('$baseUrl/$raw');
      add('$baseUrl/uploads/$raw');
    }

    // Ganti http→https atau sebaliknya (beberapa device blok mixed content)
    if (resolved.startsWith('http://')) {
      add(resolved.replaceFirst('http://', 'https://'));
    } else if (resolved.startsWith('https://')) {
      add(resolved.replaceFirst('https://', 'http://'));
    }

    return out;
  }

  Future<VideoPlayerController?> _tryNetwork(String url) async {
    final c = VideoPlayerController.networkUrl(
      Uri.parse(url),
      httpHeaders: const {
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
      },
    );
    try {
      await c.initialize().timeout(const Duration(seconds: 25));
      return c;
    } catch (_) {
      try {
        await c.dispose();
      } catch (_) {}
      return null;
    }
  }

  Future<VideoPlayerController?> _tryDownloadThenPlay(String url) async {
    try {
      final dir = await getTemporaryDirectory();
      final name =
          'chat_vid_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final dest = File('${dir.path}/$name');
      final res = await http
          .get(Uri.parse(url), headers: const {
            'Accept': '*/*',
            'User-Agent':
                'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
          })
          .timeout(const Duration(minutes: 2));
      if (res.statusCode < 200 || res.statusCode >= 300) return null;
      if (res.bodyBytes.isEmpty) return null;
      await dest.writeAsBytes(res.bodyBytes, flush: true);
      final c = VideoPlayerController.file(dest);
      await c.initialize().timeout(const Duration(seconds: 20));
      return c;
    } catch (_) {
      return null;
    }
  }

  Future<VideoPlayerController?> _tryLocalFile(String path) async {
    try {
      final f = File(path);
      if (!await f.exists()) return null;
      final c = VideoPlayerController.file(f);
      await c.initialize().timeout(const Duration(seconds: 15));
      return c;
    } catch (_) {
      return null;
    }
  }

  Future<void> _initVideo() async {
    // Bersihkan controller lama
    try {
      _chewie?.dispose();
    } catch (_) {}
    try {
      await _ctrl?.dispose();
    } catch (_) {}
    _chewie = null;
    _ctrl = null;

    final raw = widget.videoUrl.trim();
    if (raw.isEmpty) {
      if (mounted) {
        setState(() {
          _error = 'URL video kosong';
          _isLoading = false;
        });
      }
      return;
    }

    // Path lokal langsung
    if (!raw.startsWith('http') && !raw.startsWith('/') && raw.contains('/')) {
      final local = await _tryLocalFile(raw);
      if (local != null) {
        await _attachController(local);
        return;
      }
    }

    final candidates = _urlCandidates(raw);
    VideoPlayerController? success;

    // 1) Coba network langsung
    for (final url in candidates) {
      success = await _tryNetwork(url);
      if (success != null) break;
    }

    // 2) Kalau gagal (sering karena /uploads 404 / CORS), download lalu play dari file
    if (success == null) {
      for (final url in candidates) {
        if (!url.startsWith('http')) continue;
        success = await _tryDownloadThenPlay(url);
        if (success != null) break;
      }
    }

    if (success != null) {
      await _attachController(success);
    } else if (mounted) {
      setState(() {
        _error =
            'Tidak bisa memutar video.\nPastikan file ter-upload & server menyajikan /uploads.';
        _isLoading = false;
      });
    }
  }

  Future<void> _attachController(VideoPlayerController c) async {
    _ctrl = c;
    _chewie = ChewieController(
      videoPlayerController: c,
      autoPlay: true,
      looping: false,
      aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
      allowFullScreen: true,
      materialProgressColors: ChewieProgressColors(
        playedColor: const Color(0xFFC52222),
        handleColor: const Color(0xFFDE4A4A),
        bufferedColor: Colors.white.withOpacity(0.3),
        backgroundColor: Colors.white.withOpacity(0.1),
      ),
      placeholder: Container(
        color: Colors.black,
        child: const Center(
            child: CircularProgressIndicator(color: Colors.white)),
      ),
      errorBuilder: (context, errorMessage) {
        return Center(
          child: Text(
            errorMessage,
            style: const TextStyle(color: Colors.white70),
            textAlign: TextAlign.center,
          ),
        );
      },
    );
    if (mounted) {
      setState(() {
        _isLoading = false;
        _error = null;
      });
    }
  }

  @override
  void dispose() {
    _chewie?.dispose();
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        color: Colors.black,
        child: const Center(
            child: CircularProgressIndicator(color: Colors.white)),
      );
    }

    if (_error != null) {
      return Container(
        color: Colors.black,
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 48),
              const SizedBox(height: 16),
              const Text(
                'Gagal memuat video',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(
                _error!,
                style: const TextStyle(color: Colors.white54, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _isLoading = true;
                    _error = null;
                  });
                  _initVideo();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC52222),
                ),
                child: const Text('Coba Lagi'),
              ),
            ],
          ),
        ),
      );
    }

    return Stack(
      children: [
        if (_chewie != null) Chewie(controller: _chewie!),
        if (widget.onSave != null)
          Positioned(
            top: 16,
            right: 16,
            child: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: Colors.black54,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.download, color: Colors.white),
              ),
              onPressed: widget.onSave,
            ),
          ),
      ],
    );
  }
}