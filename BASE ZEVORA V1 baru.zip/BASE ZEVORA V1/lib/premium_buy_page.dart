import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'premium_service.dart';

/// Halaman Beli Centang Biru — UI mirip screenshot.
/// Pembayaran HANYA dari saldo tabungan.
class PremiumBuyPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const PremiumBuyPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<PremiumBuyPage> createState() => _PremiumBuyPageState();
}

class _PremiumBuyPageState extends State<PremiumBuyPage> {
  PremiumStatus? _status;
  double _tabungan = 0;
  List<Map<String, dynamic>> _history = [];
  bool _loading = true;
  bool _buying = false;

  static const _bg = Color(0xFF000000);
  static const _card = Color(0xFF14161C);
  static const _blue = Color(0xFF1D9BF0);
  static const _blueBtn = Color(0xFF2B7DE9);
  static const _text = Color(0xFFE8ECF2);
  static const _textSub = Color(0xFF8B93A7);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final s = await PremiumService.statusOf(widget.username);
    final t = await PremiumService.getTabunganSaldo(widget.username);
    final h = await PremiumService.history();
    if (!mounted) return;
    setState(() {
      _status = s;
      _tabungan = t;
      _history = h.where((e) => e['username'] == widget.username).toList();
      _loading = false;
    });
  }

  String _rp(double n) {
    final s = n.toStringAsFixed(0);
    final buf = StringBuffer('Rp');
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Future<void> _buy(PremiumPackage pkg) async {
    if (_buying) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Beli Centang Biru?',
            style: TextStyle(color: _text)),
        content: Text(
          'Paket: ${pkg.label}\nHarga: ${_rp(pkg.price)}\n\n'
          'Dibayar dari saldo tabungan.\nSaldo: ${_rp(_tabungan)}',
          style: const TextStyle(color: _textSub, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: _textSub)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _blueBtn,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('BELI'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _buying = true);
    final err = await PremiumService.buyWithTabungan(
      username: widget.username,
      pkg: pkg,
    );
    if (!mounted) return;
    setState(() => _buying = false);

    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(err),
          backgroundColor: Colors.red.shade700,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    HapticFeedback.mediumImpact();
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Berhasil! Centang biru aktif (${pkg.label})'),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final active = _status?.active == true;

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _text, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Centang Biru',
          style: TextStyle(
            color: _text,
            fontWeight: FontWeight.w600,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: _textSub),
            onPressed: _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _blue))
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              children: [
                // Status card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: active
                          ? _blue.withOpacity(0.45)
                          : Colors.white.withOpacity(0.06),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _blue.withOpacity(0.15),
                        ),
                        child: const Icon(Icons.verified,
                            color: _blue, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Centang biru',
                              style: TextStyle(
                                color: _text,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              active
                                  ? (_status!.permanent
                                      ? 'Terverifikasi · Permanen'
                                      : 'Terverifikasi · s/d ${_fmtDate(_status!.expiresAt)}')
                                  : 'Belum terverifikasi',
                              style: TextStyle(
                                color: active ? _blue : _textSub,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Tabungan info
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1D24),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _blue.withOpacity(0.25)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.account_balance_wallet_outlined,
                          color: _blue.withOpacity(0.9), size: 20),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Bayar dari Saldo Tabungan',
                              style: TextStyle(
                                  color: _text,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              'Saldo tersedia: ${_rp(_tabungan)}',
                              style: const TextStyle(
                                  color: _textSub, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 22),
                const Text(
                  'Pilih paket',
                  style: TextStyle(
                    color: _text,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),

                ...PremiumService.packages.map((pkg) {
                  final canBuy = _tabungan >= pkg.price && !_buying;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: _card,
                        borderRadius: BorderRadius.circular(14),
                        border:
                            Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.verified, color: _blue, size: 26),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  pkg.label,
                                  style: const TextStyle(
                                    color: _text,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  _rp(pkg.price),
                                  style: const TextStyle(
                                    color: _textSub,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 36,
                            child: ElevatedButton(
                              onPressed: canBuy ? () => _buy(pkg) : null,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _blueBtn,
                                disabledBackgroundColor:
                                    _blueBtn.withOpacity(0.25),
                                foregroundColor: Colors.white,
                                disabledForegroundColor:
                                    Colors.white.withOpacity(0.4),
                                elevation: 0,
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 18),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: const Text(
                                'BELI',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),

                if (_tabungan <= 0) ...[
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: Colors.orange.withOpacity(0.3)),
                    ),
                    child: const Text(
                      'Saldo tabungan kosong. Isi tabungan dulu untuk membeli centang biru.',
                      style: TextStyle(color: Colors.orange, fontSize: 12),
                    ),
                  ),
                ],

                const SizedBox(height: 24),
                const Text(
                  'Riwayat',
                  style: TextStyle(
                    color: _text,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                if (_history.isEmpty)
                  const Text(
                    'Belum ada transaksi.',
                    style: TextStyle(color: _textSub, fontSize: 13),
                  )
                else
                  ..._history.map((h) {
                    final at = DateTime.tryParse(h['at']?.toString() ?? '');
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.verified, color: _blue, size: 20),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    h['package']?.toString() ?? '-',
                                    style: const TextStyle(
                                        color: _text,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13),
                                  ),
                                  Text(
                                    at != null
                                        ? '${at.day.toString().padLeft(2, '0')}/${at.month.toString().padLeft(2, '0')}/${at.year}'
                                        : '-',
                                    style: const TextStyle(
                                        color: _textSub, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              _rp((h['price'] is num)
                                  ? (h['price'] as num).toDouble()
                                  : 0),
                              style: const TextStyle(
                                  color: _textSub, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              ],
            ),
    );
  }

  String _fmtDate(DateTime? d) {
    if (d == null) return '-';
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }
}
