import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'wa_profile_page.dart';
import 'wa_privacy_page.dart';

/// Chat settings hub — WhatsApp style (lengkap)
class WaSettingsPage extends StatelessWidget {
  final String username;
  final String role;
  final String sessionKey;

  const WaSettingsPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  static const _green = Color(0xFF25D366);
  static const _bg = Color(0xFF0B141A);
  static const _card = Color(0xFF111B21);
  static const _text = Color(0xFFE9EDEF);
  static const _muted = Color(0xFF8696A0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _text),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Pengaturan', style: TextStyle(color: _text)),
      ),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          ListTile(
            leading: CircleAvatar(
              backgroundColor: _green.withOpacity(0.2),
              child: Text(
                username.isNotEmpty ? username[0].toUpperCase() : '?',
                style: const TextStyle(
                    color: _green, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(username,
                style: const TextStyle(
                    color: _text, fontWeight: FontWeight.w600, fontSize: 17)),
            subtitle: Text(role,
                style: const TextStyle(color: _muted, fontSize: 13)),
            trailing: const Icon(Icons.qr_code_2, color: _muted),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaProfilePage(
                    username: username,
                    role: role,
                    sessionKey: sessionKey,
                  ),
                ),
              );
            },
          ),
          const Divider(color: Colors.white12),
          _item(
            context,
            icon: Icons.key_outlined,
            title: 'Akun',
            subtitle: 'Notifikasi keamanan, ganti role, info akun',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaAccountPage(
                    username: username,
                    role: role,
                    sessionKey: sessionKey,
                  ),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.lock_outline,
            title: 'Privasi',
            subtitle: 'Foto profil, online, terakhir dilihat, status',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaPrivacyPage(username: username),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.person_outline,
            title: 'Profil',
            subtitle: 'Nama, foto, tentang, username, role',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaProfilePage(
                    username: username,
                    role: role,
                    sessionKey: sessionKey,
                  ),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.chat_outlined,
            title: 'Chat',
            subtitle: 'Tema, wallpaper, riwayat chat',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaChatSettingsPage(username: username),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.notifications_none,
            title: 'Notifikasi',
            subtitle: 'Pesan, grup, dan dering panggilan',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      WaNotificationSettingsPage(username: username),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.storage_outlined,
            title: 'Penyimpanan dan data',
            subtitle: 'Foto, video, file, unduhan otomatis',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaStoragePage(username: username),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.language,
            title: 'Bahasa aplikasi',
            subtitle: 'Indonesia (perangkat)',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => WaLanguagePage(username: username),
                ),
              );
            },
          ),
          _item(
            context,
            icon: Icons.help_outline,
            title: 'Bantuan',
            subtitle: 'Chat owner, channel, TikTok',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const WaHelpPage(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _item(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: _muted),
      title: Text(title, style: const TextStyle(color: _text, fontSize: 16)),
      subtitle: Text(subtitle,
          style: const TextStyle(color: _muted, fontSize: 13)),
      onTap: onTap,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Shared WA palette
// ═══════════════════════════════════════════════════════════════
class _Wa {
  static const green = Color(0xFF25D366);
  static const teal = Color(0xFF008069);
  static const bg = Color(0xFF0B141A);
  static const card = Color(0xFF111B21);
  static const surface = Color(0xFF1F2C34);
  static const text = Color(0xFFE9EDEF);
  static const muted = Color(0xFF8696A0);
}

PreferredSizeWidget _waAppBar(String title, {List<Widget>? actions}) {
  return AppBar(
    elevation: 0,
    iconTheme: const IconThemeData(color: _Wa.text),
    title: Text(title, style: const TextStyle(color: _Wa.text)),
    actions: actions,
  );
}

// ═══════════════════════════════════════════════════════════════
// AKUN — notifikasi keamanan, ganti role, info akun
// ═══════════════════════════════════════════════════════════════
class WaAccountPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const WaAccountPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<WaAccountPage> createState() => _WaAccountPageState();
}

class _WaAccountPageState extends State<WaAccountPage> {
  bool _securityNotif = true;
  bool _twoStep = false;
  String _displayRole = '';
  String _email = '';
  String _phone = '';

  static const _roles = [
    'member',
    'reseller',
    'vip',
    'admin',
    'partner',
    'owner',
    'developer',
    'staff',
    'creator',
  ];

  @override
  void initState() {
    super.initState();
    _displayRole = widget.role;
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final u = widget.username;
    setState(() {
      _securityNotif = p.getBool('wa_sec_notif_$u') ?? true;
      _twoStep = p.getBool('wa_2fa_$u') ?? false;
      _displayRole = p.getString('wa_display_role_$u') ?? widget.role;
      _email = p.getString('wa_email_$u') ?? '';
      _phone = p.getString('wa_phone_$u') ?? '';
    });
  }

  Future<void> _saveBool(String key, bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(key, v);
  }

  Future<void> _changeRole() async {
    final result = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _Wa.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text(
                  'Ganti Role (tampilan lokal)',
                  style: TextStyle(
                      color: _Wa.text,
                      fontWeight: FontWeight.w700,
                      fontSize: 16),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Perubahan role di sini hanya tampilan di perangkat. Role server tetap dikelola admin/developer.',
                  style: TextStyle(color: _Wa.muted, fontSize: 12),
                ),
              ),
              const SizedBox(height: 8),
              ..._roles.map((r) {
                final selected =
                    r.toLowerCase() == _displayRole.toLowerCase();
                return ListTile(
                  title: Text(r.toUpperCase(),
                      style: const TextStyle(color: _Wa.text)),
                  trailing: selected
                      ? const Icon(Icons.check, color: _Wa.green)
                      : null,
                  onTap: () => Navigator.pop(ctx, r),
                );
              }),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (result == null) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('wa_display_role_${widget.username}', result);
    setState(() => _displayRole = result);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Role tampilan diubah ke $result')),
    );
  }

  Future<void> _editField({
    required String title,
    required String current,
    required String prefKey,
    required ValueChanged<String> onSaved,
  }) async {
    final ctrl = TextEditingController(text: current);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _Wa.card,
        title: Text(title, style: const TextStyle(color: _Wa.text)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: _Wa.text),
          decoration: const InputDecoration(
            enabledBorder:
                UnderlineInputBorder(borderSide: BorderSide(color: _Wa.muted)),
            focusedBorder:
                UnderlineInputBorder(borderSide: BorderSide(color: _Wa.green)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: _Wa.muted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Simpan', style: TextStyle(color: _Wa.green)),
          ),
        ],
      ),
    );
    if (ok == true) {
      final p = await SharedPreferences.getInstance();
      await p.setString(prefKey, ctrl.text.trim());
      onSaved(ctrl.text.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.username;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Akun'),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          _section('Keamanan'),
          SwitchListTile(
            secondary: const Icon(Icons.security, color: _Wa.muted),
            title: const Text('Notifikasi keamanan',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Dapatkan notifikasi saat ada login dari perangkat lain',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _securityNotif,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _securityNotif = v);
              _saveBool('wa_sec_notif_$u', v);
            },
          ),
          SwitchListTile(
            secondary: const Icon(Icons.lock_person_outlined, color: _Wa.muted),
            title: const Text('Verifikasi dua langkah',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'PIN tambahan saat masuk (simulasi lokal)',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _twoStep,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _twoStep = v);
              _saveBool('wa_2fa_$u', v);
            },
          ),
          const Divider(color: Colors.white12),
          _section('Akun'),
          ListTile(
            leading: const Icon(Icons.badge_outlined, color: _Wa.muted),
            title: const Text('Ganti role', style: TextStyle(color: _Wa.text)),
            subtitle: Text(
              _displayRole.isEmpty ? widget.role : _displayRole,
              style: const TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            trailing: const Icon(Icons.chevron_right, color: _Wa.muted),
            onTap: _changeRole,
          ),
          ListTile(
            leading: const Icon(Icons.email_outlined, color: _Wa.muted),
            title: const Text('Email', style: TextStyle(color: _Wa.text)),
            subtitle: Text(
              _email.isEmpty ? 'Belum diatur' : _email,
              style: const TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            onTap: () => _editField(
              title: 'Email',
              current: _email,
              prefKey: 'wa_email_$u',
              onSaved: (v) => setState(() => _email = v),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.phone_outlined, color: _Wa.muted),
            title: const Text('Nomor terhubung',
                style: TextStyle(color: _Wa.text)),
            subtitle: Text(
              _phone.isEmpty ? 'Belum diatur' : _phone,
              style: const TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            onTap: () => _editField(
              title: 'Nomor',
              current: _phone,
              prefKey: 'wa_phone_$u',
              onSaved: (v) => setState(() => _phone = v),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline, color: _Wa.muted),
            title: const Text('Info akun', style: TextStyle(color: _Wa.text)),
            subtitle: Text(
              'Username: ${widget.username}\nRole server: ${widget.role}',
              style: const TextStyle(color: _Wa.muted, fontSize: 13),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
            title: const Text('Hapus data akun lokal',
                style: TextStyle(color: Colors.redAccent)),
            subtitle: const Text(
              'Hapus preferensi akun di perangkat ini',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: _Wa.card,
                  title: const Text('Hapus data lokal?',
                      style: TextStyle(color: _Wa.text)),
                  content: const Text(
                    'Preferensi akun di perangkat ini akan direset.',
                    style: TextStyle(color: _Wa.muted),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Batal',
                          style: TextStyle(color: _Wa.muted)),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Hapus',
                          style: TextStyle(color: Colors.redAccent)),
                    ),
                  ],
                ),
              );
              if (ok == true) {
                final p = await SharedPreferences.getInstance();
                await p.remove('wa_sec_notif_$u');
                await p.remove('wa_2fa_$u');
                await p.remove('wa_display_role_$u');
                await p.remove('wa_email_$u');
                await p.remove('wa_phone_$u');
                await _load();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Data akun lokal dihapus')),
                );
              }
            },
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Pengaturan disimpan di perangkat ini dan diterapkan di seluruh aplikasi ZEVORA PROJECT.',
              style: TextStyle(color: _Wa.muted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(t,
            style: const TextStyle(
                color: _Wa.green, fontWeight: FontWeight.w600, fontSize: 13)),
      );
}

// ═══════════════════════════════════════════════════════════════
// CHAT — tema, wallpaper, riwayat
// ═══════════════════════════════════════════════════════════════
class WaChatSettingsPage extends StatefulWidget {
  final String username;
  const WaChatSettingsPage({super.key, required this.username});

  @override
  State<WaChatSettingsPage> createState() => _WaChatSettingsPageState();
}

class _WaChatSettingsPageState extends State<WaChatSettingsPage> {
  String _theme = 'system'; // system | light | dark
  String _wallpaper = 'default';
  bool _enterIsSend = false;
  bool _mediaVisibility = true;
  bool _keepChats = true;
  double _fontSize = 1.0; // 0.85 small, 1 normal, 1.15 large

  static const _wallpapers = {
    'default': 'Default gelap',
    'solid_dark': 'Hitam solid',
    'solid_teal': 'Teal',
    'solid_purple': 'Ungu',
    'pattern_dots': 'Pola titik',
    'pattern_waves': 'Pola gelombang',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _u => widget.username;

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _theme = p.getString('wa_chat_theme_$_u') ?? 'system';
      _wallpaper = p.getString('wa_chat_wallpaper_$_u') ?? 'default';
      _enterIsSend = p.getBool('wa_chat_enter_$_u') ?? false;
      _mediaVisibility = p.getBool('wa_chat_media_vis_$_u') ?? true;
      _keepChats = p.getBool('wa_chat_keep_$_u') ?? true;
      _fontSize = p.getDouble('wa_chat_font_$_u') ?? 1.0;
    });
  }

  Future<void> _set(String key, dynamic value) async {
    final p = await SharedPreferences.getInstance();
    if (value is String) await p.setString(key, value);
    if (value is bool) await p.setBool(key, value);
    if (value is double) await p.setDouble(key, value);
  }

  Future<void> _pickTheme() async {
    final r = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _Wa.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        Widget tile(String v, String label, IconData icon) {
          return ListTile(
            leading: Icon(icon, color: _Wa.muted),
            title: Text(label, style: const TextStyle(color: _Wa.text)),
            trailing: _theme == v
                ? const Icon(Icons.check, color: _Wa.green)
                : null,
            onTap: () => Navigator.pop(ctx, v),
          );
        }

        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              tile('system', 'Default sistem', Icons.settings_suggest),
              tile('light', 'Terang', Icons.light_mode),
              tile('dark', 'Gelap', Icons.dark_mode),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (r == null) return;
    setState(() => _theme = r);
    await _set('wa_chat_theme_$_u', r);
  }

  Future<void> _pickWallpaper() async {
    final r = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _Wa.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Wallpaper chat',
                    style: TextStyle(
                        color: _Wa.text,
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
              ),
              ..._wallpapers.entries.map((e) {
                return ListTile(
                  title:
                      Text(e.value, style: const TextStyle(color: _Wa.text)),
                  trailing: _wallpaper == e.key
                      ? const Icon(Icons.check, color: _Wa.green)
                      : null,
                  onTap: () => Navigator.pop(ctx, e.key),
                );
              }),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (r == null) return;
    setState(() => _wallpaper = r);
    await _set('wa_chat_wallpaper_$_u', r);
  }

  Future<void> _clearHistory() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _Wa.card,
        title: const Text('Hapus semua chat?',
            style: TextStyle(color: _Wa.text)),
        content: const Text(
          'Riwayat chat lokal di perangkat ini akan dihapus. Tindakan ini tidak dapat dibatalkan.',
          style: TextStyle(color: _Wa.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: _Wa.muted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus',
                style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final p = await SharedPreferences.getInstance();
    final keys = p.getKeys().where((k) =>
        k.contains('chat_') ||
        k.contains('messages_') ||
        k.contains('riwayat_chat') ||
        k.startsWith('wa_history_'));
    for (final k in keys.toList()) {
      await p.remove(k);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Riwayat chat lokal dihapus')),
    );
  }

  String get _themeLabel {
    switch (_theme) {
      case 'light':
        return 'Terang';
      case 'dark':
        return 'Gelap';
      default:
        return 'Default sistem';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Chat'),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          _sec('Tampilan'),
          ListTile(
            leading: const Icon(Icons.palette_outlined, color: _Wa.muted),
            title: const Text('Tema', style: TextStyle(color: _Wa.text)),
            subtitle: Text(_themeLabel,
                style: const TextStyle(color: _Wa.muted, fontSize: 13)),
            trailing: const Icon(Icons.chevron_right, color: _Wa.muted),
            onTap: _pickTheme,
          ),
          ListTile(
            leading: const Icon(Icons.wallpaper, color: _Wa.muted),
            title: const Text('Wallpaper', style: TextStyle(color: _Wa.text)),
            subtitle: Text(
              _wallpapers[_wallpaper] ?? _wallpaper,
              style: const TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            trailing: const Icon(Icons.chevron_right, color: _Wa.muted),
            onTap: _pickWallpaper,
          ),
          ListTile(
            leading: const Icon(Icons.format_size, color: _Wa.muted),
            title:
                const Text('Ukuran font', style: TextStyle(color: _Wa.text)),
            subtitle: Slider(
              value: _fontSize,
              min: 0.85,
              max: 1.2,
              divisions: 3,
              activeColor: _Wa.green,
              label: _fontSize <= 0.9
                  ? 'Kecil'
                  : _fontSize >= 1.15
                      ? 'Besar'
                      : 'Normal',
              onChanged: (v) {
                setState(() => _fontSize = v);
                _set('wa_chat_font_$_u', v);
              },
            ),
          ),
          const Divider(color: Colors.white12),
          _sec('Chat'),
          SwitchListTile(
            secondary: const Icon(Icons.keyboard_return, color: _Wa.muted),
            title: const Text('Enter untuk kirim',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Tombol Enter mengirim pesan, bukan baris baru',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _enterIsSend,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _enterIsSend = v);
              _set('wa_chat_enter_$_u', v);
            },
          ),
          SwitchListTile(
            secondary: const Icon(Icons.photo_library_outlined, color: _Wa.muted),
            title: const Text('Visibilitas media',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Tampilkan media yang baru diterima di galeri perangkat',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _mediaVisibility,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _mediaVisibility = v);
              _set('wa_chat_media_vis_$_u', v);
            },
          ),
          SwitchListTile(
            secondary: const Icon(Icons.cloud_done_outlined, color: _Wa.muted),
            title: const Text('Simpan chat', style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Pertahankan riwayat chat di perangkat',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _keepChats,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _keepChats = v);
              _set('wa_chat_keep_$_u', v);
            },
          ),
          const Divider(color: Colors.white12),
          _sec('Riwayat chat'),
          ListTile(
            leading: const Icon(Icons.history, color: _Wa.muted),
            title: const Text('Arsip chat', style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Chat yang diarsipkan tetap tersimpan',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Buka arsip dari daftar chat')),
              );
            },
          ),
          ListTile(
            leading:
                const Icon(Icons.delete_sweep_outlined, color: Colors.redAccent),
            title: const Text('Hapus semua chat',
                style: TextStyle(color: Colors.redAccent)),
            subtitle: const Text(
              'Hapus riwayat chat lokal di perangkat ini',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            onTap: _clearHistory,
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Tema & wallpaper disimpan lokal dan akan diterapkan ke layar chat ZEVORA PROJECT.',
              style: TextStyle(color: _Wa.muted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sec(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(t,
            style: const TextStyle(
                color: _Wa.green, fontWeight: FontWeight.w600, fontSize: 13)),
      );
}

// ═══════════════════════════════════════════════════════════════
// NOTIFIKASI
// ═══════════════════════════════════════════════════════════════
class WaNotificationSettingsPage extends StatefulWidget {
  final String username;
  const WaNotificationSettingsPage({super.key, required this.username});

  @override
  State<WaNotificationSettingsPage> createState() =>
      _WaNotificationSettingsPageState();
}

class _WaNotificationSettingsPageState
    extends State<WaNotificationSettingsPage> {
  bool _msgNotif = true;
  bool _groupNotif = true;
  bool _callNotif = true;
  bool _showPreview = true;
  bool _vibrate = true;
  bool _highPriority = true;
  String _msgTone = 'Default';
  String _callTone = 'Default';
  String _groupTone = 'Default';

  static const _tones = [
    'Default',
    'Silent',
    'Note',
    'Bell',
    'Chime',
    'Ping',
    'Pop',
  ];

  String get _u => widget.username;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _msgNotif = p.getBool('wa_notif_msg_$_u') ?? true;
      _groupNotif = p.getBool('wa_notif_group_$_u') ?? true;
      _callNotif = p.getBool('wa_notif_call_$_u') ?? true;
      _showPreview = p.getBool('wa_notif_preview_$_u') ?? true;
      _vibrate = p.getBool('wa_notif_vib_$_u') ?? true;
      _highPriority = p.getBool('wa_notif_prio_$_u') ?? true;
      _msgTone = p.getString('wa_tone_msg_$_u') ?? 'Default';
      _callTone = p.getString('wa_tone_call_$_u') ?? 'Default';
      _groupTone = p.getString('wa_tone_group_$_u') ?? 'Default';
    });
  }

  Future<void> _setBool(String k, bool v) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(k, v);
  }

  Future<void> _pickTone(String title, String current, String prefKey,
      ValueChanged<String> onPicked) async {
    final r = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _Wa.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(title,
                    style: const TextStyle(
                        color: _Wa.text,
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
              ),
              ..._tones.map((t) => ListTile(
                    title: Text(t, style: const TextStyle(color: _Wa.text)),
                    trailing: current == t
                        ? const Icon(Icons.check, color: _Wa.green)
                        : null,
                    onTap: () => Navigator.pop(ctx, t),
                  )),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (r == null) return;
    final p = await SharedPreferences.getInstance();
    await p.setString(prefKey, r);
    onPicked(r);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Notifikasi'),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          _sec('Pesan'),
          SwitchListTile(
            secondary:
                const Icon(Icons.notifications_active_outlined, color: _Wa.muted),
            title: const Text('Notifikasi pesan',
                style: TextStyle(color: _Wa.text)),
            value: _msgNotif,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _msgNotif = v);
              _setBool('wa_notif_msg_$_u', v);
            },
          ),
          ListTile(
            enabled: _msgNotif,
            leading: const Icon(Icons.music_note_outlined, color: _Wa.muted),
            title:
                const Text('Nada notifikasi', style: TextStyle(color: _Wa.text)),
            subtitle: Text(_msgTone,
                style: const TextStyle(color: _Wa.muted, fontSize: 13)),
            onTap: _msgNotif
                ? () => _pickTone(
                      'Nada notifikasi pesan',
                      _msgTone,
                      'wa_tone_msg_$_u',
                      (v) => setState(() => _msgTone = v),
                    )
                : null,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.visibility_outlined, color: _Wa.muted),
            title: const Text('Tampilkan pratinjau',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Tampilkan nama pengirim dan teks pesan',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _showPreview,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _showPreview = v);
              _setBool('wa_notif_preview_$_u', v);
            },
          ),
          SwitchListTile(
            secondary: const Icon(Icons.priority_high, color: _Wa.muted),
            title: const Text('Prioritas tinggi',
                style: TextStyle(color: _Wa.text)),
            subtitle: const Text(
              'Tampilkan pop-up notifikasi di bagian atas layar',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
            value: _highPriority,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _highPriority = v);
              _setBool('wa_notif_prio_$_u', v);
            },
          ),
          const Divider(color: Colors.white12),
          _sec('Grup'),
          SwitchListTile(
            secondary: const Icon(Icons.group_outlined, color: _Wa.muted),
            title: const Text('Notifikasi grup',
                style: TextStyle(color: _Wa.text)),
            value: _groupNotif,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _groupNotif = v);
              _setBool('wa_notif_group_$_u', v);
            },
          ),
          ListTile(
            enabled: _groupNotif,
            leading: const Icon(Icons.music_note_outlined, color: _Wa.muted),
            title: const Text('Nada notifikasi grup',
                style: TextStyle(color: _Wa.text)),
            subtitle: Text(_groupTone,
                style: const TextStyle(color: _Wa.muted, fontSize: 13)),
            onTap: _groupNotif
                ? () => _pickTone(
                      'Nada notifikasi grup',
                      _groupTone,
                      'wa_tone_group_$_u',
                      (v) => setState(() => _groupTone = v),
                    )
                : null,
          ),
          const Divider(color: Colors.white12),
          _sec('Panggilan'),
          SwitchListTile(
            secondary: const Icon(Icons.call_outlined, color: _Wa.muted),
            title: const Text('Notifikasi panggilan',
                style: TextStyle(color: _Wa.text)),
            value: _callNotif,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _callNotif = v);
              _setBool('wa_notif_call_$_u', v);
            },
          ),
          ListTile(
            enabled: _callNotif,
            leading: const Icon(Icons.ring_volume_outlined, color: _Wa.muted),
            title: const Text('Nada dering', style: TextStyle(color: _Wa.text)),
            subtitle: Text(_callTone,
                style: const TextStyle(color: _Wa.muted, fontSize: 13)),
            onTap: _callNotif
                ? () => _pickTone(
                      'Nada dering panggilan',
                      _callTone,
                      'wa_tone_call_$_u',
                      (v) => setState(() => _callTone = v),
                    )
                : null,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.vibration, color: _Wa.muted),
            title: const Text('Getar', style: TextStyle(color: _Wa.text)),
            value: _vibrate,
            activeColor: _Wa.green,
            onChanged: (v) {
              setState(() => _vibrate = v);
              _setBool('wa_notif_vib_$_u', v);
            },
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Pengaturan notifikasi disimpan di perangkat. Beberapa opsi bergantung pada izin notifikasi sistem.',
              style: TextStyle(color: _Wa.muted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sec(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(t,
            style: const TextStyle(
                color: _Wa.green, fontWeight: FontWeight.w600, fontSize: 13)),
      );
}

// ═══════════════════════════════════════════════════════════════
// PENYIMPANAN DAN DATA
// ═══════════════════════════════════════════════════════════════
class WaStoragePage extends StatefulWidget {
  final String username;
  const WaStoragePage({super.key, required this.username});

  @override
  State<WaStoragePage> createState() => _WaStoragePageState();
}

class _WaStoragePageState extends State<WaStoragePage> {
  bool _loading = true;
  int _photosBytes = 0;
  int _videosBytes = 0;
  int _filesBytes = 0;
  int _otherBytes = 0;
  int _photoCount = 0;
  int _videoCount = 0;
  int _fileCount = 0;
  List<File> _photoFiles = [];
  List<File> _videoFiles = [];
  List<File> _otherFiles = [];

  bool _autoPhoto = true;
  bool _autoVideo = false;
  bool _autoDoc = false;
  bool _wifiOnly = true;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
    _scan();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    final u = widget.username;
    setState(() {
      _autoPhoto = p.getBool('wa_auto_photo_$u') ?? true;
      _autoVideo = p.getBool('wa_auto_video_$u') ?? false;
      _autoDoc = p.getBool('wa_auto_doc_$u') ?? false;
      _wifiOnly = p.getBool('wa_wifi_only_$u') ?? true;
    });
  }

  Future<void> _scan() async {
    setState(() => _loading = true);
    final photos = <File>[];
    final videos = <File>[];
    final others = <File>[];
    int pB = 0, vB = 0, fB = 0, oB = 0;

    final dirs = <Directory>[];
    try {
      dirs.add(await getApplicationDocumentsDirectory());
    } catch (_) {}
    try {
      dirs.add(await getApplicationSupportDirectory());
    } catch (_) {}
    try {
      final t = await getTemporaryDirectory();
      dirs.add(t);
    } catch (_) {}

    final photoExt = {
      'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic'
    };
    final videoExt = {'mp4', 'mov', 'mkv', 'avi', 'webm', '3gp'};

    for (final root in dirs) {
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (entity is! File) continue;
          final path = entity.path.toLowerCase();
          // fokus ke folder app media / stories / chat
          final relevant = path.contains('ortax') ||
              path.contains('xeno') ||
              path.contains('story') ||
              path.contains('chat') ||
              path.contains('media') ||
              path.contains('download') ||
              path.contains('cache');
          if (!relevant && !path.contains('/app_flutter')) continue;
          int len = 0;
          try {
            len = await entity.length();
          } catch (_) {
            continue;
          }
          final ext = path.split('.').last;
          if (photoExt.contains(ext)) {
            photos.add(entity);
            pB += len;
          } else if (videoExt.contains(ext)) {
            videos.add(entity);
            vB += len;
          } else if (path.contains('download') ||
              ext == 'pdf' ||
              ext == 'doc' ||
              ext == 'docx' ||
              ext == 'zip' ||
              ext == 'apk') {
            others.add(entity);
            fB += len;
          } else {
            oB += len;
          }
        }
      } catch (_) {}
    }

    if (!mounted) return;
    setState(() {
      _photoFiles = photos;
      _videoFiles = videos;
      _otherFiles = others;
      _photosBytes = pB;
      _videosBytes = vB;
      _filesBytes = fB;
      _otherBytes = oB;
      _photoCount = photos.length;
      _videoCount = videos.length;
      _fileCount = others.length;
      _loading = false;
    });
  }

  String _fmt(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    }
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  Future<void> _deleteList(List<File> files, String label) async {
    if (files.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tidak ada $label untuk dihapus')),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _Wa.card,
        title: Text('Hapus $label?', style: const TextStyle(color: _Wa.text)),
        content: Text(
          '${files.length} file (~${_fmt(files.fold<int>(0, (a, f) {
            try {
              return a + f.lengthSync();
            } catch (_) {
              return a;
            }
          }))}) akan dihapus dari perangkat.',
          style: const TextStyle(color: _Wa.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: _Wa.muted)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus',
                style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    int deleted = 0;
    for (final f in files) {
      try {
        if (await f.exists()) {
          await f.delete();
          deleted++;
        }
      } catch (_) {}
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$deleted $label dihapus')),
    );
    await _scan();
  }

  @override
  Widget build(BuildContext context) {
    final total =
        _photosBytes + _videosBytes + _filesBytes + _otherBytes;
    final u = widget.username;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Penyimpanan dan data', actions: [
        IconButton(
          icon: const Icon(Icons.refresh, color: _Wa.text),
          onPressed: _scan,
        ),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _Wa.green))
          : ListView(
              children: [
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _Wa.card,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Penggunaan penyimpanan aplikasi',
                            style: TextStyle(
                                color: _Wa.text, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 8),
                        Text(_fmt(total),
                            style: const TextStyle(
                                color: _Wa.green,
                                fontSize: 28,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        _barSegment(_photosBytes, total, const Color(0xFF53BDEB)),
                        const SizedBox(height: 4),
                        _barSegment(_videosBytes, total, const Color(0xFF25D366)),
                        const SizedBox(height: 4),
                        _barSegment(_filesBytes, total, const Color(0xFFFFA726)),
                        const SizedBox(height: 4),
                        _barSegment(_otherBytes, total, _Wa.muted),
                        const SizedBox(height: 12),
                        _legend('Foto', _photosBytes, _photoCount,
                            const Color(0xFF53BDEB)),
                        _legend('Video', _videosBytes, _videoCount,
                            const Color(0xFF25D366)),
                        _legend('File', _filesBytes, _fileCount,
                            const Color(0xFFFFA726)),
                        _legend('Lainnya', _otherBytes, null, _Wa.muted),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                ListTile(
                  leading:
                      const Icon(Icons.photo_outlined, color: Color(0xFF53BDEB)),
                  title: const Text('Hapus foto',
                      style: TextStyle(color: _Wa.text)),
                  subtitle: Text(
                    '$_photoCount foto · ${_fmt(_photosBytes)}',
                    style: const TextStyle(color: _Wa.muted, fontSize: 13),
                  ),
                  onTap: () => _deleteList(_photoFiles, 'foto'),
                ),
                ListTile(
                  leading:
                      const Icon(Icons.videocam_outlined, color: Color(0xFF25D366)),
                  title: const Text('Hapus video',
                      style: TextStyle(color: _Wa.text)),
                  subtitle: Text(
                    '$_videoCount video · ${_fmt(_videosBytes)}',
                    style: const TextStyle(color: _Wa.muted, fontSize: 13),
                  ),
                  onTap: () => _deleteList(_videoFiles, 'video'),
                ),
                ListTile(
                  leading:
                      const Icon(Icons.insert_drive_file_outlined,
                          color: Color(0xFFFFA726)),
                  title: const Text('Hapus file',
                      style: TextStyle(color: _Wa.text)),
                  subtitle: Text(
                    '$_fileCount file · ${_fmt(_filesBytes)}',
                    style: const TextStyle(color: _Wa.muted, fontSize: 13),
                  ),
                  onTap: () => _deleteList(_otherFiles, 'file'),
                ),
                ListTile(
                  leading:
                      const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: const Text('Hapus semua media',
                      style: TextStyle(color: Colors.redAccent)),
                  subtitle: const Text(
                    'Foto, video, dan file aplikasi',
                    style: TextStyle(color: _Wa.muted, fontSize: 13),
                  ),
                  onTap: () async {
                    await _deleteList(
                      [..._photoFiles, ..._videoFiles, ..._otherFiles],
                      'media',
                    );
                  },
                ),
                const Divider(color: Colors.white12),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: Text('Unduhan otomatis media',
                      style: TextStyle(
                          color: _Wa.green,
                          fontWeight: FontWeight.w600,
                          fontSize: 13)),
                ),
                SwitchListTile(
                  title: const Text('Foto', style: TextStyle(color: _Wa.text)),
                  value: _autoPhoto,
                  activeColor: _Wa.green,
                  onChanged: (v) async {
                    setState(() => _autoPhoto = v);
                    final p = await SharedPreferences.getInstance();
                    await p.setBool('wa_auto_photo_$u', v);
                  },
                ),
                SwitchListTile(
                  title: const Text('Video', style: TextStyle(color: _Wa.text)),
                  value: _autoVideo,
                  activeColor: _Wa.green,
                  onChanged: (v) async {
                    setState(() => _autoVideo = v);
                    final p = await SharedPreferences.getInstance();
                    await p.setBool('wa_auto_video_$u', v);
                  },
                ),
                SwitchListTile(
                  title: const Text('Dokumen', style: TextStyle(color: _Wa.text)),
                  value: _autoDoc,
                  activeColor: _Wa.green,
                  onChanged: (v) async {
                    setState(() => _autoDoc = v);
                    final p = await SharedPreferences.getInstance();
                    await p.setBool('wa_auto_doc_$u', v);
                  },
                ),
                SwitchListTile(
                  title: const Text('Hanya saat Wi-Fi',
                      style: TextStyle(color: _Wa.text)),
                  subtitle: const Text(
                    'Unduh otomatis hanya lewat Wi-Fi',
                    style: TextStyle(color: _Wa.muted, fontSize: 13),
                  ),
                  value: _wifiOnly,
                  activeColor: _Wa.green,
                  onChanged: (v) async {
                    setState(() => _wifiOnly = v);
                    final p = await SharedPreferences.getInstance();
                    await p.setBool('wa_wifi_only_$u', v);
                  },
                ),
                const SizedBox(height: 24),
              ],
            ),
    );
  }

  Widget _barSegment(int bytes, int total, Color color) {
    final frac = total <= 0 ? 0.0 : (bytes / total).clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: LinearProgressIndicator(
        value: frac,
        minHeight: 8,
        backgroundColor: _Wa.surface,
        valueColor: AlwaysStoppedAnimation(color),
      ),
    );
  }

  Widget _legend(String label, int bytes, int? count, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Container(
              width: 10,
              height: 10,
              decoration:
                  BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(
              child: Text(label, style: const TextStyle(color: _Wa.text))),
          Text(
            count == null
                ? _fmt(bytes)
                : '$count · ${_fmt(bytes)}',
            style: const TextStyle(color: _Wa.muted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BAHASA
// ═══════════════════════════════════════════════════════════════
class WaLanguagePage extends StatefulWidget {
  final String username;
  const WaLanguagePage({super.key, required this.username});

  @override
  State<WaLanguagePage> createState() => _WaLanguagePageState();
}

class _WaLanguagePageState extends State<WaLanguagePage> {
  String _lang = 'id';

  static const _langs = [
    ('id', 'Indonesia'),
    ('en', 'English'),
    ('ms', 'Bahasa Melayu'),
    ('jv', 'Jawa'),
    ('su', 'Sunda'),
    ('ar', 'العربية'),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _lang = p.getString('wa_lang_${widget.username}') ??
          p.getString('app_language') ??
          'id';
    });
  }

  Future<void> _select(String code) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('wa_lang_${widget.username}', code);
    await p.setString('app_language', code);
    setState(() => _lang = code);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Bahasa diubah ke ${_langs.firstWhere((e) => e.$1 == code, orElse: () => (code, code)).$2}. Restart app untuk menerapkan penuh.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Bahasa aplikasi'),
      body: ListView(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Pilih bahasa yang digunakan di aplikasi ZEVORA PROJECT.',
              style: TextStyle(color: _Wa.muted, fontSize: 13),
            ),
          ),
          ..._langs.map((e) {
            final selected = _lang == e.$1;
            return ListTile(
              title: Text(e.$2, style: const TextStyle(color: _Wa.text)),
              subtitle: Text(e.$1.toUpperCase(),
                  style: const TextStyle(color: _Wa.muted, fontSize: 12)),
              trailing: selected
                  ? const Icon(Icons.check_circle, color: _Wa.green)
                  : const Icon(Icons.circle_outlined, color: _Wa.muted),
              onTap: () => _select(e.$1),
            );
          }),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// BANTUAN — chat owner, channel, tiktok
// ═══════════════════════════════════════════════════════════════
class WaHelpPage extends StatelessWidget {
  const WaHelpPage({super.key});

  Future<void> _open(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Tidak bisa membuka $url')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _waAppBar('Bantuan'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Butuh bantuan? Hubungi tim ZEVORA PROJECT lewat salah satu saluran di bawah.',
            style: TextStyle(color: _Wa.muted, fontSize: 13),
          ),
          const SizedBox(height: 20),
          _helpButton(
            context,
            icon: Icons.chat,
            color: const Color(0xFF25D366),
            title: 'Chat Owner',
            subtitle: 'Hubungi owner via WhatsApp',
            onTap: () => _open(context, 'https://wa.me/6283169690420'),
          ),
          const SizedBox(height: 12),
          _helpButton(
            context,
            icon: Icons.campaign_outlined,
            color: const Color(0xFF229ED9),
            title: 'Channel Telegram',
            subtitle: 'Join channel ZEVORA PROJECT',
            onTap: () => _open(context, 'https://t.me/informasi_zevora'),
          ),
          const SizedBox(height: 12),
          _helpButton(
            context,
            icon: Icons.music_note,
            color: const Color(0xFF000000),
            title: 'TikTok',
            subtitle: '@NanzzPrime',
            onTap: () =>
                _open(context, 'https://www.tiktok.com/@nanzz_dev_sxc_sxecx'),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _Wa.card,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('FAQ singkat',
                    style: TextStyle(
                        color: _Wa.text, fontWeight: FontWeight.w700)),
                SizedBox(height: 8),
                Text(
                  '• Session expired → login ulang.\n'
                  '• Notifikasi tidak masuk → cek izin notifikasi sistem & menu Notifikasi.\n'
                  '• Penyimpanan penuh → hapus media di Penyimpanan dan data.\n'
                  '• Story hilang → pastikan tidak lebih dari 24 jam.',
                  style: TextStyle(color: _Wa.muted, fontSize: 13, height: 1.45),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _helpButton(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: _Wa.card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color == const Color(0xFF000000)
                    ? _Wa.text
                    : color),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: _Wa.text,
                            fontWeight: FontWeight.w700,
                            fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: const TextStyle(
                            color: _Wa.muted, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.open_in_new, color: _Wa.muted, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}
