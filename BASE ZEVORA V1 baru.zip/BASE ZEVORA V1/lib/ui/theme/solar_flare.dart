import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

class SolarFlare extends ThemeItem {
  @override
  int get id => 6;
  @override
  String get name => 'Solar Flare';
  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: Color(0xFFFFB45E), textMainColor: Color(0xFFFFF7EC),
        textSubColor: Color(0xFFD2B394), backgroundColor: Color(0xFF170D08),
        backgroundSubColor: Color(0xFF352014), modalSheetBackgroundColor: Color(0xFF28180E),
        onAccent: Color(0xFF2D1708), glowColor: Color(0xFFFF8B3D),
        cardBorderColor: Color(0x55FFB45E), glassColor: Color(0x993C2618),
      );
  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: Color(0xFFD97725), textMainColor: Color(0xFF3B210F),
        textSubColor: Color(0xFF8A6345), backgroundColor: Color(0xFFFFF6EA),
        backgroundSubColor: Color(0xFFFFE6C9), modalSheetBackgroundColor: Color(0xFFFFFBF5),
        onAccent: Colors.white, glowColor: Color(0xFFD97725),
        cardBorderColor: Color(0x44D97725), glassColor: Color(0xCCFFFFFF),
      );
}
