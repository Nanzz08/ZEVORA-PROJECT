import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

class RoseQuartz extends ThemeItem {
  @override
  int get id => 5;
  @override
  String get name => 'Rose Quartz';
  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: Color(0xFFFF91B5), textMainColor: Color(0xFFFFF1F6),
        textSubColor: Color(0xFFD6A7B8), backgroundColor: Color(0xFF170A12),
        backgroundSubColor: Color(0xFF321626), modalSheetBackgroundColor: Color(0xFF26111D),
        onAccent: Color(0xFF2B1020), glowColor: Color(0xFFFF6F9E),
        cardBorderColor: Color(0x55FF91B5), glassColor: Color(0x993D1B2D),
      );
  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: Color(0xFFD94F82), textMainColor: Color(0xFF351827),
        textSubColor: Color(0xFF87566B), backgroundColor: Color(0xFFFFF2F6),
        backgroundSubColor: Color(0xFFF9DCE7), modalSheetBackgroundColor: Color(0xFFFFF8FA),
        onAccent: Colors.white, glowColor: Color(0xFFD94F82),
        cardBorderColor: Color(0x44D94F82), glassColor: Color(0xCCFFFFFF),
      );
}
