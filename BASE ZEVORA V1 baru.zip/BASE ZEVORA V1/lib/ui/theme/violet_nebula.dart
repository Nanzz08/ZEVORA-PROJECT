import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

class VioletNebula extends ThemeItem {
  @override
  int get id => 7;
  @override
  String get name => 'Violet Nebula';
  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: Color(0xFFB69AFF), textMainColor: Color(0xFFF7F2FF),
        textSubColor: Color(0xFFB6A9D1), backgroundColor: Color(0xFF100B1B),
        backgroundSubColor: Color(0xFF25183A), modalSheetBackgroundColor: Color(0xFF1B1230),
        onAccent: Color(0xFF1C1030), glowColor: Color(0xFF9D75FF),
        cardBorderColor: Color(0x55B69AFF), glassColor: Color(0x992E2045),
      );
  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: Color(0xFF7952C8), textMainColor: Color(0xFF25183A),
        textSubColor: Color(0xFF665382), backgroundColor: Color(0xFFF6F1FF),
        backgroundSubColor: Color(0xFFE8DDFB), modalSheetBackgroundColor: Color(0xFFFCFAFF),
        onAccent: Colors.white, glowColor: Color(0xFF7952C8),
        cardBorderColor: Color(0x447952C8), glassColor: Color(0xCCFFFFFF),
      );
}
