import 'package:flutter/foundation.dart';
import 'package:fiona/ui/theme/themes.dart';
import 'package:fiona/ui/theme/types.dart';

/// Lightweight state holder for screens that opt into the UI theme collection.
/// It does not replace the existing app-wide AppTheme or alter saved settings.
class UiThemeController extends ChangeNotifier {
  UiThemeController({int initialThemeId = 2}) : _selected = themeById(initialThemeId);

  ThemeItem _selected;
  bool _useLightVariant = false;

  ThemeItem get selected => _selected;
  bool get useLightVariant => _useLightVariant;
  AnimeStreamTheme get theme => _useLightVariant ? _selected.lightVariant : _selected.theme;

  void selectTheme(int id) {
    final next = themeById(id);
    if (next.id == _selected.id) return;
    _selected = next;
    notifyListeners();
  }

  void setLightVariant(bool value) {
    if (_useLightVariant == value) return;
    _useLightVariant = value;
    notifyListeners();
  }

  void toggleVariant() => setLightVariant(!_useLightVariant);
}
