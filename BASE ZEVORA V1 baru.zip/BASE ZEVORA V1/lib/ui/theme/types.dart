import 'package:flutter/material.dart';

/// Shared visual tokens for the optional ZEVORA UI theme collection.
/// Defaults keep the original supplied theme constructors source-compatible.
class AnimeStreamTheme {
  final Color accentColor;
  final Color textMainColor;
  final Color textSubColor;
  final Color backgroundColor;
  final Color backgroundSubColor;
  final Color modalSheetBackgroundColor;
  final Color onAccent;
  final Color glowColor;
  final Color cardBorderColor;
  final Color glassColor;
  final Color warmAccent;
  final double cardRadius;
  final double controlRadius;
  final double glassBlur;
  final double borderWidth;
  final Duration motionDuration;

  AnimeStreamTheme({
    required this.accentColor,
    required this.textMainColor,
    required this.textSubColor,
    required this.backgroundColor,
    required this.backgroundSubColor,
    required this.modalSheetBackgroundColor,
    required this.onAccent,
    Color? glowColor,
    Color? cardBorderColor,
    Color? glassColor,
    Color? warmAccent,
    this.cardRadius = 24,
    this.controlRadius = 15,
    this.glassBlur = 14,
    this.borderWidth = 0.9,
    this.motionDuration = const Duration(milliseconds: 220),
  })  : glowColor = glowColor ?? accentColor,
        cardBorderColor = cardBorderColor ?? accentColor.withOpacity(0.35),
        glassColor = glassColor ?? backgroundSubColor.withOpacity(0.55),
        warmAccent = warmAccent ?? const Color(0xFFFFB648);

  LinearGradient get backgroundGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [backgroundColor, backgroundSubColor, backgroundColor],
      );

  LinearGradient get accentGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color.lerp(accentColor, Colors.white, .22)!, accentColor],
      );
}

abstract class ThemeItem {
  int get id;
  String get name;
  AnimeStreamTheme get theme;
  AnimeStreamTheme get lightVariant;
}
