import 'package:fiona/ui/theme/arctic_glass.dart';
import 'package:fiona/ui/theme/aurora_glow.dart';
import 'package:fiona/ui/theme/lime.dart';
import 'package:fiona/ui/theme/midnight_glass.dart';
import 'package:fiona/ui/theme/rose_quartz.dart';
import 'package:fiona/ui/theme/solar_flare.dart';
import 'package:fiona/ui/theme/types.dart';
import 'package:fiona/ui/theme/violet_nebula.dart';

/// Theme presets supplied with the project plus additional Liquid Glass palettes.
final List<ThemeItem> availableThemes = [
  AuroraGlow(),
  LimeZest(),
  MidnightGlass(),
  ArcticGlass(),
  RoseQuartz(),
  SolarFlare(),
  VioletNebula(),
];

ThemeItem themeById(int id) => availableThemes.firstWhere(
      (item) => item.id == id,
      orElse: () => availableThemes.first,
    );
