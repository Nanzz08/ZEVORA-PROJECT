import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

class ArcticGlass extends ThemeItem {
  @override
  int get id => 4;
  @override
  String get name => 'Arctic Glass';
  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: Color(0xFF72E3F2), textMainColor: Color(0xFFEFFFFF),
        textSubColor: Color(0xFF9BC9D0), backgroundColor: Color(0xFF061217),
        backgroundSubColor: Color(0xFF102A32), modalSheetBackgroundColor: Color(0xFF0D2028),
        onAccent: Color(0xFF062027), glowColor: Color(0xFF4DD9E8),
        cardBorderColor: Color(0x5572E3F2), glassColor: Color(0x99162F37),
      );
  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: Color(0xFF1598AA), textMainColor: Color(0xFF09252B),
        textSubColor: Color(0xFF426D74), backgroundColor: Color(0xFFEDFCFD),
        backgroundSubColor: Color(0xFFD7F2F4), modalSheetBackgroundColor: Color(0xFFF6FFFF),
        onAccent: Colors.white, glowColor: Color(0xFF1598AA),
        cardBorderColor: Color(0x441598AA), glassColor: Color(0xCCFFFFFF),
      );
}
