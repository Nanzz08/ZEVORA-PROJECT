import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

class MidnightGlass extends ThemeItem {
  @override
  int get id => 3;
  @override
  String get name => 'Midnight Glass';
  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: Color(0xFF7CB9FF), textMainColor: Color(0xFFF1F7FF),
        textSubColor: Color(0xFF9FB3CA), backgroundColor: Color(0xFF070D18),
        backgroundSubColor: Color(0xFF14243A), modalSheetBackgroundColor: Color(0xFF101C2D),
        onAccent: Color(0xFF07111E), glowColor: Color(0xFF4D9DFF),
        cardBorderColor: Color(0x557CB9FF), glassColor: Color(0x991B304A),
        warmAccent: Color(0xFFFFC77D),
      );
  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: Color(0xFF2877C7), textMainColor: Color(0xFF10243A),
        textSubColor: Color(0xFF536D88), backgroundColor: Color(0xFFEAF3FC),
        backgroundSubColor: Color(0xFFD7E8F8), modalSheetBackgroundColor: Color(0xFFF5FAFF),
        onAccent: Colors.white, glowColor: Color(0xFF2877C7),
        cardBorderColor: Color(0x442877C7), glassColor: Color(0xCCFFFFFF),
      );
}
