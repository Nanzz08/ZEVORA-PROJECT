import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

/// Reusable frosted-glass card with a subtle bevel and optional tap action.
class GlowCard extends StatelessWidget {
  final Widget child;
  final AnimeStreamTheme theme;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final bool strongGlow;
  final VoidCallback? onTap;

  const GlowCard({
    super.key,
    required this.child,
    required this.theme,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 22,
    this.strongGlow = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(borderRadius);
    final content = ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: theme.glassBlur, sigmaY: theme.glassBlur),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: radius,
            child: Ink(
              padding: padding,
              decoration: BoxDecoration(
                borderRadius: radius,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [theme.glassColor, theme.backgroundColor.withOpacity(.88)],
                ),
                border: Border.all(color: theme.cardBorderColor, width: theme.borderWidth),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );

    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.30), blurRadius: 22, offset: const Offset(0, 12)),
          BoxShadow(color: theme.glowColor.withOpacity(strongGlow ? .24 : .11), blurRadius: strongGlow ? 34 : 22, spreadRadius: -8),
        ],
      ),
      child: content,
    );
  }
}

class GlowIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Color onColor;
  final double size;
  const GlowIcon({super.key, required this.icon, required this.color, this.onColor = Colors.black, this.size = 34});

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(center: const Alignment(-.3, -.3), colors: [Color.lerp(color, Colors.white, .35)!, color]),
          boxShadow: [BoxShadow(color: color.withOpacity(.42), blurRadius: 13, spreadRadius: -2)],
        ),
        child: Icon(icon, size: size * .5, color: onColor),
      );
}
