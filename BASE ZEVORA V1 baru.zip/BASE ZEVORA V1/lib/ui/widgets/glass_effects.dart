import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:fiona/ui/theme/types.dart';

/// Decorative ambient background; static gradients avoid perpetual GPU work.
class LiquidBackdrop extends StatelessWidget {
  final AnimeStreamTheme theme;
  final Widget child;
  const LiquidBackdrop({super.key, required this.theme, required this.child});

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(gradient: theme.backgroundGradient),
        child: Stack(children: [
          Positioned(top: -110, right: -90, child: _GlowOrb(color: theme.glowColor, size: 290)),
          Positioned(bottom: -140, left: -110, child: _GlowOrb(color: theme.accentColor, size: 310)),
          Positioned.fill(child: child),
        ]),
      );
}

class _GlowOrb extends StatelessWidget {
  final Color color;
  final double size;
  const _GlowOrb({required this.color, required this.size});
  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: ImageFiltered(
          imageFilter: ImageFilter.blur(sigmaX: 34, sigmaY: 34),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [color.withOpacity(.20), color.withOpacity(0)]),
            ),
          ),
        ),
      );
}

class GlowActionButton extends StatelessWidget {
  final AnimeStreamTheme theme;
  final Widget child;
  final VoidCallback? onPressed;
  final bool prominent;
  const GlowActionButton({super.key, required this.theme, required this.child, required this.onPressed, this.prominent = false});

  @override
  Widget build(BuildContext context) => AnimatedOpacity(
        duration: theme.motionDuration,
        opacity: onPressed == null ? .48 : 1,
        child: Material(
          color: prominent ? theme.accentColor : theme.glassColor,
          borderRadius: BorderRadius.circular(theme.controlRadius),
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(theme.controlRadius),
            child: Ink(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(theme.controlRadius),
                border: Border.all(color: theme.cardBorderColor, width: theme.borderWidth),
                gradient: prominent ? theme.accentGradient : null,
                boxShadow: [BoxShadow(color: theme.glowColor.withOpacity(prominent ? .18 : .07), blurRadius: 18, spreadRadius: -7)],
              ),
              child: Center(child: DefaultTextStyle.merge(style: TextStyle(color: prominent ? theme.onAccent : theme.textMainColor, fontWeight: FontWeight.w700), child: child),),
            ),
          ),
        ),
      );
}

class GlowPill extends StatelessWidget {
  final AnimeStreamTheme theme;
  final String label;
  final IconData? icon;
  const GlowPill({super.key, required this.theme, required this.label, this.icon});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          color: theme.glassColor,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: theme.cardBorderColor),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 14, color: theme.accentColor), const SizedBox(width: 6)],
          Text(label, style: TextStyle(color: theme.textMainColor, fontSize: 11, fontWeight: FontWeight.w700)),
        ]),
      );
}

class GlassSection extends StatelessWidget {
  final AnimeStreamTheme theme;
  final String title;
  final Widget child;
  const GlassSection({super.key, required this.theme, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(left: 3, bottom: 10), child: Text(title, style: TextStyle(color: theme.textMainColor, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: .2))),
        child,
      ]);
}
