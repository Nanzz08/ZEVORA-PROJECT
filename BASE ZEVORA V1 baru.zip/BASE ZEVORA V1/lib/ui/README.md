# ZEVORA UI Theme & Effects

This folder contains the supplied UI starter structure, normalized to the Flutter package name `fiona`, and expanded with reusable Liquid Glass presentation components.

## Theme presets

- Aurora Glow
- Lime Zest
- Midnight Glass
- Arctic Glass
- Rose Quartz
- Solar Flare
- Violet Nebula

Use `availableThemes` / `themeById` from `ui/theme/themes.dart`. `UiThemeController` in `ui/theme/theme_controller.dart` is a lightweight optional controller; it does not replace the existing app-wide `AppTheme` or change persisted theme preferences.

## Effects

- `GlowCard`: frosted surface with border and soft glow.
- `LiquidBackdrop`: static ambient gradients without a continuously running animation.
- `GlowActionButton`: reusable glass/primary action button.
- `GlowPill`: compact status/tag chip.
- `GlassSection`: consistent section heading layout.

The UI kit is presentation-only. Existing page callbacks, navigation, authentication, and API code remain outside this folder.
