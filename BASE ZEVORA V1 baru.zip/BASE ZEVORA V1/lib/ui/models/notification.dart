/// Optional notification callbacks. The app's existing notification pipeline
/// remains authoritative; these hooks intentionally add no second plugin.
class NotificationController {
  @pragma('vm:entry-point')
  static Future<void> onActionReceivedMethod(Object? action) async {}
  @pragma('vm:entry-point')
  static Future<void> onNotificationCreatedMethod(Object? notification) async {}
  @pragma('vm:entry-point')
  static Future<void> onNotificationDisplayedMethod(Object? notification) async {}
  @pragma('vm:entry-point')
  static Future<void> onDismissActionReceivedMethod(Object? action) async {}
}

class NotificationService {
  Future<void> init() async {}
}
