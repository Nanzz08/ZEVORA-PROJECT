import 'package:flutter/material.dart';

final GlobalKey<ScaffoldMessengerState> snackBarMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

void floatingSnackBar(
  String message, {
  Color? color,
  Duration duration = const Duration(seconds: 3),
}) {
  final messenger = snackBarMessengerKey.currentState;
  if (messenger == null) return;
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(message),
        duration: duration,
        behavior: SnackBarBehavior.floating,
        backgroundColor: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
}
