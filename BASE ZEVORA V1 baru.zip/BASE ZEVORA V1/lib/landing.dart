import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'tap.dart';
import 'app_theme.dart';
import 'glass_kit.dart';

// ═══════════════════════════════════════════════════════════════
// 3D COMIC THEME
// ═══════════════════════════════════════════════════════════════

class _C {
  static const white = Colors.white;
  static Color get bg => AppTheme.I.bg;
  static Color get softBg => AppTheme.I.surface;
  static Color get blue => AppTheme.I.accent;
  static Color get blueDark => AppTheme.I.accentDark;
  static Color get blueLight => AppTheme.I.accentFrost;
  static Color get blueShadow => AppTheme.I.accentDark.withOpacity(0.42);
  static Color get text => AppTheme.I.text;
  static Color get grey => AppTheme.I.textSub;
  static const green = Color(0xFF35D49A);
  static const red = Color(0xFFFF647C);
  static Color get border => AppTheme.I.borderLit;

  static BoxDecoration comicCard({
    Color? color,
    double radius = 18,
    double borderWidth = 1.2,
  }) {
    return BoxDecoration(
      color: color ?? softBg,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border, width: borderWidth),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.20),
          offset: const Offset(0, 8),
          blurRadius: 22,
        ),
        BoxShadow(
          color: blue.withOpacity(0.07),
          offset: const Offset(0, 2),
          blurRadius: 14,
        ),
      ],
    );
  }

  static BoxDecoration comicBlueButton({double radius = 14}) {
    return BoxDecoration(
      gradient: LinearGradient(
        colors: [blueDark, blue],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: blue.withOpacity(0.55), width: 1.2),
      boxShadow: [
        BoxShadow(
          color: blue.withOpacity(0.22),
          offset: const Offset(0, 5),
          blurRadius: 16,
        ),
      ],
    );
  }

  static BoxDecoration comicOutlineButton({double radius = 16}) {
    return BoxDecoration(
      color: softBg,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: border, width: 1.2),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.16),
          offset: const Offset(0, 5),
          blurRadius: 14,
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// COMIC DOT PATTERN
// ═══════════════════════════════════════════════════════════════

class _ComicDotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.blue.withOpacity(0.045)
      ..style = PaintingStyle.fill;

    const spacing = 28.0;
    for (double y = 0; y < size.height; y += spacing) {
      for (double x = 0; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.8, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ═══════════════════════════════════════════════════════════════
// LANDING PAGE
// ═══════════════════════════════════════════════════════════════

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  VideoPlayerController? _videoController;

  @override
  void initState() {
    super.initState();
    AppTheme.I.addListener(_handleThemeChanged);
    AppTheme.I.load();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _animationController, curve: Curves.easeOut));
    _slideAnimation = Tween<Offset>(
            begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _animationController, curve: Curves.easeOutCubic));

    _animationController.forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));

    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController?.setLooping(true);
        _videoController?.setVolume(0.0);
        _videoController?.play();
      }).catchError((e) {
        debugPrint("Error loading landing video: $e");
      });
  }

  void _handleThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    AppTheme.I.removeListener(_handleThemeChanged);
    _animationController.dispose();
    _pulseController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  // Mempertahankan alur login lama melalui named route aplikasi.
  Future<void> _handleLoginPress() async {
    if (!mounted) return;
    Navigator.pushNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Positioned.fill(child: Container(color: _C.bg)),
            Positioned.fill(
              child: CustomPaint(painter: _ComicDotPatternPainter()),
            ),
            SafeArea(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                    child: Column(
                      children: [
                        // ── 1. VIDEO BANNER ──
                        Container(
                          width: double.infinity,
                          height: 250,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            color: _C.softBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                                color: _C.border, width: 1.2),
                            boxShadow: [
                              BoxShadow(color: Colors.black.withOpacity(0.22), offset: const Offset(0, 8), blurRadius: 22),
                              BoxShadow(color: _C.blue.withOpacity(0.08), offset: const Offset(0, 2), blurRadius: 16),
                            ],
                          ),
                          child: _videoController != null &&
                                  _videoController!.value.isInitialized
                              ? FittedBox(
                                  fit: BoxFit.cover,
                                  child: SizedBox(
                                    width: _videoController!.value.size.width,
                                    height:
                                        _videoController!.value.size.height,
                                    child: VideoPlayer(_videoController!),
                                  ),
                                )
                              : Container(
                                  color: _C.softBg,
                                  child: Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(
                                          width: 30,
                                          height: 30,
                                          child:
                                              CircularProgressIndicator(
                                            color: _C.blue,
                                            strokeWidth: 3,
                                          ),
                                        ),
                                        SizedBox(height: 12),
                                        Text(
                                          "MEMUAT...",
                                          style: TextStyle(
                                            color: _C.blue,
                                            fontSize: 11,
                                            letterSpacing: 3,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Rajdhani',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                        ),
                        const SizedBox(height: 28),

                        // ── 2. JUDUL BESAR ──
                        Text(
                          "ZEVORA PROJECT",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 5.0,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          width: 60,
                          height: 4,
                          decoration: BoxDecoration(
                            color: _C.blue,
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(
                                color: _C.border, width: 1.0),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          "PREMIUM  ·  STABLE  ·  SECURE",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: _C.blue,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 2.4,
                          ),
                        ),
                        const SizedBox(height: 28),

                        // ── 3. INFO CARD ──
                        GlassPanel(
                          radius: 22,
                          blur: 14,
                          opacity: .09,
                          padding: const EdgeInsets.all(1),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(22),
                            decoration: _C.comicCard(radius: 20, borderWidth: 1.0),
                            child: Column(
                              children: [
                                AnimatedBuilder(
                                animation: _pulseAnimation,
                                builder: (context, child) {
                                  return Transform.scale(
                                    scale: _pulseAnimation.value,
                                    child: const GlassIconBadge(
                                      icon: Icons.shield_rounded,
                                      color: Colors.white,
                                      size: 66,
                                      radius: 33,
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 18),
                              Text(
                                "ZEVORA PROJECT MODULE",
                                style: TextStyle(
                                  color: _C.text,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 1.8,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                "Aplikasi dengan desain modern dan fitur terintegrasi. Dikembangkan untuk pengalaman penggunaan ZEVORA PROJECT.",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: _C.grey,
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w600,
                                  height: 1.7,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),

                        // ── 4. LOGIN BUTTON ──
                        GestureDetector(
                          onTap: _handleLoginPress,
                          child: Container(
                            width: double.infinity,
                            height: 56,
                            decoration:
                                _C.comicBlueButton(radius: 16),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.rocket_launch_rounded,
                                    color: Colors.white, size: 18),
                                SizedBox(width: 10),
                                Text(
                                  "LOGIN TO ZEVORA PROJECT",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),

                        // ── 5. CONTACT SUPPORT ──
                        GestureDetector(
                          onTap: () => _openUrl("https://t.me/NanzzPrime"),
                          child: Container(
                            width: double.infinity,
                            height: 54,
                            decoration:
                                _C.comicOutlineButton(radius: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.headset_mic_rounded,
                                    color: _C.blue, size: 17),
                                SizedBox(width: 10),
                                Text(
                                  "CONTACT SUPPORT",
                                  style: TextStyle(
                                    color: _C.text,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Rajdhani',
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 36),

                        // ── 6. HUBUNGI KAMI ──
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Container(
                                height: 2.5,
                                color: _C.blueDark.withOpacity(0.2),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              child: Text(
                                "HUBUNGI KAMI",
                                style: TextStyle(
                                  color: _C.blue.withOpacity(0.7),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 3,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                height: 2.5,
                                color: _C.blueDark.withOpacity(0.2),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),

                        // ==========================================
                        // KOTAK 3D COMIC UNTUK SOSIAL MEDIA
                        // ==========================================
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                          decoration: BoxDecoration(
                            color: _C.softBg, // Selaras dengan surface dashboard
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: _C.border, width: 1.2), // Border dashboard
                            boxShadow: [
                              BoxShadow(
                                color: _C.blueShadow,
                                offset: const Offset(0, 6),
                                blurRadius: 18,
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildSocialIcon(
                                  FontAwesomeIcons.whatsapp,
                                  "https://wa.me/6283169690420",
                                  "WhatsApp",
                                  active: true),
                              _buildSocialIcon(
                                  FontAwesomeIcons.telegram,
                                  "https://t.me/NanzzPrime",
                                  "Telegram",
                                  active: true),
                              _buildSocialIcon(
                                  FontAwesomeIcons.instagram,
                                  "https://instagram.com/",
                                  "Instagram",
                                  active: false),
                            ],
                          ),
                        ),
                        // ==========================================

                        const SizedBox(height: 28),
                        Text(
                          "© 2026 ZEVORA PROJECT. All in For You",
                          style: TextStyle(
                            color: _C.grey,
                            fontSize: 9.5,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Rajdhani',
                          ),
                        ),
                        const SizedBox(height: 10),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialIcon(
    IconData icon,
    String url,
    String label, {
    required bool active,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () => _openUrl(url),
          child: Container(
            width: 60,
            height: 60,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: active ? _C.blue : _C.softBg,
              border: Border.all(color: _C.border, width: 1.2), // Border halus
              boxShadow: [
                BoxShadow(
                  color: active ? _C.blue.withOpacity(0.28) : Colors.black.withOpacity(0.16),
                  offset: const Offset(0, 4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Icon(
              icon,
              color: active ? Colors.white : _C.blue,
              size: 24,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(
            color: _C.text,
            fontSize: 10,
            fontWeight: FontWeight.w900,
            fontFamily: 'Rajdhani',
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}