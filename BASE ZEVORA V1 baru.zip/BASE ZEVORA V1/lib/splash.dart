import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'contact_page.dart';
import 'dashboard_page.dart';
import 'pin_lock_page.dart';
import 'pin_lock_service.dart';
import 'glass_kit.dart';
import 'music_mclaren_engineer_page.dart';

// ─── Palette: Biru Tua Metalik (konsisten seluruh app) ───────────────────────
class _C {
  static const bg        = Color(0xFF090D14);
  static const steel     = Color(0xFF102D4B);
  static const redMid    = Color(0xFF1769AA);
  static const redLight  = Color(0xFF0A84FF);
  static const chrome    = Color(0xFF70B8FF);
  static const frost     = Color(0xFFB7DDFF);
  static const text      = Color(0xFFF5F5F5);
  static const textSub   = Color(0xFFB8B8B8);
  static const border    = Color(0xFF293547);
}

/// Splash soundtrack is owned by the splash flow itself. It deliberately
/// survives the SplashScreen -> onboarding route replacement and is stopped
/// immediately before the Dashboard is opened.
class _SplashAudio {
  static AudioPlayer? _player;
  static bool _started = false;

  static Future<void> start() async {
    if (_started) return;
    _started = true;
    final player = AudioPlayer();
    _player = player;
    try {
      await player.setReleaseMode(ReleaseMode.loop);
      await player.setVolume(0.22);
      await player.play(AssetSource('sounds/splash_theme.wav'));
    } catch (_) {
      _started = false;
      _player = null;
      try { await player.dispose(); } catch (_) {}
    }
  }

  static Future<void> stop() async {
    final player = _player;
    _player = null;
    _started = false;
    if (player == null) return;
    try { await player.stop(); } catch (_) {}
    try { await player.dispose(); } catch (_) {}
  }
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;
  bool _fadeOutStarted = false;
  bool _isSkipped = false;
  bool _hasNavigated = false;

  // Animations
  late AnimationController _fadeOutCtrl;   // video fade to black
  late AnimationController _uiCtrl;        // UI entrance
  late AnimationController _glowCtrl;      // text glow pulse
  late AnimationController _ringCtrl;      // rotating ring
  late AnimationController _progressCtrl;  // loading bar
  late AnimationController _particleCtrl;  // floating particles
  late AnimationController _skipBtnCtrl;   // skip button animation

  late Animation<double> _uiFade;
  late Animation<Offset>  _uiSlide;
  late Animation<double>  _glowAnim;
  late Animation<double>  _fadeOut;
  late Animation<double>  _skipBtnOpacity;
  late Animation<Offset>  _skipBtnSlide;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideo();
    _SplashAudio.start();
  }

  void _initAnimations() {
    _fadeOutCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fadeOut = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _fadeOutCtrl, curve: Curves.easeIn));

    _uiCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _uiFade  = CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOut);
    _uiSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOutCubic));

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _ringCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 5))
      ..repeat();

    _progressCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 4));

    _particleCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _skipBtnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _skipBtnOpacity = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _skipBtnCtrl, curve: Curves.easeOut));
    _skipBtnSlide = Tween<Offset>(begin: const Offset(0, 0.35), end: Offset.zero)
        .animate(CurvedAnimation(parent: _skipBtnCtrl, curve: Curves.easeOutCubic));
    
    // Show skip button after 0.5 seconds
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _skipBtnCtrl.forward();
    });
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoCtrl.setLooping(false);
        _videoCtrl.play();

        // Start UI animations after video loads
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) {
            _uiCtrl.forward();
            _progressCtrl.forward();
          }
        });

        _videoCtrl.addListener(_onVideoProgress);
      }).catchError((_) {
        // Fallback: no video, still show UI and auto-navigate
        if (mounted) {
          setState(() => _videoReady = false);
          _uiCtrl.forward();
          _progressCtrl.forward();
          Future.delayed(const Duration(seconds: 4), _navigate);
        }
      });
  }

  void _onVideoProgress() {
    if (!mounted || _isSkipped) return;
    final pos = _videoCtrl.value.position;
    final dur = _videoCtrl.value.duration;
    if (dur == Duration.zero) return;

    // Start fade-out 1s before end
    if (pos >= dur - const Duration(seconds: 1) && !_fadeOutStarted) {
      _fadeOutStarted = true;
      _fadeOutCtrl.forward();
    }

    // Navigate when done
    if (pos >= dur) _navigate();
  }

  void _skip() {
    if (_isSkipped) return;
    _isSkipped = true;
    
    // Stop video
    _videoCtrl.pause();
    _videoCtrl.removeListener(_onVideoProgress);
    
    // Start fade out and navigate
    _fadeOutStarted = true;
    _fadeOutCtrl.forward().then((_) {
      if (mounted) _navigate();
    });
  }

  void _navigate() {
    if (!mounted || _hasNavigated) return;
    _hasNavigated = true;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => PostSplashOnboarding(
          username:    widget.username,
          password:    widget.password,
          role:        widget.role,
          expiredDate: widget.expiredDate,
          sessionKey:  widget.sessionKey,
          listBug:     widget.listBug,
          listBugGroup:     widget.listBugGroup,
          listDoos:    widget.listDoos,
          news:        widget.news,
          jjVideos:    widget.jjVideos,
          thanksTo: widget.thanksTo,
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
          child: child,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoCtrl.removeListener(_onVideoProgress);
    _videoCtrl.dispose();
    _fadeOutCtrl.dispose();
    _uiCtrl.dispose();
    _glowCtrl.dispose();
    _ringCtrl.dispose();
    _progressCtrl.dispose();
    _particleCtrl.dispose();
    _skipBtnCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_videoReady && !_isSkipped)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: VideoPlayer(_videoCtrl),
                ),
              ),
            ),

          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0x33000000), Color(0xDD000000)],
                ),
              ),
            ),
          ),

          Positioned.fill(
            child: FadeTransition(
              opacity: _uiFade,
              child: SlideTransition(
                position: _uiSlide,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Spacer(flex: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.07),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: _C.redLight.withOpacity(.38)),
                      ),
                      child: Text('SECURE MEMBER ENVIRONMENT', style: TextStyle(fontFamily: 'Roboto', color: _C.frost.withOpacity(.92), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                    ),
                    const SizedBox(height: 17),
                    _buildLogoRing(),
                    const SizedBox(height: 16),
                    Text(
                      'ZEVORA PROJECT',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        color: _C.text,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3.0,
                        shadows: [Shadow(color: _C.redMid.withOpacity(0.65), blurRadius: 18)],
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Selamat datang di ruang digital ZEVORA PROJECT', textAlign: TextAlign.center,
                      style: TextStyle(fontFamily: 'Roboto', color: Color(0xFFE2E2E2), fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: .4)),
                    const SizedBox(height: 7),
                    Text('Menyiapkan dashboard, tools, dan sesi akun Anda…', textAlign: TextAlign.center,
                      style: TextStyle(fontFamily: 'Roboto', color: _C.textSub.withOpacity(.8), fontSize: 10, letterSpacing: .3)),
                    const Spacer(flex: 4),
                  ],
                ),
              ),
            ),
          ),

          Positioned(
            right: 16,
            bottom: 54,
            child: FadeTransition(
              opacity: _skipBtnOpacity,
              child: SlideTransition(
                position: _skipBtnSlide,
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _skip,
                    borderRadius: BorderRadius.circular(22),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 11,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0x66000000),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: _C.redMid.withOpacity(0.65),
                        ),
                      ),
                      child: const Text(
                        '→ LEWATI',
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: _C.text,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeOut,
              child: Container(color: _C.bg),
            ),
        ],
      ),
    );
  }

  // ─── Logo Ring ────────────────────────────────────────────────────────────
  Widget _buildLogoRing() {
    return AnimatedBuilder(
      animation: Listenable.merge([_ringCtrl, _glowCtrl]),
      builder: (_, __) => SizedBox(
        width: 160, height: 160,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer static ring
            Container(
              width: 158, height: 158,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _C.redMid.withOpacity(_glowAnim.value * 0.15),
                  width: 1,
                ),
              ),
            ),
            // Rotating dashed-style ring
            Transform.rotate(
              angle: _ringCtrl.value * math.pi * 2,
              child: Container(
                width: 138, height: 138,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: SweepGradient(
                    colors: [
                      _C.redLight.withOpacity(_glowAnim.value * 0.7),
                      Colors.transparent,
                      _C.chrome.withOpacity(_glowAnim.value * 0.4),
                      Colors.transparent,
                      _C.redLight.withOpacity(_glowAnim.value * 0.3),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            // Counter-rotating inner ring
            Transform.rotate(
              angle: -_ringCtrl.value * math.pi * 2 * 0.6,
              child: Container(
                width: 118, height: 118,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.steel.withOpacity(_glowAnim.value * 0.5),
                    width: 1.5,
                  ),
                ),
              ),
            ),
            // Core glow
            Container(
              width: 96, height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.bg,
                boxShadow: [
                  BoxShadow(
                    color: _C.redMid.withOpacity(_glowAnim.value * 0.55),
                    blurRadius: 40,
                    spreadRadius: 0,
                  ),
                ],
                border: Border.all(
                  color: _C.redLight.withOpacity(_glowAnim.value * 0.5),
                  width: 1.5,
                ),
              ),
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Center(
                    child: Icon(Icons.water_rounded,
                        color: _C.redLight.withOpacity(_glowAnim.value),
                        size: 44),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Title ────────────────────────────────────────────────────────────────
  Widget _buildTitle() {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => ShaderMask(
        shaderCallback: (b) => LinearGradient(
          colors: [
            _C.chrome,
            _C.frost.withOpacity(0.9 + _glowAnim.value * 0.1),
            _C.redLight,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(b),
        child: Text(
          'ZEVORAl PROJECT',
          style: TextStyle(
            fontSize: 36,
            fontFamily: 'Roboto',
            color: Colors.white,
            letterSpacing: 1.5,
            shadows: [
              Shadow(
                color: _C.redMid.withOpacity(_glowAnim.value * 0.8),
                blurRadius: 24,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubtitle() {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: _C.border.withOpacity(0.4),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _C.redMid.withOpacity(_glowAnim.value * 0.25),
          ),
        ),
        child: Text(
          'Powered by @NanzzPrime',
          style: TextStyle(
            color: _C.textSub.withOpacity(0.7 + _glowAnim.value * 0.3),
            fontSize: 12,
            letterSpacing: 0.5,
          ),
        ),
      ),
    );
  }

  // ─── Bottom Bar ───────────────────────────────────────────────────────────
  Widget _buildBottomBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 34),
      child: GlassPanel(
        radius: 22,
        blur: 14,
        opacity: .075,
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
        child: Column(
        children: [
          // Loading dots
          _LoadingDots(),
          const SizedBox(height: 18),

          // Progress bar
          AnimatedBuilder(
            animation: _progressCtrl,
            builder: (_, __) => Column(children: [
              // Bar
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: Stack(children: [
                  Container(
                    height: 3,
                    width: double.infinity,
                    color: _C.border.withOpacity(0.5),
                  ),
                  Container(
                    height: 3,
                    width: math.max(0.0, MediaQuery.of(context).size.width - 84).toDouble() *
                        _progressCtrl.value,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.steel, _C.redMid, _C.redLight],
                      ),
                      borderRadius: BorderRadius.circular(3),
                      boxShadow: [
                        BoxShadow(
                          color: _C.redMid.withOpacity(0.5),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              Text(
                '${(_progressCtrl.value * 100).toInt()}%  Memuat...',
                style: const TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  letterSpacing: 0.5,
                ),
              ),
            ]),
          ),
        ],
        ),
      ),
    );
  }
}

// ─── Loading Dots ─────────────────────────────────────────────────────────────
class _LoadingDots extends StatefulWidget {
  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}

class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0);
          final s = math.sin(t * math.pi);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Transform.scale(
              scale: 0.4 + s * 0.6,
              child: Container(
                width: 7, height: 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.redMid.withOpacity(0.35 + s * 0.65),
                  boxShadow: [
                    BoxShadow(
                      color: _C.redMid.withOpacity(s * 0.4),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Particle Painter ─────────────────────────────────────────────────────────
class _ParticlePainter extends CustomPainter {
  final double t;
  _ParticlePainter(this.t);

  static final _rand = math.Random(42);
  static final _particles = List.generate(28, (i) => _Particle(
    x: _rand.nextDouble(),
    y: _rand.nextDouble(),
    size: 1.0 + _rand.nextDouble() * 2.0,
    speed: 0.04 + _rand.nextDouble() * 0.1,
    phase: _rand.nextDouble(),
    opacity: 0.15 + _rand.nextDouble() * 0.35,
  ));

  @override
  void paint(Canvas canvas, Size size) {
    // Grid
    final grid = Paint()
      ..color = const Color(0xFF4A1616).withOpacity(0.3)
      ..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Central glow
    final center = Offset(size.width / 2, size.height * 0.38);
    final glow   = Paint()
      ..shader = RadialGradient(colors: [
        _C.steel.withOpacity(0.18 + math.sin(t * math.pi * 2) * 0.06),
        Colors.transparent,
      ], radius: 0.6).createShader(
          Rect.fromCircle(center: center, radius: size.width * 0.7));
    canvas.drawCircle(center, size.width * 0.7, glow);

    // Floating particles
    for (final p in _particles) {
      final px = p.x * size.width;
      final rawY = p.y + (t * p.speed) % 1.0;
      final py = (rawY % 1.0) * size.height;
      final drift = math.sin((t + p.phase) * math.pi * 2) * 8;
      final osc = math.sin((t * 2 + p.phase) * math.pi);
      final opacity = p.opacity * (0.5 + osc * 0.5);

      canvas.drawCircle(
        Offset(px + drift, py),
        p.size,
        Paint()..color = _C.redLight.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.t != t;
}

class _Particle {
  final double x, y, size, speed, phase, opacity;
  const _Particle({
    required this.x, required this.y, required this.size,
    required this.speed, required this.phase, required this.opacity,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// POST-SPLASH ONBOARDING
// Muncul tepat setelah SplashScreen selesai. Background menggunakan video
// splash yang sama, dibuat loop agar animasinya tetap bergerak.
// ─────────────────────────────────────────────────────────────────────────────
class PostSplashOnboarding extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const PostSplashOnboarding({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<PostSplashOnboarding> createState() => _PostSplashOnboardingState();
}

class _PostSplashOnboardingState extends State<PostSplashOnboarding>
    with TickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _contentCtrl;
  late final AnimationController _glowCtrl;
  late final AnimationController _bgCtrl;
  VideoPlayerController? _videoCtrl;
  bool _videoReady = false;
  int _page = 0;

  static const _red = Color(0xFFE3262F);
  static const _redBright = Color(0xFF70B8FF);
  static const _redDark = Color(0xFF5A0B10);
  static const _black = Color(0xFF050505);

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _contentCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
    _initBackgroundVideo();
  }

  Future<void> _initBackgroundVideo() async {
    final controller = VideoPlayerController.asset('assets/videos/splash.mp4');
    _videoCtrl = controller;
    try {
      await controller.initialize();
      if (!mounted) {
        controller.dispose();
        return;
      }
      controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      setState(() => _videoReady = true);
    } catch (_) {
      if (mounted) setState(() => _videoReady = false);
      controller.dispose();
    }
  }

  @override
  void dispose() {
    _SplashAudio.stop();
    _pageController.dispose();
    _contentCtrl.dispose();
    _glowCtrl.dispose();
    _bgCtrl.dispose();
    _videoCtrl?.dispose();
    super.dispose();
  }

  void _next() {
    if (_page < 2) {
      _contentCtrl.reset();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeOutCubic,
      );
    } else {
      _openDashboard();
    }
  }

  void _onPageChanged(int value) {
    setState(() => _page = value);
    _contentCtrl.forward();
  }

  Future<void> _openDashboard() async {
    final pinOn = await PinLockService.isEnabled();
    if (pinOn && mounted) {
      final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => PinLockPage(
            isSetup: false,
            onUnlocked: () {},
          ),
        ),
      );
      if (ok != true || !mounted) return;
    }
    if (!mounted) return;
    await _SplashAudio.stop();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listBugGroup: widget.listBugGroup,
          listDoos: widget.listDoos,
          news: widget.news,
          jjVideos: widget.jjVideos,
          thanksTo: widget.thanksTo,
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  Future<void> _joinTelegram() async {
    final uri = Uri.parse('https://t.me/NanzzPrime');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _contactOwner() async {
    // Reuse the existing in-app Customer Service/Contact Owner page.
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const ContactPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_videoReady && _videoCtrl != null)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl!.value.size.width,
                  height: _videoCtrl!.value.size.height,
                  child: VideoPlayer(_videoCtrl!),
                ),
              ),
            ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.42),
                    const Color(0xFF160406).withOpacity(0.72),
                    Colors.black.withOpacity(0.94),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgCtrl,
              builder: (_, __) => CustomPaint(
                painter: _RedParticlePainter(_bgCtrl.value),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: _onPageChanged,
                    itemCount: 3,
                    itemBuilder: (_, index) => _buildPage(index),
                  ),
                ),
                _buildBottomBar(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage(int index) {
    const titles = [
      'Selamat Datang di ZEVORA PROJECT',
      'ZEVORA PROJECT Apps',
      'Team ZEVORA PROJECT',
    ];
    const subtitles = [
      'WELCOME TO ZEVORA PROJECT',
      'READY TO USE ZEVORA PROJECT',
      'JOIN US NOW',
    ];
    const descriptions = [
      'Jadilah Awan Hitam Yang Menutupi Para Bintang.',
      'Menjadi Penjahat Yang Membasmi Para Pahlawan.',
      'Diam Bukan Berati Lemah.',
    ];
    const icons = [
      Icons.shield_rounded,
      Icons.rocket_launch_rounded,
      Icons.send_rounded,
    ];

    return AnimatedBuilder(
      animation: _contentCtrl,
      builder: (_, __) {
        final opacity = Curves.easeOut.transform(_contentCtrl.value);
        final slide = (1 - Curves.easeOutCubic.transform(_contentCtrl.value)) * 24;
        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: Offset(0, slide),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 8),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(),
                  _buildIcon(icons[index]),
                  const SizedBox(height: 30),
                  Text(
                    titles[index],
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Roboto',
                      fontSize: 25,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.0,
                      shadows: [Shadow(color: Color(0xAAE3262F), blurRadius: 18)],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    subtitles[index],
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _redBright,
                      fontFamily: 'Roboto',
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 330),
                    child: Text(
                      descriptions[index],
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFFD2D2D2),
                        fontFamily: 'Roboto',
                        fontSize: 11,
                        height: 1.8,
                      ),
                    ),
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildIcon(IconData icon) {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) {
        final g = Curves.easeInOut.transform(_glowCtrl.value);
        return Container(
          width: 116,
          height: 116,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [_redDark, _red],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: _redBright.withOpacity(0.35 + g * 0.45),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _red.withOpacity(0.20 + g * 0.22),
                blurRadius: 30 + g * 16,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Icon(icon, color: Colors.white, size: 48),
        );
      },
    );
  }

  Widget _buildBottomBar() {
    final isLast = _page == 2;
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 8, 22, 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              3,
              (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: i == _page ? 26 : 7,
                height: 7,
                decoration: BoxDecoration(
                  color: i == _page ? _redBright : Colors.white24,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: i == _page
                      ? const [BoxShadow(color: Color(0x66E3262F), blurRadius: 8)]
                      : null,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (isLast)
            Row(
              children: [
                Expanded(
                  child: _actionButton(
                    icon: Icons.send_rounded,
                    label: 'JOIN TELEGRAM',
                    onTap: _joinTelegram,
                    outlined: true,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _actionButton(
                    icon: Icons.person_outline_rounded,
                    label: 'CONTACT OWNER',
                    onTap: _contactOwner,
                  ),
                ),
              ],
            )
          else
            Align(
              alignment: Alignment.centerRight,
              child: _actionButton(
                icon: Icons.arrow_forward_rounded,
                label: 'LANJUT',
                onTap: _next,
              ),
            ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: _openDashboard,
            child: const Text(
              'LEWATI',
              style: TextStyle(
                color: Colors.white54,
                fontFamily: 'Roboto',
                fontSize: 10,
                letterSpacing: 1.2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool outlined = false,
  }) {
    return SizedBox(
      height: 52,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 18),
              label: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
              style: OutlinedButton.styleFrom(
                foregroundColor: _redBright,
                side: const BorderSide(color: _red),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                textStyle: const TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            )
          : ElevatedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 18),
              label: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
              style: ElevatedButton.styleFrom(
                backgroundColor: _red,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                textStyle: const TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                ),
              ),
            ),
    );
  }
}

class _RedParticlePainter extends CustomPainter {
  final double t;
  _RedParticlePainter(this.t);

  static const _redBright = Color(0xFF70B8FF);

  static final _random = math.Random(42);
  static final _particles = List.generate(
    32,
    (_) => _RedParticle(
      x: _random.nextDouble(),
      y: _random.nextDouble(),
      size: 0.7 + _random.nextDouble() * 2.2,
      speed: 0.04 + _random.nextDouble() * 0.09,
      phase: _random.nextDouble(),
    ),
  );

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = const Color(0x22E3262F)
      ..strokeWidth = 0.5;
    const step = 48.0;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    for (final p in _particles) {
      final py = ((p.y + t * p.speed) % 1.0) * size.height;
      final px = p.x * size.width +
          math.sin((t + p.phase) * math.pi * 2) * 8;
      final opacity = 0.12 + (math.sin((t + p.phase) * math.pi * 2) + 1) * 0.10;
      canvas.drawCircle(
        Offset(px, py),
        p.size,
        Paint()..color = _redBright.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RedParticlePainter oldDelegate) =>
      oldDelegate.t != t;
}

class _RedParticle {
  final double x;
  final double y;
  final double size;
  final double speed;
  final double phase;

  const _RedParticle({
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.phase,
  });
}


/// Post-login handoff: replaces only the former post-auth splash stage.
/// Authentication data and the existing PIN-lock gate are passed through intact.
class PostLoginEngineerMusicGate extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const PostLoginEngineerMusicGate({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<PostLoginEngineerMusicGate> createState() =>
      _PostLoginEngineerMusicGateState();
}

class _PostLoginEngineerMusicGateState
    extends State<PostLoginEngineerMusicGate> {
  bool _openingDashboard = false;

  Future<void> _openDashboard() async {
    if (_openingDashboard) return;
    _openingDashboard = true;

    final pinOn = await PinLockService.isEnabled();
    if (pinOn && mounted) {
      final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => PinLockPage(
            isSetup: false,
            onUnlocked: () {},
          ),
        ),
      );
      if (ok != true || !mounted) {
        _openingDashboard = false;
        return;
      }
    }
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listBugGroup: widget.listBugGroup,
          listDoos: widget.listDoos,
          news: widget.news,
          jjVideos: widget.jjVideos,
          thanksTo: widget.thanksTo,
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MusicMcLarenEngineerPage(
      username: widget.username,
      role: widget.role,
      onContinue: _openDashboard,
    );
  }
}
