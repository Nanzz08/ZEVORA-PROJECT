import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'pin_lock_service.dart';

/// Halaman set / unlock PIN angka atau pola.
/// Tema hitam + merah. Mode: setup | unlock
class PinLockPage extends StatefulWidget {
  final bool isSetup;
  /// Dipanggil setelah unlock sukses (atau setup selesai).
  final VoidCallback? onUnlocked;
  /// Jika setup selesai, optional callback.
  final VoidCallback? onSetupDone;

  const PinLockPage({
    super.key,
    this.isSetup = false,
    this.onUnlocked,
    this.onSetupDone,
  });

  @override
  State<PinLockPage> createState() => _PinLockPageState();
}

class _PinLockPageState extends State<PinLockPage>
    with SingleTickerProviderStateMixin {
  static const _bg = Color(0xFF0A0505);
  static const _card = Color(0xFF1A0C0C);
  static const _red = Color(0xFFE53935);
  static const _redDim = Color(0xFFB71C1C);
  static const _text = Color(0xFFFFF0F0);
  static const _textSub = Color(0xFFB08080);

  // setup: choose type first
  String? _setupType; // 'pin' | 'pattern'
  String _phase = 'choose'; // choose | enter | confirm | unlock
  String _firstValue = '';
  String _current = '';
  String _error = '';
  bool _loadingType = true;
  String? _unlockType;

  late AnimationController _shakeCtrl;

  @override
  void initState() {
    super.initState();
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    if (widget.isSetup) {
      _phase = 'choose';
      _loadingType = false;
    } else {
      _loadUnlockType();
    }
  }

  Future<void> _loadUnlockType() async {
    final t = await PinLockService.getType();
    setState(() {
      _unlockType = t ?? 'pin';
      _phase = 'unlock';
      _loadingType = false;
    });
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    super.dispose();
  }

  void _shake() {
    _shakeCtrl.forward(from: 0);
    HapticFeedback.heavyImpact();
  }

  // ── PIN angka ──────────────────────────────────────
  void _onDigit(String d) {
    if (_current.length >= 4) return;
    HapticFeedback.selectionClick();
    setState(() {
      _current += d;
      _error = '';
    });
    if (_current.length == 4) {
      Future.delayed(const Duration(milliseconds: 120), _onPinComplete);
    }
  }

  void _onBackspace() {
    if (_current.isEmpty) return;
    HapticFeedback.selectionClick();
    setState(() {
      _current = _current.substring(0, _current.length - 1);
      _error = '';
    });
  }

  Future<void> _onPinComplete() async {
    if (widget.isSetup) {
      if (_phase == 'enter') {
        setState(() {
          _firstValue = _current;
          _current = '';
          _phase = 'confirm';
        });
      } else if (_phase == 'confirm') {
        if (_current != _firstValue) {
          setState(() {
            _error = 'PIN tidak cocok. Coba lagi.';
            _current = '';
            _phase = 'enter';
            _firstValue = '';
          });
          _shake();
          return;
        }
        await PinLockService.setLock(type: 'pin', value: _current);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('PIN berhasil disimpan'),
            backgroundColor: _redDim,
            behavior: SnackBarBehavior.floating,
          ),
        );
        widget.onSetupDone?.call();
        Navigator.pop(context, true);
      }
    } else {
      final ok = await PinLockService.verify(_current);
      if (ok) {
        widget.onUnlocked?.call();
        if (mounted && Navigator.canPop(context)) {
          Navigator.pop(context, true);
        }
      } else {
        setState(() {
          _error = 'PIN salah';
          _current = '';
        });
        _shake();
      }
    }
  }

  // ── Pattern ────────────────────────────────────────
  final List<int> _pattern = [];
  final Set<int> _patternVisited = {};

  void _onPatternPoint(int idx) {
    if (_patternVisited.contains(idx)) return;
    HapticFeedback.selectionClick();
    setState(() {
      _pattern.add(idx);
      _patternVisited.add(idx);
      _error = '';
    });
  }

  void _onPatternEnd() {
    if (_pattern.length < 4) {
      setState(() {
        _error = 'Minimal 4 titik';
        _pattern.clear();
        _patternVisited.clear();
      });
      _shake();
      return;
    }
    final value = _pattern.join('-');
    _handlePatternValue(value);
  }

  Future<void> _handlePatternValue(String value) async {
    if (widget.isSetup) {
      if (_phase == 'enter') {
        setState(() {
          _firstValue = value;
          _pattern.clear();
          _patternVisited.clear();
          _phase = 'confirm';
        });
      } else if (_phase == 'confirm') {
        if (value != _firstValue) {
          setState(() {
            _error = 'Pola tidak cocok. Coba lagi.';
            _pattern.clear();
            _patternVisited.clear();
            _phase = 'enter';
            _firstValue = '';
          });
          _shake();
          return;
        }
        await PinLockService.setLock(type: 'pattern', value: value);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pola berhasil disimpan'),
            backgroundColor: _redDim,
            behavior: SnackBarBehavior.floating,
          ),
        );
        widget.onSetupDone?.call();
        Navigator.pop(context, true);
      }
    } else {
      final ok = await PinLockService.verify(value);
      if (ok) {
        widget.onUnlocked?.call();
        if (mounted && Navigator.canPop(context)) {
          Navigator.pop(context, true);
        }
      } else {
        setState(() {
          _error = 'Pola salah';
          _pattern.clear();
          _patternVisited.clear();
        });
        _shake();
      }
    }
  }

  String get _title {
    if (_phase == 'choose') return 'ATUR KEAMANAN';
    if (_phase == 'enter') {
      return _setupType == 'pattern' ? 'BUAT POLA' : 'BUAT PIN';
    }
    if (_phase == 'confirm') {
      return _setupType == 'pattern' ? 'KONFIRMASI POLA' : 'KONFIRMASI PIN';
    }
    return 'MASUKAN PIN';
  }

  String get _subtitle {
    if (_phase == 'choose') return 'Pilih metode kunci aplikasi';
    if (_phase == 'enter') {
      return _setupType == 'pattern'
          ? 'Gambar pola (min. 4 titik)'
          : 'Masukkan 4 digit PIN baru';
    }
    if (_phase == 'confirm') {
      return _setupType == 'pattern'
          ? 'Ulangi pola yang sama'
          : 'Masukkan ulang PIN';
    }
    return _unlockType == 'pattern'
        ? 'Gambar pola untuk membuka'
        : 'Masukkan PIN untuk membuka dashboard';
  }

  @override
  Widget build(BuildContext context) {
    if (_loadingType) {
      return const Scaffold(
        backgroundColor: Colors.transparent,
        body: Center(child: CircularProgressIndicator(color: _red)),
      );
    }

    final usePattern = widget.isSetup
        ? _setupType == 'pattern'
        : _unlockType == 'pattern';

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _shakeCtrl,
          builder: (context, child) {
            final t = _shakeCtrl.value;
            final dx = math.sin(t * math.pi * 6) * 10 * (1 - t);
            return Transform.translate(offset: Offset(dx, 0), child: child);
          },
          child: Column(
            children: [
              if (widget.isSetup)
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: _text, size: 20),
                    onPressed: () {
                      if (_phase == 'enter' || _phase == 'confirm') {
                        setState(() {
                          _phase = 'choose';
                          _setupType = null;
                          _current = '';
                          _firstValue = '';
                          _pattern.clear();
                          _patternVisited.clear();
                          _error = '';
                        });
                      } else {
                        Navigator.pop(context);
                      }
                    },
                  ),
                ),
              const Spacer(flex: 1),
              // Lock icon
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red.withOpacity(0.12),
                  border: Border.all(color: _red.withOpacity(0.45), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: _red.withOpacity(0.25),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(
                  usePattern == true
                      ? Icons.gesture_rounded
                      : Icons.lock_rounded,
                  color: _red,
                  size: 32,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                _title,
                style: const TextStyle(
                  color: _text,
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _textSub, fontSize: 13),
              ),
              if (_error.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  _error,
                  style: const TextStyle(color: _red, fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ],
              const SizedBox(height: 28),

              if (_phase == 'choose') _buildChooseType(),

              if (_phase != 'choose' && usePattern != true) ...[
                _buildPinDots(),
                const SizedBox(height: 28),
                _buildKeypad(),
              ],

              if (_phase != 'choose' && usePattern == true) ...[
                _buildPatternPad(),
              ],

              const Spacer(flex: 2),

              if (!widget.isSetup)
                TextButton(
                  onPressed: () async {
                    // optional: disable lock if forgot — only for developer convenience
                    // leave empty; user must set again from profile
                  },
                  child: const Text(
                    '',
                    style: TextStyle(color: _textSub, fontSize: 12),
                  ),
                ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChooseType() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          _typeCard(
            icon: Icons.pin_rounded,
            title: 'PIN Angka',
            subtitle: '4 digit angka',
            onTap: () => setState(() {
              _setupType = 'pin';
              _phase = 'enter';
              _current = '';
              _error = '';
            }),
          ),
          const SizedBox(height: 14),
          _typeCard(
            icon: Icons.gesture_rounded,
            title: 'Pola',
            subtitle: 'Gambar pola di 9 titik',
            onTap: () => setState(() {
              _setupType = 'pattern';
              _phase = 'enter';
              _pattern.clear();
              _patternVisited.clear();
              _error = '';
            }),
          ),
          const SizedBox(height: 24),
          TextButton(
            onPressed: () async {
              await PinLockService.clearLock();
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Kunci aplikasi dinonaktifkan'),
                  backgroundColor: _redDim,
                  behavior: SnackBarBehavior.floating,
                ),
              );
              Navigator.pop(context, false);
            },
            child: const Text(
              'Hapus / Nonaktifkan Kunci',
              style: TextStyle(color: _textSub, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _red.withOpacity(0.35)),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _red.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: _red, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          color: _text, fontWeight: FontWeight.w700, fontSize: 15)),
                  Text(subtitle,
                      style: const TextStyle(color: _textSub, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: _textSub),
          ],
        ),
      ),
    );
  }

  Widget _buildPinDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(4, (i) {
        final filled = i < _current.length;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          margin: const EdgeInsets.symmetric(horizontal: 10),
          width: filled ? 16 : 14,
          height: filled ? 16 : 14,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? _red : Colors.transparent,
            border: Border.all(
              color: filled ? _red : _textSub.withOpacity(0.5),
              width: 2,
            ),
            boxShadow: filled
                ? [BoxShadow(color: _red.withOpacity(0.45), blurRadius: 8)]
                : null,
          ),
        );
      }),
    );
  }

  Widget _buildKeypad() {
    final keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', 'del'],
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        children: keys.map((row) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: row.map((k) {
                if (k.isEmpty) return const SizedBox(width: 72, height: 72);
                return _keyBtn(k);
              }).toList(),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _keyBtn(String k) {
    final isDel = k == 'del';
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => isDel ? _onBackspace() : _onDigit(k),
        customBorder: const CircleBorder(),
        child: Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _card,
            border: Border.all(color: _red.withOpacity(0.25)),
            boxShadow: [
              BoxShadow(
                color: _red.withOpacity(0.08),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: isDel
                ? const Icon(Icons.backspace_outlined, color: _text, size: 22)
                : Text(
                    k,
                    style: const TextStyle(
                      color: _text,
                      fontSize: 26,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildPatternPad() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 48),
      child: AspectRatio(
        aspectRatio: 1,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final size = constraints.maxWidth;
            final cell = size / 3;
            return GestureDetector(
              onPanStart: (d) => _hitPattern(d.localPosition, cell),
              onPanUpdate: (d) => _hitPattern(d.localPosition, cell),
              onPanEnd: (_) => _onPatternEnd(),
              child: CustomPaint(
                painter: _PatternPainter(
                  selected: List.from(_pattern),
                  color: _red,
                  dim: _textSub,
                ),
                size: Size(size, size),
              ),
            );
          },
        ),
      ),
    );
  }

  void _hitPattern(Offset pos, double cell) {
    final col = (pos.dx / cell).floor().clamp(0, 2);
    final row = (pos.dy / cell).floor().clamp(0, 2);
    // only register if near center of cell
    final cx = col * cell + cell / 2;
    final cy = row * cell + cell / 2;
    final dist = (pos - Offset(cx, cy)).distance;
    if (dist > cell * 0.35) return;
    final idx = row * 3 + col;
    _onPatternPoint(idx);
  }
}

class _PatternPainter extends CustomPainter {
  final List<int> selected;
  final Color color;
  final Color dim;

  _PatternPainter({
    required this.selected,
    required this.color,
    required this.dim,
  });

  Offset _center(int i, Size size) {
    final cell = size.width / 3;
    final col = i % 3;
    final row = i ~/ 3;
    return Offset(col * cell + cell / 2, row * cell + cell / 2);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = color.withOpacity(0.7)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    // lines
    for (var i = 0; i < selected.length - 1; i++) {
      canvas.drawLine(
        _center(selected[i], size),
        _center(selected[i + 1], size),
        linePaint,
      );
    }

    // dots
    for (var i = 0; i < 9; i++) {
      final c = _center(i, size);
      final active = selected.contains(i);
      final paint = Paint()
        ..color = active ? color : dim.withOpacity(0.4)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(c, active ? 14 : 10, paint);
      if (active) {
        canvas.drawCircle(
          c,
          20,
          Paint()
            ..color = color.withOpacity(0.25)
            ..style = PaintingStyle.fill,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _PatternPainter old) =>
      old.selected != selected;
}
