import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:fiona/Qaxer/api.dart';
import 'change_password_page.dart';
import 'pin_lock_page.dart';
import 'premium_service.dart';
import 'premium_buy_page.dart';

// Ganti dengan URL API lo
const String _baseUrl = Api.api; 

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _profileImage;
  String? _networkImageUrl; // Buat nyimpen URL foto dari server
  bool _isUploadingImage = false;
  bool _isVerified = false;

  final ImagePicker _picker = ImagePicker();

  // Controller buat edit profile
  final TextEditingController _displayNameController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _sessionKeyController = TextEditingController();
  
  bool _isSavingProfile = false;

  // --- TEMA WARNA CYAN ---
  final Color bgDark = const Color(0xFF0A0F16);
  final Color primaryCyan = const Color(0xFF345675);
  final Color accentCyan = const Color(0xFF6F94B8);
  final Color primaryWhite = Colors.white;

  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    _loadLocalProfileImage();
    _fetchProfileData();
    _loadVerified();
  }

  Future<void> _loadVerified() async {
    final v = await PremiumService.isVerified(widget.username);
    if (mounted) setState(() => _isVerified = v);
  }

  Future<void> _loadLocalProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _fetchProfileData() async {
    try {
      final res = await http.get(Uri.parse("$_baseUrl/api/getProfile?username=${widget.username}&sessionKey=${widget.sessionKey}"));
      final json = jsonDecode(res.body);
      if (json["success"] == true) {
        setState(() {
          _displayNameController.text = json["displayName"] ?? "";
          _bioController.text = json["bio"] ?? "";
          _networkImageUrl = json["profileImageUrl"]; // Ambil URL foto dari server
        });
      }
    } catch (_) {}
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: bgDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFF345675)),
              title: const Text("Kamera", style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF6F94B8)),
              title: const Text("Galeri", style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: source, imageQuality: 70);
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);

        // 1. Update UI lokal biar real-time (foto langsung berubah)
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        
        setState(() {
          _profileImage = imageFile;
          _networkImageUrl = null; // Prioritaskan tampilin foto lokal yg baru dipilih
          _isUploadingImage = true;
        });

        // 2. Upload ke server
        var request = http.MultipartRequest('POST', Uri.parse('$_baseUrl/api/uploadProfileImage'));
        request.fields['username'] = widget.username;
        request.fields['sessionKey'] = widget.sessionKey;
        request.files.add(await http.MultipartFile.fromPath('image', imageFile.path));
        
        var response = await request.send();
        
        if (mounted) {
          setState(() => _isUploadingImage = false);
        }

        if (response.statusCode == 200) {
          var responseData = await response.stream.toBytes();
          var responseString = String.fromCharCodes(responseData);
          var json = jsonDecode(responseString);
          
          if (json['success'] == true) {
            // Simpen url ke cache
            await prefs.setString('profile_image_url_${widget.username}', json['imageUrl']);
            
            if (mounted) {
              setState(() {
                _networkImageUrl = json['imageUrl'];
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Foto profil berhasil diupload!"), backgroundColor: Colors.red),
              );
            }
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Gagal upload foto ke server"), backgroundColor: Colors.red),
            );
          }
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isUploadingImage = false);
      print("Error picking image: $e");
    }
  }

  Future<void> _saveProfile() async {
    if (_sessionKeyController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Session Key wajib diisi untuk konfirmasi!"), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isSavingProfile = true);

    try {
      final res = await http.post(
        Uri.parse("$_baseUrl/api/updateProfile"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'sessionKey': _sessionKeyController.text.trim(),
          'displayName': _displayNameController.text.trim(),
          'bio': _bioController.text.trim(),
        }),
      );

      final json = jsonDecode(res.body);
      if (json["success"] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Profile berhasil diperbarui!"), backgroundColor: Colors.red),
          );
          _sessionKeyController.clear();
          FocusScope.of(context).unfocus();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Gagal: ${json["message"] ?? 'Unknown error'}"), backgroundColor: Colors.red),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red),
        );
      }
    }

    if (mounted) setState(() => _isSavingProfile = false);
  }

  @override
  Widget build(BuildContext context) {
    final displayName = _displayNameController.text.trim().isNotEmpty
        ? _displayNameController.text.trim()
        : widget.username;

    Widget sectionTitle(String title, String subtitle) => Padding(
      padding: const EdgeInsets.fromLTRB(4, 23, 4, 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: -0.2)),
          const SizedBox(height: 3),
          Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.43), fontSize: 11)),
        ],
      ),
    );

    Widget settingsTile({required IconData icon, required String title, required String subtitle, required VoidCallback onTap, Color? tint, Widget? trailing}) {
      final color = tint ?? accentCyan;
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(17),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            child: Row(
              children: [
                Container(
                  width: 41,
                  height: 41,
                  decoration: BoxDecoration(color: color.withOpacity(0.13), borderRadius: BorderRadius.circular(13)),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.43), fontSize: 10.5), maxLines: 2, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                trailing ?? Icon(Icons.chevron_right_rounded, color: Colors.white.withOpacity(0.35), size: 21),
              ],
            ),
          ),
        ),
      );
    }

    Widget settingsGroup(List<Widget> children) => Container(
      decoration: BoxDecoration(
        color: const Color(0xFF151D29).withOpacity(0.88),
        borderRadius: BorderRadius.circular(21),
        border: Border.all(color: Colors.white.withOpacity(0.075)),
      ),
      child: Column(children: children),
    );

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Settings', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: -0.4)),
        centerTitle: false,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, const Color(0xFF142638).withOpacity(0.72), bgDark],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(17, 8, 17, 34),
          children: [
            Container(
              padding: const EdgeInsets.all(17),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [const Color(0xFF1D3548), const Color(0xFF14202E), const Color(0xFF171D2B)],
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(0.10)),
                boxShadow: [BoxShadow(color: primaryCyan.withOpacity(0.17), blurRadius: 25, offset: const Offset(0, 10))],
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: _isUploadingImage ? null : _showImageSourceDialog,
                    child: Stack(
                      children: [
                        Container(
                          width: 76,
                          height: 76,
                          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: accentCyan.withOpacity(0.8), width: 2.2)),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : (_networkImageUrl != null && _networkImageUrl!.isNotEmpty
                                    ? Image.network(_networkImageUrl!, fit: BoxFit.cover)
                                    : Container(color: primaryCyan.withOpacity(0.3), child: const Icon(Icons.person_rounded, color: Colors.white, size: 36))),
                          ),
                        ),
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(color: accentCyan, shape: BoxShape.circle, border: Border.all(color: bgDark, width: 2)),
                            child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 12),
                          ),
                        ),
                        if (_isUploadingImage)
                          const Positioned.fill(child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))),
                      ],
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(child: Text(displayName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))),
                            if (_isVerified) ...[const SizedBox(width: 5), const VerifiedBadge(size: 16)],
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text('@${widget.username}', style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 11)),
                        const SizedBox(height: 9),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                          decoration: BoxDecoration(color: accentCyan.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                          child: Text(widget.role.toUpperCase(), style: TextStyle(color: accentCyan, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded, color: Colors.white.withOpacity(0.35)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            settingsTile(
              icon: Icons.verified_rounded,
              title: _isVerified ? 'Verified account' : 'Get verified',
              subtitle: _isVerified ? 'Your account verification is active' : 'Upgrade your profile with a verification badge',
              tint: const Color(0xFF1D9BF0),
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => PremiumBuyPage(username: widget.username, sessionKey: widget.sessionKey)));
                _loadVerified();
              },
              trailing: _isVerified ? const Icon(Icons.check_circle_rounded, color: Color(0xFF1D9BF0)) : Icon(Icons.chevron_right_rounded, color: Colors.white.withOpacity(0.35)),
            ),

            sectionTitle('Account', 'Your account information and profile details'),
            settingsGroup([
              settingsTile(icon: Icons.alternate_email_rounded, title: 'Username', subtitle: widget.username, onTap: () {}),
              Divider(height: 1, indent: 68, color: Colors.white.withOpacity(0.055)),
              settingsTile(icon: Icons.badge_outlined, title: 'Display name & bio', subtitle: 'Edit how your profile appears to others', onTap: () { FocusScope.of(context).requestFocus(FocusNode()); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Edit nama dan bio melalui bagian Profile details di bawah.'))); }),
              Divider(height: 1, indent: 68, color: Colors.white.withOpacity(0.055)),
              settingsTile(icon: Icons.workspace_premium_outlined, title: 'Account role', subtitle: widget.role.toUpperCase(), onTap: () {}),
              Divider(height: 1, indent: 68, color: Colors.white.withOpacity(0.055)),
              settingsTile(icon: Icons.event_available_rounded, title: 'Membership expiry', subtitle: widget.expiredDate, onTap: () {}),
            ]),

            sectionTitle('Privacy & security', 'Keep your account protected'),
            settingsGroup([
              settingsTile(
                icon: Icons.lock_reset_rounded,
                title: 'Change password',
                subtitle: 'Update your account password',
                tint: const Color(0xFF70A9F5),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChangePasswordPage(username: widget.username, sessionKey: widget.sessionKey))),
              ),
              Divider(height: 1, indent: 68, color: Colors.white.withOpacity(0.055)),
              settingsTile(
                icon: Icons.pin_rounded,
                title: 'App lock / PIN',
                subtitle: 'Set a PIN or pattern to protect access',
                tint: const Color(0xFFB69AF6),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PinLockPage(isSetup: true))),
              ),
              Divider(height: 1, indent: 68, color: Colors.white.withOpacity(0.055)),
              settingsTile(
                icon: Icons.key_rounded,
                title: 'Session key',
                subtitle: 'View your private session identifier',
                tint: const Color(0xFFF2B76B),
                onTap: () => showModalBottomSheet(
                  context: context,
                  backgroundColor: const Color(0xFF172231),
                  shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
                  builder: (ctx) => Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Session key', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      SelectableText(widget.sessionKey, style: TextStyle(color: accentCyan, fontSize: 12, height: 1.5)),
                    ]),
                  ),
                ),
              ),
            ]),

            sectionTitle('Profile details', 'Update your public profile information'),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF151D29).withOpacity(0.88), borderRadius: BorderRadius.circular(21), border: Border.all(color: Colors.white.withOpacity(0.075))),
              child: Column(
                children: [
                  _buildTextField(controller: _displayNameController, label: 'Display name', icon: Icons.person_outline_rounded),
                  const SizedBox(height: 12),
                  _buildTextField(controller: _bioController, label: 'Bio', icon: Icons.notes_rounded, maxLines: 3),
                  const SizedBox(height: 12),
                  _buildTextField(controller: _sessionKeyController, label: 'Confirm with session key', icon: Icons.vpn_key_rounded, obscureText: true),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: _isSavingProfile ? null : _saveProfile,
                      icon: _isSavingProfile ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_rounded, size: 18),
                      label: Text(_isSavingProfile ? 'Saving...' : 'Save profile', style: const TextStyle(fontWeight: FontWeight.w800)),
                      style: ElevatedButton.styleFrom(backgroundColor: primaryCyan, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),
            Center(child: Text('ZEVORA PROJECT  •  ACCOUNT SETTINGS', style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1.2))),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    int maxLines = 1,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      maxLines: obscureText ? 1 : maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: primaryCyan, size: 20),
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey.shade400),
        filled: true,
        fillColor: bgDark.withOpacity(0.5),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: borderGlass),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accentCyan, width: 2),
        ),
      ),
    );
  }

  Widget _buildInfoCard({required IconData icon, required String label, required String value}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGlass),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: primaryCyan.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: accentCyan, size: 16),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(color: Colors.grey.shade400, fontSize: 11, fontWeight: FontWeight.w600),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }
}