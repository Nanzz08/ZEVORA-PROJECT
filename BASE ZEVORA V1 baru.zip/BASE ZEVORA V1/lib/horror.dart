// horror.dart (Exotory Style - Dark Horror Theme)

import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:async';

class HorrorSurvivalGame extends StatelessWidget {
  const HorrorSurvivalGame({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '🌙 NIGHT SURVIVAL',
      debugShowCheckedModeBanner: false,
      home: const HorrorGameScreen(),
    );
  }
}

class HorrorGameScreen extends StatefulWidget {
  const HorrorGameScreen({Key? key}) : super(key: key);

  @override
  State<HorrorGameScreen> createState() => _HorrorGameScreenState();
}

class _HorrorGameScreenState extends State<HorrorGameScreen>
    with TickerProviderStateMixin {
  // ─── EXOTORY DARK COLORS ──────────────────────────────────────────────
  final Color primaryColor = const Color(0xFF4A148C);
  final Color accentColor = const Color(0xFFCE93D8);
  final Color glowColor = const Color(0xFF9C27B0);
  final Color backgroundColor = const Color(0xFF080012);
  final Color surfaceColor = const Color(0xFF10001E);
  final Color cardColor = const Color(0xFF1A0028);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFE1BEE7);
  final Color textMuted = const Color(0xFF7B5B8C);
  final Color dangerColor = const Color(0xFFFF1744);
  final Color successColor = const Color(0xFF00E676);
  final Color warningColor = const Color(0xFFFFAB00);
  final Color darkPurple = const Color(0xFF0D0015);

  // ─── GAME VARIABLES ──────────────────────────────────────────────
  late Offset playerPos;
  late Offset monsterPos;
  late Offset treasurePos;
  
  int health = 100;
  int sanity = 100;
  int score = 0;
  int level = 1;
  bool gameOver = false;
  bool gameLost = false;
  bool showWarning = false;
  
  late AnimationController _pulseController;
  late AnimationController _monsterController;
  late AnimationController _bloodController;
  
  late Timer gameTimer;
  late Timer monsterAITimer;
  
  double gameWidth = 400;
  double gameHeight = 600;
  double playerSize = 40;
  double monsterSize = 50;
  double treasureSize = 30;
  
  Random random = Random();
  double monsterSpeed = 2.0;
  double monsterChaseDistance = 150;
  int consecutiveHeartbeats = 0;

  @override
  void initState() {
    super.initState();
    _initGame();
  }

  void _initGame() {
    playerPos = Offset(gameWidth / 2, gameHeight / 2);
    monsterPos = Offset(random.nextDouble() * gameWidth, 
                       random.nextDouble() * gameHeight);
    treasurePos = Offset(random.nextDouble() * gameWidth,
                        random.nextDouble() * gameHeight);
    
    health = 100;
    sanity = 100;
    score = 0;
    level = 1;
    gameOver = false;
    gameLost = false;
    monsterSpeed = 2.0 + (level * 0.5);
    
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();
    
    _monsterController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat();
    
    _bloodController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    gameTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      _updateGame();
    });
    
    monsterAITimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      _updateMonsterAI();
    });
  }

  void _updateGame() {
    if (gameOver || gameLost) return;
    
    setState(() {
      double distToMonster = 
        (playerPos - monsterPos).distance;
      
      if (distToMonster < monsterChaseDistance) {
        showWarning = true;
        consecutiveHeartbeats++;
        sanity = max(0, sanity - 1);
      } else {
        showWarning = false;
        consecutiveHeartbeats = 0;
        sanity = min(100, (sanity + 0.3).toInt());
      }
      
      if (distToMonster < (playerSize + monsterSize) / 2) {
        health = max(0, health - 5);
        _bloodController.forward(from: 0.0);
        
        double angle = atan2(playerPos.dy - monsterPos.dy,
                            playerPos.dx - monsterPos.dx);
        playerPos = Offset(
          playerPos.dx + cos(angle) * 50,
          playerPos.dy + sin(angle) * 50,
        );
        
        if (health <= 0) {
          gameLost = true;
        }
      }
      
      if ((playerPos - treasurePos).distance < (playerSize + treasureSize) / 2) {
        score += 100 * level;
        health = min(100, health + 20);
        sanity = min(100, sanity + 30);
        treasurePos = Offset(random.nextDouble() * gameWidth,
                            random.nextDouble() * gameHeight);
        
        if (score >= 500 * level) {
          gameOver = true;
        }
      }
      
      playerPos = Offset(
        playerPos.dx.clamp(playerSize/2, gameWidth - playerSize/2),
        playerPos.dy.clamp(playerSize/2, gameHeight - playerSize/2),
      );
      
      if (sanity <= 30) {
        health = max(0, (health - 0.5).toInt());
      }
      
      if (health <= 0) {
        gameLost = true;
      }
    });
  }

  void _updateMonsterAI() {
    if (gameOver || gameLost) return;
    
    double distToPlayer = (monsterPos - playerPos).distance;
    
    if (distToPlayer < monsterChaseDistance) {
      double angle = atan2(playerPos.dy - monsterPos.dy,
                          playerPos.dx - monsterPos.dx);
      
      setState(() {
        monsterPos = Offset(
          monsterPos.dx + cos(angle) * monsterSpeed,
          monsterPos.dy + sin(angle) * monsterSpeed,
        );
      });
    } else {
      setState(() {
        monsterPos = Offset(
          monsterPos.dx + (random.nextDouble() - 0.5) * 10,
          monsterPos.dy + (random.nextDouble() - 0.5) * 10,
        );
      });
    }
    
    monsterPos = Offset(
      monsterPos.dx.clamp(monsterSize/2, gameWidth - monsterSize/2),
      monsterPos.dy.clamp(monsterSize/2, gameHeight - monsterSize/2),
    );
  }

  void _movePlayer(Offset delta) {
    setState(() {
      playerPos = playerPos + delta;
      playerPos = Offset(
        playerPos.dx.clamp(playerSize/2, gameWidth - playerSize/2),
        playerPos.dy.clamp(playerSize/2, gameHeight - playerSize/2),
      );
    });
  }

  @override
  void dispose() {
    gameTimer.cancel();
    monsterAITimer.cancel();
    _pulseController.dispose();
    _monsterController.dispose();
    _bloodController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildStatusBar(),
          Expanded(
            child: _buildGameArea(),
          ),
          _buildControls(),
        ],
      ),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      leading: IconButton(
        icon: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: primaryColor.withOpacity(0.3)),
          ),
          child: const Icon(Icons.arrow_back_ios_new, color: Color(0xFFCE93D8), size: 16),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: const Icon(Icons.nights_stay_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentColor, primaryColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              'NIGHT SURVIVAL',
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
      centerTitle: true,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryColor, accentColor],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 14),
              const SizedBox(width: 4),
              Text(
                'LVL $level',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ─── STATUS BAR ──────────────────────────────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      color: surfaceColor,
      padding: const EdgeInsets.all(12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatusItem(
            icon: Icons.favorite_rounded,
            label: 'HEALTH',
            value: health,
            color: dangerColor,
            iconColor: dangerColor,
          ),
          _buildStatusItem(
            icon: Icons.visibility_rounded,
            label: 'SANITY',
            value: sanity,
            color: accentColor,
            iconColor: accentColor,
          ),
          _buildStatusItem(
            icon: Icons.star_rounded,
            label: 'SCORE',
            value: score,
            color: warningColor,
            iconColor: warningColor,
            isScore: true,
          ),
        ],
      ),
    );
  }

  Widget _buildStatusItem({
    required IconData icon,
    required String label,
    required int value,
    required Color color,
    required Color iconColor,
    bool isScore = false,
  }) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: iconColor, size: 14),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  color: textMuted,
                  fontSize: 8,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          if (!isScore) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: value / 100,
                minHeight: 4,
                backgroundColor: cardColor,
                valueColor: AlwaysStoppedAnimation<Color>(
                  value > 30 ? color : dangerColor,
                ),
              ),
            ),
            Text(
              '$value%',
              style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ] else ...[
            Text(
              '$value',
              style: TextStyle(
                color: color,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── GAME AREA ────────────────────────────────────────────────────────────
  Widget _buildGameArea() {
    return Container(
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF0D0015),
            const Color(0xFF080012),
          ],
        ),
        border: Border.all(
          color: showWarning 
              ? dangerColor.withOpacity(0.3) 
              : primaryColor.withOpacity(0.1),
          width: showWarning ? 2 : 1,
        ),
        boxShadow: [
          if (showWarning)
            BoxShadow(
              color: dangerColor.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 5,
            ),
        ],
      ),
      child: Stack(
        children: [
          // ─── FOG EFFECT ─────────────────────────────────────────────
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                radius: 0.8,
                colors: [
                  Colors.transparent,
                  const Color(0xFF080012).withOpacity(0.7),
                ],
              ),
            ),
          ),
          
          // ─── GRID PATTERN ────────────────────────────────────────────
          CustomPaint(
            painter: _GridPainter(),
            size: Size.infinite,
          ),
          
          // ─── GLOW ORB ──────────────────────────────────────────────
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.06),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.04),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          
          // ─── HEARTBEAT WARNING ──────────────────────────────────────
          if (showWarning)
            ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 1.03).animate(
                CurvedAnimation(
                  parent: _pulseController,
                  curve: Curves.easeInOut,
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: dangerColor.withOpacity(0.15),
                    width: 2,
                  ),
                ),
              ),
            ),
          
          // ─── TREASURE ──────────────────────────────────────────────
          Positioned(
            left: treasurePos.dx - treasureSize/2,
            top: treasurePos.dy - treasureSize/2,
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 1.15).animate(
                CurvedAnimation(
                  parent: _pulseController,
                  curve: Curves.easeInOut,
                ),
              ),
              child: Container(
                width: treasureSize,
                height: treasureSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [warningColor, Colors.orange.shade700],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: warningColor.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: const Center(
                  child: Text(
                    '💎',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ),
          ),
          
          // ─── MONSTER ────────────────────────────────────────────────
          Positioned(
            left: monsterPos.dx - monsterSize/2,
            top: monsterPos.dy - monsterSize/2,
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 1.06).animate(
                CurvedAnimation(
                  parent: _monsterController,
                  curve: Curves.easeInOut,
                ),
              ),
              child: Container(
                width: monsterSize,
                height: monsterSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF1A0000),
                      Colors.red.shade900,
                    ],
                  ),
                  border: Border.all(
                    color: dangerColor.withOpacity(0.2),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: dangerColor.withOpacity(0.15),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Center(
                  child: Text(
                    '👿',
                    style: TextStyle(fontSize: 28),
                  ),
                ),
              ),
            ),
          ),
          
          // ─── PLAYER ──────────────────────────────────────────────────
          Positioned(
            left: playerPos.dx - playerSize/2,
            top: playerPos.dy - playerSize/2,
            child: Container(
              width: playerSize,
              height: playerSize,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [accentColor.withOpacity(0.8), primaryColor.withOpacity(0.8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.15),
                    blurRadius: 12,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: const Center(
                child: Text(
                  '🧑',
                  style: TextStyle(fontSize: 24),
                ),
              ),
            ),
          ),
          
          // ─── BLOOD EFFECT ──────────────────────────────────────────
          if (_bloodController.isAnimating)
            Positioned.fill(
              child: FadeTransition(
                opacity: Tween<double>(begin: 0.2, end: 0.0)
                  .animate(_bloodController),
                child: Container(
                  color: dangerColor.withOpacity(0.15),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ─── CONTROLS ─────────────────────────────────────────────────────────────
  Widget _buildControls() {
    return Container(
      color: surfaceColor,
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          if (!gameOver && !gameLost) ...[
            Text(
              '👆 GESER UNTUK BERGERAK',
              style: TextStyle(
                color: textMuted.withOpacity(0.3),
                fontSize: 8,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 6),
            GestureDetector(
              onPanUpdate: (details) {
                _movePlayer(details.delta);
              },
              child: Container(
                width: double.infinity,
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF0D0015),
                      const Color(0xFF080012),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border.all(
                    color: primaryColor.withOpacity(0.08),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor.withOpacity(0.3), accentColor.withOpacity(0.1)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: accentColor.withOpacity(0.05),
                      ),
                    ),
                    child: Text(
                      '👆 GESER AREA INI',
                      style: TextStyle(
                        color: textMuted.withOpacity(0.3),
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ] else ...[
            _buildGameOverlay(),
          ],
        ],
      ),
    );
  }

  // ─── GAME OVERLAY ─────────────────────────────────────────────────────────
  Widget _buildGameOverlay() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF1A0028),
            const Color(0xFF0D0015),
          ],
        ),
        border: Border.all(
          color: gameOver ? warningColor.withOpacity(0.15) : dangerColor.withOpacity(0.15),
          width: 1.5,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(
            gameOver ? '🎉 LEVEL SELESAI!' : '💀 GAME OVER',
            style: TextStyle(
              color: gameOver ? warningColor : dangerColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildResultItem('⭐ Score', '$score', warningColor),
              const SizedBox(width: 16),
              _buildResultItem('❤️ Health', '$health%', successColor),
              const SizedBox(width: 16),
              _buildResultItem('🌙 Level', '$level', accentColor),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    gameTimer.cancel();
                    monsterAITimer.cancel();
                    _pulseController.dispose();
                    _monsterController.dispose();
                    _bloodController.dispose();
                    setState(_initGame);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: const Text(
                    'MAIN LAGI',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                      fontSize: 10,
                    ),
                  ),
                ),
              ),
              if (gameOver) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      gameTimer.cancel();
                      monsterAITimer.cancel();
                      _pulseController.dispose();
                      _monsterController.dispose();
                      _bloodController.dispose();
                      level++;
                      monsterSpeed += 0.5;
                      setState(_initGame);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: warningColor,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'NEXT →',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResultItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            color: textMuted.withOpacity(0.5),
            fontSize: 8,
            fontWeight: FontWeight.w600,
            fontFamily: 'Orbitron',
            letterSpacing: 0.5,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }
}

// ─── GRID PAINTER ───────────────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.5;

    final spacing = 30.0;

    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}