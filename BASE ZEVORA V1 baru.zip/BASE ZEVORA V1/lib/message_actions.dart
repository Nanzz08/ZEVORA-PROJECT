import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// WhatsApp-style message actions
enum MsgAction { reply, react, forward, copy, deleteMe, deleteEveryone, info, star }

const kWaReactions = ['👍', '❤️', '😂', '😮', '😢', '🙏', '🔥', '🎉'];

class MessageActionResult {
  final MsgAction action;
  final String? emoji;
  MessageActionResult(this.action, {this.emoji});
}

/// Bottom sheet like WhatsApp long-press menu
Future<MessageActionResult?> showMessageActionsSheet({
  required BuildContext context,
  required bool isMe,
  required String previewText,
  bool canDeleteEveryone = true,
}) {
  return showModalBottomSheet<MessageActionResult>(
    context: context,
    backgroundColor: const Color(0xFF1F2C34),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (ctx) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            // Quick reactions row
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: kWaReactions.map((e) {
                  return InkWell(
                    onTap: () => Navigator.pop(
                      ctx,
                      MessageActionResult(MsgAction.react, emoji: e),
                    ),
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: 40,
                      height: 40,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        shape: BoxShape.circle,
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 22)),
                    ),
                  );
                }).toList(),
              ),
            ),
            const Divider(color: Colors.white12, height: 1),
            // Preview
            if (previewText.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    previewText.length > 80
                        ? '${previewText.substring(0, 80)}…'
                        : previewText,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.55),
                      fontSize: 13,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ),
            _tile(ctx, Icons.reply, 'Balas', MsgAction.reply),
            _tile(ctx, Icons.content_copy, 'Salin', MsgAction.copy),
            _tile(ctx, Icons.shortcut, 'Teruskan', MsgAction.forward),
            _tile(ctx, Icons.star_border, 'Bintang', MsgAction.star),
            _tile(ctx, Icons.info_outline, 'Info', MsgAction.info),
            if (isMe) ...[
              _tile(ctx, Icons.delete_outline, 'Hapus untuk saya',
                  MsgAction.deleteMe, color: Colors.redAccent),
              if (canDeleteEveryone)
                _tile(ctx, Icons.delete_forever, 'Hapus untuk semua',
                    MsgAction.deleteEveryone, color: Colors.redAccent),
            ] else
              _tile(ctx, Icons.delete_outline, 'Hapus untuk saya',
                  MsgAction.deleteMe, color: Colors.redAccent),
            const SizedBox(height: 8),
          ],
        ),
      );
    },
  );
}

Widget _tile(
  BuildContext ctx,
  IconData icon,
  String label,
  MsgAction action, {
  Color color = Colors.white,
}) {
  return ListTile(
    leading: Icon(icon, color: color, size: 22),
    title: Text(label, style: TextStyle(color: color, fontSize: 15)),
    onTap: () => Navigator.pop(ctx, MessageActionResult(action)),
    dense: true,
  );
}

/// Reply quote bar above input
class ReplyBar extends StatelessWidget {
  final String author;
  final String preview;
  final VoidCallback onClose;
  final Color accent;

  const ReplyBar({
    super.key,
    required this.author,
    required this.preview,
    required this.onClose,
    this.accent = const Color(0xFF25D366),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2C34),
        borderRadius: BorderRadius.circular(12),
        border: Border(
          left: BorderSide(color: accent, width: 3),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  author,
                  style: TextStyle(
                    color: accent,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  preview,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.65),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, color: Colors.white54, size: 18),
            onPressed: onClose,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
          ),
        ],
      ),
    );
  }
}

/// Small reaction chips under bubble
class ReactionChips extends StatelessWidget {
  final Map<String, int> reactions;
  final VoidCallback? onTap;

  const ReactionChips({super.key, required this.reactions, this.onTap});

  @override
  Widget build(BuildContext context) {
    if (reactions.isEmpty) return const SizedBox.shrink();
    final entries = reactions.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(top: 4),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2C34),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: entries.take(4).map((e) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Text(
                e.value > 1 ? '${e.key}${e.value}' : e.key,
                style: const TextStyle(fontSize: 12),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

/// Quoted reply inside bubble
class QuotedReply extends StatelessWidget {
  final String author;
  final String text;
  final Color accent;

  const QuotedReply({
    super.key,
    required this.author,
    required this.text,
    this.accent = const Color(0xFF25D366),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.25),
        borderRadius: BorderRadius.circular(8),
        border: Border(left: BorderSide(color: accent, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            author,
            style: TextStyle(
              color: accent,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            text,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

/// Local persistence for reactions / deleted / starred
class MessageLocalStore {
  static Future<Map<String, Map<String, int>>> loadReactions(String room) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('msg_react_$room');
    if (raw == null) return {};
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return map.map((k, v) => MapEntry(
            k,
            Map<String, int>.from(
              (v as Map).map((kk, vv) => MapEntry(kk.toString(), (vv as num).toInt())),
            ),
          ));
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveReactions(
      String room, Map<String, Map<String, int>> data) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('msg_react_$room', jsonEncode(data));
  }

  static Future<Set<String>> loadDeleted(String room) async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('msg_del_$room') ?? []).toSet();
  }

  static Future<void> saveDeleted(String room, Set<String> ids) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('msg_del_$room', ids.toList());
  }

  static Future<Set<String>> loadStarred(String room) async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('msg_star_$room') ?? []).toSet();
  }

  static Future<void> saveStarred(String room, Set<String> ids) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('msg_star_$room', ids.toList());
  }
}

/// Forward picker sheet (simple list of targets)
Future<String?> showForwardSheet(BuildContext context, List<String> targets) {
  return showModalBottomSheet<String>(
    context: context,
    backgroundColor: const Color(0xFF1F2C34),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (ctx) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Teruskan ke',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            if (targets.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Tidak ada target',
                    style: TextStyle(color: Colors.white54)),
              )
            else
              ...targets.map(
                (t) => ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFF25D366),
                    child: Text(
                      t.isNotEmpty ? t[0].toUpperCase() : '?',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  title: Text(t, style: const TextStyle(color: Colors.white)),
                  onTap: () => Navigator.pop(ctx, t),
                ),
              ),
            const SizedBox(height: 12),
          ],
        ),
      );
    },
  );
}

void copyToClipboard(BuildContext context, String text) {
  if (text.isEmpty) return;
  Clipboard.setData(ClipboardData(text: text));
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('Pesan disalin'),
      behavior: SnackBarBehavior.floating,
      duration: Duration(seconds: 1),
    ),
  );
}
