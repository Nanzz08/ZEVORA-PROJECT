import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'welcome.dart';
import 'glass_kit.dart';

/// Fingerprint unlock — layout mirip foto referensi + tema hitam-merah + animasi scan kece.
class FingerprintPage extends StatefulWidget {
  const FingerprintPage({super.key});

  @override
  State<FingerprintPage> createState() => _FingerprintPageState();
}

class _FingerprintPageState extends State<FingerprintPage>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _isHolding = false;
  bool _isSuccess = false;
  int _lastHapticPct = 0;
  final AudioPlayer _sfxPress = AudioPlayer();
  final AudioPlayer _sfxTick = AudioPlayer();
  final AudioPlayer _sfxSuccess = AudioPlayer();
  Timer? _holdTimer;
  Timer? _clockTimer;
  DateTime _now = DateTime.now();
  String _tz = 'WIB';

  late AnimationController _pulseCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _successCtrl;
  late AnimationController _holdCtrl;
  late AnimationController _rippleCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _burstCtrl;
  late AnimationController _ringSpinCtrl;

  late Animation<double> _successScale;
  late Animation<double> _successFade;
  late Animation<double> _holdScale;

  static const _bg = Color(0xFF080D18);
  static const _red = Color(0xFF6C8CFF);
  static const _redBright = Color(0xFF9AB5FF);
  static const _redDim = Color(0xFF172A55);
  static const _redSoft = Color(0xFF111D34);
  static const _text = Color(0xFFF4F7FF);
  static const _textSub = Color(0xFFAAB8D2);

  static const _days = [
    'SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU', 'MINGGU'
  ];
  static const _months = [
    'JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI',
    'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER'
  ];

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: _bg,
      systemNavigationBarIconBrightness: Brightness.light,
    ));

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat(reverse: true);
    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 10))..repeat();

    _successCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _successScale = Tween<double>(begin: 0.6, end: 1.0).animate(CurvedAnimation(parent: _successCtrl, curve: Curves.elasticOut));
    _successFade = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _successCtrl, curve: Curves.easeOut));

    _holdCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 180));
    _holdScale = Tween<double>(begin: 1.0, end: 0.92).animate(CurvedAnimation(parent: _holdCtrl, curve: Curves.easeOut));

    _rippleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));
    _particleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _burstCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _ringSpinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _clockTimer?.cancel();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    _orbitCtrl.dispose();
    _successCtrl.dispose();
    _holdCtrl.dispose();
    _rippleCtrl.dispose();
    _scanCtrl.dispose();
    _particleCtrl.dispose();
    _burstCtrl.dispose();
    _ringSpinCtrl.dispose();
    _sfxPress.dispose();
    _sfxTick.dispose();
    _sfxSuccess.dispose();
    super.dispose();
  }

  DateTime get _tzNow {
    // WIB = UTC+7, WITA = UTC+8, WIT = UTC+9
    final utc = DateTime.now().toUtc();
    final offsetHours = switch (_tz) {
      'WITA' => 8,
      'WIT' => 9,
      _ => 7, // WIB default
    };
    return utc.add(Duration(hours: offsetHours));
  }

  String get _timeStr {
    final t = _tzNow;
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    final s = t.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  String get _dayName => _days[(_tzNow.weekday - 1) % 7];
  String get _monthName => _months[_tzNow.month - 1];
  int get _dayNum => _tzNow.day;
  int get _year => _tzNow.year;

  Future<void> _playSfx(AudioPlayer player, String asset) async {
    try {
      await player.stop();
      await player.play(AssetSource(asset.startsWith('assets/') ? asset.substring(7) : asset));
    } catch (_) {
      SystemSound.play(SystemSoundType.click);
    }
  }

  void _startHold() {
    if (_isSuccess) return;
    setState(() => _isHolding = true);
    HapticFeedback.mediumImpact();
    _playSfx(_sfxPress, 'sounds/fp_press.wav');
    _holdCtrl.forward();
    _rippleCtrl.repeat();
    _scanCtrl.repeat();
    _particleCtrl.repeat();
    _orbitCtrl.duration = const Duration(milliseconds: 2400);
    _orbitCtrl.repeat();

    _holdTimer?.cancel();
    _holdTimer = Timer.periodic(const Duration(milliseconds: 28), (timer) {
      if (!_isHolding || _isSuccess) { timer.cancel(); return; }
      setState(() => _progress = (_progress + 0.014).clamp(0.0, 1.0));
      final pct = (_progress * 100).round();
      if (pct >= _lastHapticPct + 10) {
        _lastHapticPct = pct;
        HapticFeedback.selectionClick();
        _playSfx(_sfxTick, 'sounds/fp_tick.wav');
      }
      if (_progress >= 1.0) { timer.cancel(); _onSuccess(); }
    });
  }

  void _stopHold() {
    if (_isSuccess) return;
    setState(() => _isHolding = false);
    _holdCtrl.reverse();
    _rippleCtrl.stop(); _rippleCtrl.reset();
    _scanCtrl.stop(); _scanCtrl.reset();
    _particleCtrl.stop(); _particleCtrl.reset();
    _orbitCtrl.duration = const Duration(seconds: 10);
    _orbitCtrl.repeat();
    _holdTimer?.cancel();

    if (_progress < 1.0) {
      _holdTimer = Timer.periodic(const Duration(milliseconds: 24), (timer) {
        if (_isHolding || _isSuccess) { timer.cancel(); return; }
        setState(() => _progress = (_progress - 0.022).clamp(0.0, 1.0));
        if (_progress <= 0.0) { timer.cancel(); _lastHapticPct = 0; }
      });
    }
  }

  void _onSuccess() {
    setState(() { _isSuccess = true; _isHolding = false; _progress = 1.0; });
    HapticFeedback.heavyImpact();
    _playSfx(_sfxSuccess, 'sounds/fp_success.wav');
    _holdCtrl.reverse();
    _rippleCtrl.stop(); _scanCtrl.stop(); _particleCtrl.stop();
    _successCtrl.forward();
    _burstCtrl.forward(from: 0);

    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const WelcomePage(),
          transitionDuration: const Duration(milliseconds: 550),
          transitionsBuilder: (_, anim, __, child) {
            return FadeTransition(
              opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
              child: ScaleTransition(
                scale: Tween<double>(begin: 1.05, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
                child: child,
              ),
            );
          },
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(
            painter: _GridPainter(color: _red.withOpacity(0.06), accent: _red.withOpacity(0.12)),
            size: Size.infinite,
          ),
          AnimatedBuilder(
            animation: Listenable.merge([_glowCtrl, _holdCtrl]),
            builder: (_, __) {
              final intensity = _isHolding ? 0.40 + _progress * 0.50 : 0.15 + _glowCtrl.value * 0.12;
              return DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, 0.25),
                    radius: 1.15,
                    colors: [
                      _red.withOpacity(intensity * 0.45),
                      _redDim.withOpacity(intensity * 0.22),
                      _bg,
                    ],
                  ),
                ),
              );
            },
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 28),
                Text(
                  _timeStr,
                  style: TextStyle(
                    color: _redBright, fontSize: 52, fontWeight: FontWeight.w300, letterSpacing: 6, height: 1.0,
                    shadows: [Shadow(color: _red.withOpacity(0.42), blurRadius: 22)],
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(width: 36, height: 1, color: _red.withOpacity(0.35)),
                    const SizedBox(width: 12),
                    Text(_dayName, style: TextStyle(color: _textSub, fontSize: 12, letterSpacing: 4, fontWeight: FontWeight.w500)),
                    const SizedBox(width: 12),
                    Container(width: 36, height: 1, color: _red.withOpacity(0.35)),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text('$_dayNum', style: TextStyle(color: _redBright, fontSize: 42, fontWeight: FontWeight.w300, height: 1, shadows: [Shadow(color: _red.withOpacity(0.5), blurRadius: 12)])),
                    const SizedBox(width: 10),
                    Text(_monthName, style: const TextStyle(color: _text, fontSize: 16, fontWeight: FontWeight.w500, letterSpacing: 2)),
                  ],
                ),
                const SizedBox(height: 6),
                Text('$_year', style: TextStyle(color: _textSub.withOpacity(0.7), fontSize: 13, letterSpacing: 3)),
                const SizedBox(height: 18),
                GlassPanel(
                  radius: 24,
                  blur: 12,
                  opacity: .07,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _TzPill(label: 'WIB', selected: _tz == 'WIB', onTap: () => setState(() => _tz = 'WIB')),
                      const SizedBox(width: 10),
                      _TzPill(label: 'WITA', selected: _tz == 'WITA', onTap: () => setState(() => _tz = 'WITA')),
                      const SizedBox(width: 10),
                      _TzPill(label: 'WIT', selected: _tz == 'WIT', onTap: () => setState(() => _tz = 'WIT')),
                    ],
                  ),
                ),
                const Spacer(flex: 2),
                GestureDetector(
                  onTapDown: (_) => _startHold(),
                  onTapUp: (_) => _stopHold(),
                  onTapCancel: _stopHold,
                  onLongPressStart: (_) => _startHold(),
                  onLongPressEnd: (_) => _stopHold(),
                  child: AnimatedBuilder(
                    animation: Listenable.merge([_pulseCtrl, _glowCtrl, _orbitCtrl, _successCtrl, _holdCtrl, _rippleCtrl, _scanCtrl, _particleCtrl, _burstCtrl, _ringSpinCtrl]),
                    builder: (context, _) {
                      final scale = _isSuccess ? _successScale.value : _holdScale.value;
                      final ringGlow = _isHolding ? 0.55 + _progress * 0.45 : 0.25 + _pulseCtrl.value * 0.2;
                      return Transform.scale(
                        scale: scale,
                        child: SizedBox(
                          width: 220, height: 220,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              if (_isHolding && !_isSuccess)
                                ...List.generate(3, (i) {
                                  final t = (_rippleCtrl.value + i * 0.33) % 1.0;
                                  return Container(
                                    width: 120 + t * 100, height: 120 + t * 100,
                                    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _red.withOpacity((1 - t) * 0.45), width: 1.5)),
                                  );
                                }),
                              if (_isSuccess)
                                ...List.generate(3, (i) {
                                  final t = (_burstCtrl.value - i * 0.15).clamp(0.0, 1.0);
                                  return Opacity(opacity: (1 - t) * 0.7, child: Container(
                                    width: 100 + t * 140, height: 100 + t * 140,
                                    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _redBright.withOpacity(0.6), width: 2)),
                                  ));
                                }),
                              Transform.rotate(
                                angle: _ringSpinCtrl.value * math.pi * 2,
                                child: CustomPaint(size: const Size(210, 210), painter: _DashedRingPainter(color: _red.withOpacity(0.35 + ringGlow * 0.3), strokeWidth: 1.5, dashCount: 36)),
                              ),
                              SizedBox(
                                width: 190, height: 190,
                                child: CircularProgressIndicator(
                                  value: _isSuccess ? 1.0 : (_isHolding ? _progress : null),
                                  strokeWidth: 3.5,
                                  backgroundColor: _red.withOpacity(0.12),
                                  valueColor: AlwaysStoppedAnimation(_isSuccess ? Colors.greenAccent : _redBright),
                                ),
                              ),
                              CustomPaint(size: const Size(200, 200), painter: _CornerBracketsPainter(color: _redBright.withOpacity(0.7 + ringGlow * 0.3))),
                              Container(
                                width: 140, height: 140,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                                    colors: [const Color(0xFF243653).withOpacity(.92), const Color(0xFF0D1729).withOpacity(.98)],
                                  ),
                                  border: Border.all(color: (_isSuccess ? const Color(0xFF65E6B2) : Colors.white).withOpacity(_isSuccess ? .82 : .30), width: 1.6),
                                  boxShadow: [
                                    BoxShadow(color: (_isSuccess ? const Color(0xFF65E6B2) : _red).withOpacity(0.22 + ringGlow * 0.28), blurRadius: 34, spreadRadius: 2),
                                    const BoxShadow(color: Colors.black54, blurRadius: 22, offset: Offset(0, 12)),
                                  ],
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    if (_isHolding && !_isSuccess)
                                      ClipOval(
                                        child: Align(
                                          alignment: Alignment(0, -1 + _scanCtrl.value * 2),
                                          child: Container(
                                            width: 140, height: 4,
                                            decoration: BoxDecoration(
                                              gradient: LinearGradient(colors: [Colors.transparent, _redBright.withOpacity(0.9), Colors.transparent]),
                                              boxShadow: [BoxShadow(color: _redBright.withOpacity(0.8), blurRadius: 12, spreadRadius: 2)],
                                            ),
                                          ),
                                        ),
                                      ),
                                    Icon(Icons.fingerprint, size: 64, color: _isSuccess ? Colors.greenAccent : _redBright.withOpacity(0.75 + ringGlow * 0.25)),
                                    if (_isSuccess)
                                      FadeTransition(
                                        opacity: _successFade,
                                        child: Container(
                                          width: 140, height: 140,
                                          decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.greenAccent.withOpacity(0.15)),
                                          child: const Icon(Icons.check_rounded, size: 56, color: Colors.greenAccent),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (_isHolding && !_isSuccess)
                                ...List.generate(8, (i) {
                                  final angle = (i / 8) * math.pi * 2 + _particleCtrl.value * math.pi * 2;
                                  final r = 85 + math.sin(_particleCtrl.value * math.pi * 2 + i) * 12;
                                  return Positioned(
                                    left: 110 + math.cos(angle) * r - 3,
                                    top: 110 + math.sin(angle) * r - 3,
                                    child: Container(
                                      width: 6, height: 6,
                                      decoration: BoxDecoration(shape: BoxShape.circle, color: _redBright.withOpacity(0.7), boxShadow: [BoxShadow(color: _redBright.withOpacity(0.5), blurRadius: 6)]),
                                    ),
                                  );
                                }),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 28),
                Text(
                  _isSuccess ? 'BERHASIL' : 'VERIFIKASI KEAMANAN',
                  style: TextStyle(color: _isSuccess ? Colors.greenAccent : _text, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 3),
                ),
                const SizedBox(height: 8),
                Text(
                  _isSuccess ? 'Membuka aplikasi...' : (_isHolding ? 'Memindai... ${(_progress * 100).round()}%' : 'SENTUH SIDIK JARI ANDA UNTUK MELANJUTKAN'),
                  style: TextStyle(color: _textSub.withOpacity(0.85), fontSize: 11, letterSpacing: 1.2),
                  textAlign: TextAlign.center,
                ),
                const Spacer(flex: 2),
                CustomPaint(size: const Size(56, 56), painter: _HexLockPainter(color: _red.withOpacity(0.7), fillColor: _redSoft)),
                const SizedBox(height: 12),
                Container(
                  width: 120, height: 3,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    gradient: LinearGradient(colors: [Colors.transparent, _red.withOpacity(0.8), Colors.transparent]),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TzPill extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _TzPill({required this.label, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF7898FF).withOpacity(0.18) : const Color(0xFF172238).withOpacity(0.72),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? const Color(0xFF9AB5FF).withOpacity(.9) : Colors.white.withOpacity(.16), width: selected ? 1.4 : 1),
        ),
        child: Text(label, style: TextStyle(color: selected ? const Color(0xFFB9CCFF) : const Color(0xFFAAB8D2), fontSize: 12, fontWeight: selected ? FontWeight.w700 : FontWeight.w500, letterSpacing: 1)),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final Color color;
  final Color accent;
  _GridPainter({required this.color, required this.accent});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..strokeWidth = 0.8..style = PaintingStyle.stroke;
    const step = 48.0;
    for (double x = 0; x < size.width; x += step) canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += step) canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    final accentPaint = Paint()..color = accent..strokeWidth = 1.2..style = PaintingStyle.stroke;
    canvas.drawLine(const Offset(0, 80), const Offset(120, 0), accentPaint);
    canvas.drawLine(Offset(size.width, 60), Offset(size.width - 100, 0), accentPaint);
    canvas.drawLine(Offset(0, size.height - 100), Offset(80, size.height), accentPaint);
    canvas.drawLine(Offset(size.width, size.height - 80), Offset(size.width - 90, size.height), accentPaint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DashedRingPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final int dashCount;
  _DashedRingPainter({required this.color, this.strokeWidth = 1.5, this.dashCount = 32});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..strokeWidth = strokeWidth..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - strokeWidth;
    final sweep = (math.pi * 2) / dashCount;
    for (int i = 0; i < dashCount; i++) {
      if (i % 2 == 0) continue;
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), i * sweep, sweep * 0.7, false, paint);
    }
  }
  @override
  bool shouldRepaint(covariant _DashedRingPainter old) => old.color != color;
}

class _CornerBracketsPainter extends CustomPainter {
  final Color color;
  _CornerBracketsPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..strokeWidth = 2.2..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    const len = 22.0;
    final w = size.width; final h = size.height;
    canvas.drawLine(const Offset(0, len), const Offset(0, 0), paint);
    canvas.drawLine(const Offset(0, 0), const Offset(len, 0), paint);
    canvas.drawLine(Offset(w - len, 0), Offset(w, 0), paint);
    canvas.drawLine(Offset(w, 0), Offset(w, len), paint);
    canvas.drawLine(Offset(0, h - len), Offset(0, h), paint);
    canvas.drawLine(Offset(0, h), Offset(len, h), paint);
    canvas.drawLine(Offset(w - len, h), Offset(w, h), paint);
    canvas.drawLine(Offset(w, h), Offset(w, h - len), paint);
  }
  @override
  bool shouldRepaint(covariant _CornerBracketsPainter old) => old.color != color;
}

class _HexLockPainter extends CustomPainter {
  final Color color;
  final Color fillColor;
  _HexLockPainter({required this.color, required this.fillColor});
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2; final cy = size.height / 2; final r = size.width / 2 - 2;
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = (math.pi / 3) * i - math.pi / 2;
      final x = cx + r * math.cos(angle); final y = cy + r * math.sin(angle);
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = fillColor..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.8);
    final lockPaint = Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.6..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCenter(center: Offset(cx, cy - 4), width: 12, height: 12), math.pi, math.pi, false, lockPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy + 5), width: 16, height: 12), const Radius.circular(2)), Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.6);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
