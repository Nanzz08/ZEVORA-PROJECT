import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class _PortColors {
  static const bg = Color(0xFF080808);
  static const card = Color(0xFF111111);
  static const inner = Color(0xFF171717);
  static const border = Color(0xFF321818);
  static const red = Color(0xFFEF233C);
  static const redDark = Color(0xFF7F1D1D);
  static const green = Color(0xFF22C55E);
  static const amber = Color(0xFFF59E0B);
  static const text = Color(0xFFF5F5F5);
  static const sub = Color(0xFFA1A1AA);
}

class PortInfo {
  final int port;
  final String service;
  final bool isOpen;
  final String status;

  const PortInfo({
    required this.port,
    required this.service,
    required this.isOpen,
    required this.status,
  });
}

class PortScannerPage extends StatefulWidget {
  const PortScannerPage({super.key});

  @override
  State<PortScannerPage> createState() => _PortScannerPageState();
}

class _PortScannerPageState extends State<PortScannerPage>
    with SingleTickerProviderStateMixin {
  final _controller = TextEditingController(text: '192.168.1.1');
  final _formKey = GlobalKey<FormState>();
  late final AnimationController _bgController;

  bool _scanning = false;
  String? _error;
  String? _target;
  List<PortInfo> _results = const [];

  // Common TCP services. Scanning is intentionally limited to loopback/private
  // IPv4 addresses so the utility is useful for networks you control.
  static const _ports = <Map<String, Object>>[
    {'port': 21, 'service': 'FTP'},
    {'port': 22, 'service': 'SSH'},
    {'port': 23, 'service': 'Telnet'},
    {'port': 25, 'service': 'SMTP'},
    {'port': 53, 'service': 'DNS'},
    {'port': 80, 'service': 'HTTP'},
    {'port': 110, 'service': 'POP3'},
    {'port': 143, 'service': 'IMAP'},
    {'port': 443, 'service': 'HTTPS'},
    {'port': 445, 'service': 'SMB'},
    {'port': 3306, 'service': 'MySQL'},
    {'port': 3389, 'service': 'RDP'},
    {'port': 5432, 'service': 'PostgreSQL'},
    {'port': 6379, 'service': 'Redis'},
    {'port': 27017, 'service': 'MongoDB'},
  ];

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _controller.dispose();
    super.dispose();
  }

  bool _isIPv4(String value) {
    final parts = value.split('.');
    if (parts.length != 4) return false;
    for (final part in parts) {
      final n = int.tryParse(part);
      if (n == null || n < 0 || n > 255) return false;
    }
    return true;
  }

  bool _isAllowedTarget(String ip) {
    if (!_isIPv4(ip)) return false;
    final p = ip.split('.').map(int.parse).toList();
    final is10 = p[0] == 10;
    final is172 = p[0] == 172 && p[1] >= 16 && p[1] <= 31;
    final is192 = p[0] == 192 && p[1] == 168;
    final is127 = p[0] == 127;
    final is169 = p[0] == 169 && p[1] == 254;
    return is10 || is172 || is192 || is127 || is169;
  }

  String _serviceFor(int port) {
    for (final item in _ports) {
      if (item['port'] == port) return item['service'] as String;
    }
    return 'TCP';
  }

  Future<bool> _isPortOpen(String ip, int port) async {
    Socket? socket;
    try {
      socket = await Socket.connect(
        ip,
        port,
        timeout: const Duration(milliseconds: 700),
      );
      return true;
    } on SocketException {
      return false;
    } on OSError {
      return false;
    } finally {
      socket?.destroy();
    }
  }

  Future<void> _scan() async {
    if (!_formKey.currentState!.validate()) return;
    final ip = _controller.text.trim();

    setState(() {
      _scanning = true;
      _error = null;
      _results = const [];
      _target = ip;
    });

    final results = <PortInfo>[];
    try {
      // Sequential, low-rate checks avoid creating a burst of connections.
      for (final item in _ports) {
        if (!mounted) return;
        final port = item['port'] as int;
        final service = item['service'] as String;
        final open = await _isPortOpen(ip, port);
        results.add(PortInfo(
          port: port,
          service: service,
          isOpen: open,
          status: open ? 'OPEN' : 'CLOSED / FILTERED',
        ));
        if (mounted) setState(() => _results = List.unmodifiable(results));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Gagal melakukan pemeriksaan koneksi: $e');
      }
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Target disalin'),
      behavior: SnackBarBehavior.floating,
      duration: Duration(seconds: 1),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final open = _results.where((e) => e.isOpen).length;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgController,
              builder: (_, __) => CustomPaint(
                painter: _GridPainter(_bgController.value),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _header(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        _inputCard(),
                        const SizedBox(height: 14),
                        if (_error != null) _errorCard(),
                        if (_target != null) _resultCard(open),
                        const SizedBox(height: 12),
                        _noticeCard(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: _PortColors.border)),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _PortColors.text, size: 19),
          ),
          const SizedBox(width: 4),
          const Icon(Icons.network_check_rounded, color: _PortColors.red),
          const SizedBox(width: 10),
          const Text(
            'PORT SCANNER',
            style: TextStyle(
              color: _PortColors.text,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
            ),
          ),
          const Spacer(),
          if (_scanning)
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: _PortColors.red,
              ),
            ),
        ],
      ),
    );
  }

  Widget _inputCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _PortColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _PortColors.border),
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Target IP',
                style: TextStyle(color: _PortColors.text, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text(
              'Gunakan alamat loopback atau jaringan private yang kamu kelola.',
              style: TextStyle(color: _PortColors.sub, fontSize: 12),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _controller,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: _PortColors.text),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.dns_rounded, color: _PortColors.red),
                hintText: '192.168.1.1',
                hintStyle: const TextStyle(color: _PortColors.sub),
                filled: true,
                fillColor: _PortColors.inner,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: _PortColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: _PortColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: _PortColors.red),
                ),
              ),
              validator: (value) {
                final ip = value?.trim() ?? '';
                if (!_isIPv4(ip)) return 'Format IPv4 tidak valid';
                if (!_isAllowedTarget(ip)) {
                  return 'Port scanner hanya untuk localhost/private IPv4';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _scanning ? null : _scan,
                icon: const Icon(Icons.radar_rounded),
                label: Text(_scanning ? 'SCANNING...' : 'START PORT SCAN'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _PortColors.red,
                  disabledBackgroundColor: _PortColors.redDark,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: _PortColors.red.withOpacity(.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _PortColors.red.withOpacity(.35)),
      ),
      child: Text(_error!, style: const TextStyle(color: _PortColors.text)),
    );
  }

  Widget _resultCard(int openCount) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _PortColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _PortColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.router_rounded, color: _PortColors.red),
              const SizedBox(width: 10),
              Expanded(
                child: Text('$_target',
                    style: const TextStyle(
                        color: _PortColors.text, fontWeight: FontWeight.w800)),
              ),
              IconButton(
                onPressed: () => _copy(_target!),
                icon: const Icon(Icons.copy_rounded,
                    color: _PortColors.sub, size: 19),
              ),
            ],
          ),
          Text(
            _scanning
                ? 'Memeriksa... $openCount port terbuka ditemukan'
                : '$openCount port terbuka dari ${_results.length} port umum',
            style: TextStyle(
              color: openCount > 0 ? _PortColors.green : _PortColors.sub,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 14),
          const Divider(color: _PortColors.border),
          const SizedBox(height: 8),
          ..._results.map(_portTile),
        ],
      ),
    );
  }

  Widget _portTile(PortInfo info) {
    final color = info.isOpen ? _PortColors.green : _PortColors.sub;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: info.isOpen
            ? _PortColors.green.withOpacity(.07)
            : _PortColors.inner,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: info.isOpen
              ? _PortColors.green.withOpacity(.35)
              : _PortColors.border,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 48,
            child: Text('${info.port}',
                style: TextStyle(color: color, fontWeight: FontWeight.w800)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(info.service,
                    style: const TextStyle(
                        color: _PortColors.text, fontWeight: FontWeight.w600)),
                Text(info.status,
                    style: TextStyle(color: color, fontSize: 10)),
              ],
            ),
          ),
          Icon(
            info.isOpen ? Icons.check_circle_rounded : Icons.remove_circle_outline,
            color: color,
            size: 19,
          ),
        ],
      ),
    );
  }

  Widget _noticeCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _PortColors.inner,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _PortColors.border),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.shield_outlined, color: _PortColors.amber, size: 19),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Scanner melakukan pemeriksaan TCP ringan pada port umum dan hanya menerima localhost/private IPv4. Gunakan hanya pada perangkat atau jaringan yang kamu miliki/diizinkan.',
              style: TextStyle(color: _PortColors.sub, fontSize: 11, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final double t;
  const _GridPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _PortColors.red.withOpacity(.07)
      ..strokeWidth = .5;
    const step = 36.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    final sweep = Paint()
      ..color = _PortColors.red.withOpacity(.04 + .02 * t)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(size.width * t, size.height * .15), 100, sweep);
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) => oldDelegate.t != t;
}
