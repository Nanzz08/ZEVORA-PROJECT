// ============================================================
// 🟣 BUG MENU PAGE — Purple Edition
// File: bug_menu_page.dart
// Menu carousel untuk: Manta Bug, Tes Func, Manage Sender
// ============================================================
import 'package:flutter/material.dart';

import 'home_page.dart';
import 'bug_sender.dart';
import 'spam_pair.dart';

// ═════════════════════════════════════════════════════════════
// ═════════════════════════════════════════════════════════════
// 🎨 PALETTE
// ═════════════════════════════════════════════════════════════
class _PC {
  static const bg          = Color(0xFF080D16);
  static const surface     = Color(0xFF111B29);
  static const card        = Color(0xFF182130);
  static const border      = Color(0xFF26384D);
  static const borderLit   = Color(0xFF38516B);

  static const purple      = Color(0xFF3B82F6);
  static const purpleMid   = Color(0xFF2563EB);
  static const purpleDeep  = Color(0xFF172554);
  static const purpleNeon  = Color(0xFF60A5FA);
  static const purpleSoft  = Color(0xFF93C5FD);
  static const purpleFrost = Color(0xFFDBEAFE);

  static const text        = Color(0xFFFAFAFA);
  static const textSub     = Color(0xFFA1A1AA);
  static const textDim     = Color(0xFF52525B);
}

// ═════════════════════════════════════════════════════════════
// 📦 MENU DATA
// ═════════════════════════════════════════════════════════════
class _MenuData {
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final String badge;
  final List<String> features;
  final VoidCallback onStart;

  const _MenuData({
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.badge,
    required this.features,
    required this.onStart,
  });
}

// ═════════════════════════════════════════════════════════════
// 🚀 BUG MENU PAGE
// ═════════════════════════════════════════════════════════════
class BugMenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final VoidCallback? onBackToDashboard;

  const BugMenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    this.onBackToDashboard,
  });

  @override
  State<BugMenuPage> createState() => _BugMenuPageState();
}

class _BugMenuPageState extends State<BugMenuPage>
    with TickerProviderStateMixin {
  late final PageController _pageCtrl;
  late final AnimationController _bgCtrl;
  int _currentPage = 0;

  late final List<_MenuData> _menus;

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController(viewportFraction: 0.88);
    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _menus = [
      _MenuData(
        title: 'ZEVORA BUG',
        subtitle: 'Number workspace',
        description:
            'Buka workspace utama untuk memilih function dan mengelola pengiriman nomor.',
        icon: Icons.bug_report_rounded,
        badge: 'MAIN WORKSPACE',
        features: const [
          'Number mode',
          'Tools dan payload asli',
        ],
        onStart: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => HomePage(
                username: widget.username,
                password: widget.password,
                sessionKey: widget.sessionKey,
                listBug: widget.listBug,
                listBugGroup: widget.listBugGroup,
                role: widget.role,
                expiredDate: widget.expiredDate,
                initialMode: 'number',
                onBackToDashboard: widget.onBackToDashboard,
              ),
            ),
          );
        },
      ),
      _MenuData(
        title: 'BUG GROUP',
        subtitle: 'Group workspace',
        description:
            'Buka workspace pengelolaan dan pemilihan function khusus grup.',
        icon: Icons.groups_rounded,
        badge: 'GROUP MODE',
        features: const [
          'Group mode',
          'Group list asli',
        ],
        onStart: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => HomePage(
                username: widget.username,
                password: widget.password,
                sessionKey: widget.sessionKey,
                listBug: widget.listBug,
                listBugGroup: widget.listBugGroup,
                role: widget.role,
                expiredDate: widget.expiredDate,
                initialMode: 'group',
                onBackToDashboard: widget.onBackToDashboard,
              ),
            ),
          );
        },
      ),
      _MenuData(
        title: 'TEST FUNCTION',
        subtitle: 'Local function workspace',
        description:
            'Buka tab Test Function yang memang tersedia di HomePage untuk memeriksa function.',
        icon: Icons.code_rounded,
        badge: 'TEST MODE',
        features: const [
          'Test Function tab',
          'Existing validation',
        ],
        onStart: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => HomePage(
                username: widget.username,
                password: widget.password,
                sessionKey: widget.sessionKey,
                listBug: widget.listBug,
                listBugGroup: widget.listBugGroup,
                role: widget.role,
                expiredDate: widget.expiredDate,
                initialMode: 'testfunc',
                onBackToDashboard: widget.onBackToDashboard,
              ),
            ),
          );
        },
      ),
      _MenuData(
        title: 'PAIRING CODE',
        subtitle: 'Device pairing',
        description:
            'Buka halaman pairing yang sudah tersedia untuk membuat kode pairing perangkat.',
        icon: Icons.phonelink_lock_rounded,
        badge: 'PAIRING',
        features: const [
          'Existing pairing flow',
          'Server validation',
        ],
        onStart: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SpamPairPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      ),
      _MenuData(
        title: 'MANAGE SENDER',
        subtitle: 'WhatsApp sender management',
        description:
            'Tambah, hapus, dan pantau sender melalui halaman pengelolaan yang sudah tersedia.',
        icon: Icons.phonelink_setup_rounded,
        badge: 'ESSENTIAL',
        features: const [
          'Private & Global sender',
          'Existing sender API',
        ],
        onStart: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      ),
    ];
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _bgCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _PC.bg,
      body: Stack(
        children: [
          // Background glow
          AnimatedBuilder(
            animation: _bgCtrl,
            builder: (_, __) => CustomPaint(
              painter: _BgPainter(_bgCtrl.value),
              size: Size.infinite,
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                // Top bar
                _buildTopBar(),
                const SizedBox(height: 8),

                // Header section
                _buildHeader(),
                const SizedBox(height: 20),

                // Carousel
                Expanded(
                  child: PageView.builder(
                    controller: _pageCtrl,
                    itemCount: _menus.length,
                    onPageChanged: (i) =>
                        setState(() => _currentPage = i),
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (_, i) => _buildMenuCard(_menus[i], i),
                  ),
                ),

                // Dots indicator
                const SizedBox(height: 14),
                _buildDots(),
                const SizedBox(height: 16),

                // Info bar
                _buildInfoBar(),
                const SizedBox(height: 12),

                // Bottom nav
                _buildBottomNav(),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🔝 TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Material(
            color: _PC.card.withOpacity(.82),
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => Navigator.of(context).maybePop(),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _PC.borderLit, width: 1),
                ),
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  color: _PC.purpleSoft,
                  size: 17,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _PC.purpleSoft.withOpacity(.5)),
              boxShadow: [
                BoxShadow(color: _PC.purple.withOpacity(.22), blurRadius: 16),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/logo.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.shield_rounded,
                  color: _PC.purpleSoft,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ZEVORA PROJECT',
                  style: TextStyle(
                    color: _PC.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                    fontFamily: 'Qaxer',
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  widget.username,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _PC.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: _PC.purple.withOpacity(.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _PC.purpleSoft.withOpacity(.32)),
            ),
            child: const Text(
              'BUG TOOLS',
              style: TextStyle(
                color: _PC.purpleFrost,
                fontSize: 8,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                fontFamily: 'Ready',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📝 HEADER — BUG MENU
  // ═══════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Icon bulat kiri
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_PC.purpleDeep, _PC.purpleMid],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                  color: _PC.purpleSoft.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _PC.purple.withOpacity(0.5),
                  blurRadius: 22,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/logo.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.bolt_rounded,
                  color: Colors.white,
                  size: 32,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BUG MENU',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    height: 1.0,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _PC.purple.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color:
                                _PC.purpleSoft.withOpacity(0.5)),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.circle,
                              color: Color(0xFF22C55E), size: 6),
                          SizedBox(width: 5),
                          Text('ONLINE v2.0',
                              style: TextStyle(
                                  color: _PC.purpleFrost,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _PC.purple.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color:
                                _PC.purpleSoft.withOpacity(0.35)),
                      ),
                      child: const Text('Elegant Edition',
                          style: TextStyle(
                              color: _PC.purpleFrost,
                              fontSize: 8,
                              fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pilih menu yang tersedia bosque!',
                  style: TextStyle(
                    color: _PC.textSub,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🎴 MENU CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildMenuCard(_MenuData menu, int index) {
    final isActive = index == _currentPage;

    return AnimatedBuilder(
      animation: _pageCtrl,
      builder: (context, child) {
        double value = 1.0;
        if (_pageCtrl.position.haveDimensions) {
          value = (_pageCtrl.page! - index);
          value = (1 - (value.abs() * 0.15)).clamp(0.85, 1.0);
        }
        final scale = isActive ? 1.0 : value;

        return Center(
          child: Transform.scale(
            scale: scale,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _PC.purpleDeep.withOpacity(0.85),
                    _PC.card,
                  ],
                ),
                border: Border.all(
                  color: _PC.purpleSoft.withOpacity(0.35),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _PC.purple.withOpacity(0.25),
                    blurRadius: 30,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  // Bunga dekorasi
                  Positioned(
                    top: -30,
                    right: -30,
                    child: Icon(
                      Icons.local_florist_rounded,
                      size: 140,
                      color: _PC.purpleSoft.withOpacity(0.06),
                    ),
                  ),
                  Positioned(
                    bottom: -20,
                    left: -20,
                    child: Icon(
                      Icons.auto_awesome_rounded,
                      size: 110,
                      color: _PC.purple.withOpacity(0.08),
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Top row: icon + badge
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 54,
                              height: 54,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                color: _PC.purple
                                    .withOpacity(0.15),
                                border: Border.all(
                                    color: _PC.purpleSoft
                                        .withOpacity(0.4),
                                    width: 1.5),
                              ),
                              child: Icon(menu.icon,
                                  color: _PC.purpleFrost, size: 26),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                borderRadius:
                                    BorderRadius.circular(20),
                                color: _PC.purple
                                    .withOpacity(0.20),
                                border: Border.all(
                                    color: _PC.purpleSoft
                                        .withOpacity(0.5),
                                    width: 1.2),
                              ),
                              child: Text(
                                menu.badge,
                                style: const TextStyle(
                                  color: _PC.purpleFrost,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                  fontFamily: 'Ready',
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 24),

                        // Title
                        Text(
                          menu.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.1,
                            fontFamily: 'Qaxer',
                          ),
                        ),
                        const SizedBox(height: 6),

                        // Subtitle
                        Text(
                          menu.subtitle,
                          style: const TextStyle(
                            color: _PC.purpleFrost,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Aktura',
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Divider
                        Container(
                          height: 1,
                          color: _PC.purpleSoft.withOpacity(0.2),
                        ),
                        const SizedBox(height: 14),

                        // Description
                        Text(
                          menu.description,
                          style: const TextStyle(
                            color: _PC.textSub,
                            fontSize: 12,
                            height: 1.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Features chips
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: menu.features.map((f) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: _PC.purple
                                    .withOpacity(0.12),
                                borderRadius:
                                    BorderRadius.circular(12),
                                border: Border.all(
                                    color: _PC.purpleSoft
                                        .withOpacity(0.25)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.check_circle_rounded,
                                      color: _PC.purpleSoft, size: 11),
                                  const SizedBox(width: 5),
                                  Text(
                                    f,
                                    style: const TextStyle(
                                        color: _PC.purpleFrost,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),

                        const Spacer(),

                        // Start button
                        GestureDetector(
                          onTap: menu.onStart,
                          child: Container(
                            height: 54,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: _PC.purple.withOpacity(0.25),
                              border: Border.all(
                                  color: _PC.purpleSoft
                                      .withOpacity(0.5),
                                  width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color:
                                      _PC.purple.withOpacity(0.25),
                                  blurRadius: 18,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: const Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.center,
                              children: [
                                Text(
                                  'START MODULE',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 2,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Icon(Icons.arrow_forward_rounded,
                                    color: Colors.white, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ⚫ DOTS
  // ═══════════════════════════════════════════════════════════
  Widget _buildDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_menus.length, (i) {
        final active = i == _currentPage;
        return GestureDetector(
          onTap: () {
            _pageCtrl.animateToPage(
              i,
              duration: const Duration(milliseconds: 380),
              curve: Curves.easeOutCubic,
            );
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: active ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: active
                  ? _PC.purpleSoft
                  : _PC.purpleSoft.withOpacity(0.25),
              borderRadius: BorderRadius.circular(4),
              boxShadow: active
                  ? [
                      BoxShadow(
                        color: _PC.purple.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ]
                  : null,
            ),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ℹ️ INFO BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildInfoBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _PC.card.withOpacity(0.6),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _PC.border, width: 1.2),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [_PC.purpleDeep, _PC.purpleMid],
                ),
                border: Border.all(
                    color: _PC.purpleSoft.withOpacity(0.35)),
              ),
              child: const Icon(Icons.verified_rounded,
                  color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pilih workspace untuk membuka tools yang tersedia di project.',
                    style: TextStyle(
                      color: _PC.text,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.circle,
                          color: _PC.purpleSoft, size: 5),
                      SizedBox(width: 5),
                      Text(
                        'TOOLS WORKSPACE',
                        style: TextStyle(
                          color: _PC.purpleFrost,
                          fontSize: 8.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🔻 BOTTOM NAV
  // ═══════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.bolt_rounded, color: _PC.purpleSoft.withOpacity(.75), size: 13),
          const SizedBox(width: 6),
          const Text(
            'ZEVORA PROJECT  •  WORKSPACE SELECTOR',
            style: TextStyle(
              color: _PC.textDim,
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 BACKGROUND PAINTER
// ═════════════════════════════════════════════════════════════
class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
        Offset.zero & size, Paint()..color = _PC.bg);

    // Glow atas
    final cx = size.width * 0.5;
    final cy = size.height * 0.15;

    for (int i = 0; i < 3; i++) {
      final angle = (t * 6.28) + (i * 2.09);
      final r = 120.0 + i * 70.0;
      final ox = cx + (angle % 1) * 20 - 10;
      final oy = cy + (angle % 1) * 15 - 7;

      final paint = Paint()
        ..shader = RadialGradient(
          colors: [
            _PC.purple.withOpacity(0.10 - i * 0.025),
            Colors.transparent,
          ],
        ).createShader(
            Rect.fromCircle(center: Offset(ox, oy), radius: r));
      canvas.drawCircle(Offset(ox, oy), r, paint);
    }

    // Dot pattern
    final dotPaint = Paint()
      ..color = _PC.purpleSoft.withOpacity(0.06);
    const spacing = 32.0;
    for (double y = 0; y < size.height; y += spacing) {
      for (double x = 0; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.2, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BgPainter old) => old.t != t;
}

// ═════════════════════════════════════════════════════════════
// 🛠️ HELPER — biar bisa pakai FontAwesome icon
// ═════════════════════════════════════════════════════════════
class FaIconData {
  final IconData icon;
  const FaIconData(this.icon);
}