import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'app_theme.dart';
import 'premium_service.dart';

// ─── XENOGRAM THEME ──────────────────────────────────────────
Color get _accent => AppTheme.I.accent;
const Color _bg = Color(0xFF070B12);
const Color _card = Color(0xFF0E1520);
const Color _card2 = Color(0xFF121A26);
const Color _text = Color(0xFFE8ECF2);
const Color _muted = Color(0xFF7A8799);

/// Helper image: URL / data-URI / path lokal
Widget _storyImage(
  String content, {
  BoxFit fit = BoxFit.cover,
  Widget Function(BuildContext, Object, StackTrace?)? errorBuilder,
}) {
  if (content.startsWith('http://') ||
      content.startsWith('https://') ||
      content.startsWith('data:')) {
    return Image.network(content, fit: fit, errorBuilder: errorBuilder);
  }
  try {
    final f = File(content);
    if (f.existsSync()) {
      return Image.file(f, fit: fit, errorBuilder: errorBuilder);
    }
  } catch (_) {}
  return ColoredBox(
    color: _card,
    child: const Center(child: Icon(Icons.broken_image, color: Colors.white38)),
  );
}

// ─── MODEL ───────────────────────────────────────────────────
class StoryItem {
  final String id;
  final String ownerUsername;
  final String type; // 'text' | 'image' | 'video'
  final String content;
  final String bgColor;
  final String txtColor;
  final String thumbnailUrl;
  final DateTime createdAt;
  final List<String> viewers;
  /// username -> emoji reaction
  final Map<String, String> reactions;
  /// usernames who liked (heart)
  final List<String> likes;
  /// {user, text, at}
  final List<Map<String, dynamic>> replies;

  const StoryItem({
    required this.id,
    required this.ownerUsername,
    required this.type,
    required this.content,
    required this.bgColor,
    required this.txtColor,
    required this.thumbnailUrl,
    required this.createdAt,
    required this.viewers,
    this.reactions = const {},
    this.likes = const [],
    this.replies = const [],
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) {
    final rawReact = j['reactions'];
    final reactions = <String, String>{};
    if (rawReact is Map) {
      rawReact.forEach((k, v) {
        if (v != null) reactions[k.toString()] = v.toString();
      });
    }
    final rawReplies = j['replies'];
    final replies = <Map<String, dynamic>>[];
    if (rawReplies is List) {
      for (final r in rawReplies) {
        if (r is Map) replies.add(Map<String, dynamic>.from(r));
      }
    }
    return StoryItem(
      id: j['id']?.toString() ?? '',
      ownerUsername: (j['ownerUsername'] ?? j['username'] ?? j['userId'] ?? '')
          .toString(),
      type: j['type']?.toString() ?? 'text',
      content: (j['content'] ?? j['url'] ?? j['mediaUrl'] ?? '').toString(),
      bgColor: (j['bg_color'] ?? j['bgColor'] ?? '#0d0d1a').toString(),
      txtColor: (j['txt_color'] ?? j['txtColor'] ?? '#00F5FF').toString(),
      thumbnailUrl:
          (j['thumbnail'] ?? j['thumbnailUrl'] ?? '').toString(),
      createdAt: DateTime.tryParse(
            (j['created_at'] ?? j['createdAt'] ?? '').toString(),
          ) ??
          DateTime.now(),
      viewers: List<String>.from(j['viewers'] ?? []),
      reactions: reactions,
      likes: List<String>.from(j['likes'] ?? []),
      replies: replies,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': ownerUsername,
        'type': type,
        'content': content,
        'bg_color': bgColor,
        'txt_color': txtColor,
        'thumbnail': thumbnailUrl,
        'created_at': createdAt.toIso8601String(),
        'viewers': viewers,
        'reactions': reactions,
        'likes': likes,
        'replies': replies,
      };

  StoryItem copyWith({
    List<String>? viewers,
    Map<String, String>? reactions,
    List<String>? likes,
    List<Map<String, dynamic>>? replies,
  }) =>
      StoryItem(
        id: id,
        ownerUsername: ownerUsername,
        type: type,
        content: content,
        bgColor: bgColor,
        txtColor: txtColor,
        thumbnailUrl: thumbnailUrl,
        createdAt: createdAt,
        viewers: viewers ?? this.viewers,
        reactions: reactions ?? this.reactions,
        likes: likes ?? this.likes,
        replies: replies ?? this.replies,
      );
}

class UserStoryGroup {
  final String username;
  final List<StoryItem> stories;
  final bool isMe;

  const UserStoryGroup({
    required this.username,
    required this.stories,
    required this.isMe,
  });
}

// ─── SERVICE ─────────────────────────────────────────────────
class StoryService {
  final String baseUrl;
  final String sessionKey;
  final String username;

  StoryService({
    required this.baseUrl,
    required this.sessionKey,
    required this.username,
  });

  String _url(String endpoint) {
    final root = baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final path = endpoint.startsWith('/') ? endpoint : '/$endpoint';
    final uri = Uri.parse('$root$path');
    final params = <String, String>{...uri.queryParameters};
    if (sessionKey.trim().isNotEmpty) params['key'] = sessionKey.trim();
    return uri.replace(queryParameters: params).toString();
  }

  Future<Map<String, dynamic>?> _readJson(http.StreamedResponse response) async {
    try {
      final body = await response.stream.bytesToString();
      if (body.trim().isEmpty) return null;
      final decoded = jsonDecode(body);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  bool _uploadSucceeded(int statusCode, Map<String, dynamic>? data) {
    if (statusCode < 200 || statusCode >= 300) return false;
    if (data == null) return true;
    if (data['success'] is bool) return data['success'] == true;
    if (data['ok'] is bool) return data['ok'] == true;
    if (data['error'] is bool) return data['error'] != true;
    return true;
  }

  String get _prefsKey =>
      'local_stories_v2_${username.trim().toLowerCase()}';
  String get _deletedKey =>
      'deleted_stories_v2_${username.trim().toLowerCase()}';
  // Legacy keys (migrasi otomatis)
  static const _legacyPrefsKey = 'local_stories_v1';
  static const _legacyDeletedKey = 'deleted_stories_v1';
  /// Store bersama untuk story orang lain yang diterima dari server/chat
  static const _sharedPrefsKey = 'shared_stories_v1_all';

  Future<String?> _copyLocal(File mediaFile, String type) async {
    try {
      // Support dir lebih stabil di Android (tidak mudah dibersihkan sistem)
      Directory baseDir;
      try {
        baseDir = await getApplicationSupportDirectory();
      } catch (_) {
        baseDir = await getApplicationDocumentsDirectory();
      }
      final storyDir = Directory('${baseDir.path}/ortaxgram_stories');
      if (!await storyDir.exists()) {
        await storyDir.create(recursive: true);
      }
      var ext = 'bin';
      final parts = mediaFile.path.split('.');
      if (parts.length > 1) {
        ext = parts.last.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (ext.isEmpty || ext.length > 5) {
          ext = type == 'video' ? 'mp4' : 'jpg';
        }
      } else {
        ext = type == 'video' ? 'mp4' : 'jpg';
      }
      final name = '${type}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      final dest = File('${storyDir.path}/$name');
      // Copy bytes agar tidak bergantung cache ImagePicker
      await mediaFile.copy(dest.path);
      if (!await dest.exists() || await dest.length() == 0) {
        final bytes = await mediaFile.readAsBytes();
        await dest.writeAsBytes(bytes, flush: true);
      }
      return dest.path;
    } catch (_) {
      try {
        final dir = await getApplicationDocumentsDirectory();
        final storyDir = Directory('${dir.path}/ortaxgram_stories');
        if (!await storyDir.exists()) await storyDir.create(recursive: true);
        final name =
            '${type}_${DateTime.now().millisecondsSinceEpoch}.dat';
        final dest = File('${storyDir.path}/$name');
        final bytes = await mediaFile.readAsBytes();
        await dest.writeAsBytes(bytes, flush: true);
        return dest.path;
      } catch (_) {
        return null;
      }
    }
  }

  Future<bool> postMediaStory(File mediaFile, String type) async {
    final id = 'story_${DateTime.now().millisecondsSinceEpoch}';
    // WAJIB simpan salinan lokal dulu — jangan andalkan path cache picker
    final localPath = await _copyLocal(mediaFile, type);
    if (localPath == null || localPath.isEmpty) {
      return false;
    }

    String? serverUrl;

    // Coba upload server (best-effort) — story tetap ada lokal meski gagal
    try {
      final endpoints = <String>[
        _url('/api/stories/upload'),
        _url('/api/story/upload'),
        '$baseUrl/chat/upload-${type == 'video' ? 'video' : 'image'}',
        '$baseUrl/chat/upload-file',
      ];
      for (final ep in endpoints) {
        try {
          final req = http.MultipartRequest('POST', Uri.parse(ep));
          if (sessionKey.isNotEmpty) req.fields['key'] = sessionKey;
          req.fields['username'] = username;
          req.fields['userId'] = username;
          req.fields['type'] = type;
          req.files.add(await http.MultipartFile.fromPath(
            type == 'video' ? 'video' : 'image',
            localPath,
          ));
          final res = await req.send().timeout(const Duration(seconds: 45));
          final data = await _readJson(res);
          if (_uploadSucceeded(res.statusCode, data)) {
            final url = data?['url']?.toString() ??
                data?['mediaUrl']?.toString() ??
                data?['fileUrl']?.toString();
            if (url != null &&
                url.isNotEmpty &&
                (url.startsWith('http://') || url.startsWith('https://'))) {
              serverUrl = url;
              break;
            }
          }
        } catch (_) {}
      }
    } catch (_) {}

    // Lokal tetap dipakai di device sendiri; kalau server URL ada, simpan
    // sebagai content agar device lain bisa memuat media yang sama.
    final contentForShare = (serverUrl != null && serverUrl.isNotEmpty)
        ? serverUrl
        : localPath;
    final item = StoryItem(
      id: id,
      ownerUsername: username,
      type: type,
      content: contentForShare,
      bgColor: '#0d0d1a',
      txtColor: '#00F5FF',
      thumbnailUrl: type == 'image'
          ? (serverUrl ?? localPath)
          : (serverUrl ?? ''),
      createdAt: DateTime.now(),
      viewers: const [],
    );
    await _saveLocal(item);
    // Broadcast ke semua user (chat global + shared store + API)
    await _broadcastStory(item);
    return true;
  }

  /// Sebarkan story ke chat global & endpoint API agar terlihat semua orang.
  Future<void> _broadcastStory(StoryItem item) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final shared = prefs.getStringList(_sharedPrefsKey) ?? [];
      shared.removeWhere((s) {
        try {
          final m = jsonDecode(s);
          return m is Map && m['id']?.toString() == item.id;
        } catch (_) {
          return false;
        }
      });
      shared.insert(0, jsonEncode(item.toJson()));
      while (shared.length > 120) {
        shared.removeLast();
      }
      await prefs.setStringList(_sharedPrefsKey, shared);
    } catch (_) {}

    final payload = item.toJson();
    // Lewat chat global sebagai __STORY__ / __STATUS__
    try {
      await http
          .post(
            Uri.parse('$baseUrl/chat/send'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'id': item.id,
              'userId': username,
              'username': username,
              'role': 'Member',
              'message': '__STORY__${jsonEncode(payload)}',
              'timestamp': item.createdAt.toIso8601String(),
              'type': 'story',
              'room': 'global',
              'roomId': 'global',
            }),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {}
    // Endpoint khusus
    for (final path in ['/api/stories', '/api/story', '/api/status']) {
      try {
        await http
            .post(
              Uri.parse(_url(path)),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode(payload),
            )
            .timeout(const Duration(seconds: 5));
      } catch (_) {}
    }
  }

  Future<void> _saveLocal(StoryItem item) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      // Merge legacy + current
      final raw = prefs.getStringList(_prefsKey) ??
          prefs.getStringList(_legacyPrefsKey) ??
          [];
      // Hapus duplikat id
      raw.removeWhere((s) {
        try {
          final m = jsonDecode(s);
          return m is Map && m['id']?.toString() == item.id;
        } catch (_) {
          return false;
        }
      });
      raw.insert(0, jsonEncode(item.toJson()));
      while (raw.length > 80) {
        raw.removeLast();
      }
      final ok = await prefs.setStringList(_prefsKey, raw);
      // Pastikan flush ke disk
      await prefs.reload();
      if (!ok) {
        // Fallback: coba simpan satu-per-satu key
        await prefs.setString(
          '${_prefsKey}_item_${item.id}',
          jsonEncode(item.toJson()),
        );
      }
    } catch (_) {}
  }

  bool _isUsableContent(String content) {
    if (content.isEmpty) return false;
    if (content.startsWith('http://') ||
        content.startsWith('https://') ||
        content.startsWith('data:')) {
      return true;
    }
    try {
      final f = File(content);
      return f.existsSync() && f.lengthSync() > 0;
    } catch (_) {
      return false;
    }
  }

  Future<List<StoryItem>> fetchStories() async {
    final items = <StoryItem>[];
    final deletedIds = <String>{};
    final seen = <String>{};
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.reload(); // baca nilai terbaru dari disk setelah restart

      deletedIds.addAll(prefs.getStringList(_deletedKey) ?? []);
      deletedIds.addAll(prefs.getStringList(_legacyDeletedKey) ?? []);

      final raw = <String>[
        ...(prefs.getStringList(_prefsKey) ?? const <String>[]),
        ...(prefs.getStringList(_legacyPrefsKey) ?? const <String>[]),
        ...(prefs.getStringList(_sharedPrefsKey) ?? const <String>[]),
      ];

      // Juga ambil item fallback individu
      for (final k in prefs.getKeys()) {
        if (k.startsWith('${_prefsKey}_item_')) {
          final v = prefs.getString(k);
          if (v != null && v.isNotEmpty) raw.add(v);
        }
      }

      final cleaned = <String>[];
      for (final s in raw) {
        try {
          final m = jsonDecode(s);
          if (m is! Map) continue;
          final item = StoryItem.fromJson(Map<String, dynamic>.from(m));
          if (item.id.isEmpty || seen.contains(item.id)) continue;
          if (deletedIds.contains(item.id)) continue;
          if (DateTime.now().difference(item.createdAt).inHours >= 24) continue;
          // Skip media yang file lokalnya sudah hilang total (kecuali URL remote)
          if ((item.type == 'image' || item.type == 'video') &&
              !_isUsableContent(item.content) &&
              !_isUsableContent(item.thumbnailUrl)) {
            continue;
          }
          seen.add(item.id);
          items.add(item);
          cleaned.add(jsonEncode(item.toJson()));
        } catch (_) {}
      }

      // Tulis ulang ke key per-user agar migrasi stabil
      if (cleaned.isNotEmpty) {
        await prefs.setStringList(_prefsKey, cleaned.take(80).toList());
      }
    } catch (_) {}

    // Server /api/stories
    try {
      final res = await http
          .get(Uri.parse(_url('/api/stories')))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final decoded = jsonDecode(res.body);
        final list = decoded is List
            ? decoded
            : (decoded is Map
                ? (decoded['stories'] ?? decoded['data'] ?? [])
                : []);
        if (list is List) {
          for (final e in list) {
            if (e is! Map) continue;
            final item =
                StoryItem.fromJson(Map<String, dynamic>.from(e));
            if (DateTime.now().difference(item.createdAt).inHours < 24 &&
                item.id.isNotEmpty &&
                !deletedIds.contains(item.id) &&
                !seen.contains(item.id)) {
              seen.add(item.id);
              items.add(item);
            }
          }
        }
      }
    } catch (_) {}

    // Tarik dari chat global hanya __STORY__ (bukan __STATUS__ dari chat WA)
    // Status chat (wa_status) dan story ZEVORA PROJECTgram dipisah agar status chat tidak muncul di story.
    try {
      final uri = Uri.parse('$baseUrl/chat/messages').replace(
        queryParameters: {'room': 'global', 'roomId': 'global'},
      );
      final res =
          await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        dynamic decoded = jsonDecode(res.body);
        List list = [];
        if (decoded is List) {
          list = decoded;
        } else if (decoded is Map) {
          list = (decoded['messages'] ?? decoded['data'] ?? []) as List? ?? [];
        }
        final sharedToSave = <String>[];
        for (final raw in list) {
          if (raw is! Map) continue;
          final msg = raw['message']?.toString() ?? '';
          Map<String, dynamic>? map;
          // Hanya __STORY__ — __STATUS__ khusus status chat, jangan masuk story
          if (msg.startsWith('__STORY__')) {
            try {
              final d = jsonDecode(msg.substring('__STORY__'.length));
              if (d is Map) map = Map<String, dynamic>.from(d);
            } catch (_) {}
          }
          if (map == null) continue;
          final item = StoryItem.fromJson({
            'id': map['id'] ??
                raw['id'] ??
                'story_${raw['timestamp'] ?? DateTime.now().millisecondsSinceEpoch}',
            'ownerUsername':
                map['ownerUsername'] ?? map['username'] ?? raw['username'] ?? '',
            'username':
                map['ownerUsername'] ?? map['username'] ?? raw['username'] ?? '',
            'type': map['type'] ?? 'text',
            'content': map['content'] ?? map['url'] ?? map['mediaUrl'] ?? '',
            'bgColor': map['bgColor'] ?? map['bg_color'] ?? '#0d0d1a',
            'txtColor': map['txtColor'] ?? map['txt_color'] ?? '#00F5FF',
            'thumbnailUrl': map['thumbnailUrl'] ?? map['thumbnail'] ?? '',
            'createdAt': map['createdAt'] ??
                map['created_at'] ??
                raw['timestamp'] ??
                DateTime.now().toIso8601String(),
            'viewers': map['viewers'] ?? [],
          });
          if (item.id.isEmpty || seen.contains(item.id)) continue;
          if (deletedIds.contains(item.id)) continue;
          if (DateTime.now().difference(item.createdAt).inHours >= 24) continue;
          seen.add(item.id);
          items.add(item);
          sharedToSave.add(jsonEncode(item.toJson()));
        }
        if (sharedToSave.isNotEmpty) {
          try {
            final prefs = await SharedPreferences.getInstance();
            final existing = prefs.getStringList(_sharedPrefsKey) ?? [];
            final merged = <String>{...sharedToSave, ...existing}.toList();
            await prefs.setStringList(
                _sharedPrefsKey, merged.take(120).toList());
          } catch (_) {}
        }
      }
    } catch (_) {}

    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Future<void> deleteStory(String id) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final deleted = prefs.getStringList(_deletedKey) ??
          prefs.getStringList(_legacyDeletedKey) ??
          [];
      if (!deleted.contains(id)) {
        deleted.add(id);
        await prefs.setStringList(_deletedKey, deleted);
      }
      for (final key in [_prefsKey, _legacyPrefsKey]) {
        final raw = prefs.getStringList(key) ?? [];
        raw.removeWhere((s) {
          try {
            final m = jsonDecode(s);
            return m is Map && m['id']?.toString() == id;
          } catch (_) {
            return false;
          }
        });
        await prefs.setStringList(key, raw);
      }
      await prefs.remove('${_prefsKey}_item_$id');
    } catch (_) {}
  }

  Future<void> markViewed(String id, String viewer) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList(_prefsKey) ??
          prefs.getStringList(_legacyPrefsKey) ??
          [];
      for (var i = 0; i < raw.length; i++) {
        try {
          final m = Map<String, dynamic>.from(jsonDecode(raw[i]) as Map);
          if (m['id']?.toString() == id) {
            final viewers = List<String>.from(m['viewers'] ?? []);
            if (!viewers.contains(viewer)) {
              viewers.add(viewer);
              m['viewers'] = viewers;
              raw[i] = jsonEncode(m);
            }
            break;
          }
        } catch (_) {}
      }
      await prefs.setStringList(_prefsKey, raw);
    } catch (_) {}
  }

  Future<void> _patchStory(String id, void Function(Map<String, dynamic> m) patch) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getStringList(_prefsKey) ??
          prefs.getStringList(_legacyPrefsKey) ??
          [];
      for (var i = 0; i < raw.length; i++) {
        try {
          final m = Map<String, dynamic>.from(jsonDecode(raw[i]) as Map);
          if (m['id']?.toString() == id) {
            patch(m);
            raw[i] = jsonEncode(m);
            break;
          }
        } catch (_) {}
      }
      await prefs.setStringList(_prefsKey, raw);
      await prefs.reload();
    } catch (_) {}
  }

  Future<StoryItem?> toggleLike(String id, String user) async {
    StoryItem? updated;
    await _patchStory(id, (m) {
      final likes = List<String>.from(m['likes'] ?? []);
      if (likes.contains(user)) {
        likes.remove(user);
      } else {
        likes.add(user);
      }
      m['likes'] = likes;
      updated = StoryItem.fromJson(m);
    });
    return updated;
  }

  Future<StoryItem?> setReaction(String id, String user, String emoji) async {
    StoryItem? updated;
    await _patchStory(id, (m) {
      final reactions = Map<String, dynamic>.from(m['reactions'] ?? {});
      if (reactions[user] == emoji) {
        reactions.remove(user);
      } else {
        reactions[user] = emoji;
      }
      m['reactions'] = reactions;
      updated = StoryItem.fromJson(m);
    });
    return updated;
  }

  Future<StoryItem?> addReply(String id, String user, String text) async {
    StoryItem? updated;
    await _patchStory(id, (m) {
      final replies = <Map<String, dynamic>>[];
      final raw = m['replies'];
      if (raw is List) {
        for (final e in raw) {
          if (e is Map) replies.add(Map<String, dynamic>.from(e));
        }
      }
      replies.add({
        'user': user,
        'text': text,
        'at': DateTime.now().toIso8601String(),
      });
      m['replies'] = replies;
      updated = StoryItem.fromJson(m);
    });
    return updated;
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY SECTION — entry di dashboard (ringkas)
// ═══════════════════════════════════════════════════════════════
class StorySection extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String serverUrl;

  const StorySection({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.serverUrl,
  });

  @override
  State<StorySection> createState() => _StorySectionState();
}

class _StorySectionState extends State<StorySection> {
  late final StoryService _svc;
  List<UserStoryGroup> _groups = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _svc = StoryService(
      baseUrl: widget.serverUrl,
      sessionKey: widget.sessionKey,
      username: widget.username,
    );
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final items = await _svc.fetchStories();
    final map = <String, List<StoryItem>>{};
    for (final s in items) {
      map.putIfAbsent(s.ownerUsername, () => []).add(s);
    }
    final groups = <UserStoryGroup>[];
    // Own stories first
    if (map.containsKey(widget.username)) {
      groups.add(UserStoryGroup(
        username: widget.username,
        stories: map[widget.username]!,
        isMe: true,
      ));
      map.remove(widget.username);
    }
    for (final e in map.entries) {
      groups.add(UserStoryGroup(
        username: e.key,
        stories: e.value,
        isMe: false,
      ));
    }
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _loading = false;
    });
  }

  void _openXenogram() {
    Navigator.of(context)
        .push(
      MaterialPageRoute(
        builder: (_) => XenogramPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
          serverUrl: widget.serverUrl,
        ),
      ),
    )
        .then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    final accent = _accent;
    return GestureDetector(
      onTap: _openXenogram,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _card.withOpacity(0.9),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.12),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: accent.withOpacity(0.6), width: 1.5),
                    gradient: LinearGradient(
                      colors: [
                        accent.withOpacity(0.25),
                        accent.withOpacity(0.05),
                      ],
                    ),
                  ),
                  child: Icon(Icons.auto_awesome, color: accent, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ZEVORA GRAM',
                        style: TextStyle(
                          color: _text,
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          letterSpacing: 1.2,
                        ),
                      ),
                      Text(
                        'Share your moment.',
                        style: TextStyle(color: _muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: accent.withOpacity(0.7)),
              ],
            ),
            const SizedBox(height: 14),
            // Mini story row
            SizedBox(
              height: 78,
              child: _loading
                  ? Center(
                      child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: accent,
                        ),
                      ),
                    )
                  : ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        // Add button
                        _MiniRing(
                          accent: accent,
                          child: Icon(Icons.add, color: accent, size: 26),
                          label: 'Buat',
                          onTap: _openXenogram,
                        ),
                        const SizedBox(width: 12),
                        ..._groups.take(8).map((g) {
                          final hasVideo =
                              g.stories.any((s) => s.type == 'video');
                          return Padding(
                            padding: const EdgeInsets.only(right: 12),
                            child: _MiniRing(
                              accent: accent,
                              child: hasVideo
                                  ? Icon(Icons.play_arrow_rounded,
                                      color: accent, size: 28)
                                  : Text(
                                      g.username.isNotEmpty
                                          ? g.username[0].toUpperCase()
                                          : '?',
                                      style: TextStyle(
                                        color: accent,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                      ),
                                    ),
                              label: g.isMe ? 'Kamu' : g.username,
                              onTap: _openXenogram,
                            ),
                          );
                        }),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniRing extends StatelessWidget {
  final Color accent;
  final Widget child;
  final String label;
  final VoidCallback onTap;

  const _MiniRing({
    required this.accent,
    required this.child,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: accent.withOpacity(0.7), width: 2),
              color: _card2,
            ),
            child: Center(child: child),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: 56,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(color: _muted, fontSize: 10),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// XENOGRAM PAGE — full page seperti video
// ═══════════════════════════════════════════════════════════════
class XenogramPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String serverUrl;

  const XenogramPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.serverUrl,
  });

  @override
  State<XenogramPage> createState() => _XenogramPageState();
}

class _XenogramPageState extends State<XenogramPage> {
  late final StoryService _svc;
  List<UserStoryGroup> _groups = [];
  bool _loading = true;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    _svc = StoryService(
      baseUrl: widget.serverUrl,
      sessionKey: widget.sessionKey,
      username: widget.username,
    );
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final items = await _svc.fetchStories();
    final map = <String, List<StoryItem>>{};
    for (final s in items) {
      map.putIfAbsent(s.ownerUsername, () => []).add(s);
    }
    final groups = <UserStoryGroup>[];
    if (map.containsKey(widget.username)) {
      groups.add(UserStoryGroup(
        username: widget.username,
        stories: map[widget.username]!,
        isMe: true,
      ));
      map.remove(widget.username);
    } else {
      // Always show self as "add" ring even without stories
    }
    for (final e in map.entries) {
      groups.add(UserStoryGroup(
        username: e.key,
        stories: e.value,
        isMe: false,
      ));
    }
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _loading = false;
    });
  }

  void _showCreateSheet() {
    final accent = _accent;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) {
        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFF0C121C),
            borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                'Buat ZEVORA GRAM',
                style: TextStyle(
                  color: _text,
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 18),
              _CreateOption(
                icon: Icons.image_outlined,
                label: 'Upload foto',
                accent: accent,
                onTap: () {
                  Navigator.pop(ctx);
                  _pickAndPost(ImageSource.gallery, isVideo: false);
                },
              ),
              const SizedBox(height: 10),
              _CreateOption(
                icon: Icons.videocam_outlined,
                label: 'Upload video',
                accent: accent,
                onTap: () {
                  Navigator.pop(ctx);
                  _pickAndPost(ImageSource.gallery, isVideo: true);
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Future<void> _pickAndPost(ImageSource source, {required bool isVideo}) async {
    final picker = ImagePicker();
    try {
      final XFile? file = isVideo
          ? await picker.pickVideo(
              source: source,
              maxDuration: const Duration(seconds: 60),
            )
          : await picker.pickImage(source: source, imageQuality: 85);
      if (file == null) return;

      setState(() => _uploading = true);
      final ok = await _svc.postMediaStory(
        File(file.path),
        isVideo ? 'video' : 'image',
      );
      if (!mounted) return;
      setState(() => _uploading = false);

      if (ok) {
        HapticFeedback.mediumImpact();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Story berhasil dibuat'),
            backgroundColor: const Color(0xFF1A2332),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          ),
        );
        await _load();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal membuat story')),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _uploading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _openViewer(UserStoryGroup group, {int startIndex = 0}) {
    Navigator.of(context)
        .push(
      PageRouteBuilder(
        opaque: true,
        pageBuilder: (_, __, ___) => XenogramViewer(
          group: group,
          startIndex: startIndex,
          myUsername: widget.username,
          service: _svc,
        ),
        transitionsBuilder: (_, anim, __, child) {
          return FadeTransition(opacity: anim, child: child);
        },
      ),
    )
        .then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    final accent = _accent;
    final accountCount = _groups.length + 1; // self + others

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // App bar
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 12, 8),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new,
                            color: _text, size: 20),
                        onPressed: () => Navigator.pop(context),
                      ),
                      Expanded(
                        child: Text(
                          'ZEVORA GRAM',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: _text,
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.add_circle_outline,
                            color: accent, size: 26),
                        onPressed: _showCreateSheet,
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    children: [
                      // Banner card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: accent.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: accent.withOpacity(0.55), width: 1.5),
                                gradient: LinearGradient(
                                  colors: [
                                    accent.withOpacity(0.3),
                                    accent.withOpacity(0.05),
                                  ],
                                ),
                              ),
                              child: Icon(Icons.auto_awesome,
                                  color: accent, size: 24),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'ZEVORA GRAM',
                                    style: TextStyle(
                                      color: _text,
                                      fontWeight: FontWeight.w800,
                                      fontSize: 16,
                                      letterSpacing: 1.1,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Share your moment.',
                                    style: TextStyle(
                                      color: _muted,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 22),

                      // Story header
                      Row(
                        children: [
                          const Text(
                            'Story',
                            style: TextStyle(
                              color: _text,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            '$accountCount akun',
                            style: const TextStyle(color: _muted, fontSize: 12),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      // Story circles
                      SizedBox(
                        height: 100,
                        child: _loading
                            ? Center(
                                child: CircularProgressIndicator(
                                  color: accent,
                                  strokeWidth: 2,
                                ),
                              )
                            : ListView(
                                scrollDirection: Axis.horizontal,
                                children: [
                                  // Create (+)
                                  _StoryRing(
                                    accent: accent,
                                    icon: Icons.add,
                                    label: widget.username.toUpperCase(),
                                    onTap: _showCreateSheet,
                                  ),
                                  const SizedBox(width: 14),
                                  // Own stories if any
                                  if (_groups.any((g) => g.isMe))
                                    ...[
                                      _StoryRing(
                                        accent: accent,
                                        icon: Icons.play_arrow_rounded,
                                        label: widget.username.toUpperCase(),
                                        onTap: () {
                                          final me = _groups
                                              .firstWhere((g) => g.isMe);
                                          _openViewer(me);
                                        },
                                      ),
                                      const SizedBox(width: 14),
                                    ],
                                  // Others
                                  ..._groups
                                      .where((g) => !g.isMe)
                                      .map((g) => Padding(
                                            padding:
                                                const EdgeInsets.only(right: 14),
                                            child: _StoryRing(
                                              accent: accent,
                                              icon: Icons.play_arrow_rounded,
                                              label: g.username.toUpperCase(),
                                              onTap: () => _openViewer(g),
                                            ),
                                          )),
                                ],
                              ),
                      ),

                      const SizedBox(height: 20),

                      // Info card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _card2,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white.withOpacity(0.05)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'ZEVORA GRAM',
                              style: TextStyle(
                                color: _text,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Tempat berbagi foto dan video selama 24 jam. Untuk chat pribadi, gunakan tombol WhatsApp di dashboard.',
                              style: TextStyle(
                                color: _muted,
                                fontSize: 12,
                                height: 1.45,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Uploading overlay
          if (_uploading)
            Container(
              color: Colors.black54,
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: accent),
                    const SizedBox(height: 14),
                    const Text(
                      'Mengunggah story...',
                      style: TextStyle(color: _text),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
      // Floating create shortcut
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreateSheet,
        backgroundColor: accent.withOpacity(0.2),
        foregroundColor: accent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: accent.withOpacity(0.5)),
        ),
        icon: const Icon(Icons.add),
        label: const Text(
          'Buat ZEVORA GRAM',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _CreateOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;

  const _CreateOption({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.06)),
          ),
          child: Row(
            children: [
              Icon(icon, color: accent, size: 22),
              const SizedBox(width: 14),
              Text(
                label,
                style: const TextStyle(
                  color: _text,
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StoryRing extends StatelessWidget {
  final Color accent;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _StoryRing({
    required this.accent,
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: SweepGradient(
                colors: [
                  accent,
                  accent.withOpacity(0.3),
                  const Color(0xFF7C4DFF),
                  accent,
                ],
              ),
            ),
            padding: const EdgeInsets.all(2.5),
            child: Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: _bg,
              ),
              child: Container(
                margin: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: accent.withOpacity(0.4), width: 1.5),
                  color: _card2,
                ),
                child: Icon(icon, color: accent, size: 28),
              ),
            ),
          ),
          const SizedBox(height: 6),
          SizedBox(
            width: 72,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _muted,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// VIEWER — full screen story seperti Instagram / video
// ═══════════════════════════════════════════════════════════════
class XenogramViewer extends StatefulWidget {
  final UserStoryGroup group;
  final int startIndex;
  final String myUsername;
  final StoryService service;

  const XenogramViewer({
    super.key,
    required this.group,
    required this.startIndex,
    required this.myUsername,
    required this.service,
  });

  @override
  State<XenogramViewer> createState() => _XenogramViewerState();
}

class _XenogramViewerState extends State<XenogramViewer>
    with TickerProviderStateMixin {
  late int _index;
  late AnimationController _progress;
  VideoPlayerController? _video;
  bool _paused = false;
  final _commentCtrl = TextEditingController();
  bool _showReactions = false;
  String? _floatingEmoji;
  late AnimationController _emojiAnim;

  static const _waReactions = [
    '❤️', '😂', '😮', '😢', '🙏', '🔥', '👍', '🎉',
  ];

  List<StoryItem> get _stories => widget.group.stories;
  StoryItem get _current => _stories[_index];

  bool get _liked => _current.likes.contains(widget.myUsername);
  String? get _myReaction => _current.reactions[widget.myUsername];

  @override
  void initState() {
    super.initState();
    _index = widget.startIndex.clamp(0, _stories.length - 1);
    _progress = AnimationController(vsync: this);
    _emojiAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _progress.addStatusListener((s) {
      if (s == AnimationStatus.completed) _next();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _startCurrent());
  }

  Future<void> _startCurrent() async {
    await _video?.dispose();
    _video = null;
    _progress.stop();
    _progress.reset();

    final item = _current;
    widget.service.markViewed(item.id, widget.myUsername);

    if (item.type == 'video') {
      try {
        if (item.content.startsWith('http')) {
          _video = VideoPlayerController.networkUrl(Uri.parse(item.content));
        } else {
          _video = VideoPlayerController.file(File(item.content));
        }
        await _video!.initialize();
        if (!mounted) return;
        setState(() {});
        final dur = _video!.value.duration;
        _progress.duration =
            dur.inMilliseconds > 500 ? dur : const Duration(seconds: 15);
        if (!_paused) {
          _video!.play();
          _progress.forward();
        }
      } catch (_) {
        _progress.duration = const Duration(seconds: 5);
        if (!_paused) _progress.forward();
      }
    } else {
      _progress.duration = const Duration(seconds: 5);
      if (!_paused) _progress.forward();
    }
  }

  void _next() {
    if (_index < _stories.length - 1) {
      setState(() => _index++);
      _startCurrent();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_index > 0) {
      setState(() => _index--);
      _startCurrent();
    } else {
      _progress
        ..reset()
        ..forward();
    }
  }

  void _togglePause() {
    setState(() => _paused = !_paused);
    if (_paused) {
      _progress.stop();
      _video?.pause();
    } else {
      _progress.forward();
      _video?.play();
    }
  }

  void _pauseOnly() {
    if (!_paused) {
      setState(() => _paused = true);
      _progress.stop();
      _video?.pause();
    }
  }

  Future<void> _toggleLike() async {
    final updated = await widget.service.toggleLike(
      _current.id,
      widget.myUsername,
    );
    if (updated != null && mounted) {
      setState(() {
        _stories[_index] = updated;
      });
      if (updated.likes.contains(widget.myUsername)) {
        _playFloating('❤️');
      }
    }
  }

  Future<void> _react(String emoji) async {
    final updated = await widget.service.setReaction(
      _current.id,
      widget.myUsername,
      emoji,
    );
    if (updated != null && mounted) {
      setState(() {
        _stories[_index] = updated;
        _showReactions = false;
      });
      if (updated.reactions[widget.myUsername] == emoji) {
        _playFloating(emoji);
      }
    }
  }

  void _playFloating(String emoji) {
    setState(() => _floatingEmoji = emoji);
    _emojiAnim
      ..reset()
      ..forward().then((_) {
        if (mounted) setState(() => _floatingEmoji = null);
      });
  }

  Future<void> _sendReply() async {
    final t = _commentCtrl.text.trim();
    if (t.isEmpty) return;
    final updated = await widget.service.addReply(
      _current.id,
      widget.myUsername,
      t,
    );
    _commentCtrl.clear();
    if (updated != null && mounted) {
      setState(() => _stories[_index] = updated);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Balasan terkirim: $t'),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF075E54),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    _progress.dispose();
    _emojiAnim.dispose();
    _video?.dispose();
    _commentCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = _accent;
    final item = _current;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.localPosition.dx < w * 0.3) {
            _prev();
          } else if (d.localPosition.dx > w * 0.7) {
            _next();
          } else {
            _togglePause();
          }
        },
        onVerticalDragEnd: (d) {
          if (d.primaryVelocity != null && d.primaryVelocity! > 300) {
            Navigator.pop(context);
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Content
            if (item.type == 'video' &&
                _video != null &&
                _video!.value.isInitialized)
              Center(
                child: AspectRatio(
                  aspectRatio: _video!.value.aspectRatio,
                  child: VideoPlayer(_video!),
                ),
              )
            else if (item.type == 'image')
              _storyImage(
                item.content,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Center(
                  child: Icon(Icons.broken_image, color: Colors.white38, size: 48),
                ),
              )
            else
              Container(
                color: const Color(0xFF0A1020),
                alignment: Alignment.center,
                padding: const EdgeInsets.all(24),
                child: Text(
                  item.content,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: _text,
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                  ),
                ),
              ),

            // Top gradient
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 120,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
              ),
            ),

            // Progress bars
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                child: Column(
                  children: [
                    Row(
                      children: List.generate(_stories.length, (i) {
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: AnimatedBuilder(
                              animation: _progress,
                              builder: (_, __) {
                                double v = 0;
                                if (i < _index) v = 1;
                                if (i == _index) v = _progress.value;
                                return ClipRRect(
                                  borderRadius: BorderRadius.circular(2),
                                  child: LinearProgressIndicator(
                                    value: v,
                                    minHeight: 2.5,
                                    backgroundColor: Colors.white24,
                                    valueColor: AlwaysStoppedAnimation(
                                      i == _index ? accent : Colors.white70,
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 12),
                    // Header user
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: accent.withOpacity(0.3),
                          child: Text(
                            widget.group.username.isNotEmpty
                                ? widget.group.username[0].toUpperCase()
                                : '?',
                            style: TextStyle(
                              color: accent,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: VerifiedName(
                            username: widget.group.username,
                            displayName: widget.group.username.toUpperCase(),
                            style: const TextStyle(
                              color: _text,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                              letterSpacing: 0.5,
                            ),
                            badgeSize: 14,
                          ),
                        ),
                        Icon(Icons.visibility_outlined,
                            color: Colors.white70, size: 22),
                        const SizedBox(width: 4),
                        Text(
                          '${item.viewers.length}',
                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // Comment bar
            Positioned(
              left: 12,
              right: 12,
              bottom: MediaQuery.of(context).padding.bottom + 8,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Reaction chips on status (like WA)
                  if (_current.reactions.isNotEmpty || _current.likes.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        children: [
                          if (_current.likes.isNotEmpty)
                            Container(
                              margin: const EdgeInsets.only(right: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.black54,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(
                                '❤️ ${_current.likes.length}',
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 12),
                              ),
                            ),
                          ..._current.reactions.values.toSet().map((e) {
                            final count = _current.reactions.values
                                .where((x) => x == e)
                                .length;
                            return Container(
                              margin: const EdgeInsets.only(right: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.black54,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(
                                '$e $count',
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 12),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),

                  // Emoji reaction picker (WhatsApp style)
                  if (_showReactions)
                    Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1F2C34),
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.4),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: _waReactions.map((e) {
                          final selected = _myReaction == e;
                          return GestureDetector(
                            onTap: () => _react(e),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              margin: const EdgeInsets.symmetric(horizontal: 2),
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: selected
                                    ? Colors.white24
                                    : Colors.transparent,
                                shape: BoxShape.circle,
                              ),
                              child: Text(e, style: const TextStyle(fontSize: 26)),
                            ),
                          );
                        }).toList(),
                      ),
                    ),

                  // Reply bar + like + react (WhatsApp Status style)
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          height: 46,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1F2C34),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Colors.white12),
                          ),
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: () {
                                  _pauseOnly();
                                  setState(
                                      () => _showReactions = !_showReactions);
                                },
                                child: Text(
                                  _myReaction ?? '😊',
                                  style: const TextStyle(fontSize: 22),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: TextField(
                                  controller: _commentCtrl,
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 14),
                                  decoration: const InputDecoration(
                                    hintText: 'Balas status...',
                                    hintStyle: TextStyle(color: Colors.white54),
                                    border: InputBorder.none,
                                    isDense: true,
                                  ),
                                  onTap: _pauseOnly,
                                  onSubmitted: (_) => _sendReply(),
                                ),
                              ),
                              GestureDetector(
                                onTap: _sendReply,
                                child: const Icon(Icons.send_rounded,
                                    color: Color(0xFF25D366), size: 22),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Heart like
                      GestureDetector(
                        onTap: _toggleLike,
                        child: Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _liked
                                ? const Color(0xFFE11D48)
                                : const Color(0xFF1F2C34),
                            border: Border.all(
                              color: _liked
                                  ? const Color(0xFFE11D48)
                                  : Colors.white24,
                            ),
                          ),
                          child: Icon(
                            _liked
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: _liked ? Colors.white : Colors.white70,
                            size: 22,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Floating emoji animation
            if (_floatingEmoji != null)
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _emojiAnim,
                    builder: (_, __) {
                      final t = Curves.easeOut.transform(_emojiAnim.value);
                      return Center(
                        child: Opacity(
                          opacity: (1 - t).clamp(0.0, 1.0),
                          child: Transform.translate(
                            offset: Offset(0, -80 * t),
                            child: Transform.scale(
                              scale: 0.8 + t * 1.4,
                              child: Text(
                                _floatingEmoji!,
                                style: const TextStyle(fontSize: 64),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
