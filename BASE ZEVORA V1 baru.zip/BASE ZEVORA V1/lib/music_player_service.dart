// Global music player — persists across pages + floating ball + library
import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MusicTrack {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String duration;
  final String url; // stream URL (may be resolved later)
  final String coverUrl;
  final String year;
  final String videoId; // YouTube video id (optional)
  final String genre;

  const MusicTrack({
    this.id = '',
    required this.title,
    required this.artist,
    required this.album,
    required this.duration,
    required this.url,
    required this.coverUrl,
    this.year = '',
    this.videoId = '',
    this.genre = '',
  });

  factory MusicTrack.fromMap(Map<String, dynamic> m) => MusicTrack(
        id: m['id']?.toString() ?? '',
        title: m['title']?.toString() ?? '',
        artist: m['artist']?.toString() ?? '',
        album: m['album']?.toString() ?? '',
        duration: m['duration']?.toString() ?? '',
        url: m['url']?.toString() ?? '',
        coverUrl: m['coverUrl']?.toString() ?? '',
        year: m['year']?.toString() ?? '',
        videoId: m['videoId']?.toString() ?? '',
        genre: m['genre']?.toString() ?? '',
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'duration': duration,
        'url': url,
        'coverUrl': coverUrl,
        'year': year,
        'videoId': videoId,
        'genre': genre,
      };

  MusicTrack copyWith({String? url, String? id}) => MusicTrack(
        id: id ?? this.id,
        title: title,
        artist: artist,
        album: album,
        duration: duration,
        url: url ?? this.url,
        coverUrl: coverUrl,
        year: year,
        videoId: videoId,
        genre: genre,
      );

  String get uniqueKey => id.isNotEmpty
      ? id
      : (videoId.isNotEmpty
          ? videoId
          : '${title}_$artist'.toLowerCase().replaceAll(' ', '_'));
}

typedef StreamResolver = Future<String?> Function(MusicTrack track);

class MusicPlayerService extends ChangeNotifier {
  MusicPlayerService._() {
    _player.onPlayerStateChanged.listen((s) {
      _isPlaying = s == PlayerState.playing;
      notifyListeners();
    });
    _player.onDurationChanged.listen((d) {
      _total = d;
      notifyListeners();
    });
    _player.onPositionChanged.listen((p) {
      _position = p;
      notifyListeners();
    });
    _player.onPlayerComplete.listen((_) {
      if (_repeat) {
        playIndex(_index);
      } else if (_shuffle) {
        playRandom();
      } else {
        next();
      }
    });
    _loadLibrary();
  }

  static final MusicPlayerService I = MusicPlayerService._();

  final AudioPlayer _player = AudioPlayer();
  final List<MusicTrack> playlist = [];

  /// Optional: resolve YouTube videoId → direct audio stream URL
  StreamResolver? streamResolver;

  int _index = 0;
  bool _isPlaying = false;
  bool _loading = false;
  bool _repeat = false;
  bool _shuffle = false;
  bool _showFloating = false;
  Duration _position = Duration.zero;
  Duration _total = Duration.zero;
  String? _lastError;

  // Library
  final List<MusicTrack> _recentlyPlayed = [];
  final List<MusicTrack> _favorites = [];
  Set<String> _favKeys = {};

  MusicTrack? get current =>
      playlist.isEmpty ? null : playlist[_index.clamp(0, playlist.length - 1)];
  bool get isPlaying => _isPlaying;
  bool get loading => _loading;
  bool get isRepeat => _repeat;
  bool get isShuffle => _shuffle;
  bool get showFloating => _showFloating;
  Duration get position => _position;
  Duration get total => _total;
  String? get lastError => _lastError;
  int get index => _index;
  List<MusicTrack> get recentlyPlayed => List.unmodifiable(_recentlyPlayed);
  List<MusicTrack> get favorites => List.unmodifiable(_favorites);

  void setShowFloating(bool v) {
    if (_showFloating == v) return;
    _showFloating = v;
    notifyListeners();
  }

  void setPlaylist(List<MusicTrack> tracks, {int startIndex = 0}) {
    playlist
      ..clear()
      ..addAll(tracks);
    _index = startIndex.clamp(0, playlist.isEmpty ? 0 : playlist.length - 1);
    notifyListeners();
  }

  Future<String?> _resolveUrl(MusicTrack t) async {
    if (streamResolver != null) {
      final r = await streamResolver!(t);
      if (r != null && r.isNotEmpty) return r;
    }
    if (t.url.isNotEmpty) return t.url;
    return null;
  }

  Future<void> playIndex(int i) async {
    if (playlist.isEmpty) return;
    _index = i.clamp(0, playlist.length - 1);
    final t = playlist[_index];
    _loading = true;
    _lastError = null;
    _position = Duration.zero;
    _total = Duration.zero;
    notifyListeners();
    try {
      await _player.stop();
      final streamUrl = await _resolveUrl(t);
      if (streamUrl == null || streamUrl.isEmpty) {
        _lastError = 'Tidak bisa memutar lagu ini';
        _isPlaying = false;
        _loading = false;
        notifyListeners();
        return;
      }
      if (streamUrl != t.url) {
        playlist[_index] = t.copyWith(url: streamUrl);
      }
      await _player.play(UrlSource(streamUrl));
      _isPlaying = true;
      await _addToRecent(playlist[_index]);
    } catch (e) {
      debugPrint('play error: $e');
      _lastError = e.toString();
      _isPlaying = false;
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> toggle() async {
    if (current == null) return;
    if (_isPlaying) {
      await _player.pause();
    } else {
      if (_position == Duration.zero && _total == Duration.zero) {
        await playIndex(_index);
      } else {
        await _player.resume();
      }
    }
  }

  Future<void> pause() async => _player.pause();
  Future<void> resume() async => _player.resume();

  Future<void> next() async {
    if (playlist.isEmpty) return;
    if (_shuffle) {
      await playRandom();
    } else {
      final n = (_index + 1) % playlist.length;
      await playIndex(n);
    }
  }

  Future<void> previous() async {
    if (playlist.isEmpty) return;
    if (_position.inSeconds > 3) {
      await _player.seek(Duration.zero);
      return;
    }
    final p = (_index - 1 + playlist.length) % playlist.length;
    await playIndex(p);
  }

  Future<void> playRandom() async {
    if (playlist.length <= 1) {
      await playIndex(0);
      return;
    }
    int n;
    do {
      n = DateTime.now().millisecondsSinceEpoch % playlist.length;
    } while (n == _index);
    await playIndex(n);
  }

  Future<void> seek(Duration d) async => _player.seek(d);

  void toggleRepeat() {
    _repeat = !_repeat;
    notifyListeners();
  }

  void toggleShuffle() {
    _shuffle = !_shuffle;
    notifyListeners();
  }

  Future<void> stopAndHide() async {
    await _player.stop();
    _isPlaying = false;
    _showFloating = false;
    _position = Duration.zero;
    notifyListeners();
  }

  // ─── Library helpers ───────────────────────────────────────
  bool isFavorite(MusicTrack t) => _favKeys.contains(t.uniqueKey);

  Future<void> toggleFavorite(MusicTrack t) async {
    final key = t.uniqueKey;
    if (_favKeys.contains(key)) {
      _favKeys.remove(key);
      _favorites.removeWhere((e) => e.uniqueKey == key);
    } else {
      _favKeys.add(key);
      _favorites.insert(0, t);
      if (_favorites.length > 100) _favorites.removeLast();
    }
    notifyListeners();
    await _saveLibrary();
  }

  Future<void> _addToRecent(MusicTrack t) async {
    final key = t.uniqueKey;
    _recentlyPlayed.removeWhere((e) => e.uniqueKey == key);
    _recentlyPlayed.insert(0, t);
    if (_recentlyPlayed.length > 50) _recentlyPlayed.removeLast();
    await _saveLibrary();
    notifyListeners();
  }

  Future<void> _loadLibrary() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favJson = prefs.getStringList('music_favorites') ?? [];
      final recentJson = prefs.getStringList('music_recent') ?? [];
      _favorites
        ..clear()
        ..addAll(favJson.map((s) {
          try {
            return MusicTrack.fromMap(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        }).whereType<MusicTrack>());
      _favKeys = _favorites.map((e) => e.uniqueKey).toSet();
      _recentlyPlayed
        ..clear()
        ..addAll(recentJson.map((s) {
          try {
            return MusicTrack.fromMap(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        }).whereType<MusicTrack>());
      notifyListeners();
    } catch (e) {
      debugPrint('load library error: $e');
    }
  }

  Future<void> _saveLibrary() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
        'music_favorites',
        _favorites.map((e) => jsonEncode(e.toMap())).toList(),
      );
      await prefs.setStringList(
        'music_recent',
        _recentlyPlayed.map((e) => jsonEncode(e.toMap())).toList(),
      );
    } catch (e) {
      debugPrint('save library error: $e');
    }
  }

  Future<void> clearRecent() async {
    _recentlyPlayed.clear();
    await _saveLibrary();
    notifyListeners();
  }
}
