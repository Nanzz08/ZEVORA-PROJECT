import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_theme.dart';

/// Premium theme selector. Uses the existing AppTheme controller and all
/// registered presets, so saved theme IDs and app-wide theme updates remain intact.
class ThemePickerPage extends StatefulWidget {
  const ThemePickerPage({super.key});

  @override
  State<ThemePickerPage> createState() => _ThemePickerPageState();
}

class _ThemePickerPageState extends State<ThemePickerPage> {
  final TextEditingController _searchController = TextEditingController();
  String _selected = AppTheme.I.currentThemeId;
  String _query = '';

  @override
  void initState() {
    super.initState();
    AppTheme.I.addListener(_handleThemeChanged);
  }

  void _handleThemeChanged() {
    if (!mounted) return;
    setState(() => _selected = AppTheme.I.currentThemeId);
  }

  @override
  void dispose() {
    AppTheme.I.removeListener(_handleThemeChanged);
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    final colors = theme.colors;
    final presets = AppTheme.presets.where((preset) {
      final q = _query.toLowerCase();
      return preset.name.toLowerCase().contains(q) || preset.id.toLowerCase().contains(q);
    }).toList(growable: false);

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          tooltip: 'Kembali',
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: colors.accent, size: 19),
          onPressed: () => Navigator.maybePop(context),
        ),
        title: Text(
          'Theme & Appearance',
          style: TextStyle(color: colors.accent, fontWeight: FontWeight.w800, fontSize: 17, letterSpacing: .35),
        ),
        actions: [
          IconButton(
            tooltip: 'Reset tema',
            onPressed: () => _selectTheme('navy', 'Navy'),
            icon: Icon(Icons.restart_alt_rounded, color: colors.accent),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: Colors.white.withOpacity(.07)),
        ),
      ),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [theme.accentDark, theme.accent, theme.accent.withOpacity(.72)],
                      ),
                      boxShadow: [
                        BoxShadow(color: theme.accent.withOpacity(.22), blurRadius: 22, offset: const Offset(0, 9)),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white.withOpacity(.22))),
                          child: const Icon(Icons.palette_rounded, color: Colors.white, size: 25),
                        ),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const Text('PERSONALIZE YOUR APP', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.3)),
                            const SizedBox(height: 4),
                            Text(theme.current.name, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 2),
                            const Text('Tema aktif · tersimpan otomatis', style: TextStyle(color: Colors.white70, fontSize: 11)),
                          ]),
                        ),
                        const Icon(Icons.check_circle_rounded, color: Colors.white, size: 24),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _searchController,
                    onChanged: (value) => setState(() => _query = value.trim()),
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'Cari nama tema atau warna...',
                      hintStyle: TextStyle(color: Colors.white.withOpacity(.38)),
                      prefixIcon: Icon(Icons.search_rounded, color: theme.accent),
                      suffixIcon: _query.isEmpty ? null : IconButton(
                        onPressed: () { _searchController.clear(); setState(() => _query = ''); },
                        icon: const Icon(Icons.close_rounded, color: Colors.white54),
                      ),
                      filled: true,
                      fillColor: colors.card.withOpacity(.78),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: colors.cardBorder.withOpacity(.55))),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: colors.cardBorder.withOpacity(.55))),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: theme.accent.withOpacity(.8), width: 1.4)),
                    ),
                  ),
                  const SizedBox(height: 11),
                  Row(children: [
                    Text('PILIH PRESET', style: TextStyle(color: Colors.white.withOpacity(.8), fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
                    const Spacer(),
                    Text('${presets.length} tema', style: TextStyle(color: Colors.white.withOpacity(.42), fontSize: 11)),
                  ]),
                ],
              ),
            ),
            Expanded(
              child: presets.isEmpty
                  ? Center(child: Text('Tema tidak ditemukan', style: TextStyle(color: Colors.white.withOpacity(.5))))
                  : LayoutBuilder(
                      builder: (context, constraints) {
                        final columns = constraints.maxWidth >= 620 ? 3 : 2;
                        return GridView.builder(
                          padding: const EdgeInsets.fromLTRB(18, 0, 18, 22),
                          itemCount: presets.length,
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: columns,
                            crossAxisSpacing: 11,
                            mainAxisSpacing: 11,
                            childAspectRatio: 1.55,
                          ),
                          itemBuilder: (context, index) {
                            final preset = presets[index];
                            final active = preset.id == _selected;
                            return _ThemePresetCard(
                              preset: preset,
                              active: active,
                              onTap: () => _selectTheme(preset.id, preset.name),
                            );
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectTheme(String id, String name) async {
    if (_selected == id) return;
    HapticFeedback.selectionClick();
    await AppTheme.I.setTheme(id);
    if (!mounted) return;
    setState(() => _selected = id);
    final colors = AppTheme.I.colors;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text('$name berhasil diterapkan', style: const TextStyle(fontWeight: FontWeight.w700)),
        backgroundColor: colors.accent.withOpacity(.96),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ));
  }
}

class _ThemePresetCard extends StatelessWidget {
  final ThemePreset preset;
  final bool active;
  final VoidCallback onTap;

  const _ThemePresetCard({required this.preset, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = preset.accent;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            color: const Color(0xFF121A27),
            border: Border.all(color: active ? accent : Colors.white.withOpacity(.09), width: active ? 1.7 : 1),
            boxShadow: active ? [BoxShadow(color: accent.withOpacity(.16), blurRadius: 17, offset: const Offset(0, 5))] : const [],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 37, height: 37, decoration: BoxDecoration(shape: BoxShape.circle, gradient: preset.tileGrad), child: const Icon(Icons.palette_rounded, color: Colors.white, size: 18)),
              const Spacer(),
              Icon(active ? Icons.check_circle_rounded : Icons.circle_outlined, color: active ? accent : Colors.white24, size: 20),
            ]),
            const Spacer(),
            Text(preset.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Row(children: [
              Container(width: 7, height: 7, decoration: BoxDecoration(color: accent, shape: BoxShape.circle)),
              const SizedBox(width: 6),
              Expanded(child: Text(active ? 'Sedang digunakan' : 'Terapkan tema', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? accent : Colors.white38, fontSize: 10.5))),
            ]),
          ]),
        ),
      ),
    );
  }
}
