import 'package:flutter/material.dart';

class AppColors {
  // Warna utama sekarang menggunakan putih/abu-abu terang
  static const Color primary = Color(0xFFE0E0E0); 

  // Compatibility aliases used by the original visual components.
  static const Color bg = background;
  static const Color textPrimary = text;
  
  // Mengganti cyan menjadi abu-abu terang
  static const Color cyan = Color(0xFFBDBDBD); 
  static const Color cyanDim = Color(0xFF757575); 
  
  // Mengganti violetBright menjadi putih
  static const Color violetBright = Color(0xFFFFFFFF); 
  static const Color borderGlow = Color(0xFF9E9E9E); 
  
  // Gradien sekarang dari abu-abu gelap ke abu-abu terang
  static const LinearGradient glowGrad = LinearGradient(
    colors: [cyanDim, violetBright],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
  
  // Warna pendukung diubah ke abu-abu
  static const Color primaryDark = Color(0xFF424242); 
  static const Color accent = Color(0xFF9E9E9E); // Abu-abu medium
  
  // Warna dasar tetap gelap (Hitam)
  static const Color background = Color(0xFF000000); // Hitam pekat
  static const Color surface = Color(0xFF121212);    // Hitam keabu-abuan
  static const Color card = Color(0xFF1E1E1E);       // Abu-abu sangat gelap
  
  // Teks
  static const Color text = Colors.white;
  static const Color textSub = Color(0xFF9E9E9E);    // Abu-abu terang untuk subteks
  
  // Status warna diubah menjadi grayscale (putih/abu-abu)
  static const Color success = Color(0xFFE0E0E0); 
  static const Color warning = Color(0xFFBDBDBD); 
  static const Color danger = Color(0xFF9E9E9E); 
  
  // Garis batas (Border)
  static const Color border = Color(0xFF333333); 
}