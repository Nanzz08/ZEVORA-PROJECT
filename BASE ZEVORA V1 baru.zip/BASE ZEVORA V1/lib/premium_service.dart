import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';

/// Premium Centang Biru — beli hanya dari saldo tabungan.
class PremiumService {
  static const _mapKey = 'premium_verified_map_v1';
  static const _historyKey = 'premium_buy_history_v1';

  static String _tabunganSaldoKey(String u) => 'tabungan_${u}_saldo';
  static String _tabunganKeluarKey(String u) => 'tabungan_${u}_keluar';
  static String _tabunganTxKey(String u) => 'tabungan_${u}_tx';

  static const packages = <PremiumPackage>[
    PremiumPackage(id: '10d', label: '10 Hari', days: 10, price: 5000),
    PremiumPackage(id: '1m', label: '1 Bulan', days: 30, price: 10000),
    PremiumPackage(id: 'perm', label: 'Permanen', days: null, price: 50000),
  ];

  static Future<Map<String, dynamic>> _loadMap() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_mapKey);
    if (raw == null || raw.isEmpty) return {};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {};
    }
  }

  static Future<void> _saveMap(Map<String, dynamic> map) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_mapKey, jsonEncode(map));
  }

  static String _norm(String u) => u.trim().toLowerCase();

  /// Cache status agar centang biru konsisten di semua UI.
  static final Map<String, bool> _cache = {};
  static void clearCache([String? username]) {
    if (username == null) {
      _cache.clear();
    } else {
      _cache.remove(_norm(username));
    }
  }

  /// Status verifikasi user (aktif / expired / belum).
  /// Hanya true jika user sudah beli centang biru (dan belum expired).
  static Future<PremiumStatus> statusOf(String username) async {
    final key = _norm(username);
    if (key.isEmpty) {
      return PremiumStatus(active: false, permanent: false, expiresAt: null);
    }
    final map = await _loadMap();
    // dukung key lama (asli) dan normalisasi
    final entry = map[key] ?? map[username] ?? map[username.trim()];
    if (entry == null) {
      return PremiumStatus(active: false, permanent: false, expiresAt: null);
    }
    final permanent = entry['permanent'] == true;
    DateTime? exp;
    if (entry['expiresAt'] != null) {
      exp = DateTime.tryParse(entry['expiresAt'].toString());
    }
    if (permanent) {
      return PremiumStatus(active: true, permanent: true, expiresAt: null);
    }
    if (exp != null && exp.isAfter(DateTime.now())) {
      return PremiumStatus(active: true, permanent: false, expiresAt: exp);
    }
    // expired → bersihkan (semua variasi key)
    if (exp != null && !exp.isAfter(DateTime.now())) {
      map.remove(key);
      map.remove(username);
      map.remove(username.trim());
      await _saveMap(map);
    }
    return PremiumStatus(active: false, permanent: false, expiresAt: exp);
  }

  static Future<bool> isVerified(String username) async {
    final key = _norm(username);
    if (key.isEmpty) return false;
    if (_cache.containsKey(key)) return _cache[key]!;
    final s = await statusOf(username);
    _cache[key] = s.active;
    return s.active;
  }

  /// Grant centang biru tanpa potong saldo (khusus developer tools).
  /// Return null jika sukses, atau pesan error.
  static Future<String?> grantPremium({
    required String username,
    required PremiumPackage pkg,
  }) async {
    final ukey = _norm(username);
    if (ukey.isEmpty) return 'Username tidak valid';

    final map = await _loadMap();
    final existing = map[ukey] ?? map[username];
    DateTime base = DateTime.now();
    final wasPermanent = existing != null && existing['permanent'] == true;

    map.remove(username);
    map.remove(username.trim());

    if (wasPermanent || pkg.days == null) {
      map[ukey] = {
        'permanent': true,
        'expiresAt': null,
        'boughtAt': DateTime.now().toIso8601String(),
        'package': pkg.id,
        'grantedBy': 'developer',
      };
    } else {
      if (existing != null && existing['expiresAt'] != null) {
        final oldExp = DateTime.tryParse(existing['expiresAt'].toString());
        if (oldExp != null && oldExp.isAfter(DateTime.now())) {
          base = oldExp;
        }
      }
      final exp = base.add(Duration(days: pkg.days!));
      map[ukey] = {
        'permanent': false,
        'expiresAt': exp.toIso8601String(),
        'boughtAt': DateTime.now().toIso8601String(),
        'package': pkg.id,
        'grantedBy': 'developer',
      };
    }
    await _saveMap(map);
    clearCache(username);

    final p = await SharedPreferences.getInstance();
    final hist = p.getStringList(_historyKey) ?? [];
    hist.insert(
      0,
      jsonEncode({
        'username': username,
        'package': pkg.label,
        'price': 0,
        'at': DateTime.now().toIso8601String(),
        'note': 'Granted by developer',
      }),
    );
    await p.setStringList(_historyKey, hist.take(50).toList());
    return null;
  }

  /// Cabut centang biru (developer tools).
  static Future<void> revokePremium(String username) async {
    final map = await _loadMap();
    final ukey = _norm(username);
    map.remove(ukey);
    map.remove(username);
    map.remove(username.trim());
    await _saveMap(map);
    clearCache(username);
  }

  static Future<double> getTabunganSaldo(String username) async {
    final p = await SharedPreferences.getInstance();
    return p.getDouble(_tabunganSaldoKey(username)) ?? 0.0;
  }

  /// Beli paket premium pakai saldo tabungan saja.
  /// Return null jika sukses, atau pesan error.
  static Future<String?> buyWithTabungan({
    required String username,
    required PremiumPackage pkg,
  }) async {
    final p = await SharedPreferences.getInstance();
    final saldo = p.getDouble(_tabunganSaldoKey(username)) ?? 0.0;
    if (saldo < pkg.price) {
      return 'Saldo tabungan tidak cukup.\nSaldo: Rp${_fmt(saldo)}\nHarga: Rp${_fmt(pkg.price)}';
    }

    // Potong tabungan
    final newSaldo = saldo - pkg.price;
    final keluar =
        (p.getDouble(_tabunganKeluarKey(username)) ?? 0.0) + pkg.price;
    await p.setDouble(_tabunganSaldoKey(username), newSaldo);
    await p.setDouble(_tabunganKeluarKey(username), keluar);

    final rawTx = p.getStringList(_tabunganTxKey(username)) ?? [];
    rawTx.insert(
      0,
      jsonEncode({
        'id': 'prem_${DateTime.now().millisecondsSinceEpoch}',
        'type': 'keluar',
        'amount': pkg.price,
        'note': 'Beli Centang Biru (${pkg.label})',
        'at': DateTime.now().toIso8601String(),
      }),
    );
    await p.setStringList(_tabunganTxKey(username), rawTx.take(100).toList());

    // Set / perpanjang premium — simpan dengan key normalisasi
    final map = await _loadMap();
    final ukey = _norm(username);
    final existing = map[ukey] ?? map[username];
    DateTime base = DateTime.now();
    bool wasPermanent = existing != null && existing['permanent'] == true;
    // bersihkan key lama non-normalized
    map.remove(username);
    map.remove(username.trim());
    if (wasPermanent) {
      map[ukey] = {
        'permanent': true,
        'expiresAt': null,
        'boughtAt': DateTime.now().toIso8601String(),
        'package': pkg.id,
      };
    } else if (pkg.days == null) {
      map[ukey] = {
        'permanent': true,
        'expiresAt': null,
        'boughtAt': DateTime.now().toIso8601String(),
        'package': pkg.id,
      };
    } else {
      if (existing != null && existing['expiresAt'] != null) {
        final oldExp = DateTime.tryParse(existing['expiresAt'].toString());
        if (oldExp != null && oldExp.isAfter(DateTime.now())) {
          base = oldExp;
        }
      }
      final exp = base.add(Duration(days: pkg.days!));
      map[ukey] = {
        'permanent': false,
        'expiresAt': exp.toIso8601String(),
        'boughtAt': DateTime.now().toIso8601String(),
        'package': pkg.id,
      };
    }
    await _saveMap(map);
    clearCache(username);

    // Riwayat beli
    final hist = p.getStringList(_historyKey) ?? [];
    hist.insert(
      0,
      jsonEncode({
        'username': username,
        'package': pkg.label,
        'price': pkg.price,
        'at': DateTime.now().toIso8601String(),
      }),
    );
    await p.setStringList(_historyKey, hist.take(50).toList());

    return null;
  }

  static Future<List<Map<String, dynamic>>> history() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_historyKey) ?? [];
    final out = <Map<String, dynamic>>[];
    for (final s in raw) {
      try {
        out.add(Map<String, dynamic>.from(jsonDecode(s) as Map));
      } catch (_) {}
    }
    return out;
  }

  static String _fmt(double n) {
    final s = n.toStringAsFixed(0);
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}

class PremiumPackage {
  final String id, label;
  final int? days; // null = permanen
  final double price;
  const PremiumPackage({
    required this.id,
    required this.label,
    required this.days,
    required this.price,
  });
}

class PremiumStatus {
  final bool active;
  final bool permanent;
  final DateTime? expiresAt;
  const PremiumStatus({
    required this.active,
    required this.permanent,
    required this.expiresAt,
  });
}

/// Widget centang biru kecil di samping nama.
class VerifiedBadge extends StatelessWidget {
  final double size;
  const VerifiedBadge({super.key, this.size = 16});

  @override
  Widget build(BuildContext context) {
    return Icon(
      Icons.verified,
      size: size,
      color: const Color(0xFF1D9BF0),
    );
  }
}

/// Nama + centang biru otomatis (cek status user).
class VerifiedName extends StatefulWidget {
  final String username;
  final String? displayName;
  final TextStyle? style;
  final double badgeSize;
  final int? maxLines;
  final TextOverflow? overflow;

  const VerifiedName({
    super.key,
    required this.username,
    this.displayName,
    this.style,
    this.badgeSize = 15,
    this.maxLines,
    this.overflow,
  });

  @override
  State<VerifiedName> createState() => _VerifiedNameState();
}

class _VerifiedNameState extends State<VerifiedName> {
  bool _verified = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void didUpdateWidget(covariant VerifiedName old) {
    super.didUpdateWidget(old);
    if (old.username != widget.username) _check();
  }

  Future<void> _check() async {
    final v = await PremiumService.isVerified(widget.username);
    if (mounted) setState(() => _verified = v);
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.displayName != null && widget.displayName!.isNotEmpty)
        ? widget.displayName!
        : widget.username;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Flexible(
          child: Text(
            name,
            style: widget.style,
            maxLines: widget.maxLines,
            overflow: widget.overflow ?? TextOverflow.ellipsis,
          ),
        ),
        if (_verified) ...[
          const SizedBox(width: 4),
          VerifiedBadge(size: widget.badgeSize),
        ],
      ],
    );
  }
}
