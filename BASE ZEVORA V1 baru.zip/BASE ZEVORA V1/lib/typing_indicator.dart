import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:fiona/Qaxer/api.dart';

/// Animated "typing…" bubble (WhatsApp style)
class TypingBubble extends StatefulWidget {
  final String? label; // e.g. "Rizz is typing"
  final Color accent;

  const TypingBubble({
    super.key,
    this.label,
    this.accent = const Color(0xFF25D366),
  });

  @override
  State<TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<TypingBubble>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2C34),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16),
            topRight: Radius.circular(16),
            bottomRight: Radius.circular(16),
            bottomLeft: Radius.circular(4),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (widget.label != null) ...[
              Text(
                widget.label!,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 8),
            ],
            AnimatedBuilder(
              animation: _c,
              builder: (_, __) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(3, (i) {
                    final t = (_c.value + i * 0.2) % 1.0;
                    final dy = (t < 0.5 ? t : 1 - t) * -6;
                    final opacity = 0.35 + (t < 0.5 ? t : 1 - t) * 0.65;
                    return Transform.translate(
                      offset: Offset(0, dy),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: widget.accent.withOpacity(opacity),
                          shape: BoxShape.circle,
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// Manages typing presence for a chat room (private / global / group)
class TypingController {
  final String roomId; // e.g. private:userA_userB | global | group:name
  final String myUsername;
  final void Function(List<String> typingUsers) onChanged;

  WebSocketChannel? _ws;
  Timer? _idleTimer;
  Timer? _pollTimer;
  Timer? _stopBroadcastTimer;
  bool _amTyping = false;
  final Map<String, DateTime> _others = {};
  bool _disposed = false;

  TypingController({
    required this.roomId,
    required this.myUsername,
    required this.onChanged,
  });

  String get _prefsKey => 'typing_room_$roomId';

  Future<void> start() async {
    _connectWs();
    _pollTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _pruneAndNotify();
      _readPrefs();
    });
  }

  void _connectWs() {
    try {
      String url = Api.api;
      if (url.startsWith('https')) {
        url = 'wss://${url.substring(8)}';
      } else if (url.startsWith('http')) {
        url = 'ws://${url.substring(7)}';
      } else {
        url = 'ws://ortaxxpanellegalnihdeck.xyzraa.biz.id:2058';
      }
      _ws = WebSocketChannel.connect(Uri.parse(url));
      _ws!.sink.add(jsonEncode({
        'type': 'typing_join',
        'room': roomId,
        'from': myUsername,
      }));
      _ws!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            if (data is! Map) return;
            final t = data['type']?.toString();
            if (t == 'typing' || t == 'typing_start' || t == 'typing_stop') {
              final from = data['from']?.toString() ?? '';
              final room = data['room']?.toString() ?? '';
              if (from.isEmpty || from == myUsername) return;
              if (room.isNotEmpty && room != roomId) return;
              // also match private peer room
              final active = t != 'typing_stop' && data['active'] != false;
              if (active) {
                _others[from] = DateTime.now();
              } else {
                _others.remove(from);
              }
              _pruneAndNotify();
            }
          } catch (_) {}
        },
        onError: (_) {},
        onDone: () {},
      );
    } catch (_) {}
  }

  /// Call when local user types in TextField
  void onLocalTextChanged(String text) {
    if (_disposed) return;
    if (text.trim().isEmpty) {
      _stopLocalTyping();
      return;
    }
    if (!_amTyping) {
      _amTyping = true;
      _broadcast(true);
    }
    _idleTimer?.cancel();
    _idleTimer = Timer(const Duration(milliseconds: 1800), _stopLocalTyping);
  }

  void onLocalSend() {
    _stopLocalTyping();
  }

  void _stopLocalTyping() {
    if (!_amTyping) return;
    _amTyping = false;
    _idleTimer?.cancel();
    _broadcast(false);
  }

  void _broadcast(bool active) {
    try {
      _ws?.sink.add(jsonEncode({
        'type': active ? 'typing' : 'typing_stop',
        'room': roomId,
        'from': myUsername,
        'active': active,
      }));
    } catch (_) {}
    // SharedPreferences bridge (same device / multi-account test + offline)
    _writePrefs(active);
  }

  Future<void> _writePrefs(bool active) async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_prefsKey);
      Map<String, dynamic> map = {};
      if (raw != null) {
        try {
          map = Map<String, dynamic>.from(jsonDecode(raw) as Map);
        } catch (_) {}
      }
      if (active) {
        map[myUsername] = DateTime.now().millisecondsSinceEpoch;
      } else {
        map.remove(myUsername);
      }
      await p.setString(_prefsKey, jsonEncode(map));
    } catch (_) {}
  }

  Future<void> _readPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_prefsKey);
      if (raw == null) return;
      final map = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final now = DateTime.now();
      map.forEach((user, ts) {
        if (user == myUsername) return;
        final ms = ts is int ? ts : int.tryParse(ts.toString()) ?? 0;
        final at = DateTime.fromMillisecondsSinceEpoch(ms);
        if (now.difference(at).inSeconds <= 3) {
          _others[user] = at;
        }
      });
      _pruneAndNotify();
    } catch (_) {}
  }

  void _pruneAndNotify() {
    final now = DateTime.now();
    _others.removeWhere((_, t) => now.difference(t).inSeconds > 3);
    if (!_disposed) {
      onChanged(_others.keys.toList()..sort());
    }
  }

  void dispose() {
    _disposed = true;
    _stopLocalTyping();
    _idleTimer?.cancel();
    _pollTimer?.cancel();
    _stopBroadcastTimer?.cancel();
    try {
      _ws?.sink.close();
    } catch (_) {}
  }
}
