import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'tiktok_coin_service.dart';

/// Halaman Beli Koin — UI mirip screenshot.
/// Pembayaran HANYA dari saldo tabungan.
class TiktokBuyCoinPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const TiktokBuyCoinPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<TiktokBuyCoinPage> createState() => _TiktokBuyCoinPageState();
}

class _TiktokBuyCoinPageState extends State<TiktokBuyCoinPage> {
  int _coins = 0;
  double _tabungan = 0;
  bool _loading = true;
  bool _buying = false;

  static const _bg = Color(0xFF000000);
  static const _card = Color(0xFF14161C);
  static const _cardSoft = Color(0xFF1A1D24);
  static const _blue = Color(0xFF4B9EFF);
  static const _text = Color(0xFFE8ECF2);
  static const _textSub = Color(0xFF8B93A7);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final c = await TiktokCoinService.getCoins(widget.username);
    final t = await TiktokCoinService.getTabunganSaldo(widget.username);
    if (!mounted) return;
    setState(() {
      _coins = c;
      _tabungan = t;
      _loading = false;
    });
  }

  String _rp(double n) {
    final s = n.toStringAsFixed(0);
    final buf = StringBuffer('Rp');
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Future<void> _buy(CoinPackage pkg) async {
    if (_buying) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Beli Koin?', style: TextStyle(color: _text)),
        content: Text(
          '${pkg.coins} Koin seharga ${_rp(pkg.price)}\n'
          'akan dibayar dari saldo tabungan.\n\n'
          'Saldo tabungan: ${_rp(_tabungan)}',
          style: const TextStyle(color: _textSub, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: _textSub)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _blue,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('BELI'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _buying = true);
    final err = await TiktokCoinService.buyWithTabungan(
      username: widget.username,
      pkg: pkg,
    );
    if (!mounted) return;
    setState(() => _buying = false);

    if (err != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(err),
          backgroundColor: Colors.red.shade700,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    HapticFeedback.mediumImpact();
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Berhasil! +${pkg.coins} Koin'),
        backgroundColor: Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _text, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Koin',
          style: TextStyle(
            color: _text,
            fontWeight: FontWeight.w600,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _blue))
          : RefreshIndicator(
              color: _blue,
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                children: [
                  // Saldo Koin card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Saldo Koin',
                          style: TextStyle(color: _textSub, fontSize: 13),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [Color(0xFFFFD54F), Color(0xFFFFA000)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: const Icon(Icons.monetization_on,
                                  color: Colors.white, size: 22),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              '$_coins',
                              style: const TextStyle(
                                color: _text,
                                fontSize: 28,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Koin dipakai untuk mengirim gift saat LIVE.',
                          style: TextStyle(color: _textSub, fontSize: 12),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Tabungan info
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: _cardSoft,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _blue.withOpacity(0.25)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.account_balance_wallet_outlined,
                            color: _blue.withOpacity(0.9), size: 20),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Bayar dari Saldo Tabungan',
                                style: TextStyle(
                                    color: _text,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600),
                              ),
                              Text(
                                'Saldo tersedia: ${_rp(_tabungan)}',
                                style: const TextStyle(
                                    color: _textSub, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),
                  const Text(
                    'Beli Koin',
                    style: TextStyle(
                      color: _text,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 14),

                  ...TiktokCoinService.packages.map((pkg) {
                    final canBuy = _tabungan >= pkg.price && !_buying;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: _card,
                          borderRadius: BorderRadius.circular(16),
                          border:
                              Border.all(color: Colors.white.withOpacity(0.05)),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF2A2410),
                                border: Border.all(
                                    color: const Color(0xFFFFD54F)
                                        .withOpacity(0.35)),
                              ),
                              child: const Center(
                                child: Icon(Icons.monetization_on,
                                    color: Color(0xFFFFD54F), size: 22),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${pkg.coins} Koin',
                                    style: const TextStyle(
                                      color: _text,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    _rp(pkg.price),
                                    style: const TextStyle(
                                      color: _textSub,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 36,
                              child: ElevatedButton(
                                onPressed: canBuy ? () => _buy(pkg) : null,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _blue,
                                  disabledBackgroundColor:
                                      _blue.withOpacity(0.25),
                                  foregroundColor: Colors.white,
                                  disabledForegroundColor:
                                      Colors.white.withOpacity(0.4),
                                  elevation: 0,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 18),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                child: const Text(
                                  'BELI',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),

                  if (_tabungan <= 0) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: Colors.orange.withOpacity(0.3)),
                      ),
                      child: const Text(
                        'Saldo tabungan kosong. Isi tabungan dulu di menu Tabungan untuk membeli koin.',
                        style: TextStyle(color: Colors.orange, fontSize: 12),
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
