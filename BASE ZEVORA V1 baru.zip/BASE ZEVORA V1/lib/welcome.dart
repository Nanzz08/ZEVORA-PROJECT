import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'landing.dart';

/// Selamat datang setelah splash — gaya onboarding ZEVORA, tema hitam-merah.
class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  static const _bg = Color(0xFF050505);
  static const _red = Color(0xFFE11D48);
  static const _redBright = Color(0xFFFF2D55);
  static const _textSub = Color(0xFF9A7A80);

  final PageController _pageCtrl = PageController();
  int _page = 0;

  static const _pages = <_WelcomeSlide>[
    _WelcomeSlide(
      badge: 'SISTEM UTAMA',
      title: 'SELAMAT DATANG',
      subtitle: 'ZEVORA PROJECT',
      body:
          'Aplikasi utilitas serbaguna generasi baru yang menghadirkan performa tinggi, proteksi keamanan menyeluruh, sistem modular canggih, dan integrasi multi-server tanpa hambatan.',
      icon: Icons.shield_outlined,
    ),
    _WelcomeSlide(
      badge: 'KEAMANAN',
      title: 'AMAN & PRIVASI',
      subtitle: 'SECURE LAYER',
      body:
          'Setiap sesi dilindungi verifikasi berlapis. Data tetap privat, akses terkontrol, dan sistem siap menjaga kenyamananmu saat memakai seluruh fitur ZEVORA PROJECT.',
      icon: Icons.lock_outline_rounded,
    ),
    _WelcomeSlide(
      badge: 'FITUR',
      title: 'MODULAR POWER',
      subtitle: 'FULL TOOLKIT',
      body:
          'Tools, chat, trade, TikTok, RAT, bug sender, dan banyak lagi dalam satu aplikasi. Dirancang cepat, stabil, dan mudah dipakai setiap hari.',
      icon: Icons.grid_view_rounded,
    ),
    _WelcomeSlide(
      badge: 'KOMUNITAS',
      title: 'TEAM ZEVORA PROJECT',
      subtitle: 'JOIN US NOW',
      body:
          'Diam bukan berarti lemah. Bergabung dengan komunitas, dapatkan update, dan hubungi owner kapan saja melalui Telegram resmi.',
      icon: Icons.groups_rounded,
    ),
  ];

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  void _goLanding() {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionDuration: const Duration(milliseconds: 450),
        transitionsBuilder: (_, animation, __, child) => FadeTransition(
          opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
          child: child,
        ),
      ),
    );
  }

  void _next() {
    if (_page < _pages.length - 1) {
      _pageCtrl.nextPage(
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutCubic,
      );
    } else {
      _goLanding();
    }
  }

  Future<void> _openTelegram() async {
    final u = Uri.parse('https://t.me/NanzzPrime');
    if (await canLaunchUrl(u)) {
      await launchUrl(u, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _page >= _pages.length - 1;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image + dark red overlay
          Image.asset(
            'assets/images/landing.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF1A080C), Color(0xFF050505)],
                ),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.55),
                  Colors.black.withOpacity(0.78),
                  Colors.black.withOpacity(0.94),
                ],
              ),
            ),
          ),
          CustomPaint(
            painter: _GridPainter(color: _red.withOpacity(0.07)),
            size: Size.infinite,
          ),

          SafeArea(
            child: Column(
              children: [
                // Top LEWATI
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Row(
                    children: [
                      const Spacer(),
                      TextButton(
                        onPressed: _goLanding,
                        style: TextButton.styleFrom(
                          foregroundColor: _redBright,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                            side: BorderSide(color: _red.withOpacity(0.45)),
                          ),
                          backgroundColor: Colors.black.withOpacity(0.35),
                        ),
                        child: const Text(
                          'LEWATI  >>',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Pages
                Expanded(
                  child: PageView.builder(
                    controller: _pageCtrl,
                    itemCount: _pages.length,
                    onPageChanged: (i) => setState(() => _page = i),
                    itemBuilder: (context, index) {
                      final s = _pages[index];
                      return _SlideView(slide: s, pageIndex: index);
                    },
                  ),
                ),

                // Page indicator
                Text(
                  '${_page + 1} / ${_pages.length}',
                  style: TextStyle(
                    color: _textSub.withOpacity(0.9),
                    fontSize: 12,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_pages.length, (i) {
                    final active = i == _page;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: active ? 18 : 7,
                      height: 7,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: active ? _red : Colors.white24,
                      ),
                    );
                  }),
                ),

                const SizedBox(height: 14),
                Text(
                  'Tap atau geser untuk lanjut',
                  style: TextStyle(
                    color: _textSub.withOpacity(0.75),
                    fontSize: 11,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 14),

                // Bottom actions
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
                  child: isLast
                      ? Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: _openTelegram,
                                icon: const Icon(Icons.send_rounded, size: 16),
                                label: const Text('JOIN TELEGRAM'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: _redBright,
                                  side: BorderSide(
                                      color: _red.withOpacity(0.65)),
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  textStyle: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: _goLanding,
                                icon: const Icon(Icons.person_rounded, size: 16),
                                label: const Text('CONTACT OWNER'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: _red,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  textStyle: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton(
                            onPressed: _next,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _red,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'LANJUTKAN',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Icon(Icons.arrow_forward_rounded, size: 18),
                              ],
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WelcomeSlide {
  final String badge;
  final String title;
  final String subtitle;
  final String body;
  final IconData icon;

  const _WelcomeSlide({
    required this.badge,
    required this.title,
    required this.subtitle,
    required this.body,
    required this.icon,
  });
}

class _SlideView extends StatelessWidget {
  final _WelcomeSlide slide;
  final int pageIndex;

  const _SlideView({required this.slide, required this.pageIndex});

  static const _red = Color(0xFFE11D48);
  static const _redBright = Color(0xFFFF2D55);
  static const _textSub = Color(0xFF9A7A80);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Logo circle
          Container(
            width: 88,
            height: 88,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF12080A),
              border: Border.all(color: _red.withOpacity(0.65), width: 2),
              boxShadow: [
                BoxShadow(
                  color: _red.withOpacity(0.35),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Icon(slide.icon, color: _redBright, size: 36),
          ),
          const SizedBox(height: 14),
          const Text(
            'ZEVORA PROJECT',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
              letterSpacing: 4,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          // Badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _red.withOpacity(0.5)),
              color: _red.withOpacity(0.12),
            ),
            child: Text(
              slide.badge,
              style: const TextStyle(
                color: _redBright,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 22),
          Text(
            slide.title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 26,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            slide.subtitle,
            style: TextStyle(
              color: _redBright.withOpacity(0.9),
              fontSize: 13,
              letterSpacing: 3,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            slide.body,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _textSub.withOpacity(0.95),
              fontSize: 13,
              height: 1.55,
            ),
          ),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 0.7;
    const step = 40.0;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
