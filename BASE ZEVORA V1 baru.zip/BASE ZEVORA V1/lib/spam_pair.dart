import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:fiona/Qaxer/api.dart';

/// Pairing utility — satu kali request pairing ke endpoint resmi server.
/// Tidak melakukan spam / pengiriman berulang otomatis.
class SpamPairPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const SpamPairPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<SpamPairPage> createState() => _SpamPairPageState();
}

class _SpamPairPageState extends State<SpamPairPage> {
  final _targetController = TextEditingController();
  bool _loading = false;
  String? _pairingCode;
  String? _statusMsg;
  bool _statusError = false;

  static const Color _seaBlue = Color(0xFF0EA5E9);
  static const Color _deepBlue = Color(0xFF075985);
  static const Color _bg = Color(0xFF050A0F);

  String get _baseUrl => Api.api.replaceFirst(RegExp(r'/+$'), '');

  @override
  void dispose() {
    _targetController.dispose();
    super.dispose();
  }

  String _normalizeNumber(String raw) {
    var cleaned = raw.replaceAll(RegExp(r'[\s\-]'), '');
    if (cleaned.startsWith('08')) {
      cleaned = '+62${cleaned.substring(1)}';
    } else if (cleaned.startsWith('62') && !cleaned.startsWith('+')) {
      cleaned = '+$cleaned';
    } else if (!cleaned.startsWith('+') && cleaned.startsWith('8')) {
      cleaned = '+62$cleaned';
    }
    return cleaned;
  }

  Future<void> _preparePairing() async {
    final target = _targetController.text.trim();
    if (target.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan nomor target terlebih dahulu.')),
      );
      return;
    }

    final cleaned = _normalizeNumber(target);
    if (!RegExp(r'^\+?62\d{9,13}$').hasMatch(cleaned.replaceFirst('+', '')) &&
        !RegExp(r'^\+62\d{9,13}$').hasMatch(cleaned)) {
      // Accept +62… after normalize
      if (!RegExp(r'^\+62\d{9,13}$').hasMatch(cleaned)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Format nomor tidak valid. Contoh: +628xxxxxxxxxx'),
          ),
        );
        return;
      }
    }

    setState(() {
      _loading = true;
      _pairingCode = null;
      _statusMsg = null;
      _statusError = false;
    });

    try {
      // Endpoint resmi yang sama dipakai bug_sender untuk pairing
      final params = <String, String>{
        'key': widget.sessionKey,
        'number': cleaned,
        'isGlobal': '0',
        'global': 'false',
        'senderMode': 'private',
        'scope': 'private',
      };
      final uri =
          Uri.parse('$_baseUrl/getPairing').replace(queryParameters: params);
      final res = await http.get(uri).timeout(const Duration(seconds: 25));

      Map<String, dynamic> data = {};
      try {
        final decoded = jsonDecode(res.body);
        if (decoded is Map) data = Map<String, dynamic>.from(decoded);
      } catch (_) {}

      if (res.statusCode == 200 && (data['valid'] == true || data['success'] == true)) {
        final code = data['pairingCode']?.toString() ??
            data['code']?.toString() ??
            data['pairing']?.toString() ??
            '';
        setState(() {
          _pairingCode = code.isNotEmpty ? code : null;
          _statusMsg = code.isNotEmpty
              ? 'Pairing code siap untuk $cleaned'
              : (data['message']?.toString() ??
                  'Nomor $cleaned siap. Pairing berhasil diproses server.');
          _statusError = false;
        });
        if (code.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Pairing code: $code'),
              backgroundColor: _seaBlue,
              duration: const Duration(seconds: 5),
            ),
          );
        }
      } else {
        // Fallback endpoint alternatif yang sering dipakai panel
        final alt = await _tryAltEndpoints(cleaned);
        if (alt != null) {
          setState(() {
            _pairingCode = alt['code'];
            _statusMsg = alt['msg'];
            _statusError = false;
          });
        } else {
          final err = data['message']?.toString() ??
              data['error']?.toString() ??
              'Server error: ${res.statusCode}';
          setState(() {
            _statusMsg = err;
            _statusError = true;
          });
        }
      }
    } catch (e) {
      setState(() {
        _statusMsg = 'Koneksi gagal: $e';
        _statusError = true;
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<Map<String, String>?> _tryAltEndpoints(String number) async {
    final candidates = [
      '$_baseUrl/pairing?key=${widget.sessionKey}&number=${Uri.encodeComponent(number)}',
      '$_baseUrl/spam/pairing?key=${widget.sessionKey}&number=${Uri.encodeComponent(number)}',
      '$_baseUrl/getPairingCode?key=${widget.sessionKey}&number=${Uri.encodeComponent(number)}',
    ];
    for (final url in candidates) {
      try {
        final res =
            await http.get(Uri.parse(url)).timeout(const Duration(seconds: 12));
        if (res.statusCode != 200) continue;
        final decoded = jsonDecode(res.body);
        if (decoded is! Map) continue;
        final data = Map<String, dynamic>.from(decoded);
        if (data['valid'] == true || data['success'] == true) {
          final code = data['pairingCode']?.toString() ??
              data['code']?.toString() ??
              '';
          return {
            'code': code,
            'msg': code.isNotEmpty
                ? 'Pairing code siap untuk $number'
                : (data['message']?.toString() ?? 'Pairing diproses'),
          };
        }
      } catch (_) {}
    }
    return null;
  }

  void _copyCode() {
    if (_pairingCode == null || _pairingCode!.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairingCode!));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Kode disalin ke clipboard')),
    );
  }

  void _closeToDashboard() {
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: _closeToDashboard,
        ),
        title: const Text(
          'SPAM PAIRING',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_seaBlue, _deepBlue],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: _seaBlue.withOpacity(0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.link_rounded, color: Colors.white, size: 32),
                  SizedBox(height: 12),
                  Text(
                    'SPAM PAIRING',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Pairing kode ke nomor target (sekali request)',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _targetController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Nomor Target',
                hintText: '+628xxxxxxxxxx',
                labelStyle: const TextStyle(color: _seaBlue),
                hintStyle: const TextStyle(color: Colors.white30),
                prefixIcon: const Icon(Icons.phone_android, color: _seaBlue),
                filled: true,
                fillColor: const Color(0xFF0B1520),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFF164E63)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFF164E63)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: _seaBlue, width: 1.5),
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Gunakan hanya untuk nomor yang Anda miliki atau izinkan. '
              'Halaman ini mengirim satu request pairing ke server (bukan spam otomatis berulang).',
              style: TextStyle(color: Colors.white54, height: 1.5),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 54,
              child: ElevatedButton.icon(
                onPressed: _loading ? null : _preparePairing,
                icon: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.link_rounded),
                label: Text(
                  _loading ? 'MEMPROSES...' : 'SIAPKAN PAIRING',
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    letterSpacing: .8,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _seaBlue,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: _seaBlue.withOpacity(0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
            if (_statusMsg != null) ...[
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _statusError
                      ? const Color(0xFF3F1A1A)
                      : const Color(0xFF0B1520),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: _statusError
                        ? const Color(0xFFE11D48)
                        : _seaBlue.withOpacity(0.5),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _statusMsg!,
                      style: TextStyle(
                        color: _statusError
                            ? const Color(0xFFFF8A8A)
                            : Colors.white,
                        height: 1.4,
                      ),
                    ),
                    if (_pairingCode != null && _pairingCode!.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: SelectableText(
                              _pairingCode!,
                              style: const TextStyle(
                                color: _seaBlue,
                                fontSize: 28,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 4,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: _copyCode,
                            icon: const Icon(Icons.copy, color: _seaBlue),
                            tooltip: 'Salin kode',
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
