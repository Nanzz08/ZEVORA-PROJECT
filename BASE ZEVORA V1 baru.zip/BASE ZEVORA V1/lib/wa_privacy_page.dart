import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Privacy settings — WhatsApp style
class WaPrivacyPage extends StatefulWidget {
  final String username;

  const WaPrivacyPage({super.key, required this.username});

  @override
  State<WaPrivacyPage> createState() => _WaPrivacyPageState();
}

class _WaPrivacyPageState extends State<WaPrivacyPage> {
  // everyone | contacts | nobody
  String _photo = 'everyone';
  String _about = 'everyone';
  String _status = 'contacts';
  String _lastSeen = 'everyone';
  String _online = 'everyone';
  bool _readReceipts = true;

  static const _green = Color(0xFF25D366);
  static const _bg = Color(0xFF0B141A);
  static const _card = Color(0xFF111B21);
  static const _text = Color(0xFFE9EDEF);
  static const _muted = Color(0xFF8696A0);

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _k => widget.username;

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _photo = p.getString('priv_photo_$_k') ?? 'everyone';
      _about = p.getString('priv_about_$_k') ?? 'everyone';
      _status = p.getString('priv_status_$_k') ?? 'contacts';
      _lastSeen = p.getString('priv_lastseen_$_k') ?? 'everyone';
      _online = p.getString('priv_online_$_k') ?? 'everyone';
      _readReceipts = p.getBool('priv_read_$_k') ?? true;
    });
  }

  Future<void> _save(String key, String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, value);
  }

  Future<void> _pickVisibility({
    required String title,
    required String current,
    required ValueChanged<String> onChanged,
    required String prefKey,
  }) async {
    final result = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        Widget tile(String value, String label) {
          final selected = current == value;
          return ListTile(
            title: Text(label, style: const TextStyle(color: _text)),
            trailing: selected
                ? const Icon(Icons.check, color: _green)
                : null,
            onTap: () => Navigator.pop(ctx, value),
          );
        }

        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Text(
                  title,
                  style: const TextStyle(
                    color: _text,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              tile('everyone', 'Semua orang'),
              tile('contacts', 'Kontak saya'),
              tile('nobody', 'Tidak ada (hanya saya)'),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );

    if (result != null) {
      setState(() => onChanged(result));
      await _save(prefKey, result);
    }
  }

  String _label(String v) {
    switch (v) {
      case 'everyone':
        return 'Semua orang';
      case 'contacts':
        return 'Kontak saya';
      case 'nobody':
        return 'Tidak ada';
      default:
        return v;
    }
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Text(
          t,
          style: const TextStyle(
            color: _green,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      );

  Widget _row({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      title: Text(title, style: const TextStyle(color: _text, fontSize: 16)),
      subtitle: Text(subtitle, style: const TextStyle(color: _muted, fontSize: 13)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _text),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Privasi', style: TextStyle(color: _text)),
      ),
      body: ListView(
        children: [
          // Banner
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF0A3D2E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.lock_outline, color: _green, size: 22),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Kendalikan privasi dan pilih pengaturan yang tepat bagi Anda.',
                    style: TextStyle(color: Colors.green.shade100, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),

          _sectionTitle('Siapa yang bisa melihat informasi pribadi saya'),

          _row(
            title: 'Terakhir dilihat dan online',
            subtitle: _label(_lastSeen),
            onTap: () => _pickVisibility(
              title: 'Terakhir dilihat',
              current: _lastSeen,
              prefKey: 'priv_lastseen_$_k',
              onChanged: (v) {
                _lastSeen = v;
                // online follows last seen by default (WA behavior-ish)
                _online = v;
                _save('priv_online_$_k', v);
              },
            ),
          ),
          _row(
            title: 'Status online',
            subtitle: _label(_online),
            onTap: () => _pickVisibility(
              title: 'Status online',
              current: _online,
              prefKey: 'priv_online_$_k',
              onChanged: (v) => _online = v,
            ),
          ),
          _row(
            title: 'Foto profil',
            subtitle: _label(_photo),
            onTap: () => _pickVisibility(
              title: 'Foto profil',
              current: _photo,
              prefKey: 'priv_photo_$_k',
              onChanged: (v) => _photo = v,
            ),
          ),
          _row(
            title: 'Tentang',
            subtitle: _label(_about),
            onTap: () => _pickVisibility(
              title: 'Tentang',
              current: _about,
              prefKey: 'priv_about_$_k',
              onChanged: (v) => _about = v,
            ),
          ),
          _row(
            title: 'Status',
            subtitle: _label(_status),
            onTap: () => _pickVisibility(
              title: 'Status',
              current: _status,
              prefKey: 'priv_status_$_k',
              onChanged: (v) => _status = v,
            ),
          ),

          const Divider(color: Colors.white12, height: 24),

          _sectionTitle('Pesan'),

          SwitchListTile(
            value: _readReceipts,
            activeColor: _green,
            title: const Text('Laporan dibaca',
                style: TextStyle(color: _text, fontSize: 16)),
            subtitle: const Text(
              'Jika dinonaktifkan, Anda tidak mengirim atau menerima laporan dibaca.',
              style: TextStyle(color: _muted, fontSize: 12),
            ),
            onChanged: (v) async {
              setState(() => _readReceipts = v);
              final p = await SharedPreferences.getInstance();
              await p.setBool('priv_read_$_k', v);
            },
          ),

          const SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Pengaturan disimpan di perangkat ini dan diterapkan di seluruh aplikasi ZEVORA PROJECT.',
              style: TextStyle(color: _muted, fontSize: 12),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}
