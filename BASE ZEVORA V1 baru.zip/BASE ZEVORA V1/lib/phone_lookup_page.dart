import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Qaxer/api.dart';

class PhoneLookupPage extends StatefulWidget {
  const PhoneLookupPage({super.key});

  @override
  State<PhoneLookupPage> createState() => _PhoneLookupPageState();
}

class _PhoneLookupPageState extends State<PhoneLookupPage> {
  static const primary = Color(0xFFE03030);
  static const bg = Color(0xFF080204);
  static const text = Color(0xFFF5EAEA);
  static const text70 = Color(0xA6F5EAEA);
  static const text54 = Color(0x66F5EAEA);
  static const emerald = Color(0xFF34D399);
  static const green = Color(0xFF4ADE80);
  static const red = Color(0xFFEF4444);

  final input = TextEditingController();
  final scaffoldKey = GlobalKey<ScaffoldState>();

  bool loading = false;
  String? error;
  Map<String, dynamic>? ipData;
  Map<String, dynamic>? phoneData;
  String username = '-';
  String expired = '-';

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadIPInfo();
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    try {
      final r = await http.get(
        Uri.parse('${Api.api}/api/user-data'),
        headers: {'Cache-Control': 'no-cache'},
      );
      if (r.statusCode != 200) return;
      final j = jsonDecode(r.body);
      if (!mounted) return;
      setState(() {
        username = j['username']?.toString() ?? '-';
        final d = DateTime.tryParse(j['expired']?.toString() ?? '');
        expired = d == null ? '-' : _date(d);
      });
    } catch (_) {}
  }

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  bool _isIP(String s) =>
      RegExp(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$').hasMatch(s);

  Future<void> lookup() async {
    final value = input.text.trim();
    if (value.isEmpty || loading) return;
    if (_isIP(value)) {
      await _loadIPInfo(value);
    } else {
      await _analyzePhone(value);
    }
  }

  Future<void> _loadIPInfo([String? ip]) async {
    setState(() {
      loading = true;
      error = null;
      phoneData = null;
    });

    try {
      const fields =
          'status,message,query,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as';
      final uri = Uri.https(
        'ip-api.com',
        '/json/${ip ?? ''}',
        {'fields': fields},
      );
      final r = await http.get(uri);
      final data = jsonDecode(r.body) as Map<String, dynamic>;

      if (!mounted) return;
      setState(() => loading = false);

      if (data['status'] == 'success') {
        setState(() => ipData = data);
      } else {
        setState(() => error = 'Error: ${data['message'] ?? 'Invalid IP'}');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'Error: $e';
      });
    }
  }

  Future<void> _analyzePhone(String phone) async {
    setState(() {
      loading = true;
      error = null;
      ipData = null;
      phoneData = null;
    });

    try {
      final uri = Uri.parse('/api/phone-lookup').replace(
        queryParameters: {'number': phone},
      );
      final r = await http.get(uri);
      final data = jsonDecode(r.body) as Map<String, dynamic>;

      if (!mounted) return;
      setState(() => loading = false);

      if (data['valid'] != true) {
        setState(() => error = data['error']?.toString() ?? 'Invalid phone number');
      } else {
        setState(() => phoneData = data);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'Error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.transparent,
      drawer: _drawer(),
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: primary),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              Navigator.pushNamed(context, '/tools');
            }
          },
        ),
        title: Image.network(
          'https://files.catbox.moe/rvo5hy.png',
          height: 50,
          errorBuilder: (_, __, ___) =>
              const Icon(Icons.phone, color: primary),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: primary),
            onPressed: () => Navigator.pushNamed(context, '/logout'),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0C0202), Color(0xFF080204), Color(0xFF0A0203)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.phone, color: emerald),
                        SizedBox(width: 10),
                        Text(
                          'Phone Lookup',
                          style: TextStyle(
                            color: text,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Phone number analysis & IP geolocation lookup',
                      style: TextStyle(color: text54, fontSize: 12),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: input,
                            keyboardType: TextInputType.phone,
                            textInputAction: TextInputAction.search,
                            onSubmitted: (_) => lookup(),
                            style: const TextStyle(
                              color: text,
                              fontSize: 13,
                              fontFamily: 'monospace',
                            ),
                            decoration: InputDecoration(
                              hintText: 'Enter phone number or IP address',
                              hintStyle: const TextStyle(color: text54),
                              filled: true,
                              fillColor: const Color(0x0F34D399),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 14,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide: const BorderSide(
                                  color: Color(0x4D34D399),
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14),
                                borderSide:
                                    const BorderSide(color: emerald),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        SizedBox(
                          height: 50,
                          child: ElevatedButton(
                            onPressed: loading ? null : lookup,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0x4034D399),
                              foregroundColor: emerald,
                              elevation: 0,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 18),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                                side: const BorderSide(
                                  color: Color(0x4D34D399),
                                ),
                              ),
                            ),
                            child: const Icon(Icons.search),
                          ),
                        ),
                      ],
                    ),
                    if (loading) ...[
                      const SizedBox(height: 30),
                      const Center(
                        child: Column(
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: emerald,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              'Looking up...',
                              style: TextStyle(color: text54, fontSize: 13),
                            ),
                          ],
                        ),
                      ),
                    ],
                    if (error != null) ...[
                      const SizedBox(height: 16),
                      _error(error!),
                    ],
                    if (ipData != null) _ipResults(ipData!),
                    if (phoneData != null) _phoneResults(phoneData!),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _error(String s) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0x1AE03030),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0x33E03030)),
        ),
        child: Text(s, style: const TextStyle(color: Color(0xFFFF6B6B))),
      );

  Widget _section(String title, IconData icon) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 10),
        child: Row(
          children: [
            Icon(icon, color: emerald, size: 16),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                color: text,
                fontSize: 14,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      );

  Widget _ipResults(Map<String, dynamic> d) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _section('Your IP Geolocation', Icons.public),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0x3334D399)),
            gradient: const LinearGradient(
              colors: [Color(0x1434D399), Color(0x80080202)],
            ),
          ),
          child: Column(
            children: [
              Text(
                d['query']?.toString() ?? '-',
                style: const TextStyle(
                  color: emerald,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'PUBLIC IP ADDRESS',
                style: TextStyle(color: text54, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _info('Country',
                '${d['country'] ?? '-'} (${d['countryCode'] ?? '-'})', Icons.flag),
            _info('Region', d['regionName'] ?? '-', Icons.map),
            _info('City', d['city'] ?? '-', Icons.location_city),
            _info('Timezone', d['timezone'] ?? '-', Icons.access_time),
            _info(
              'Coordinates',
              '${d['lat'] ?? '-'}, ${d['lon'] ?? '-'}',
              Icons.explore,
            ),
            _info('ZIP', d['zip'] ?? '-', Icons.markunread_mailbox),
            _info('ISP', d['isp'] ?? '-', Icons.business, full: true),
            _info(
              'AS / Org',
              '${d['as'] ?? ''} - ${d['org'] ?? '-'}',
              Icons.dns,
              full: true,
            ),
          ],
        ),
      ],
    );
  }

  Widget _info(String label, dynamic value, IconData icon,
      {bool full = false}) {
    return SizedBox(
      width: full ? double.infinity : 175,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0x0A34D399),
          border: Border.all(color: const Color(0x2634D399)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: emerald, size: 10),
                const SizedBox(width: 6),
                Text(
                  label.toUpperCase(),
                  style: const TextStyle(
                    color: text54,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              value.toString(),
              softWrap: true,
              style: const TextStyle(color: text, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _phoneResults(Map<String, dynamic> d) {
    final country = d['country_data'];
    final rows = <MapEntry<String, String>>[
      MapEntry('Country',
          '${d['country_flag'] ?? ''} ${d['country_name'] ?? 'Unknown'}'),
      MapEntry('Country Code', d['country_code']?.toString() ?? '-'),
      MapEntry('Local Number', d['local_number']?.toString() ?? '-'),
      MapEntry('Length', '${d['number_length'] ?? '-'} digits'),
      MapEntry('Type', d['type']?.toString() ?? '-'),
      MapEntry(
          'Possible Carrier', d['possible_carrier']?.toString() ?? 'Unknown'),
    ];

    if (country is Map) {
      rows.addAll([
        MapEntry('Capital', country['capital']?.toString() ?? '-'),
        MapEntry('Region', country['region']?.toString() ?? '-'),
        MapEntry(
          'Population',
          country['population'] == null
              ? '-'
              : country['population'].toString(),
        ),
        MapEntry('Currency', country['currency']?.toString() ?? '-'),
        MapEntry('Language', country['languages']?.toString() ?? '-'),
        MapEntry('Timezone', country['timezones']?.toString() ?? '-'),
      ]);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _section('Phone Analysis', Icons.phone),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0x3334D399)),
            gradient: const LinearGradient(
              colors: [Color(0x1434D399), Color(0x80080202)],
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: const Color(0x2634D399),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.phone, color: emerald),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            d['formatted']?.toString() ?? input.text,
                            style: const TextStyle(
                              color: text,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${d['country_flag'] ?? ''} Valid Format',
                            style: const TextStyle(
                              color: green,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              ...rows.map(
                (r) => Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: const BoxDecoration(
                    border: Border(
                      top: BorderSide(color: Color(0x0F34D399)),
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 100,
                        child: Text(
                          r.key,
                          style: const TextStyle(
                            color: text54,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          r.value,
                          style: const TextStyle(color: text, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Drawer _drawer() {
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
              child: Column(
                children: [
                  Image.network(
                    'https://files.catbox.moe/xl24wa.png',
                    height: 110,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.shield, color: primary, size: 70),
                  ),
                  const SizedBox(height: 10),
                  _drawerInfo(Icons.person, 'USER', username),
                  const SizedBox(height: 5),
                  _drawerInfo(Icons.access_time, 'EXPIRED', expired),
                ],
              ),
            ),
            _drawerItem(Icons.home, 'Dashboard', '/dashboard'),
            _drawerItem(Icons.build, 'Tools', '/tools'),
            _drawerItem(Icons.bug_report, 'Bug Attack', '/execution'),
          ],
        ),
      ),
    );
  }

  Widget _drawerInfo(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0x0FE03030),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x38E03030)),
      ),
      child: Row(
        children: [
          Icon(icon, color: primary, size: 18),
          const SizedBox(width: 10),
          Text(label, style: const TextStyle(color: text70)),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: text, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, String route) {
    return ListTile(
      leading: Icon(icon, color: primary),
      title: Text(title, style: const TextStyle(color: text70)),
      onTap: () {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
    );
  }
}
