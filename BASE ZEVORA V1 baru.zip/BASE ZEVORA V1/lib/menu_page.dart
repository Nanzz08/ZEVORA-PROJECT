import 'dart:ui';
import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Menu utama modular untuk tab MENU dashboard.
/// Seluruh aksi diteruskan ke callback Dashboard agar sesi, role, dan navigasi
/// tetap dikelola oleh pemilik alur aplikasi.
class MenuMainPage extends StatefulWidget {
  final VoidCallback? onBug;
  final VoidCallback? onRat;
  final VoidCallback? onTools;
  final VoidCallback? onTheme;
  final VoidCallback? onProfile;
  final VoidCallback? onSettings;

  const MenuMainPage({
    super.key,
    this.onBug,
    this.onRat,
    this.onTools,
    this.onTheme,
    this.onProfile,
    this.onSettings,
  });

  @override
  State<MenuMainPage> createState() => _MenuMainPageState();
}

class _MenuMainPageState extends State<MenuMainPage> {
  late final PageController _controller;
  double _page = 0;

  List<_MenuItem> get _items => [
    _MenuItem(Icons.bug_report_rounded, 'Bug Center', 'Pilih mode WhatsApp Number, Group, atau Test Function', 'PILIH MODE', const Color(0xFF42D6A4), widget.onBug),
    _MenuItem(Icons.phone_android_rounded, 'RAT Control', 'Device dashboard & remote tools', 'OPEN RAT', const Color(0xFF69B8FF), widget.onRat),
    _MenuItem(Icons.grid_view_rounded, 'Tools Gateway', 'Utilities, media, games, dan perangkat pendukung', 'JELAJAHI TOOLS', const Color(0xFFB49AFF), widget.onTools),
    _MenuItem(Icons.palette_rounded, 'Theme Studio', 'Warna, tema dan personalisasi', 'CUSTOMIZE', const Color(0xFFFFC46B), widget.onTheme),
    _MenuItem(Icons.lock_reset_rounded, 'Account Security', 'Perbarui password akun', 'MANAGE ACCOUNT', const Color(0xFF76D9E8), widget.onProfile),
    _MenuItem(Icons.tune_rounded, 'Background Studio', 'Atur background dan tampilan', 'OPEN SETTINGS', const Color(0xFFFF8FA3), widget.onSettings),
  ];

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: .78);
    _controller.addListener(() {
      if (mounted) setState(() => _page = _controller.page ?? 0);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _activate(_MenuItem item) {
    if (item.action != null) item.action!();
  }

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    final items = _items;
    final active = _page.round().clamp(0, items.length - 1);
    final width = MediaQuery.sizeOf(context).width;
    final scale = (width / 390).clamp(.88, 1.12);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(18 * scale, 18 * scale, 18 * scale, 34 * scale),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(colors: [theme.accent, theme.accentDark]),
                  boxShadow: [BoxShadow(color: theme.accent.withOpacity(.25), blurRadius: 18, offset: const Offset(0, 7))],
                ),
                child: const Icon(Icons.apps_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('MENU & AKSES CEPAT', style: TextStyle(color: theme.text, fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.0)),
                const SizedBox(height: 3),
                Text('Pilih fitur dan workspace dari satu tempat', style: TextStyle(color: theme.textSub, fontSize: 11.5)),
              ])),
              _GlassPill(label: '${items.length} MODULES', color: theme.accent),
            ],
          ),
          SizedBox(height: 22 * scale),
          SizedBox(
            height: 330 * scale,
            child: PageView.builder(
              controller: _controller,
              itemCount: items.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                final distance = (_page - index).abs().clamp(0.0, 1.0);
                return Transform.scale(
                  scale: 1 - distance * .045,
                  child: _MenuFeatureCard(item: items[index], onTap: () => _activate(items[index])),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          Center(child: Row(mainAxisSize: MainAxisSize.min, children: List.generate(items.length, (i) => AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: i == active ? 21 : 6,
            height: 6,
            decoration: BoxDecoration(color: i == active ? theme.accent : theme.textDim.withOpacity(.45), borderRadius: BorderRadius.circular(10)),
          )))),
          SizedBox(height: 26 * scale),
          Row(children: [
            Text('QUICK ACCESS', style: TextStyle(color: theme.text, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            const SizedBox(width: 8),
            Expanded(child: Container(height: 1, color: theme.border)),
          ]),
          const SizedBox(height: 13),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.8),
            itemBuilder: (context, index) => _MenuQuickTile(item: items[index], onTap: () => _activate(items[index])),
          ),
        ],
      ),
    );
  }
}

class _MenuItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final String actionLabel;
  final Color color;
  final VoidCallback? action;
  const _MenuItem(this.icon, this.title, this.subtitle, this.actionLabel, this.color, this.action);
}

class _MenuFeatureCard extends StatelessWidget {
  final _MenuItem item;
  final VoidCallback onTap;
  const _MenuFeatureCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(28),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(28),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
              child: Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [item.color.withOpacity(.22), theme.card.withOpacity(.94), theme.bg.withOpacity(.98)]),
                  border: Border.all(color: item.color.withOpacity(.48)),
                  boxShadow: [BoxShadow(color: item.color.withOpacity(.13), blurRadius: 24, offset: const Offset(0, 10))],
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(width: 58, height: 58, decoration: BoxDecoration(color: item.color.withOpacity(.16), borderRadius: BorderRadius.circular(19), border: Border.all(color: item.color.withOpacity(.5))), child: Icon(item.icon, color: item.color, size: 29)),
                    const Spacer(),
                    Icon(Icons.north_east_rounded, color: theme.textSub, size: 19),
                  ]),
                  const Spacer(),
                  Text(item.title, style: TextStyle(color: theme.text, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: -.3)),
                  const SizedBox(height: 5),
                  Text(item.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.textSub, fontSize: 11.5, height: 1.35)),
                  const SizedBox(height: 13),
                  Row(children: [Text(item.actionLabel, style: TextStyle(color: item.color, fontSize: 9.5, fontWeight: FontWeight.w900, letterSpacing: 1.1)), const SizedBox(width: 6), Icon(Icons.arrow_forward_rounded, color: item.color, size: 13)]),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuQuickTile extends StatelessWidget {
  final _MenuItem item;
  final VoidCallback onTap;
  const _MenuQuickTile({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.I;
    return Material(
      color: theme.card.withOpacity(.7),
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(17), border: Border.all(color: item.color.withOpacity(.28))),
          child: Row(children: [
            Container(width: 36, height: 36, decoration: BoxDecoration(color: item.color.withOpacity(.13), borderRadius: BorderRadius.circular(12)), child: Icon(item.icon, color: item.color, size: 19)),
            const SizedBox(width: 9),
            Expanded(child: Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: theme.text, fontSize: 11.5, fontWeight: FontWeight.w800))),
          ]),
        ),
      ),
    );
  }
}

class _GlassPill extends StatelessWidget {
  final String label;
  final Color color;
  const _GlassPill({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(30), border: Border.all(color: color.withOpacity(.35))),
    child: Text(label, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .8)),
  );
}
