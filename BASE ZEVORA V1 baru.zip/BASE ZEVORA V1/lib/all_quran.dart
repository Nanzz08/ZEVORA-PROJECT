import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';

// ─── Palette (hitam + merah, mirip video) ────────────────────────────────────
class _QC {
  static const bg = Color(0xFF000000);       // Background Hitam Pekat
  static const surface = Color(0xFF121212);  // Panel Hitam Keabu-abuan
  static const card = Color(0xFF1E1E1E);     // Kotak Card Abu-abu Gelap
  static const border = Color(0xFF333333);   // Garis Batas Abu-abu
  static const red = Color(0xFFFFFFFF);      // (Dulu Merah) Sekarang Putih bersih
  static const redDim = Color(0xFFB3B3B3);   // (Dulu Merah Redup) Sekarang Abu-abu terang
  static const text = Color(0xFFFFFFFF);     // Teks Utama Putih
  static const textSub = Color(0xFFCCCCCC);  // Teks Sub (Abu-abu terang)
  static const textDim = Color(0xFF888888);  // Teks Redup (Abu-abu gelap)
}

// ─── Model ───────────────────────────────────────────────────────────────────
class QuranAyat {
  final int nomor;
  final String arab;
  final String latin;
  final String arti;

  const QuranAyat({
    required this.nomor,
    required this.arab,
    required this.latin,
    required this.arti,
  });
}

class QuranSurah {
  final int nomor;
  final String nama;
  final String namaLatin;
  final String arti;
  final String tempatTurun;
  final int jumlahAyat;
  final String deskripsi;
  final List<QuranAyat> ayat;

  const QuranSurah({
    required this.nomor,
    required this.nama,
    required this.namaLatin,
    required this.arti,
    required this.tempatTurun,
    required this.jumlahAyat,
    required this.deskripsi,
    required this.ayat,
  });
}

// Metadata 114 surah
class _SurahMeta {
  final int nomor;
  final String nama;
  final String namaLatin;
  final String arti;
  final int jumlahAyat;
  final String tempat;
  const _SurahMeta(this.nomor, this.nama, this.namaLatin, this.arti, this.jumlahAyat, this.tempat);
}

const List<_SurahMeta> _meta = [
  _SurahMeta(1, 'الفاتحة', 'Al-Fatihah', 'Pembukaan', 7, 'M'),
  _SurahMeta(2, 'البقرة', 'Al-Baqarah', 'Sapi Betina', 286, 'D'),
  _SurahMeta(3, 'آل عمران', "Ali 'Imran", 'Keluarga Imran', 200, 'D'),
  _SurahMeta(4, 'النساء', "An-Nisa'", 'Wanita', 176, 'D'),
  _SurahMeta(5, 'المائدة', "Al-Ma'idah", 'Hidangan', 120, 'D'),
  _SurahMeta(6, 'الأنعام', "Al-An'am", 'Binatang Ternak', 165, 'M'),
  _SurahMeta(7, 'الأعراف', "Al-A'raf", 'Tempat Tertinggi', 206, 'M'),
  _SurahMeta(8, 'الأنفال', 'Al-Anfal', 'Harta Rampasan Perang', 75, 'D'),
  _SurahMeta(9, 'التوبة', 'At-Taubah', 'Pengampunan', 129, 'D'),
  _SurahMeta(10, 'يونس', 'Yunus', 'Nabi Yunus', 109, 'M'),
  _SurahMeta(11, 'هود', 'Hud', 'Nabi Hud', 123, 'M'),
  _SurahMeta(12, 'يوسف', 'Yusuf', 'Nabi Yusuf', 111, 'M'),
  _SurahMeta(13, 'الرعد', "Ar-Ra'd", 'Guruh', 43, 'D'),
  _SurahMeta(14, 'ابراهيم', 'Ibrahim', 'Nabi Ibrahim', 52, 'M'),
  _SurahMeta(15, 'الحجر', 'Al-Hijr', 'Hijr (Nama Daerah)', 99, 'M'),
  _SurahMeta(16, 'النحل', 'An-Nahl', 'Lebah', 128, 'M'),
  _SurahMeta(17, 'الإسراء', "Al-Isra'", 'Perjalanan Malam', 111, 'M'),
  _SurahMeta(18, 'الكهف', 'Al-Kahf', 'Gua', 110, 'M'),
  _SurahMeta(19, 'مريم', 'Maryam', 'Maryam', 98, 'M'),
  _SurahMeta(20, 'طه', 'Taha', 'Taha', 135, 'M'),
  _SurahMeta(21, 'الأنبياء', "Al-Anbiya'", 'Para Nabi', 112, 'M'),
  _SurahMeta(22, 'الحج', 'Al-Hajj', 'Haji', 78, 'D'),
  _SurahMeta(23, 'المؤمنون', "Al-Mu'minun", 'Orang-orang Mukmin', 118, 'M'),
  _SurahMeta(24, 'النور', 'An-Nur', 'Cahaya', 64, 'D'),
  _SurahMeta(25, 'الفرقان', 'Al-Furqan', 'Pembeda', 77, 'M'),
  _SurahMeta(26, 'الشعراء', "Asy-Syu'ara'", 'Para Penyair', 227, 'M'),
  _SurahMeta(27, 'النمل', 'An-Naml', 'Semut', 93, 'M'),
  _SurahMeta(28, 'القصص', 'Al-Qasas', 'Kisah-kisah', 88, 'M'),
  _SurahMeta(29, 'العنكبوت', "Al-'Ankabut", 'Laba-laba', 69, 'M'),
  _SurahMeta(30, 'الروم', 'Ar-Rum', 'Bangsa Romawi', 60, 'M'),
  _SurahMeta(31, 'لقمان', 'Luqman', 'Luqman', 34, 'M'),
  _SurahMeta(32, 'السجدة', 'As-Sajdah', 'Sajdah', 30, 'M'),
  _SurahMeta(33, 'الأحزاب', 'Al-Ahzab', 'Golongan yang Bersekutu', 73, 'D'),
  _SurahMeta(34, 'سبإ', "Saba'", 'Saba', 54, 'M'),
  _SurahMeta(35, 'فاطر', 'Fatir', 'Pencipta', 45, 'M'),
  _SurahMeta(36, 'يس', 'Yasin', 'Yasin', 83, 'M'),
  _SurahMeta(37, 'الصافات', 'As-Saffat', 'Barisan-barisan', 182, 'M'),
  _SurahMeta(38, 'ص', 'Sad', 'Sad', 88, 'M'),
  _SurahMeta(39, 'الزمر', 'Az-Zumar', 'Rombongan', 75, 'M'),
  _SurahMeta(40, 'غافر', 'Gafir', 'Yang Mengampuni', 85, 'M'),
  _SurahMeta(41, 'فصلت', 'Fussilat', 'Yang Dijelaskan', 54, 'M'),
  _SurahMeta(42, 'الشورى', 'Asy-Syura', 'Musyawarah', 53, 'M'),
  _SurahMeta(43, 'الزخرف', 'Az-Zukhruf', 'Perhiasan', 89, 'M'),
  _SurahMeta(44, 'الدخان', 'Ad-Dukhan', 'Kabut', 59, 'M'),
  _SurahMeta(45, 'الجاثية', 'Al-Jasiyah', 'Yang Berlutut', 37, 'M'),
  _SurahMeta(46, 'الأحقاف', 'Al-Ahqaf', 'Bukit-bukit Pasir', 35, 'M'),
  _SurahMeta(47, 'محمد', 'Muhammad', 'Nabi Muhammad', 38, 'D'),
  _SurahMeta(48, 'الفتح', 'Al-Fath', 'Kemenangan', 29, 'D'),
  _SurahMeta(49, 'الحجرات', 'Al-Hujurat', 'Kamar-kamar', 18, 'D'),
  _SurahMeta(50, 'ق', 'Qaf', 'Qaf', 45, 'M'),
  _SurahMeta(51, 'الذاريات', 'Az-Zariyat', 'Angin yang Menerbangkan', 60, 'M'),
  _SurahMeta(52, 'الطور', 'At-Tur', 'Bukit', 49, 'M'),
  _SurahMeta(53, 'النجم', 'An-Najm', 'Bintang', 62, 'M'),
  _SurahMeta(54, 'القمر', 'Al-Qamar', 'Bulan', 55, 'M'),
  _SurahMeta(55, 'الرحمن', 'Ar-Rahman', 'Yang Maha Pemurah', 78, 'D'),
  _SurahMeta(56, 'الواقعة', "Al-Waqi'ah", 'Hari Kiamat', 96, 'M'),
  _SurahMeta(57, 'الحديد', 'Al-Hadid', 'Besi', 29, 'D'),
  _SurahMeta(58, 'المجادلة', 'Al-Mujadalah', 'Wanita yang Mengajukan Gugatan', 22, 'D'),
  _SurahMeta(59, 'الحشر', 'Al-Hasyr', 'Pengusiran', 24, 'D'),
  _SurahMeta(60, 'الممتحنة', 'Al-Mumtahanah', 'Wanita yang Diuji', 13, 'D'),
  _SurahMeta(61, 'الصف', 'As-Saff', 'Barisan', 14, 'D'),
  _SurahMeta(62, 'الجمعة', "Al-Jumu'ah", 'Hari Jumat', 11, 'D'),
  _SurahMeta(63, 'المنافقون', 'Al-Munafiqun', 'Orang-orang Munafik', 11, 'D'),
  _SurahMeta(64, 'التغابن', 'At-Tagabun', 'Hari Dinampakkan Kesalahan', 18, 'D'),
  _SurahMeta(65, 'الطلاق', 'At-Talaq', 'Talak', 12, 'D'),
  _SurahMeta(66, 'التحريم', 'At-Tahrim', 'Mengharamkan', 12, 'D'),
  _SurahMeta(67, 'الملك', 'Al-Mulk', 'Kerajaan', 30, 'M'),
  _SurahMeta(68, 'القلم', 'Al-Qalam', 'Pena', 52, 'M'),
  _SurahMeta(69, 'الحاقة', 'Al-Haqqah', 'Hari Kiamat', 52, 'M'),
  _SurahMeta(70, 'المعارج', "Al-Ma'arij", 'Tempat Naik', 44, 'M'),
  _SurahMeta(71, 'نوح', 'Nuh', 'Nabi Nuh', 28, 'M'),
  _SurahMeta(72, 'الجن', 'Al-Jinn', 'Jin', 28, 'M'),
  _SurahMeta(73, 'المزمل', 'Al-Muzzammil', 'Orang yang Berselimut', 20, 'M'),
  _SurahMeta(74, 'المدثر', 'Al-Muddassir', 'Orang yang Berkemul', 56, 'M'),
  _SurahMeta(75, 'القيامة', 'Al-Qiyamah', 'Hari Kiamat', 40, 'M'),
  _SurahMeta(76, 'الانسان', 'Al-Insan', 'Manusia', 31, 'D'),
  _SurahMeta(77, 'المرسلات', 'Al-Mursalat', 'Malaikat yang Diutus', 50, 'M'),
  _SurahMeta(78, 'النبإ', "An-Naba'", 'Berita Besar', 40, 'M'),
  _SurahMeta(79, 'النازعات', "An-Nazi'at", 'Malaikat yang Mencabut', 46, 'M'),
  _SurahMeta(80, 'عبس', "'Abasa", 'Ia Bermuka Masam', 42, 'M'),
  _SurahMeta(81, 'التكوير', 'At-Takwir', 'Menggulung', 29, 'M'),
  _SurahMeta(82, 'الإنفطار', 'Al-Infitar', 'Terbelah', 19, 'M'),
  _SurahMeta(83, 'المطففين', 'Al-Mutaffifin', 'Orang-orang yang Curang', 36, 'M'),
  _SurahMeta(84, 'الإنشقاق', 'Al-Insyiqaq', 'Terbelah', 25, 'M'),
  _SurahMeta(85, 'البروج', 'Al-Buruj', 'Gugusan Bintang', 22, 'M'),
  _SurahMeta(86, 'الطارق', 'At-Tariq', 'Yang Datang di Malam Hari', 17, 'M'),
  _SurahMeta(87, 'الأعلى', "Al-A'la", 'Yang Paling Tinggi', 19, 'M'),
  _SurahMeta(88, 'الغاشية', 'Al-Gasyiyah', 'Hari Pembalasan', 26, 'M'),
  _SurahMeta(89, 'الفجر', 'Al-Fajr', 'Fajar', 30, 'M'),
  _SurahMeta(90, 'البلد', 'Al-Balad', 'Negeri', 20, 'M'),
  _SurahMeta(91, 'الشمس', 'Asy-Syams', 'Matahari', 15, 'M'),
  _SurahMeta(92, 'الليل', 'Al-Lail', 'Malam', 21, 'M'),
  _SurahMeta(93, 'الضحى', 'Ad-Duha', 'Waktu Duha', 11, 'M'),
  _SurahMeta(94, 'الشرح', 'Asy-Syarh', 'Melapangkan', 8, 'M'),
  _SurahMeta(95, 'التين', 'At-Tin', 'Buah Tin', 8, 'M'),
  _SurahMeta(96, 'العلق', "Al-'Alaq", 'Segumpal Darah', 19, 'M'),
  _SurahMeta(97, 'القدر', 'Al-Qadr', 'Kemuliaan', 5, 'M'),
  _SurahMeta(98, 'البينة', 'Al-Bayyinah', 'Bukti yang Nyata', 8, 'D'),
  _SurahMeta(99, 'الزلزلة', 'Az-Zalzalah', 'Kegoncangan', 8, 'D'),
  _SurahMeta(100, 'العاديات', "Al-'Adiyat", 'Kuda Perang', 11, 'M'),
  _SurahMeta(101, 'القارعة', "Al-Qari'ah", 'Hari Kiamat', 11, 'M'),
  _SurahMeta(102, 'التكاثر', 'At-Takasur', 'Bermegah-megahan', 8, 'M'),
  _SurahMeta(103, 'العصر', "Al-'Asr", 'Masa', 3, 'M'),
  _SurahMeta(104, 'الهمزة', 'Al-Humazah', 'Pengumpat', 9, 'M'),
  _SurahMeta(105, 'الفيل', 'Al-Fil', 'Gajah', 5, 'M'),
  _SurahMeta(106, 'قريش', 'Quraisy', 'Suku Quraisy', 4, 'M'),
  _SurahMeta(107, 'الماعون', "Al-Ma'un", 'Barang yang Berguna', 7, 'M'),
  _SurahMeta(108, 'الكوثر', 'Al-Kausar', 'Nikmat yang Banyak', 3, 'M'),
  _SurahMeta(109, 'الكافرون', 'Al-Kafirun', 'Orang-orang Kafir', 6, 'M'),
  _SurahMeta(110, 'النصر', 'An-Nasr', 'Pertolongan', 3, 'D'),
  _SurahMeta(111, 'المسد', 'Al-Masad', 'Gejolak Api', 5, 'M'),
  _SurahMeta(112, 'الإخلاص', 'Al-Ikhlas', 'Ikhlas', 4, 'M'),
  _SurahMeta(113, 'الفلق', 'Al-Falaq', 'Waktu Subuh', 5, 'M'),
  _SurahMeta(114, 'الناس', 'An-Nas', 'Manusia', 6, 'M'),
];

final Map<int, List<QuranAyat>> _fullAyat = {
  1: const [
    QuranAyat(nomor: 1, arab: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', latin: "Bismillāhir-raḥmānir-raḥīm(i)", arti: 'Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang.'),
    QuranAyat(nomor: 2, arab: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', latin: "Al-ḥamdu lillāhi rabbil-'ālamīn(a)", arti: 'Segala puji bagi Allah, Tuhan semesta alam.'),
    QuranAyat(nomor: 3, arab: 'الرَّحْمَٰنِ الرَّحِيمِ', latin: 'Ar-raḥmānir-raḥīm(i)', arti: 'Yang Maha Pengasih lagi Maha Penyayang,'),
    QuranAyat(nomor: 4, arab: 'مَالِكِ يَوْمِ الدِّينِ', latin: 'Māliki yaumid-dīn(i)', arti: 'Pemilik hari Pembalasan.'),
    QuranAyat(nomor: 5, arab: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', latin: "Iyyāka na'budu wa iyyāka nasta'īn(u)", arti: 'Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami mohon pertolongan.'),
    QuranAyat(nomor: 6, arab: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', latin: 'Ihdinaṣ-ṣirāṭal-mustaqīm(a)', arti: 'Tunjukilah kami jalan yang lurus,'),
    QuranAyat(nomor: 7, arab: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', latin: "Ṣirāṭallażīna an'amta 'alaihim gairil-magḍụbi 'alaihim wa laḍ-ḍāllīn(a)", arti: '(yaitu) jalan orang-orang yang telah Engkau beri nikmat kepadanya, bukan (jalan) mereka yang dimurkai, dan bukan (pula jalan) mereka yang sesat.'),
  ],
  112: const [
    QuranAyat(nomor: 1, arab: 'قُلْ هُوَ اللَّهُ أَحَدٌ', latin: 'Qul huwallāhu aḥad', arti: 'Katakanlah (Muhammad), "Dialah Allah, Yang Maha Esa."'),
    QuranAyat(nomor: 2, arab: 'اللَّهُ الصَّمَدُ', latin: 'Allāhuṣ-ṣamad', arti: 'Allah tempat meminta segala sesuatu.'),
    QuranAyat(nomor: 3, arab: 'لَمْ يَلِدْ وَلَمْ يُولَدْ', latin: 'Lam yalid wa lam yūlad', arti: '(Allah) tidak beranak dan tidak pula diperanakkan.'),
    QuranAyat(nomor: 4, arab: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', latin: "Wa lam yakul lahū kufuwan aḥad", arti: 'Dan tidak ada sesuatu yang setara dengan Dia.'),
  ],
  113: const [
    QuranAyat(nomor: 1, arab: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ', latin: "Qul a'ụżu birabbil-falaq", arti: 'Katakanlah, "Aku berlindung kepada Tuhan yang menguasai subuh (fajar)."'),
    QuranAyat(nomor: 2, arab: 'مِن شَرِّ مَا خَلَقَ', latin: 'Min syarri mā khalaq', arti: 'Dari kejahatan (makhluk yang) Dia ciptakan,'),
    QuranAyat(nomor: 3, arab: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', latin: 'Wa min syarri gāsiqin iżā waqab', arti: 'Dan dari kejahatan malam apabila telah gelap gulita,'),
    QuranAyat(nomor: 4, arab: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ', latin: "Wa min syarrin-naffāṡāti fil-'uqad", arti: 'Dan dari kejahatan (perempuan-perempuan) penyihir yang meniup pada buhul-buhul (talinya),'),
    QuranAyat(nomor: 5, arab: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', latin: 'Wa min syarri ḥāsidin iżā ḥasad', arti: 'Dan dari kejahatan orang yang dengki apabila dia dengki.'),
  ],
  114: const [
    QuranAyat(nomor: 1, arab: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ', latin: "Qul a'ụżu birabbin-nās", arti: 'Katakanlah, "Aku berlindung kepada Tuhannya manusia,"'),
    QuranAyat(nomor: 2, arab: 'مَلِكِ النَّاسِ', latin: 'Malikin-nās', arti: 'Raja manusia,'),
    QuranAyat(nomor: 3, arab: 'إِلَٰهِ النَّاسِ', latin: 'Ilāhin-nās', arti: 'Sembahan manusia,'),
    QuranAyat(nomor: 4, arab: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ', latin: 'Min syarril-waswāsil-khannās', arti: 'Dari kejahatan (bisikan) setan yang bersembunyi,'),
    QuranAyat(nomor: 5, arab: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ', latin: 'Allażī yuwaswisu fī ṣudụrin-nās', arti: 'Yang membisikkan (kejahatan) ke dalam dada manusia,'),
    QuranAyat(nomor: 6, arab: 'مِنَ الْجِنَّةِ وَالنَّاسِ', latin: 'Minal-jinnati wan-nās', arti: 'Dari (golongan) jin dan manusia.'),
  ],
  36: const [
    QuranAyat(nomor: 1, arab: 'يس', latin: 'Yā sīn', arti: 'Ya Sin.'),
    QuranAyat(nomor: 2, arab: 'وَالْقُرْآنِ الْحَكِيمِ', latin: "Wal-qur'ānil-ḥakīm", arti: "Demi Al-Qur'an yang penuh hikmah,"),
    QuranAyat(nomor: 3, arab: 'إِنَّكَ لَمِنَ الْمُرْسَلِينَ', latin: 'Innaka laminal-mursalīn', arti: 'Sungguh, engkau (Muhammad) adalah salah seorang dari rasul-rasul,'),
    QuranAyat(nomor: 4, arab: 'عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ', latin: "'Alā ṣirāṭim mustaqīm", arti: 'Yang berada di atas jalan yang lurus,'),
    QuranAyat(nomor: 5, arab: 'تَنزِيلَ الْعَزِيزِ الرَّحِيمِ', latin: "Tanzīlal-'azīzir-raḥīm", arti: '(sebagai wahyu) yang diturunkan oleh (Allah) Yang Mahaperkasa, Maha Penyayang,'),
  ],
  67: const [
    QuranAyat(nomor: 1, arab: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', latin: "Tabārakallażī biyadihil-mulku wa huwa 'alā kulli syai'in qadīr", arti: 'Mahasuci Allah yang menguasai (segala) kerajaan, dan Dia Mahakuasa atas segala sesuatu.'),
    QuranAyat(nomor: 2, arab: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ', latin: "Allażī khalaqal-mauta wal-ḥayāta liyabluwakum ayyukum aḥsanu 'amalā, wa huwal-'azīzul-gafūr", arti: 'Yang menciptakan mati dan hidup, untuk menguji kamu, siapa di antara kamu yang lebih baik amalnya. Dan Dia Mahaperkasa, Maha Pengampun.'),
  ],
  55: const [
    QuranAyat(nomor: 1, arab: 'الرَّحْمَٰنُ', latin: 'Ar-raḥmān', arti: '(Allah) Yang Maha Pengasih,'),
    QuranAyat(nomor: 2, arab: 'عَلَّمَ الْقُرْآنَ', latin: "Allamal-qur'ān", arti: "Yang telah mengajarkan Al-Qur'an."),
    QuranAyat(nomor: 3, arab: 'خَلَقَ الْإِنسَانَ', latin: 'Khalaqal-insān', arti: 'Dia menciptakan manusia,'),
    QuranAyat(nomor: 4, arab: 'عَلَّمَهُ الْبَيَانَ', latin: "'Allamahul-bayān", arti: 'Mengajarnya pandai berbicara.'),
  ],
  93: const [
    QuranAyat(nomor: 1, arab: 'وَالضُّحَىٰ', latin: 'Waḍ-ḍuḥā', arti: 'Demi waktu duha (ketika matahari naik sepenggalah),'),
    QuranAyat(nomor: 2, arab: 'وَاللَّيْلِ إِذَا سَجَىٰ', latin: 'Wal-laili iżā sajā', arti: 'Dan demi malam apabila telah sunyi,'),
    QuranAyat(nomor: 3, arab: 'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ', latin: "Mā wadda'aka rabbuka wa mā qalā", arti: 'Tuhanmu tidak meninggalkan engkau (Muhammad) dan tidak (pula) membenci engkau,'),
    QuranAyat(nomor: 4, arab: 'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ', latin: "Wa lal-ākhiratu khairul laka minal-ūlā", arti: 'Dan sungguh, yang kemudian itu lebih baik bagimu dari yang permulaan.'),
    QuranAyat(nomor: 5, arab: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', latin: "Wa lasaufa yu'ṭīka rabbuka fa tarḍā", arti: 'Dan sungguh, kelak Tuhanmu pasti memberikan karunia-Nya kepadamu, sehingga engkau menjadi puas.'),
  ],
  94: const [
    QuranAyat(nomor: 1, arab: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ', latin: 'Alam nasyraḥ laka ṣadrak', arti: 'Bukankah Kami telah melapangkan dadamu (Muhammad)?'),
    QuranAyat(nomor: 2, arab: 'وَوَضَعْنَا عَنكَ وِزْرَكَ', latin: "Wa waḍa'nā 'anka wizrak", arti: 'Dan Kami pun telah menurunkan bebanmu darimu,'),
    QuranAyat(nomor: 3, arab: 'الَّذِي أَنقَضَ ظَهْرَكَ', latin: 'Allażī anqaḍa ẓahrak', arti: 'Yang memberatkan punggungmu,'),
    QuranAyat(nomor: 4, arab: 'وَرَفَعْنَا لَكَ ذِكْرَكَ', latin: "Wa rafa'nā laka żikrak", arti: 'Dan Kami tinggikan sebutan (nama)mu bagimu.'),
    QuranAyat(nomor: 5, arab: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا', latin: "Fa inna ma'al-'usri yusrā", arti: 'Maka sesungguhnya beserta kesulitan ada kemudahan,'),
    QuranAyat(nomor: 6, arab: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا', latin: "Inna ma'al-'usri yusrā", arti: 'Sesungguhnya beserta kesulitan itu ada kemudahan.'),
    QuranAyat(nomor: 7, arab: 'فَإِذَا فَرَغْتَ فَانصَبْ', latin: 'Fa iżā faragta fanṣab', arti: 'Maka apabila engkau telah selesai (dari sesuatu urusan), tetaplah bekerja keras (untuk urusan yang lain),'),
    QuranAyat(nomor: 8, arab: 'وَإِلَىٰ رَبِّكَ فَارْغَبْ', latin: "Wa ilā rabbika fargab", arti: 'Dan hanya kepada Tuhanmulah engkau berharap.'),
  ],
};

List<QuranSurah> get allQuranSurah {
  return _meta.map((m) {
    final ayat = _fullAyat[m.nomor] ??
        List.generate(
          m.jumlahAyat.clamp(0, 3),
          (i) => QuranAyat(
            nomor: i + 1,
            arab: '—',
            latin: 'Ayat ${i + 1}',
            arti: 'Tap untuk putar murottal audio (Mishary Rashid Alafasy). Teks lengkap tersedia untuk surah pilihan.',
          ),
        );
    return QuranSurah(
      nomor: m.nomor,
      nama: m.nama,
      namaLatin: m.namaLatin,
      arti: m.arti,
      tempatTurun: m.tempat == 'M' ? 'Makkiyah' : 'Madaniyah',
      jumlahAyat: m.jumlahAyat,
      deskripsi: '',
      ayat: ayat,
    );
  }).toList();
}

// ─── Halaman Utama ───────────────────────────────────────────────────────────
class AllQuranPage extends StatefulWidget {
  const AllQuranPage({super.key});

  @override
  State<AllQuranPage> createState() => _AllQuranPageState();
}

class _AllQuranPageState extends State<AllQuranPage> {
  String _search = '';
  final TextEditingController _searchCtrl = TextEditingController();

  List<_SurahMeta> get _filtered {
    if (_search.isEmpty) return _meta;
    final q = _search.toLowerCase();
    return _meta
        .where((s) =>
            s.namaLatin.toLowerCase().contains(q) ||
            s.arti.toLowerCase().contains(q) ||
            s.nama.contains(q) ||
            s.nomor.toString() == q)
        .toList();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 12, 4),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _QC.text, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const Expanded(
                    child: Text(
                      'AL-QURAN DIGITAL',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _QC.text, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1.2),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.person_outline_rounded, color: _QC.red, size: 22),
                    onPressed: () {},
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Container(
                decoration: BoxDecoration(
                  color: _QC.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _QC.border),
                ),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _search = v),
                  style: const TextStyle(color: _QC.text, fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Cari surah...',
                    hintStyle: TextStyle(color: _QC.textDim),
                    prefixIcon: Icon(Icons.search_rounded, color: _QC.textSub, size: 20),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: Row(
                children: [
                  Container(width: 8, height: 8, decoration: const BoxDecoration(color: _QC.red, shape: BoxShape.circle)),
                  const SizedBox(width: 8),
                  const Text('Qari: Mishary Rashid Alafasy', style: TextStyle(color: _QC.textSub, fontSize: 12)),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                itemCount: _filtered.length,
                itemBuilder: (context, i) {
                  final s = _filtered[i];
                  return _SurahTile(
                    meta: s,
                    onTap: () {
                      final full = allQuranSurah.firstWhere((x) => x.nomor == s.nomor);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => SurahDetailPage(surah: full)));
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SurahTile extends StatelessWidget {
  final _SurahMeta meta;
  final VoidCallback onTap;
  const _SurahTile({required this.meta, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _QC.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _QC.border.withOpacity(0.6)),
        ),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: _QC.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: _QC.red.withOpacity(0.4)),
              ),
              child: Center(child: Text('${meta.nomor}', style: const TextStyle(color: _QC.red, fontWeight: FontWeight.w700, fontSize: 13))),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(meta.namaLatin, style: const TextStyle(color: _QC.text, fontWeight: FontWeight.w600, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text('${meta.arti} · ${meta.jumlahAyat} ayat', style: const TextStyle(color: _QC.textSub, fontSize: 11)),
                ],
              ),
            ),
            Text(meta.nama, style: const TextStyle(color: _QC.red, fontSize: 18, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

// ─── Detail + Audio ──────────────────────────────────────────────────────────
class SurahDetailPage extends StatefulWidget {
  final QuranSurah surah;
  const SurahDetailPage({super.key, required this.surah});

  @override
  State<SurahDetailPage> createState() => _SurahDetailPageState();
}

class _SurahDetailPageState extends State<SurahDetailPage> {
  final AudioPlayer _player = AudioPlayer();
  int? _playingAyat;
  bool _isPlaying = false;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() { _isPlaying = false; _playingAyat = null; });
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String _audioUrl(int surah, int ayat) {
    final s = surah.toString().padLeft(3, '0');
    final a = ayat.toString().padLeft(3, '0');
    return 'https://everyayah.com/data/Alafasy_128kbps/$s$a.mp3';
  }

  Future<void> _playAyat(int ayatNomor) async {
    if (_playingAyat == ayatNomor && _isPlaying) {
      await _player.pause();
      setState(() => _isPlaying = false);
      return;
    }
    setState(() { _loading = true; _playingAyat = ayatNomor; });
    try {
      final url = _audioUrl(widget.surah.nomor, ayatNomor);
      await _player.stop();
      await _player.play(UrlSource(url));
      if (mounted) setState(() { _isPlaying = true; _loading = false; });
    } catch (e) {
      if (mounted) {
        setState(() { _loading = false; _isPlaying = false; _playingAyat = null; });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memutar audio'), backgroundColor: _QC.redDim, behavior: SnackBarBehavior.floating),
        );
      }
    }
  }

  Future<void> _playAll() async {
    if (widget.surah.ayat.isNotEmpty) await _playAyat(widget.surah.ayat.first.nomor);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 12, 4),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _QC.text, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text(s.namaLatin, style: const TextStyle(color: _QC.text, fontSize: 16, fontWeight: FontWeight.w700)),
                        Text('${s.arti} · ${s.jumlahAyat} ayat', style: const TextStyle(color: _QC.textSub, fontSize: 11)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 40),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                itemCount: s.ayat.length,
                itemBuilder: (context, i) {
                  final a = s.ayat[i];
                  final active = _playingAyat == a.nomor;
                  return GestureDetector(
                    onTap: () => _playAyat(a.nomor),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _QC.card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: active ? _QC.red.withOpacity(0.7) : _QC.border.withOpacity(0.5), width: active ? 1.5 : 1),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 26, height: 26,
                                decoration: BoxDecoration(color: _QC.red.withOpacity(0.15), shape: BoxShape.circle),
                                child: Center(child: Text('${a.nomor}', style: const TextStyle(color: _QC.red, fontSize: 11, fontWeight: FontWeight.w700))),
                              ),
                              const Spacer(),
                              if (active && _loading)
                                const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: _QC.red))
                              else if (active && _isPlaying)
                                const Icon(Icons.volume_up_rounded, color: _QC.red, size: 18)
                              else
                                Icon(Icons.play_circle_outline_rounded, color: _QC.textSub.withOpacity(0.6), size: 18),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(a.arab, textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: _QC.text, fontSize: 22, height: 1.8, fontWeight: FontWeight.w500)),
                          if (a.latin.isNotEmpty && a.latin != '—') ...[
                            const SizedBox(height: 8),
                            Text(a.latin, style: TextStyle(color: _QC.red.withOpacity(0.85), fontSize: 12, fontStyle: FontStyle.italic)),
                          ],
                          if (a.arti.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text(a.arti, style: const TextStyle(color: _QC.textSub, fontSize: 12, height: 1.4)),
                          ],
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        color: _QC.surface,
        padding: EdgeInsets.only(left: 16, right: 16, top: 10, bottom: MediaQuery.of(context).padding.bottom + 10),
        child: Row(
          children: [
            const Icon(Icons.mic_none_rounded, color: _QC.textSub, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _playingAyat != null
                    ? (_isPlaying ? 'Memutar ayat $_playingAyat' : 'Jeda ayat $_playingAyat')
                    : 'Tap ayat untuk memutar murottal',
                style: const TextStyle(color: _QC.textSub, fontSize: 12),
              ),
            ),
            IconButton(
              icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled, color: _QC.red, size: 40),
              onPressed: () {
                if (_playingAyat != null) {
                  _playAyat(_playingAyat!);
                } else {
                  _playAll();
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.stop_circle_outlined, color: _QC.textSub, size: 28),
              onPressed: () async {
                await _player.stop();
                setState(() { _isPlaying = false; _playingAyat = null; });
              },
            ),
          ],
        ),
      ),
    );
  }
}
