// tabungan_page.dart — UI baru (DEY SAVINGS style, match video)

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fiona/Qaxer/api.dart';

import 'app_theme.dart';

class TabunganPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const TabunganPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<TabunganPage> createState() => _TabunganPageState();
}

class _TabunganPageState extends State<TabunganPage> {
  double _saldo = 0;
  double _totalMasuk = 0;
  double _totalKeluar = 0;
  bool _loading = true;
  List<_Tx> _riwayat = [];

  final String _baseUrl = Api.api;
  final _fmt = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp',
    decimalDigits: 0,
  );

  Color get _a => AppTheme.I.accent;
  Color get _ad => AppTheme.I.accentDark;
  Color get _bg => AppTheme.I.bg;
  Color get _card => AppTheme.I.card;
  Color get _border => AppTheme.I.border;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await http
          .get(Uri.parse(
              '$_baseUrl/getTabungan?key=${widget.sessionKey}&username=${widget.username}'))
          .timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final data = jsonDecode(r.body);
        if (data['valid'] == true || data['success'] == true) {
          final t = data['tabungan'] ?? data['data'] ?? {};
          _saldo = _toD(t['total'] ?? t['saldo'] ?? 0);
          _totalMasuk = _toD(t['total_masuk'] ?? t['total_disimpan'] ?? _saldo);
          _totalKeluar = _toD(t['total_keluar'] ?? t['total_ditarik'] ?? 0);
        }
      }
    } catch (_) {}

    final prefs = await SharedPreferences.getInstance();
    final key = 'tabungan_${widget.username}';
    _saldo = prefs.getDouble('${key}_saldo') ?? _saldo;
    _totalMasuk = prefs.getDouble('${key}_masuk') ?? _totalMasuk;
    _totalKeluar = prefs.getDouble('${key}_keluar') ?? _totalKeluar;
    final raw = prefs.getStringList('${key}_tx') ?? [];
    _riwayat = [];
    for (final s in raw) {
      try {
        _riwayat.add(_Tx.fromJson(jsonDecode(s)));
      } catch (_) {}
    }
    _riwayat.sort((a, b) => b.at.compareTo(a.at));

    if (mounted) setState(() => _loading = false);
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'tabungan_${widget.username}';
    await prefs.setDouble('${key}_saldo', _saldo);
    await prefs.setDouble('${key}_masuk', _totalMasuk);
    await prefs.setDouble('${key}_keluar', _totalKeluar);
    await prefs.setStringList(
      '${key}_tx',
      _riwayat.take(100).map((e) => jsonEncode(e.toJson())).toList(),
    );
    try {
      await http
          .post(
            Uri.parse('$_baseUrl/saveTabungan'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'username': widget.username,
              'total': _saldo,
              'saldo': _saldo,
              'total_masuk': _totalMasuk,
              'total_keluar': _totalKeluar,
            }),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  double _toD(dynamic v) {
    if (v is num) return v.toDouble();
    return double.tryParse('$v') ?? 0;
  }

  String _rp(double n) => _fmt.format(n);

  void _snack(String m, {Color? c}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(m),
        backgroundColor: c ?? _a,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openDeposit() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _DepositSheet(
        accent: _a,
        accentDark: _ad,
        card: _card,
        bg: _bg,
        onContinue: (amount) {
          Navigator.pop(context);
          _openQris(amount);
        },
      ),
    );
  }

  void _openQris(double amount) {
    final unik = Random().nextInt(90) + 10;
    final total = amount + unik;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) => _QrisSheet(
        accent: _a,
        accentDark: _ad,
        card: _card,
        bg: _bg,
        amount: total,
        baseAmount: amount,
        unik: unik,
        username: widget.username,
        sessionKey: widget.sessionKey,
        baseUrl: _baseUrl,
        onPaid: () async {
          setState(() {
            _saldo += amount;
            _totalMasuk += amount;
            _riwayat.insert(
              0,
              _Tx(
                id: 'in_${DateTime.now().millisecondsSinceEpoch}',
                type: 'masuk',
                amount: amount,
                note: 'Deposit QRIS',
                at: DateTime.now(),
              ),
            );
          });
          await _persist();
          if (mounted) Navigator.pop(context);
          _snack('Deposit berhasil +${_rp(amount)}', c: Colors.green);
        },
      ),
    );
  }

  void _openWithdraw() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _WithdrawSheet(
        accent: _a,
        accentDark: _ad,
        card: _card,
        bg: _bg,
        saldo: _saldo,
        onSubmit: (amount, method, number, name) async {
          if (amount > _saldo) {
            _snack('Saldo tidak mencukupi', c: Colors.red);
            return;
          }
          if (amount <= 0) {
            _snack('Nominal tidak valid', c: Colors.orange);
            return;
          }
          Navigator.pop(context);
          setState(() {
            _saldo -= amount;
            _totalKeluar += amount;
            _riwayat.insert(
              0,
              _Tx(
                id: 'out_${DateTime.now().millisecondsSinceEpoch}',
                type: 'keluar',
                amount: amount,
                note: 'Tarik $method · $number · $name',
                at: DateTime.now(),
              ),
            );
          });
          await _persist();
          try {
            await http
                .post(
                  Uri.parse('$_baseUrl/withdrawTabungan'),
                  headers: {'Content-Type': 'application/json'},
                  body: jsonEncode({
                    'key': widget.sessionKey,
                    'username': widget.username,
                    'amount': amount,
                    'method': method,
                    'number': number,
                    'name': name,
                  }),
                )
                .timeout(const Duration(seconds: 8));
          } catch (_) {}
          _snack('Pengajuan penarikan ${_rp(amount)} via $method terkirim');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppTheme.I.themeId,
      builder: (_, __, ___) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios_new, color: _a, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
            title: const Text(
              'Tabungan',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.refresh, color: _a),
                onPressed: _load,
              ),
            ],
          ),
          body: _loading
              ? Center(child: CircularProgressIndicator(color: _a))
              : RefreshIndicator(
                  color: _a,
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                    children: [
                      _balanceCard(),
                      const SizedBox(height: 16),
                      _actionRow(),
                      const SizedBox(height: 12),
                      _qrisBanner(),
                      const SizedBox(height: 24),
                      Text(
                        'Ringkasan',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _summaryRow(),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Text(
                            'Riwayat transaksi',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            '${_riwayat.length} transaksi',
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (_riwayat.isEmpty)
                        _emptyHistory()
                      else
                        ..._riwayat.map(_txTile),
                    ],
                  ),
                ),
        );
      },
    );
  }

  Widget _balanceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [
            Color.lerp(_ad, const Color(0xFF0A1628), 0.3) ?? _ad,
            Color.lerp(_a, const Color(0xFF0D2137), 0.55) ?? _a,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: _a.withOpacity(0.25),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.savings_outlined, color: _a, size: 22),
              ),
              const SizedBox(width: 10),
              const Text(
                'DEY SAVINGS',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                  fontSize: 14,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.check_circle, color: Colors.greenAccent, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'AKTIF',
                      style: TextStyle(
                        color: Colors.greenAccent,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          Text(
            'Saldo tersedia',
            style: TextStyle(color: Colors.white.withOpacity(0.65), fontSize: 13),
          ),
          const SizedBox(height: 4),
          Text(
            _rp(_saldo),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 36,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _miniStat('Total disimpan', _rp(_totalMasuk))),
              const SizedBox(width: 10),
              Expanded(child: _miniStat('Total ditarik', _rp(_totalKeluar))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.25),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14)),
          const SizedBox(height: 2),
          Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.55), fontSize: 11)),
        ],
      ),
    );
  }

  Widget _actionRow() {
    return Row(
      children: [
        Expanded(
          child: _actionBtn(
            icon: Icons.add_circle_outline,
            title: 'Deposit',
            sub: 'Tambah saldo',
            color: _a,
            onTap: _openDeposit,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _actionBtn(
            icon: Icons.outbox_outlined,
            title: 'Tarik',
            sub: 'Ajukan penarikan',
            color: const Color(0xFF7C4DFF),
            onTap: _openWithdraw,
          ),
        ),
      ],
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String title,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: _card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _border),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14)),
                    Text(sub,
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.45),
                            fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _qrisBanner() {
    return Material(
      color: _card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: _openDeposit,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _border),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: _a.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.qr_code_2, color: _a, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Deposit Cepat (QRIS)',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      'Scan QR untuk menambah saldo otomatis',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.45),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: _a.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _a.withOpacity(0.5)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.qr_code, color: _a, size: 16),
                    const SizedBox(width: 4),
                    Text('QRIS',
                        style: TextStyle(
                            color: _a,
                            fontWeight: FontWeight.bold,
                            fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _summaryRow() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              children: [
                Icon(Icons.south_west, color: Colors.greenAccent.shade400, size: 20),
                const SizedBox(height: 6),
                Text(_rp(_totalMasuk),
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15)),
                const SizedBox(height: 2),
                Text('Total masuk',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.45), fontSize: 11)),
              ],
            ),
          ),
          Container(width: 1, height: 48, color: Colors.white12),
          Expanded(
            child: Column(
              children: [
                Icon(Icons.north_east, color: Colors.orangeAccent.shade200, size: 20),
                const SizedBox(height: 6),
                Text(_rp(_totalKeluar),
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15)),
                const SizedBox(height: 2),
                Text('Total keluar',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.45), fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyHistory() {
    return Container(
      height: 140,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _border),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.receipt_long_outlined,
              color: Colors.white.withOpacity(0.25), size: 40),
          const SizedBox(height: 8),
          Text(
            'Belum ada transaksi tabungan',
            style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _txTile(_Tx t) {
    final masuk = t.type == 'masuk';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _border),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: (masuk ? Colors.green : Colors.orange).withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              masuk ? Icons.south_west : Icons.north_east,
              color: masuk ? Colors.greenAccent : Colors.orangeAccent,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t.note,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 13),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  DateFormat('dd MMM yyyy · HH:mm').format(t.at),
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.4), fontSize: 11),
                ),
              ],
            ),
          ),
          Text(
            '${masuk ? '+' : '-'}${_rp(t.amount)}',
            style: TextStyle(
              color: masuk ? Colors.greenAccent : Colors.orangeAccent,
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _Tx {
  final String id, type, note;
  final double amount;
  final DateTime at;

  _Tx({
    required this.id,
    required this.type,
    required this.amount,
    required this.note,
    required this.at,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'amount': amount,
        'note': note,
        'at': at.toIso8601String(),
      };

  factory _Tx.fromJson(Map<String, dynamic> j) => _Tx(
        id: j['id']?.toString() ?? '',
        type: j['type']?.toString() ?? 'masuk',
        amount: (j['amount'] is num)
            ? (j['amount'] as num).toDouble()
            : double.tryParse('${j['amount']}') ?? 0,
        note: j['note']?.toString() ?? '',
        at: DateTime.tryParse(j['at']?.toString() ?? '') ?? DateTime.now(),
      );
}

class _DepositSheet extends StatefulWidget {
  final Color accent, accentDark, card, bg;
  final ValueChanged<double> onContinue;

  const _DepositSheet({
    required this.accent,
    required this.accentDark,
    required this.card,
    required this.bg,
    required this.onContinue,
  });

  @override
  State<_DepositSheet> createState() => _DepositSheetState();
}

class _DepositSheetState extends State<_DepositSheet> {
  final _ctrl = TextEditingController();
  static const _presets = [2000, 3000, 5000, 10000, 25000, 50000];

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      margin: const EdgeInsets.only(top: 40),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + bottom),
      decoration: BoxDecoration(
        color: widget.bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: widget.accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.account_balance_wallet_outlined,
                    color: widget.accent),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Tambah Tabungan',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 16)),
                    Text('Bayar aman menggunakan QRIS',
                        style: TextStyle(color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text('Nominal deposit',
              style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 8),
          TextField(
            controller: _ctrl,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(
                color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            decoration: InputDecoration(
              hintText: '0',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.25)),
              filled: true,
              fillColor: widget.card,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Minimal Rp2.000 · Maksimal Rp10.000.000',
            style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _presets.map((p) {
              return InkWell(
                onTap: () {
                  _ctrl.text = '$p';
                  setState(() {});
                },
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: widget.card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(
                    NumberFormat.currency(
                            locale: 'id_ID', symbol: 'Rp', decimalDigits: 0)
                        .format(p),
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.accent,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: () {
              final n = double.tryParse(_ctrl.text) ?? 0;
              if (n < 2000) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Minimal deposit Rp2.000')));
                return;
              }
              if (n > 10000000) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Maksimal deposit Rp10.000.000')));
                return;
              }
              widget.onContinue(n);
            },
            child: const Text(
              'LANJUT KE QRIS',
              style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _WithdrawSheet extends StatefulWidget {
  final Color accent, accentDark, card, bg;
  final double saldo;
  final void Function(double amount, String method, String number, String name)
      onSubmit;

  const _WithdrawSheet({
    required this.accent,
    required this.accentDark,
    required this.card,
    required this.bg,
    required this.saldo,
    required this.onSubmit,
  });

  @override
  State<_WithdrawSheet> createState() => _WithdrawSheetState();
}

class _WithdrawSheetState extends State<_WithdrawSheet> {
  final _amount = TextEditingController();
  final _number = TextEditingController();
  final _name = TextEditingController();
  String _method = 'DANA';

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    final fmt = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);
    return Container(
      margin: const EdgeInsets.only(top: 40),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + bottom),
      decoration: BoxDecoration(
        color: widget.bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: Colors.white10),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: const Color(0xFF7C4DFF).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.account_balance_wallet,
                      color: Color(0xFF7C4DFF)),
                ),
                const SizedBox(width: 12),
                const Text('Tarik Tabungan',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 16)),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Saldo tersedia ${fmt.format(widget.saldo)}',
              style: TextStyle(color: widget.accent, fontSize: 13),
            ),
            const SizedBox(height: 16),
            _field(
              controller: _amount,
              icon: Icons.payments_outlined,
              hint: 'Nominal penarikan',
              keyboard: TextInputType.number,
              digitsOnly: true,
            ),
            const SizedBox(height: 14),
            const Text('Tujuan penarikan',
                style: TextStyle(color: Colors.white70, fontSize: 13)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: _methodChip('DANA', Icons.account_balance_wallet)),
                const SizedBox(width: 10),
                Expanded(child: _methodChip('GOPAY', Icons.phone_android)),
              ],
            ),
            const SizedBox(height: 14),
            _field(
              controller: _number,
              icon: Icons.phone,
              hint: 'Nomor $_method',
              keyboard: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            _field(
              controller: _name,
              icon: Icons.person_outline,
              hint: 'Nama pemilik',
            ),
            const SizedBox(height: 10),
            Text(
              'Penarikan hanya tersedia ke DANA atau GoPay. Pastikan nomor dan nama penerima benar.',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.4), fontSize: 11, height: 1.35),
            ),
            const SizedBox(height: 18),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7C4DFF),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () {
                final a = double.tryParse(_amount.text) ?? 0;
                final n = _number.text.trim();
                final name = _name.text.trim();
                if (a <= 0 || n.isEmpty || name.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Lengkapi semua field penarikan')));
                  return;
                }
                widget.onSubmit(a, _method, n, name);
              },
              child: const Text(
                'AJUKAN PENARIKAN',
                style:
                    TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _methodChip(String label, IconData icon) {
    final on = _method == label;
    return InkWell(
      onTap: () => setState(() => _method = label),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: on
              ? const Color(0xFF7C4DFF).withOpacity(0.2)
              : widget.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: on ? const Color(0xFF7C4DFF) : Colors.white12,
            width: on ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: on ? const Color(0xFF7C4DFF) : Colors.white54, size: 18),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                  color: on ? Colors.white : Colors.white70,
                  fontWeight: FontWeight.w700,
                )),
            if (on) ...[
              const SizedBox(width: 6),
              const Icon(Icons.check_circle,
                  color: Color(0xFF7C4DFF), size: 16),
            ],
          ],
        ),
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required IconData icon,
    required String hint,
    TextInputType keyboard = TextInputType.text,
    bool digitsOnly = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboard,
      inputFormatters:
          digitsOnly ? [FilteringTextInputFormatter.digitsOnly] : null,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.35)),
        prefixIcon: Icon(icon, color: Colors.white38, size: 20),
        filled: true,
        fillColor: widget.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
    );
  }
}

class _QrisSheet extends StatefulWidget {
  final Color accent, accentDark, card, bg;
  final double amount;
  final double baseAmount;
  final int unik;
  final String username, sessionKey, baseUrl;
  final VoidCallback onPaid;

  const _QrisSheet({
    required this.accent,
    required this.accentDark,
    required this.card,
    required this.bg,
    required this.amount,
    required this.baseAmount,
    required this.unik,
    required this.username,
    required this.sessionKey,
    required this.baseUrl,
    required this.onPaid,
  });

  @override
  State<_QrisSheet> createState() => _QrisSheetState();
}

class _QrisSheetState extends State<_QrisSheet> {
  Timer? _timer;
  bool _checking = false;
  String? _statusMsg;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _check(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _check({bool silent = false}) async {
    if (_checking) return;
    setState(() {
      _checking = true;
      if (!silent) _statusMsg = 'Memeriksa pembayaran...';
    });
    bool paid = false;
    try {
      final r = await http
          .get(Uri.parse(
              '${widget.baseUrl}/checkQris?key=${widget.sessionKey}&username=${widget.username}&amount=${widget.amount.toInt()}'))
          .timeout(const Duration(seconds: 6));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        paid = d['paid'] == true || d['status'] == 'paid' || d['success'] == true;
      }
    } catch (_) {}

    if (!mounted) return;
    setState(() {
      _checking = false;
      if (paid) {
        _statusMsg = 'Pembayaran berhasil!';
      } else if (!silent) {
        _statusMsg = 'Belum terdeteksi. Scan QR lalu coba lagi.';
      }
    });
    if (paid) {
      _timer?.cancel();
      widget.onPaid();
    }
  }

  void _confirmManual() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: widget.card,
        title: const Text('Konfirmasi deposit?',
            style: TextStyle(color: Colors.white)),
        content: Text(
          'Tandai deposit ${NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0).format(widget.baseAmount)} sebagai berhasil?\n\n(Gunakan jika QRIS sudah dibayar tapi status belum otomatis.)',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: widget.accent),
            onPressed: () {
              Navigator.pop(ctx);
              _timer?.cancel();
              widget.onPaid();
            },
            child: const Text('Ya, sudah bayar',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final fmt = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);
    final payload =
        'DEYSAVINGS|${widget.username}|${widget.amount.toInt()}|${widget.unik}|${DateTime.now().millisecondsSinceEpoch}';

    return Container(
      margin: const EdgeInsets.only(top: 60),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: BoxDecoration(
        color: widget.bg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: widget.accent.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.qr_code_2, color: widget.accent, size: 28),
          ),
          const SizedBox(height: 12),
          const Text(
            'Bayar Deposit',
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18),
          ),
          const SizedBox(height: 4),
          Text(
            'Scan QRIS sesuai nominal di bawah',
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13),
          ),
          const SizedBox(height: 16),
          Text(
            fmt.format(widget.amount),
            style: TextStyle(
              color: widget.accent,
              fontSize: 32,
              fontWeight: FontWeight.w800,
            ),
          ),
          Text(
            'Termasuk kode unik ${widget.unik}',
            style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFB2F5EA),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white, width: 4),
            ),
            child: SizedBox(
              width: 200,
              height: 200,
              child: CustomPaint(
                painter: _SimpleQrPainter(payload),
                child: Center(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFB2F5EA),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'Opi pay',
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w900,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.sync, color: Colors.white38, size: 14),
              const SizedBox(width: 6),
              Text(
                'Status pembayaran dicek otomatis setiap 5 detik.',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.45), fontSize: 11),
              ),
            ],
          ),
          if (_statusMsg != null) ...[
            const SizedBox(height: 8),
            Text(_statusMsg!,
                style: TextStyle(color: widget.accent, fontSize: 12)),
          ],
          const SizedBox(height: 16),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white24),
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _checking ? null : () => _check(),
            icon: _checking
                ? SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: widget.accent),
                  )
                : const Icon(Icons.refresh, size: 18),
            label: const Text('CEK SEKARANG'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: _confirmManual,
            child: Text(
              'Sudah bayar? Konfirmasi manual',
              style: TextStyle(color: widget.accent.withOpacity(0.8), fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _SimpleQrPainter extends CustomPainter {
  final String data;
  _SimpleQrPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black;
    final n = 25;
    final cell = size.width / n;
    final hash = data.codeUnits.fold<int>(0, (a, b) => (a * 31 + b) & 0x7fffffff);
    final rnd = Random(hash);

    void finder(int x, int y) {
      for (int i = 0; i < 7; i++) {
        for (int j = 0; j < 7; j++) {
          final edge = i == 0 || i == 6 || j == 0 || j == 6;
          final center = i >= 2 && i <= 4 && j >= 2 && j <= 4;
          if (edge || center) {
            canvas.drawRect(
              Rect.fromLTWH((x + i) * cell, (y + j) * cell, cell, cell),
              paint,
            );
          }
        }
      }
    }

    finder(0, 0);
    finder(n - 7, 0);
    finder(0, n - 7);

    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if ((i < 8 && j < 8) || (i > n - 9 && j < 8) || (i < 8 && j > n - 9)) {
          continue;
        }
        if (rnd.nextDouble() > 0.55) {
          canvas.drawRect(
            Rect.fromLTWH(i * cell, j * cell, cell * 0.92, cell * 0.92),
            paint,
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _SimpleQrPainter old) => old.data != data;
}
