import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Hasil deteksi lokasi (GPS → reverse geocode → fallback IP → Jakarta).
class AppLocation {
  final double lat;
  final double lon;
  final String city;
  final String country;
  final String source; // gps | ip | fallback

  const AppLocation({
    required this.lat,
    required this.lon,
    required this.city,
    required this.country,
    required this.source,
  });

  Map<String, dynamic> toJson() => {
        'lat': lat,
        'lon': lon,
        'city': city,
        'country': country,
        'source': source,
      };

  factory AppLocation.fromJson(Map<String, dynamic> j) => AppLocation(
        lat: (j['lat'] as num).toDouble(),
        lon: (j['lon'] as num).toDouble(),
        city: j['city']?.toString() ?? 'Jakarta',
        country: j['country']?.toString() ?? 'Indonesia',
        source: j['source']?.toString() ?? 'fallback',
      );
}

class LocationService {
  LocationService._();
  static final LocationService I = LocationService._();

  static const _cacheKey = 'app_location_cache_v1';
  static const _cacheTsKey = 'app_location_cache_ts_v1';
  static const _cacheTtlMs = 60 * 60 * 1000; // 1 jam

  AppLocation? _memory;

  /// Ambil lokasi: cache → GPS → IP → Jakarta.
  Future<AppLocation> getLocation({bool forceRefresh = false}) async {
    if (!forceRefresh && _memory != null) return _memory!;

    if (!forceRefresh) {
      final cached = await _readCache();
      if (cached != null) {
        _memory = cached;
        return cached;
      }
    }

    // 1) GPS
    try {
      final gps = await _fromGps();
      if (gps != null) {
        await _saveCache(gps);
        _memory = gps;
        return gps;
      }
    } catch (e) {
      debugPrint('Location GPS error: $e');
    }

    // 2) IP
    try {
      final ip = await _fromIp();
      if (ip != null) {
        await _saveCache(ip);
        _memory = ip;
        return ip;
      }
    } catch (e) {
      debugPrint('Location IP error: $e');
    }

    // 3) Fallback Jakarta
    const fallback = AppLocation(
      lat: -6.2088,
      lon: 106.8456,
      city: 'Jakarta',
      country: 'Indonesia',
      source: 'fallback',
    );
    _memory = fallback;
    return fallback;
  }

  Future<AppLocation?> _fromGps() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint('Location service disabled');
      return null;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      debugPrint('Location permission denied');
      return null;
    }

    final pos = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.medium,
      timeLimit: const Duration(seconds: 12),
    );

    final place = await _reverseGeocode(pos.latitude, pos.longitude);
    return AppLocation(
      lat: pos.latitude,
      lon: pos.longitude,
      city: place.$1,
      country: place.$2,
      source: 'gps',
    );
  }

  Future<AppLocation?> _fromIp() async {
    final res = await http
        .get(Uri.parse('https://ipapi.co/json/'))
        .timeout(const Duration(seconds: 8));
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body);
    if (data is! Map) return null;
    final lat = (data['latitude'] as num?)?.toDouble();
    final lon = (data['longitude'] as num?)?.toDouble();
    if (lat == null || lon == null) return null;
    final city = (data['city'] ?? data['region'] ?? 'Jakarta').toString();
    final country = (data['country_name'] ?? 'Indonesia').toString();
    return AppLocation(
      lat: lat,
      lon: lon,
      city: city,
      country: country,
      source: 'ip',
    );
  }

  /// Returns (city, country)
  Future<(String, String)> _reverseGeocode(double lat, double lon) async {
    // 1) BigDataCloud (no key)
    try {
      final uri = Uri.parse(
        'https://api.bigdatacloud.net/data/reverse-geocode-client'
        '?latitude=$lat&longitude=$lon&localityLanguage=id',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map) {
          final city = (data['city'] ??
                  data['locality'] ??
                  data['principalSubdivision'] ??
                  'Lokasi Saya')
              .toString();
          final country = (data['countryName'] ?? 'Indonesia').toString();
          if (city.isNotEmpty) return (city, country);
        }
      }
    } catch (e) {
      debugPrint('Reverse geocode BDC error: $e');
    }

    // 2) Nominatim fallback
    try {
      final uri = Uri.parse(
        'https://nominatim.openstreetmap.org/reverse'
        '?lat=$lat&lon=$lon&format=json&accept-language=id',
      );
      final res = await http.get(
        uri,
        headers: {'User-Agent': 'OrtaxApp/1.0'},
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map) {
          final addr = data['address'];
          if (addr is Map) {
            final city = (addr['city'] ??
                    addr['town'] ??
                    addr['village'] ??
                    addr['county'] ??
                    addr['state'] ??
                    'Lokasi Saya')
                .toString();
            final country = (addr['country'] ?? 'Indonesia').toString();
            return (city, country);
          }
        }
      }
    } catch (e) {
      debugPrint('Reverse geocode Nominatim error: $e');
    }

    return ('Lokasi Saya', 'Indonesia');
  }

  Future<AppLocation?> _readCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final ts = prefs.getInt(_cacheTsKey) ?? 0;
      if (DateTime.now().millisecondsSinceEpoch - ts > _cacheTtlMs) {
        return null;
      }
      final raw = prefs.getString(_cacheKey);
      if (raw == null) return null;
      final map = jsonDecode(raw);
      if (map is Map) {
        return AppLocation.fromJson(Map<String, dynamic>.from(map));
      }
    } catch (_) {}
    return null;
  }

  Future<void> _saveCache(AppLocation loc) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_cacheKey, jsonEncode(loc.toJson()));
      await prefs.setInt(
          _cacheTsKey, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {}
  }

  Future<void> clearCache() async {
    _memory = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_cacheKey);
    await prefs.remove(_cacheTsKey);
  }
}
