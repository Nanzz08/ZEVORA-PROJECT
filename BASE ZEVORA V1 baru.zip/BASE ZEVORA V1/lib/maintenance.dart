import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fiona/Qaxer/api.dart';

/// Full-screen maintenance page (DEY SYSTEM style).
/// Controlled by bot: /maintenance on | /maintenance off
class MaintenancePage extends StatefulWidget {
  final String? message;
  final String? reason;
  final DateTime? endsAt;
  final bool unlimited;
  final VoidCallback? onBackToLogin;

  const MaintenancePage({
    super.key,
    this.message,
    this.reason,
    this.endsAt,
    this.unlimited = true,
    this.onBackToLogin,
  });

  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  Timer? _tickTimer;
  Timer? _pollTimer;
  Duration _remaining = Duration.zero;
  bool _checking = false;
  String _statusMsg = '';

  static const _bg = Color(0xFF050A12);
  static const _card = Color(0xFF0C1520);
  static const _border = Color(0xFF1A2A3A);
  static const _blue = Color(0xFF3B82F6);
  static const _blueDim = Color(0xFF1E3A5F);
  static const _text = Color(0xFFE8F0FE);
  static const _textSub = Color(0xFF8BA3C7);
  static const _amber = Color(0xFFF59E0B);

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _updateRemaining();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      _updateRemaining();
      // Auto exit if time ended
      if (!widget.unlimited &&
          widget.endsAt != null &&
          DateTime.now().isAfter(widget.endsAt!)) {
        _onCekSistem();
      }
    });

    // Poll server every 15s in case admin turns off early
    _pollTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) _pollStatus(silent: true);
    });
  }

  void _updateRemaining() {
    if (widget.unlimited || widget.endsAt == null) {
      setState(() => _remaining = Duration.zero);
      return;
    }
    final diff = widget.endsAt!.difference(DateTime.now());
    setState(() {
      _remaining = diff.isNegative ? Duration.zero : diff;
    });
  }

  String _fmt(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  Future<void> _pollStatus({bool silent = false}) async {
    if (_checking) return;
    if (!silent) setState(() { _checking = true; _statusMsg = ''; });
    try {
      final res = await http
          .get(Uri.parse('${Api.api}/api/maintenance'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final active = data['active'] == true;
        if (!active) {
          if (!mounted) return;
          if (widget.onBackToLogin != null) {
            widget.onBackToLogin!();
          } else {
            Navigator.of(context).popUntil((r) => r.isFirst);
          }
          return;
        }
      }
      if (!silent && mounted) {
        setState(() => _statusMsg = 'Masih dalam maintenance.');
      }
    } catch (_) {
      if (!silent && mounted) {
        setState(() => _statusMsg = 'Gagal cek status. Coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  void _onCekSistem() => _pollStatus(silent: false);

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _tickTimer?.cancel();
    _pollTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final msg = widget.message?.isNotEmpty == true
        ? widget.message!
        : 'ZEVORA PROJECT sedang melakukan peningkatan sistem.\nTenang, data dan akun kamu tetap aman.';

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Grid background
          Positioned.fill(
            child: CustomPaint(painter: _GridPainter()),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Gear icon with pulse ring
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) {
                        final t = _pulseCtrl.value;
                        return Container(
                          width: 88,
                          height: 88,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: _blue.withOpacity(0.25 + t * 0.45),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _blue.withOpacity(0.15 + t * 0.2),
                                blurRadius: 24 + t * 16,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Container(
                            margin: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _blueDim.withOpacity(0.6),
                              border: Border.all(color: _blue.withOpacity(0.5)),
                            ),
                            child: const Icon(
                              Icons.settings,
                              color: _blue,
                              size: 36,
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'ZEVORA PROJECT SYSTEM',
                      style: TextStyle(
                        color: _blue.withOpacity(0.85),
                        fontSize: 12,
                        letterSpacing: 4,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'MAINTENANCE',
                      style: TextStyle(
                        color: _text,
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'SYSTEM LOCK  •  TEMPORARILY UNAVAILABLE',
                      style: TextStyle(
                        color: _textSub.withOpacity(0.8),
                        fontSize: 10,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 28),

                    // SYSTEM UPDATE card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: _card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _border),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: _amber,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'SYSTEM UPDATE',
                                  style: TextStyle(
                                    color: _text,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  widget.reason?.isNotEmpty == true
                                      ? widget.reason!
                                      : 'Maintenance sedang berlangsung',
                                  style: const TextStyle(
                                    color: _textSub,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.lock_outline,
                              color: _textSub.withOpacity(0.7), size: 18),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Message + countdown card
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: _card,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _border),
                      ),
                      child: Column(
                        children: [
                          Text(
                            msg,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: _textSub,
                              fontSize: 13,
                              height: 1.45,
                            ),
                          ),
                          const SizedBox(height: 18),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                                vertical: 16, horizontal: 12),
                            decoration: BoxDecoration(
                              color: const Color(0xFF081018),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                  color: _blue.withOpacity(0.25)),
                            ),
                            child: Column(
                              children: [
                                Text(
                                  'ESTIMATED TIME REMAINING',
                                  style: TextStyle(
                                    color: _textSub.withOpacity(0.7),
                                    fontSize: 10,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  widget.unlimited
                                      ? '-- : -- : --'
                                      : _fmt(_remaining),
                                  style: const TextStyle(
                                    color: _blue,
                                    fontSize: 36,
                                    fontWeight: FontWeight.w700,
                                    fontFeatures: [
                                      FontFeature.tabularFigures()
                                    ],
                                    letterSpacing: 2,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  widget.unlimited
                                      ? 'TANPA BATAS  •  MANUAL OFF'
                                      : 'JAM  •  MENIT  •  DETIK',
                                  style: TextStyle(
                                    color: _textSub.withOpacity(0.55),
                                    fontSize: 9,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.verified_user_outlined,
                                  size: 14,
                                  color: Colors.greenAccent.withOpacity(0.7)),
                              const SizedBox(width: 6),
                              Text(
                                'Data & akun kamu tetap aman',
                                style: TextStyle(
                                  color: _textSub.withOpacity(0.75),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),

                    // CEK SISTEM button
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: OutlinedButton(
                        onPressed: _checking ? null : _onCekSistem,
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: _blue.withOpacity(0.6)),
                          foregroundColor: _blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          backgroundColor: _blue.withOpacity(0.08),
                        ),
                        child: _checking
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: _blue,
                                ),
                              )
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.refresh, size: 18),
                                  SizedBox(width: 8),
                                  Text(
                                    'CEK SISTEM',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1.2,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                    if (_statusMsg.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(
                        _statusMsg,
                        style: const TextStyle(color: _amber, fontSize: 12),
                      ),
                    ],
                    const SizedBox(height: 28),
                    Text(
                      'DEY APP  •  SYSTEM MAINTENANCE',
                      style: TextStyle(
                        color: _textSub.withOpacity(0.45),
                        fontSize: 10,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0E1A28)
      ..strokeWidth = 1;
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
