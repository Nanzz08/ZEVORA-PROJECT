import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'developer_message_service.dart';
import 'developer_message_history_page.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:battery_plus/battery_plus.dart'; // <--- TAMBAH INI
import 'package:system_info2/system_info2.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:fiona/Qaxer/api.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'menu_page.dart';
import 'bug_menu.dart';
import 'theme_picker_page.dart';
import 'seller_page.dart';
import 'partner_page.dart';
import 'developer_page.dart';
import 'developer_tools.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'Background/Background_Page.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'trade_page.dart';
import 'contact_page.dart';
import 'news_page.dart';
import 'edukasi_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'publik_chat.dart';
import 'chat_page.dart';
import 'tiktok_video_page.dart';
import 'webtoapk_page.dart';
import 'premium_buy_page.dart';
import 'premium_service.dart';
import 'get_link_gb_page.dart';
import 'telegram.dart';
import 'pasarOnline_page.dart';
import 'sendNotification_page.dart';
import 'tabungan_page.dart';
import 'cuaca.dart';
import 'location_service.dart';
import 'pantun.dart';
import 'kata_kata.dart';
import 'story_section.dart';
import 'spotify_music.dart';
import 'bubble_bug.dart';
import 'puisi.dart';
import 'app_theme.dart';
import 'theme_effects.dart';

final _baseUrl = Api.api;
// ─── Palette (dinamis dari AppTheme) ─────────────────────────────────────────
class _C {
  static Color get bg        => AppTheme.I.bg;
  static Color get surface   => AppTheme.I.surface;
  static Color get card      => AppTheme.I.card;
  static Color get border    => AppTheme.I.border;
  static Color get borderLit => AppTheme.I.borderLit;

  static Color get red        => AppTheme.I.accentDark;
  static Color get redMid     => AppTheme.I.accentMid;
  static Color get redLight   => AppTheme.I.accent;
  static Color get redFrost   => AppTheme.I.accentFrost;

  static Color get green     => AppTheme.I.accent;
  static Color get amber     => const Color(0xFFF59E0B);
  static Color get blue      => AppTheme.I.accentMid;

  static Color get text      => AppTheme.I.text;
  static Color get textSub   => AppTheme.I.textSub;
  static Color get textDim   => AppTheme.I.textDim;

  static LinearGradient get btnGrad => AppTheme.I.btnGrad;
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer':     return const Color(0xFF0A84FF);
    case 'owner':     return const Color(0xFFF59E0B);
    case 'moderator': return const Color(0xFFF59E0B);
    case 'partner':   return const Color(0xFFF59E0B);
    case 'admin':     return const Color(0xFFEF4444);
    case 'reseller':  return const Color(0xFF0A84FF);
    case 'vip':       return const Color(0xFFFA8B8B);
    default:          return _C.redLight;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer':     return Icons.workspace_premium_rounded;
    case 'owner':     return Icons.workspace_premium_rounded;
    case 'moderator': return Icons.workspace_premium_rounded;
    case 'partner':   return Icons.workspace_premium_rounded;
    case 'admin':     return Icons.admin_panel_settings_rounded;
    case 'reseller':  return Icons.storefront_rounded;
    case 'vip':       return Icons.star_rounded;
    default:          return Icons.person_rounded;
  }
}

// ─── Slide route helper ───────────────────────────────────────────────────────
Route _slideRoute(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, anim, __, child) => SlideTransition(
      position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
          .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
      child: child,
    ),
  );
}

// ─── Popular Cities ───────────────────────────────────────────────────────────
const _popularCities = [
  'jakarta', 'bandung', 'surabaya', 'jogja', 'semarang',
  'medan', 'makassar', 'bali', 'malang', 'palembang',
  'depok', 'bekasi', 'tangerang', 'bogor', 'lampung',
  'ponorogo', 'madura', 'cirebon', 'solo', 'balikpapan',
];

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;
  
  

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  // ── State ────────────────────────────────────────────────────────────────
  List<Map<String, dynamic>> get quickActions => [
  {
    "title": "Bug Center",
    "subtitle": "Pilih workspace nomor, grup, atau test function",
    "icon": Icons.dashboard_customize_rounded,
    "color": const Color(0xFF35D49A),
    "onTap": _openBugFromMenu,
  },
  {
    "title": "Tools Gateway",
    "subtitle": "Jelajahi seluruh kategori tools",
    "icon": Icons.grid_view_rounded,
    "color": const Color(0xFF9B8CFF),
    "onTap": () => _onNavTap(4),
  },
  {
    "title": "Menu Utama",
    "subtitle": "Akses semua halaman dan pengaturan",
    "icon": Icons.apps_rounded,
    "color": const Color(0xFFFFC46B),
    "onTap": () => _onNavTap(1),
  },
  {
    "title": "Manage Sender",
    "subtitle": "Kelola WhatsApp sender",
    "icon": Icons.wifi_tethering_error_rounded,
    "color": const Color(0xFF0A84FF),
    "onTap": () {
      Navigator.push(
        context,
        _slideRoute(
          BugSenderPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          ),
        ),
      );
    },
  },
  {
    "title": "Get Link GB",
    "subtitle": "Scan group & ambil invite link",
    "icon": Icons.link_rounded,
    "color": const Color(0xFF0A84FF),
    "onTap": () {
      Navigator.push(
        context,
        _slideRoute(
          GetLinkGbPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          ),
        ),
      );
    },
  },
  {
  "title": "RAT",
  "subtitle": "Control Devices Someone",
  "icon": Icons.security,
  "color": const Color(0xFFEF4444), // Merah
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        DeviceDashboardPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  },
},
  {
  "title": "Pasar Online",
  "subtitle": "Marketplace jasa online",
  "icon": Icons.storefront_rounded, // toko
  "color": const Color(0xffD4A843), // gold accent
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        PasarOnlinePage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  },
},
  {
  "title": "Group Workspace",
  "subtitle": "Validasi dan kelola tautan grup",
  "icon": Icons.groups_rounded,
  "color": const Color(0xFF9B8CFF),
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          listBug: listBug,
          listBugGroup: listBugGroup,
          role: role,
          expiredDate: expiredDate,
          initialMode: 'group',
        ),
      ),
    );
  },
},
    {
    "title": "Public Chat",
    "subtitle": "Chat Global User Apps",
    "icon": Icons.forum_rounded,
    "color": const Color(0xffff9800),
    "onTap": () {
      Navigator.push(
        context,
        _slideRoute(
          ChatPage(
            username: username,
            role: role,
            sessionKey: sessionKey,
          ),
        ),
      );
    },
  },
  {
    "title": "TikTok Video",
    "subtitle": "Scroll · Like · Comment · Upload",
    "icon": Icons.music_note_rounded,
    "color": const Color(0xFFFE2C55),
    "onTap": () {
      Navigator.push(
        context,
        _slideRoute(
          TiktokVideoPage(
            username: username,
            sessionKey: sessionKey,
          ),
        ),
      );
    },
  },
 {
  "title": "Web To APK",
  "subtitle": "Build website menjadi APK",
  "icon": Icons.android_rounded,
  "color": const Color(0xFF0A84FF),
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        WebToApkPage(),
      ),
    );
  },
},
 {
  "title": "Telegram Ban",
  "subtitle": "Telegram Report Spam",
  "icon": FontAwesomeIcons.telegram,
  "color": const Color(0xFF0A84FF),
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        TelegramSpamPage(sessionKey: sessionKey),
      ),
    );
  },
},
  {
  "title": "Send Notification",
  "subtitle": "Only Developer User",
  "icon": Icons.notifications_active_rounded,
  "color": const Color(0xffef4444), // merah biar keliatan penting
  "onTap": () {
    Navigator.push(
      context,
      _slideRoute(
        SendNotificationPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  },
},
  {
    "title": "Telegram",
    "subtitle": "Join ZEVORA PROJECT Channel",
    "icon": FontAwesomeIcons.telegram,
    "color": const Color(0xFFEE2A2A),
    "onTap": () {
      _openUrl("https://t.me/haiakuamel123");
    },
  },
];
      Color _hexToColor(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    return Color(int.parse(hex, radix: 16));
  }
      Future<void> _loadBackground() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final type = prefs.getString('bg_type_$username');
      final value = prefs.getString('bg_value_$username');
      if (!mounted) return;

      // Dashboard kini memakai gradient/effect native. Background MP4 yang
      // pernah tersimpan diabaikan; pilihan foto dan warna tetap didukung.
      setState(() {
        _bgType = (type == 'video') ? null : type;
        _bgValue = (type == 'video') ? null : value;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _bgType = null;
          _bgValue = null;
        });
      }
    }
  }

    Future<void> _fetchUserProfile() async {
    try {
      final res = await http.get(
        Uri.parse("$_baseUrl/api/getProfile?username=$username&key=$sessionKey"),
      );
      final json = jsonDecode(res.body);
      if (json["success"] == true && mounted) {
        setState(() {
          _displayName = json["displayName"] ?? "";
          _bio = json["bio"] ?? "";
          _networkProfileUrl = json["profileImageUrl"];
        });
      }
    } catch (_) {}
  }

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listBugGroup, listDoos;
  late List<dynamic> newsList;
  late List<dynamic> jjVideosList;
  late PageController _jjCtrl; // <--- TAMBAHKAN INI
  late List<dynamic> thanksToList;
  String? _bgType; // 'image' atau 'color'
  String? _bgValue; // URL foto atau Hex color
  String? _displayName;
  String? _bio;
  String? _networkProfileUrl;
  
  late WebSocketChannel channel;
  String androidId    = 'unknown';
  File?  _profileImage;

  int _navIndex      = 0;
  FxTheme _fxTheme = FxTheme.none;
  int _barVisualIndex = 0; // notch position on capsule bar
  Widget _body       = const SizedBox();
  int onlineUsers    = 134;
  int activeConns    = 124;

  // ── Animation controllers ────────────────────────────────────────────────
  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _drawerHeaderCtrl;

  late Animation<double> _pageFade;
  late Animation<Offset>  _pageSlide;

  // News carousel
  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _newsPage = 0;
  static const int _initialQuickPage = 5000;

late final PageController _quickCtrl = PageController(
  viewportFraction: 0.92,
  initialPage: _initialQuickPage,
);

double _page = 0;
  // ==========================
  // NEWS / SHOLAT / CUACA
  // ==========================
  int _homeTab = 0;

  String selectedCity = "jakarta";

  
  bool loadingPrayer = false;
  bool prayerLoading = false;
  bool prayerExpanded = false;
  bool _bugPressed = false;
  bool _speedMenuOpen = false;
  late AnimationController _speedMenuCtrl;

  
  Map<String, dynamic>? prayerData;


  @override
  void initState() {
    super.initState();
    DeveloperMessageService.instance.init();

    WidgetsBinding.instance.addObserver(this);
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listBugGroup     = widget.listBugGroup;
    listDoos    = widget.listDoos;
    newsList    = widget.news;
    thanksToList = widget.thanksTo;
    jjVideosList = widget.jjVideos;

    // Bubble Bug + session
    BubbleBugController.I.configure(
      sessionKey: sessionKey,
      username: username,
      role: role,
      listBug: listBug,
      listBugGroup: listBugGroup,
    );
    BubbleBugController.I.load();
    if (jjVideosList.length > 1) {
      _jjCtrl = PageController(viewportFraction: 0.65, initialPage: 5000);
    } else {
      _jjCtrl = PageController(viewportFraction: 1.0); // Full layar kalau cuma 1
    }
    selectedCity = "jakarta";
  


    // Bg orbit
    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 20),
    )..repeat();

    // Speed dial (3-dot menu): Tools · Chat · TikTok
    _speedMenuCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );

    // Page transition
    _pageCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _pageFade  = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    // Drawer header
    _drawerHeaderCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700),
    );

    _body = _newsPage_();
    _pageCtrl.forward();

    _initAndroidId();
    _loadProfileImage();

    
    _fetchPrayer(forceLocation: true);
    _fetchUserProfile(); 
    _loadBackground();
    _loadFxTheme();
    // Tema global
    AppTheme.I.load().then((_) {
      if (mounted) setState(() {});
    });
    AppTheme.I.themeId.addListener(_onThemeChanged);
_quickCtrl.addListener(() {
  if (!mounted) return;

  setState(() {
    _page = (_quickCtrl.page ?? _initialQuickPage.toDouble());
  });
});
  }

  Future<void> _loadFxTheme() async {
    final effect = await FxThemeStorage.load();
    if (mounted) setState(() => _fxTheme = effect);
  }

  void _onThemeChanged() {
    if (mounted) setState(() {});
  }


  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _resumeBackgroundMedia();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      // biarkan video pause otomatis oleh sistem
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Saat kembali dari halaman lain (route masih hidup), pastikan BG jalan lagi
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _resumeBackgroundMedia();
    });
  }

  void _resumeBackgroundMedia() {
    if (!mounted) return;
    try {
      if (!_bgCtrl.isAnimating) _bgCtrl.repeat();
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AppTheme.I.themeId.removeListener(_onThemeChanged);
    try {
      channel.sink.close(status.goingAway);
    } catch (_) {}
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _drawerHeaderCtrl.dispose();
    _speedMenuCtrl.dispose();
    _newsPageCtrl.dispose();
    _quickCtrl.dispose();
    _jjCtrl.dispose();
    super.dispose();
  }

  // ── Init helpers ──────────────────────────────────────────────────────────
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(
        Uri.parse('$_baseUrl')); //ganti ke server wajib
    channel.sink.add(jsonEncode({
      'type': 'validate', 'key': sessionKey, 'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        _handleInvalidSession(reason == 'androidIdMismatch'
            ? 'Akun ini login di perangkat lain.'
            : 'Sesi tidak valid. Silakan login ulang.');
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers  = data['onlineUsers']       ?? 134;
          activeConns  = data['activeConnections'] ?? 124;
        });
      }
    });
  }

  // ── Weather & Prayer ──────────────────────────────────────────────────────
  

  Future<void> _fetchPrayer({bool forceLocation = false}) async {
    try {
      if (mounted) setState(() => loadingPrayer = true);

      // Deteksi lokasi otomatis (GPS → IP → fallback)
      String cityQuery = selectedCity;
      try {
        final loc = await LocationService.I.getLocation(
          forceRefresh: forceLocation,
        );
        if (loc.city.isNotEmpty && loc.source != 'fallback') {
          cityQuery = loc.city;
        } else if (loc.source == 'fallback' &&
            (selectedCity.isEmpty || selectedCity == 'jakarta')) {
          cityQuery = loc.city;
        }
      } catch (e) {
        debugPrint('Prayer location detect error: $e');
      }

      final res = await http.get(
        Uri.parse(
          "$_baseUrl/api/prayertime"
          "?username=$username"
          "&key=$sessionKey"
          "&city=${Uri.encodeComponent(cityQuery)}",
        ),
      ).timeout(const Duration(seconds: 12));

      final json = jsonDecode(res.body);

      if (json["success"] == true && mounted) {
        setState(() {
          prayerData = json["result"];
          selectedCity = (json["city"] ?? cityQuery).toString();
        });
      }
    } catch (e) {
      debugPrint('Prayer fetch error: $e');
    }

    if (mounted) {
      setState(() => loadingPrayer = false);
    }
  }
  
  Future<void> searchCity(String city) async {
  if (city.trim().isEmpty) return;

  selectedCity = city.trim();

  await Future.wait([
    
    _fetchPrayer(),
  ]);

  setState(() {});
}


  // ── Change City — Search Bottom Sheet ────────────────────────────────────
  Future<void> _changeCity(String city) async {
  try {
    setState(() {
      loadingPrayer = true;
    });

    final res = await http.get(
      Uri.parse(
        "$_baseUrl/api/prayertime"
        "?username=$username"
        "&key=$sessionKey"
        "&city=${Uri.encodeComponent(city)}",
      ),
    );

    final json = jsonDecode(res.body);

    if (json["success"] == true && mounted) {
      setState(() {
        prayerData = json["result"];
        selectedCity = json["city"];
      });
    }
  } catch (e) {
    debugPrint("Prayer fetch error: $e");
  } finally {
    if (mounted) {
      setState(() {
        loadingPrayer = false;
      });
    }
  }
}
  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  /// Hapus hanya data sesi login. Pertahankan saldo, centang biru, tabungan, dll.
  Future<void> _clearSessionOnly() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');
    await prefs.remove('role');
    await prefs.remove('expiredDate');
    await prefs.remove('sessionKey');
    // Jangan clearCache premium — biar centang biru & saldo tetap setelah login ulang
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    await _clearSessionOnly();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: message,
      icon: Icons.lock_outline_rounded,
      color: _C.red,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      ),
    );
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() {
      _navIndex = index;
      _barVisualIndex = index;
    });
    switch (index) {
      case 0:
        _navigate(_newsPage_());
        break;
      case 1:
        _navigate(MenuMainPage(
          onBug: _openBugFromMenu,
          onRat: () => _onNavTap(5),
          onTools: () => _onNavTap(4),
          onTheme: _openThemeFromMenu,
          onProfile: _openAccountFromMenu,
          onSettings: _openBackgroundFromMenu,
        ));
        break;
      case 2:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(ChatPage(username: username, role: role, sessionKey: sessionKey));
        break;
      case 4:
        _navigate(ToolsPage(
          username: username,
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
          password: password,
          expiredDate: expiredDate,
          listBug: listBug,
          listBugGroup: listBugGroup,
          onAppearanceChanged: _loadFxTheme,
        ));
        break;
      case 5:
        _navigate(DeviceDashboardPage(sessionKey: sessionKey, username: username, role: role));
        break;
    }
  }

  Future<void> _openBugFromMenu() async {
    if (!mounted) return;
    await Navigator.push(
      context,
      _slideRoute(
        BugMenuPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
          listBug: listBug,
          listBugGroup: listBugGroup,
          listDoos: listDoos,
          onBackToDashboard: () => _onNavTap(0),
        ),
      ),
    );
  }

  void _openThemeFromMenu() {
    Navigator.push(context, _slideRoute(const ThemePickerPage()));
  }

  void _openAccountFromMenu() {
    Navigator.push(context, _slideRoute(ChangePasswordPage(
      username: username,
      sessionKey: sessionKey,
    )));
  }

  void _openBackgroundFromMenu() {
    Navigator.push(context, _slideRoute(BackgroundPage(
      sessionKey: sessionKey,
      username: username,
      role: role,
      onBackgroundChanged: (type, value) async {
        if (!mounted) return;
        await _loadBackground();
        if (mounted) setState(() {});
      },
    )));
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(AdminPage(sessionKey: sessionKey)); break;
      case 3: _navigate(PartnerPage(sessionKey: sessionKey, username: username)); break;
      case 4: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
      case 5: _navigate(DeveloperPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  // ── System dialog ─────────────────────────────────────────────────────────
  void _showSystemDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 50)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(height: 16),
            Text(title,
                style: TextStyle(
                    color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: _C.textSub, fontSize: 13, height: 1.5)),
            const SizedBox(height: 24),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () {
              Navigator.pop(ctx);
              onOk?.call();
            }),
          ]),
        ),
      ),
    );
  }

  // ── NEWS PAGE ─────────────────────────────────────────────────────────────
    // ── Builder untuk Background Dinamis ───────────────────────────────────────
  Widget _buildDynamicBackground() {
    // Custom image/color from the existing Background page are retained.
    if (_bgType == 'image' && _bgValue != null && _bgValue!.isNotEmpty) {
      return Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            _bgValue!,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _buildGradientBackground(),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _C.bg.withOpacity(.40),
                  _C.bg.withOpacity(.70),
                  _C.bg.withOpacity(.92),
                ],
              ),
            ),
          ),
        ],
      );
    }

    if (_bgType == 'color' && _bgValue != null && _bgValue!.isNotEmpty) {
      try {
        final selected = _hexToColor(_bgValue!);
        return _buildGradientBackground(base: selected);
      } catch (_) {}
    }

    // Default dashboard background: native gradient + soft ambient glows.
    // No MP4 asset/network playback is used behind the dashboard.
    return _buildGradientBackground();
  }

  Widget _buildGradientBackground({Color? base}) {
    final background = base ?? _C.bg;
    final accent = _C.redLight;
    final secondary = _C.blue;
    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.lerp(background, const Color(0xFF14263B), .24)!,
                background,
                Color.lerp(background, const Color(0xFF050A12), .42)!,
              ],
              stops: const [0, .54, 1],
            ),
          ),
        ),
        Positioned(
          top: -130,
          right: -95,
          child: IgnorePointer(
            child: Container(
              width: 330,
              height: 330,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [accent.withOpacity(.22), accent.withOpacity(0)],
                ),
              ),
            ),
          ),
        ),
        Positioned(
          left: -145,
          bottom: 80,
          child: IgnorePointer(
            child: Container(
              width: 350,
              height: 350,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [secondary.withOpacity(.18), secondary.withOpacity(0)],
                ),
              ),
            ),
          ),
        ),
        Positioned(
          right: -110,
          bottom: -180,
          child: IgnorePointer(
            child: Container(
              width: 360,
              height: 360,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [accent.withOpacity(.10), accent.withOpacity(0)],
                ),
              ),
            ),
          ),
        ),
        // Very subtle iOS-like grain/grid treatment without an image asset.
        Positioned.fill(
          child: IgnorePointer(
            child: Opacity(
              opacity: .035,
              child: CustomPaint(painter: _DashboardGridPainter(color: _C.text)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildWorkspaceIntro() {
    final accent = AppTheme.I.accent;
    final accentDark = AppTheme.I.accentDark;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 5, 18, 12),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(18, 17, 18, 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF172638).withOpacity(.96),
              const Color(0xFF101923).withOpacity(.97),
              Color.lerp(const Color(0xFF101923), accentDark, .22)!,
            ],
          ),
          border: Border.all(color: Colors.white.withOpacity(.16), width: 1.1),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.22), blurRadius: 22, offset: const Offset(0, 10)),
            BoxShadow(color: accent.withOpacity(.07), blurRadius: 20, spreadRadius: 1),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -24,
              top: -34,
              child: Container(
                width: 128,
                height: 128,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: accent.withOpacity(.13), width: 18),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0xFF30D158).withOpacity(.10),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: const Color(0xFF30D158).withOpacity(.28)),
                      ),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.circle, color: Color(0xFF30D158), size: 6),
                        SizedBox(width: 6),
                        Text('MEMBER AREA', style: TextStyle(color: Color(0xFFB9EBC9), fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
                      ]),
                    ),
                    const Spacer(),
                    Icon(Icons.waving_hand_rounded, color: accent.withOpacity(.9), size: 19),
                  ],
                ),
                const SizedBox(height: 15),
                Text('Selamat datang kembali,', style: TextStyle(color: Colors.white.withOpacity(.72), fontSize: 12, fontWeight: FontWeight.w500)),
                const SizedBox(height: 3),
                Text(
                  username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 25, height: 1.12, fontWeight: FontWeight.w900, letterSpacing: -.7),
                ),
                const SizedBox(height: 7),
                Text(
                  'Terima kasih telah menggunakan ZEVORA PROJECT. Semoga semua fitur membantu aktivitasmu.',
                  style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 11, height: 1.45),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    _WelcomeMeta(icon: _roleIcon(role), label: role.toUpperCase(), color: _roleColor(role)),
                    const SizedBox(width: 8),
                    Container(width: 3, height: 3, decoration: BoxDecoration(color: Colors.white.withOpacity(.35), shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Icon(Icons.event_available_rounded, size: 13, color: accent.withOpacity(.9)),
                    const SizedBox(width: 5),
                    Flexible(child: Text('Aktif sampai $expiredDate', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.66), fontSize: 10, fontWeight: FontWeight.w600))),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountStats() {
    final items = <_AccountStatData>[
      _AccountStatData('ONLINE', onlineUsers.toString(), Icons.people_alt_rounded, const Color(0xFF35D49A)),
      _AccountStatData('KONEKSI', activeConns.toString(), Icons.hub_rounded, const Color(0xFF69B7FF)),
      _AccountStatData('ROLE', role.toUpperCase(), _roleIcon(role), _roleColor(role)),
      _AccountStatData('MASA AKTIF', expiredDate, Icons.schedule_rounded, const Color(0xFFFFC46B)),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Text('Ringkasan Akun', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
            const Spacer(),
            Text('LIVE STATUS', style: TextStyle(color: Colors.white.withOpacity(.42), fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
          ]),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 2.28),
            itemBuilder: (_, i) {
              final item = items[i];
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                decoration: BoxDecoration(
                  color: const Color(0xFF101923).withOpacity(.88),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: item.color.withOpacity(.22)),
                ),
                child: Row(children: [
                  Container(width: 31, height: 31, decoration: BoxDecoration(color: item.color.withOpacity(.12), borderRadius: BorderRadius.circular(10)), child: Icon(item.icon, color: item.color, size: 16)),
                  const SizedBox(width: 9),
                  Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(item.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.48), fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: .8)),
                    const SizedBox(height: 3),
                    Text(item.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900)),
                  ])),
                ]),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAccessStrip() {
    final accent = AppTheme.I.accent;
    final items = <({IconData icon, String title, String subtitle, Color color, VoidCallback onTap})>[
      (
        icon: Icons.bug_report_rounded,
        title: 'Bug Center',
        subtitle: 'Pilih Number, Group, atau Test Function',
        color: const Color(0xFF35D49A),
        onTap: _openBugFromMenu,
      ),
      (
        icon: Icons.grid_view_rounded,
        title: 'Tools Gateway',
        subtitle: 'Jelajahi kategori tools',
        color: const Color(0xFF9B8CFF),
        onTap: () => _onNavTap(4),
      ),
      (
        icon: Icons.apps_rounded,
        title: 'Menu Utama',
        subtitle: 'Semua halaman dan pengaturan',
        color: const Color(0xFFFFC46B),
        onTap: () => _onNavTap(1),
      ),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Akses Cepat',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.2,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  height: 1,
                  color: Colors.white.withOpacity(.10),
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.bolt_rounded, color: accent, size: 17),
            ],
          ),
          const SizedBox(height: 11),
          LayoutBuilder(
            builder: (context, constraints) {
              final tileWidth = (constraints.maxWidth - 10) / 2;
              return Wrap(
                spacing: 10,
                runSpacing: 10,
                children: items.map((item) {
                  return SizedBox(
                    width: tileWidth,
                    child: Material(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(17),
                      child: InkWell(
                        onTap: item.onTap,
                        borderRadius: BorderRadius.circular(17),
                        child: Ink(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(17),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                item.color.withOpacity(.15),
                                const Color(0xFF111B29).withOpacity(.94),
                              ],
                            ),
                            border: Border.all(
                              color: item.color.withOpacity(.30),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: item.color.withOpacity(.07),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 37,
                                height: 37,
                                decoration: BoxDecoration(
                                  color: item.color.withOpacity(.14),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: item.color.withOpacity(.25),
                                  ),
                                ),
                                child: Icon(item.icon, color: item.color, size: 19),
                              ),
                              const SizedBox(width: 9),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      item.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      item.subtitle,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(.56),
                                        fontSize: 9,
                                        height: 1.25,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(
                                Icons.chevron_right_rounded,
                                color: item.color.withOpacity(.85),
                                size: 18,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _newsPage_() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 14),
          _buildWorkspaceIntro(),
          _buildAccountStats(),
          _buildQuickAccessStrip(),

          // ===== FEATURE BANNER =====
          const SizedBox(height: 2),

          // ===================== BANNERS (local assets) =====================
          SizedBox(
            height: 210,
            child: PageView.builder(
              controller: _newsPageCtrl,
              onPageChanged: (i) => setState(() => _newsPage = i),
              itemCount: 2,
              itemBuilder: (_, i) {
                final isActive = i == _newsPage;
                final asset = i == 0
                    ? 'assets/images/banner.jpg'
                    : 'assets/images/banner2.jpg';
                return AnimatedScale(
                  scale: isActive ? 1.0 : 0.94,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOutCubic,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: isActive
                                ? _C.redMid.withOpacity(0.55)
                                : _C.border,
                            width: 1.2,
                          ),
                          boxShadow: [
                            if (isActive)
                              BoxShadow(
                                color: _C.redMid.withOpacity(0.25),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                          ],
                        ),
                        child: Image.asset(
                          asset,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                          errorBuilder: (_, __, ___) => Container(
                            color: const Color(0xFF121212),
                            alignment: Alignment.center,
                            child: Icon(Icons.image_not_supported_outlined,
                                color: _C.redMid.withOpacity(0.6), size: 40),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          // Dot indicators
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(2, (i) {
              final active = i == _newsPage;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 20 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active ? _C.redMid : _C.border,
                  borderRadius: BorderRadius.circular(3),
                ),
              );
            }),
          ),

          const SizedBox(height: 22),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: StorySection(
    username: username,
    sessionKey: sessionKey,
    serverUrl: _baseUrl,
  ),
),
const SizedBox(height: 14),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: DashboardProfileCard(
    username: username,
    role: role,
    expired: expiredDate,
    profileImage: _profileImage,
    networkImageUrl: _networkProfileUrl,
    androidId: androidId,    // <--- TAMBAHIN INI WAJIB
    sessionKey: sessionKey,  // <--- TAMBAHIN INI WAJIB
  ),
),
const SizedBox(height: 24), // Keluar dari Padding
          // ── Developer message banner (di atas Quick Access) ──
          ValueListenableBuilder<DeveloperMessage?>(
            valueListenable: DeveloperMessageService.instance.latest,
            builder: (context, msg, _) {
              if (msg == null) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                child: _DeveloperMessageBanner(message: msg),
              );
            },
          ),

          // ── Quick actions header ──────────────────────────────────────────
          Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [

      const Text(
        "Quick Actions",
        style: TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.bold,
        ),
      ),

      const SizedBox(height: 4),

      Text(
        "Akses cepat ke fitur utama ZEVORA",
        style: TextStyle(
          color: Colors.white.withOpacity(.6),
        ),
      ),

      const SizedBox(height: 18),

      SizedBox(
  height: 185,
  child: PageView.builder(
    controller: _quickCtrl,
    itemCount: 100000,
    physics: const BouncingScrollPhysics(),
    itemBuilder: (_, i) {
      final index = i % quickActions.length;

      return AnimatedBuilder(
        animation: _quickCtrl,
        builder: (context, child) {
          double scale = 1.0;

          if (_quickCtrl.hasClients &&
              _quickCtrl.position.haveDimensions) {
            final diff =
                ((_quickCtrl.page ?? _initialQuickPage) - i).abs();

            scale = (1.0 - diff * 0.08).clamp(0.90, 1.0).toDouble();
          }

          return Transform.scale(
            scale: scale,
            child: child,
          );
        },
        child: _QuickActionModernCard(
          data: quickActions[index],
        ),
      );
    },
  ),
),

      const SizedBox(height: 14),

      Center(
  child: SizedBox(
    width: quickActions.length * 18,
    height: 8,
    child: AnimatedBuilder(
      animation: _quickCtrl,
      builder: (context, _) {
        final double page =
((_quickCtrl.page ?? _initialQuickPage.toDouble()) %
quickActions.length)
.toDouble();

        return Stack(
          children: [
            Row(
              children: List.generate(
                quickActions.length,
                (_) => Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            ),

            AnimatedPositioned(
              duration: const Duration(milliseconds: 0),
              curve: Curves.linear,
              left: page * 18,
              child: Container(
                width: 22,
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
          ],
        );
      },
    ),
  ),
)
    ],
  ),
),
          
          const SizedBox(height: 24),

          // ── Berita & menu tambahan (di atas area bawah / contact flow) ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Update & Edukasi",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Informasi dan pembelajaran terbaru",
                  style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 12),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _DashFeatureCard(
                        icon: Icons.newspaper_rounded,
                        title: "Berita",
                        subtitle: "Update terkini",
                        color: const Color(0xFF42A5F5),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewsPage())),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _DashFeatureCard(
                        icon: Icons.school_rounded,
                        title: "Edukasi",
                        subtitle: "Belajar online",
                        color: const Color(0xFF00C9D8),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EdukasiPage())),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // === THANKS TO (mengikuti AppTheme) ===
          if (thanksToList.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Builder(builder: (context) {
                    final accent = AppTheme.I.accent;
                    final accentDark = AppTheme.I.accentDark;
                    return Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [accent, accentDark],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.4),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.workspace_premium_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ShaderMask(
                                shaderCallback: (b) => LinearGradient(
                                  colors: [
                                    Colors.white,
                                    accent.withOpacity(0.95),
                                    accentDark,
                                  ],
                                ).createShader(b),
                                child: const Text(
                                  "Thanks To",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              Text(
                                "Special Credits · Tim & Partner",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.55),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  }),
                  const SizedBox(height: 18),
                  SizedBox(
                    height: 168,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: thanksToList.length,
                      itemBuilder: (_, i) {
                        final item = thanksToList[i];
                        return Padding(
                          padding: const EdgeInsets.only(right: 14),
                          child: _ThanksCard(
                            username: item["username"] ?? "Unknown",
                            role: item["role"] ?? "User",
                            link: item["link"] ?? "",
                            index: i,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
          
          // === TABUNGAN ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _TabunganDashboardCard(
              username: username,
              sessionKey: sessionKey,
              onTap: () {
                Navigator.push(
                  context,
                  _slideRoute(
                    TabunganPage(
                      sessionKey: sessionKey,
                      username: username,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 24),

          // === CUACA OTOMATIS (di bawah Tabungan) ===
          CuacaDashboardCard(
            onOpen: () => Navigator.push(context, _slideRoute(const CuacaPage())),
          ),
          const SizedBox(height: 24),

          // === PANTUN ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _PantunDashboardCard(
              onTap: () {
                Navigator.push(context, _slideRoute(const PantunPage()));
              },
            ),
          ),
          const SizedBox(height: 18),

          // === KATA-KATA ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _KataKataDashboardCard(
              onTap: () {
                Navigator.push(context, _slideRoute(const KataKataPage()));
              },
            ),
          ),
          const SizedBox(height: 18),

          // === PUISI ===
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _PuisiDashboardCard(
              onTap: () {
                Navigator.push(context, _slideRoute(const PuisiPage()));
              },
            ),
          ),
          const SizedBox(height: 24),

          const SizedBox(height: 14),

          
        
          const SizedBox(height: 14),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: _PrayerCard(
    data: prayerData,
    loading: loadingPrayer,
    city: selectedCity,
    onChange: _changeCity,
    
  ),
),

const SizedBox(height: 18),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: const _QaxerTeamCard(),
),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ── Scaffold ──────────────────────────────────────────────────────────────
    @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Positioned.fill(child: _buildDynamicBackground()),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.16),
                    Colors.black.withOpacity(0.34),
                    Colors.black.withOpacity(0.58),
                  ],
                  stops: const [0.0, 0.46, 1.0],
                ),
              ),
            ),
          ),
          Positioned(
            top: -115,
            right: -90,
            child: IgnorePointer(
              child: Container(
                width: 270,
                height: 270,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.redLight.withOpacity(0.12),
                  boxShadow: [
                    BoxShadow(
                      color: _C.redLight.withOpacity(0.16),
                      blurRadius: 100,
                      spreadRadius: 24,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 90,
            left: -130,
            child: IgnorePointer(
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.blue.withOpacity(0.09),
                  boxShadow: [
                    BoxShadow(
                      color: _C.blue.withOpacity(0.13),
                      blurRadius: 95,
                      spreadRadius: 18,
                    ),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: FxOverlay(theme: _fxTheme, child: _body),
              ),
            ),
          ),
          const SpotifyFloatingBall(),
          const BubbleBugOverlay(),
          const BubbleBugRestoreChip(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      toolbarHeight: 76,
      titleSpacing: 0,
      leading: Builder(
        builder: (ctx) => Semantics(
          button: true,
          label: 'Buka menu navigasi',
          child: Tooltip(
            message: 'Menu',
            child: _MenuBtn(
              onTap: () => Scaffold.of(ctx).openDrawer(),
            ),
          ),
        ),
      ),
      title: Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Flexible(
                  child: VerifiedName(
                    username: username,
                    displayName: 'Halo, $username',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.45,
                    ),
                    badgeSize: 15,
                  ),
                ),
                const SizedBox(width: 7),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: _roleColor(role).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: _roleColor(role).withOpacity(0.42)),
                  ),
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: _roleColor(role),
                      fontSize: 8,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.55,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: const Color(0xFF35D49A),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: const Color(0xFF35D49A).withOpacity(0.5), blurRadius: 7),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  'ACCOUNT ACTIVE',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(width: 7),
                Container(width: 3, height: 3, decoration: BoxDecoration(color: _C.textDim, shape: BoxShape.circle)),
                const SizedBox(width: 7),
                Flexible(
                  child: Text(
                    'EXP: $expiredDate',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: _C.textSub, fontSize: 9, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        _AppBarIconBtn(
          icon: Icons.headset_mic_rounded,
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
        ),
        _AppBarIconBtn(
          icon: Icons.music_note_rounded,
          onTap: () => Navigator.push(context, _slideRoute(const SpotifyMusicPage())),
        ),
        _AppBarIconBtn(
          icon: Icons.person_rounded,
          onTap: () async {
            await Navigator.push(
              context,
              _slideRoute(ProfilePage(
                username: username,
                password: password,
                role: role,
                expiredDate: expiredDate,
                sessionKey: sessionKey,
              )),
            );
            if (!mounted) return;
            _loadProfileImage();
            _fetchUserProfile();
          },
        ),
        const SizedBox(width: 7),
      ],
    );
  }

  void _toggleSpeedMenu() {
    if (_speedMenuOpen) {
      _speedMenuCtrl.reverse().then((_) {
        if (mounted) setState(() => _speedMenuOpen = false);
      });
    } else {
      setState(() => _speedMenuOpen = true);
      _speedMenuCtrl.forward(from: 0);
    }
  }

  void _closeSpeedMenu() {
    if (!_speedMenuOpen) return;
    _speedMenuCtrl.reverse().then((_) {
      if (mounted) setState(() => _speedMenuOpen = false);
    });
  }

  void _openToolsFromMenu() {
    _closeSpeedMenu();
    _onNavTap(4);
  }

  // ── Bottom Navigation: reference layout, native iOS glass treatment ──
  int get _bottomNavSelectedIndex {
    switch (_navIndex) {
      case 0: return 0; // Home
      case 3: return 1; // Chat
      case 2: return 3; // Info
      case 4: return 4; // Tools
      default: return -1; // Menu/RAT are available from the drawer/quick actions.
    }
  }

  Widget _buildBottomNavItem({
    required int visualIndex,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    final selected = _bottomNavSelectedIndex == visualIndex;
    final accent = _C.redLight;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 240),
            curve: Curves.easeOutCubic,
            margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 7),
            padding: const EdgeInsets.symmetric(vertical: 7),
            decoration: BoxDecoration(
              color: selected ? accent.withOpacity(.15) : Colors.transparent,
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: selected ? accent.withOpacity(.34) : Colors.transparent,
                width: 1,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedScale(
                  scale: selected ? 1.08 : 1,
                  duration: const Duration(milliseconds: 220),
                  child: Icon(
                    icon,
                    size: 21,
                    color: selected ? accent : _C.textSub,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  maxLines: 1,
                  style: TextStyle(
                    color: selected ? _C.text : _C.textSub,
                    fontSize: 9,
                    fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
                    letterSpacing: .55,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    final accent = _C.redLight;
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 0, 12, 9),
      child: Container(
        height: 76,
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color.lerp(_C.surface, const Color(0xFF101722), .18)!.withOpacity(.86),
              const Color(0xFF101722).withOpacity(.78),
            ],
          ),
          borderRadius: BorderRadius.circular(27),
          border: Border.all(color: Colors.white.withOpacity(.13), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.34),
              blurRadius: 28,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: accent.withOpacity(.09),
              blurRadius: 24,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          children: [
            _buildBottomNavItem(
              visualIndex: 0,
              icon: Icons.home_rounded,
              label: 'HOME',
              onTap: () => _onNavTap(0),
            ),
            _buildBottomNavItem(
              visualIndex: 1,
              icon: Icons.chat_bubble_rounded,
              label: 'CHAT',
              onTap: () => _onNavTap(3),
            ),
            Expanded(
              child: Center(
                child: Semantics(
                  button: true,
                  label: 'Bug menu',
                  child: GestureDetector(
                    onTap: _openBugFromMenu,
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [accent, Color.lerp(accent, _C.red, .55)!],
                        ),
                        border: Border.all(color: Colors.white.withOpacity(.42), width: 1.4),
                        boxShadow: [
                          BoxShadow(color: accent.withOpacity(.34), blurRadius: 18, offset: const Offset(0, 6)),
                          BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 12, offset: const Offset(0, 5)),
                        ],
                      ),
                      child: const Icon(Icons.bug_report_rounded, color: Colors.white, size: 25),
                    ),
                  ),
                ),
              ),
            ),
            _buildBottomNavItem(
              visualIndex: 3,
              icon: Icons.notifications_active_rounded,
              label: 'INFO',
              onTap: () => _onNavTap(2),
            ),
            _buildBottomNavItem(
              visualIndex: 4,
              icon: Icons.grid_view_rounded,
              label: 'TOOLS',
              onTap: () => _onNavTap(4),
            ),
          ],
        ),
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────────────────
    // ── Drawer ────────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      width: MediaQuery.of(context).size.width * 0.85, // Lebar drawer 85% layar
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.surface.withOpacity(.96),
              const Color(0xFF101722).withOpacity(.94),
            ],
          ),
          border: Border(right: BorderSide(color: _C.borderLit.withOpacity(.82), width: 1)),
        ),
        child: Column(
          children: [
            // ── HEADER DRAWER (PROFILE BANNER) ───────────────────────────
            _DrawerHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
              profileImage: _profileImage,
            ),
            
            // ── LIST MENU ────────────────────────────────────────────────
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  // Main navigation shortcuts. Menu and RAT remain reachable
                  // after switching the bottom navigation to the supplied reference.
                  _DrawerItem(
                    icon: Icons.grid_view_rounded,
                    label: 'Menu Utama',
                    onTap: () {
                      Navigator.pop(context);
                      _onNavTap(1);
                    },
                  ),
                  const SizedBox(height: 8),
                  _DrawerItem(
                    icon: Icons.phone_android_rounded,
                    label: 'RAT / Device Control',
                    onTap: () {
                      Navigator.pop(context);
                      _onNavTap(5);
                    },
                  ),
                  const SizedBox(height: 8),
                  // My Profile
                  _DrawerItem(
                    icon: Icons.account_circle_outlined,
                    label: 'My Profile',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ProfilePage(
                          username: username, password: password,
                          role: role, expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        )),
                      ).then((_) {
                        // Refresh foto & data pas balik dari profile
                        _loadProfileImage();
                        _fetchUserProfile();
                      });
                    },
                  ),
                  const SizedBox(height: 8),
                  _DrawerItem(
                    icon: Icons.chat_bubble_outline_rounded,
                    label: 'Global Chat',
                    onTap: () {
                      Navigator.pop(context);
                      _onNavTap(3);
                    },
                  ),
                  const SizedBox(height: 8),
                  AnimatedBuilder(
                    animation: BubbleBugController.I,
                    builder: (context, _) {
                      final visible = BubbleBugController.I.visible;
                      return _DrawerItem(
                        icon: visible ? Icons.visibility_off_rounded : Icons.bug_report_rounded,
                        label: visible ? 'Sembunyikan Floating Bug' : 'Tampilkan Floating Bug',
                        onTap: () async {
                          await BubbleBugController.I.setVisible(!visible);
                          if (mounted) Navigator.pop(context);
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  // Role Page (Hanya muncul sesuai Role User)
                  if (role == 'reseller')
                    _DrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      onTap: () => _onDrawerNav(1),
                    ),
                  if (role == 'admin')
                    _DrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: 'Admin Page',
                      onTap: () => _onDrawerNav(2),
                    ),
                  if (role == 'partner')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Partner Page',
                      onTap: () => _onDrawerNav(3),
                    ),
                  if (role == 'owner')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Page',
                      onTap: () => _onDrawerNav(4),
                    ),
                  if (role == 'developer')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Developer Page',
                      onTap: () => _onDrawerNav(5),
                    ),
                  if (role == 'developer')
                    _DrawerItem(
                      icon: Icons.build_circle_rounded,
                      label: 'Developer Tools',
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          _slideRoute(
                            DeveloperToolsPage(
                              sessionKey: sessionKey,
                              username: username,
                              role: role,
                            ),
                          ),
                        );
                      },
                    ),

                  // Memberi jarak jika ada menu role
                  if (role == 'reseller' || role == 'admin' || role == 'partner' || role == 'owner' || role == 'developer')
                    const SizedBox(height: 8),

                  // Centang Biru Premium
                  _DrawerItem(
                    icon: Icons.verified_rounded,
                    label: 'Centang Biru',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(PremiumBuyPage(
                          username: username,
                          sessionKey: sessionKey,
                        )),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  // Riwayat Aktivitas
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                  _DrawerItem(
                    icon: Icons.palette_rounded,
                    label: 'Warna, Tema & Background',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BackgroundPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                            onBackgroundChanged: (type, value) async {
                              if (!mounted) return;
                              await _loadBackground();
                              if (mounted) setState(() {});
                            },
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),

                ],
              ),
            ),

            // ── LOGOUT BUTTON (Paling Bawah) ────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              child: _DrawerItem(
                icon: Icons.logout_rounded,
                label: 'Keluar',
                isDestructive: true, // Warna merah otomatis
                onTap: () async {
                  Navigator.pop(context);
                  // Hanya hapus sesi login — jangan hapus saldo, centang biru, tabungan, dll.
                  await _clearSessionOnly();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
  }

class _DashboardGridPainter extends CustomPainter {
  final Color color;
  const _DashboardGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(.28)
      ..strokeWidth = .55
      ..style = PaintingStyle.stroke;
    const gap = 34.0;
    for (double x = 0; x <= size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DashboardGridPainter oldDelegate) =>
      oldDelegate.color != color;
}

class BottomNavClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    const double radius = 52; // ukuran cekungan

    final path = Path();

    path.moveTo(32, 0);

    // sudut kiri atas
    path.quadraticBezierTo(0, 0, 0, 32);

    // kiri bawah
    path.lineTo(0, size.height - 32);
    path.quadraticBezierTo(
      0,
      size.height,
      32,
      size.height,
    );

    // bawah
    path.lineTo(size.width - 32, size.height);

    // kanan bawah
    path.quadraticBezierTo(
      size.width,
      size.height,
      size.width,
      size.height - 32,
    );

    // kanan atas
    path.lineTo(size.width, 32);
    path.quadraticBezierTo(
      size.width,
      0,
      size.width - 32,
      0,
    );

    // menuju tengah kanan
    path.lineTo(size.width / 2 + radius, 0);

    // cekungan setengah lingkaran
    path.arcToPoint(
      Offset(size.width / 2 - radius, 0),
      radius: const Radius.circular(radius),
      clockwise: false,
    );

    // kembali ke kiri
    path.lineTo(32, 0);

    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

// ─── City Search Sheet ────────────────────────────────────────────────────────
class _CitySearchSheet extends StatefulWidget {
  const _CitySearchSheet();

  @override
  State<_CitySearchSheet> createState() => _CitySearchSheetState();
}

class _CitySearchSheetState extends State<_CitySearchSheet> {
  final _searchCtrl = TextEditingController();
  String _query = '';
  bool _searching = false;
  
  List<String> get _filtered {
  if (_query.isEmpty) return _popularCities;

  final q = _query.toLowerCase();

  return _popularCities
      .where((c) => c.toLowerCase().contains(q))
      .toList();
}

  void _pick(String city) {
    Navigator.pop(context, city);
  }

  Future<void> _searchManual() async {
  final t = _searchCtrl.text.trim().toLowerCase();
  if (t.isEmpty) return;

  setState(() => _searching = true);

  try {
    final res = await http.get(
      Uri.parse(
        "https://api.ikyyxd.my.id/Info/cuaca?apikey=kyzz&query=$t",
      ),
    );

    final json = jsonDecode(res.body);

    if (json["status"] == true) {
      Navigator.pop(context, t);
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Kota tidak ditemukan")),
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Gagal mengambil data")),
    );
  }

  if (mounted) {
    setState(() => _searching = false);
  }
}

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(() {
      setState(() { _query = _searchCtrl.text; });
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        children: [
          // ── Handle bar ─────────────────────────────────────────────────
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: _C.borderLit,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          const SizedBox(height: 18),

          // ── Title ───────────────────────────────────────────────────────
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Icon(Icons.location_on_rounded, color: _C.green, size: 22),
                SizedBox(width: 10),
                Text("Pilih Kota",
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Search bar ──────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
              ),
              child: Row(
                children: [
                  const SizedBox(width: 14),
                  Icon(Icons.search_rounded, color: _C.textSub, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _searchCtrl,
                      style: TextStyle(color: _C.text, fontSize: 14),
                      decoration: InputDecoration(
                        hintText: "Cari kota... (contoh: jogja)",
                        hintStyle: TextStyle(color: _C.textDim, fontSize: 13),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 14),
                      ),
                      onSubmitted: (_) => _searchManual(),
                    ),
                  ),
                  GestureDetector(
                    onTap: _searching ? null : _searchManual,
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: _C.btnGrad,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: _searching
                          ? const SizedBox(
                              width: 16, height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Text("Cari",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),

          // ── Subtitle ────────────────────────────────────────────────────
          
          const SizedBox(height: 12),

          // ── City grid ────────────────────────────────────────────────────
          const Spacer(),

Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: Text(
    "Masukkan nama kota lalu tekan Cari.\nContoh: Jogja, Bandung, Surabaya.",
    textAlign: TextAlign.center,
    style: TextStyle(
      color: _C.textSub,
      fontSize: 13,
      height: 1.5,
    ),
  ),
),

const Spacer(),
        ],
      ),
    );
  }
}

// ─── Social Item ─────────────────────────────────────────────────────────────
class _SocialItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;

  const _SocialItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(.08),
              border: Border.all(color: color.withOpacity(.35), width: 2),
              boxShadow: [
                BoxShadow(color: color.withOpacity(.18), blurRadius: 18, spreadRadius: 2),
              ],
            ),
            child: Center(child: FaIcon(icon, color: color, size: 32)),
          ),
          const SizedBox(height: 10),
          Text(title, style: TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

// ─── Qaxer Team Card ─────────────────────────────────────────────────────────
class _QaxerTeamCard extends StatelessWidget {
  const _QaxerTeamCard({super.key});

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border),
      ),
      child: Column(
        children: [
          RichText(
  textAlign: TextAlign.center,
  text: TextSpan(
    children: [
      TextSpan(
        text: "CONNECT WITH ",
        style: TextStyle(
          color: _C.text,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
      TextSpan(
        text: "ZEVORA PROJECT",
        style: TextStyle(
          color: _C.text,
          fontSize: 18,
          fontWeight: FontWeight.bold,
          fontFamily: 'Roboto',
        ),
      ),
    ],
  ),
),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _SocialItem(
                icon: FontAwesomeIcons.telegram,
                color: const Color(0xFFF62929),
                title: "Telegram",
                onTap: () => _openUrl("https://t.me/ameluchuu"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.whatsapp,
                color: const Color(0xFFD32525),
                title: "WhatsApp",
                onTap: () => _openUrl("https://wa.me/6281222257330"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.tiktok,
                color: Colors.white,
                title: "TikTok",
                onTap: () => _openUrl("https://www.tiktok.com/@ortax_official"),
              ),
            ],
          ),
          const SizedBox(height: 18),
          RichText(
  textAlign: TextAlign.center,
  text: TextSpan(
    children: [
      TextSpan(
        text: "Selalu nantikan project terbaru dari ",
        style: TextStyle(
          color: _C.textSub,
          fontSize: 12,
        ),
      ),
      TextSpan(
        text: "ZEVORA PROJECT",
        style: TextStyle(
          color: _C.textSub,
          fontSize: 12,
          fontFamily: 'Roboto',
        ),
      ),
    ],
  ),
),
        ],
      ),
    );
  }
}

// ─── Stats Strip ──────────────────────────────────────────────────────────────
class _StatsStrip extends StatelessWidget {
  final int online;
  final int connections;
  const _StatsStrip({required this.online, required this.connections});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            _StatItem(icon: Icons.people_alt_rounded, label: 'Online', value: '$online', color: _C.green),
            Container(width: 1, height: 32, color: _C.border, margin: const EdgeInsets.symmetric(horizontal: 16)),
            _StatItem(icon: Icons.wifi_rounded, label: 'Koneksi', value: '$connections', color: _C.redLight),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _C.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _C.green.withOpacity(0.3)),
              ),
              child: Text('LIVE',
                  style: TextStyle(color: _C.green, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Stat Item ────────────────────────────────────────────────────────────────
class _StatItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatItem({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: color, size: 16),
      const SizedBox(width: 8),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color, fontSize: 15, fontFamily: 'Roboto', fontWeight: FontWeight.w800)),
        Text(label, style: TextStyle(color: _C.textSub, fontFamily: 'Roboto', fontSize: 10)),
      ]),
    ]);
  }
}

// ─── Home Tabs (News / Sholat / Cuaca) ────────────────────────────────────────
class _HomeTabs extends StatelessWidget {
  final int current;
  final Function(int) onChanged;

  const _HomeTabs({required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Widget tab(String title, int index, IconData icon) {
      final active = current == index;
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () { onChanged(index); },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            height: 46,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: active ? _C.btnGrad : null,
              color: active ? null : _C.surface,
              border: Border.all(color: active ? Colors.transparent : _C.border),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 17, color: active ? Colors.white : _C.textSub),
                const SizedBox(width: 6),
                Text(title,
                    style: TextStyle(
                      color: active ? Colors.white : _C.textSub,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    )),
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          tab("News", 0, Icons.newspaper),
          tab("Sholat", 1, Icons.mosque),
          tab("Cuaca", 2, Icons.cloud),
        ],
      ),
    );
  }
}

// ─── News Card ────────────────────────────────────────────────────────────────
class _NewsCard extends StatelessWidget {
  final dynamic item;
  final bool isActive;
  const _NewsCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isActive ? _C.borderLit : _C.border,
          width: isActive ? 1.5 : 1,
        ),
        boxShadow: isActive
            ? [BoxShadow(color: _C.red.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8))]
            : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Always keep a visible local backdrop so a broken/slow banner URL
            // can never leave a solid black card.
            Image.asset('assets/images/landing.jpg', fit: BoxFit.cover),
            if (item['image'] != null && item['image'].toString().isNotEmpty)
              NewsMedia(url: item['image']),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xE6080808), Colors.transparent],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  stops: [0.0, 0.7],
                ),
              ),
            ),
            Positioned(
              bottom: 16, left: 16, right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  
                  const SizedBox(height: 6),
                  Text(
                    item['title'] ?? 'No Title',
                    style: TextStyle(color: _C.text, fontSize: 15, fontFamily: 'Roboto', fontWeight: FontWeight.w700, height: 1.3),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (item['desc'] != null && item['desc'].toString().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(item['desc'],
                        style: TextStyle(color: _C.textSub, fontSize: 11, fontFamily: 'Roboto', height: 1.4),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActionModernCard extends StatelessWidget {
  final Map<String, dynamic> data;

  const _QuickActionModernCard({
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: data["onTap"],
      child: Container(
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xF21B2430),
              Color.lerp(const Color(0xFF111923), data["color"] as Color, .18)!
                  .withOpacity(.98),
            ],
          ),
          border: Border.all(color: (data["color"] as Color).withOpacity(.38), width: 1.15),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.22),
              blurRadius: 20,
              offset: const Offset(0, 9),
            ),
            BoxShadow(
              color: (data["color"] as Color).withOpacity(.07),
              blurRadius: 18,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 18,
              right: 18,
              child: Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Colors.white.withOpacity(.22), Colors.transparent],
                  ),
                ),
              ),
            ),
            Positioned(
              right: -20,
              bottom: -20,
              child: Icon(
                data["icon"],
                size: 170,
                color: (data["color"] as Color).withOpacity(.09),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.white.withOpacity(.09),
                    child: Icon(
                      data["icon"],
                      color: Colors.white,
                    ),
                  ),

                  const Spacer(),

                  Text(
                    data["title"],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 27,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Roboto',
                    ),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    data["subtitle"],
                    style: TextStyle(
                      color: Colors.white.withOpacity(.85),
                    ),
                  ),
                ],
              ),
            ),

            Positioned(
              right: 22,
              top: 26,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.07),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.white.withOpacity(.12)),
                ),
                child: const Text(
                  "Tap →",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Prayer Card ──────────────────────────────────────────────────────────────
class _PrayerCard extends StatelessWidget {
  final Map<String, dynamic>? data;
  final bool loading;
  final String city;
  final Future<void> Function(String) onChange;

  const _PrayerCard({
    super.key,
    required this.data,
    required this.loading,
    required this.city,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    if (loading || data == null) {
      return Container(
        height: 320,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(22),
        ),
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final jadwal = data!["waktu"];
    final now = TimeOfDay.now();

    final prayers = <Map<String, String>>[
      {"name": "Subuh", "time": jadwal["Fajr"]},
      {"name": "Dzuhur", "time": jadwal["Dhuhr"]},
      {"name": "Ashar", "time": jadwal["Asr"]},
      {"name": "Maghrib", "time": jadwal["Maghrib"]},
      {"name": "Isya", "time": jadwal["Isha"]},
    ];

    String nextName = prayers.first["name"]!;
    String nextTime = prayers.first["time"]!;

    for (final p in prayers) {
      final split = p["time"]!.split(":");
      final h = int.parse(split[0]);
      final m = int.parse(split[1]);

      if (h > now.hour || (h == now.hour && m > now.minute)) {
        nextName = p["name"]!;
        nextTime = p["time"]!;
        break;
      }
    }

    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.35),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: CustomPaint(
          painter: HoneycombPainter(),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(.15),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(
                        Icons.mosque_rounded,
                        color: Colors.redAccent,
                        size: 26,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Prayer Times",
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            data!["lokasi"] ?? city,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontFamily: 'Roboto',
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Next : ",
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextSpan(
                              text: "$nextName • $nextTime",
                              style: const TextStyle(
                                color: Colors.white,
                                fontFamily: 'Roboto',
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.15),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: const Text(
                        "LIVE",
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.white,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: LinearGradient(
                      colors: [
                        Colors.red.shade900,
                        Colors.red.shade700,
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.red.withOpacity(.35),
                        blurRadius: 18,
                      )
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        color: Colors.amber,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "$nextName - $nextTime",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 132,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    children: [
                      _PrayerItem(
                        title: "SUBUH",
                        time: jadwal["Fajr"],
                        icon: Icons.nightlight_round,
                        colors: const [
                          Color(0xFFFF6363),
                          Color(0xFFD44242),
                        ],
                      ),
                      const SizedBox(width: 12),
                      _PrayerItem(
                        title: "DZUHUR",
                        time: jadwal["Dhuhr"],
                        icon: Icons.wb_sunny_rounded,
                        colors: const [
                          Color(0xffFFB300),
                          Color(0xffF57C00),
                        ],
                      ),
                      const SizedBox(width: 12),
                      _PrayerItem(
                        title: "ASHAR",
                        time: jadwal["Asr"],
                        icon: Icons.cloud,
                        colors: const [
                          Color(0xffFF7043),
                          Color(0xffF4511E),
                        ],
                      ),
                      const SizedBox(width: 12),
                      _PrayerItem(
                        title: "MAGHRIB",
                        time: jadwal["Maghrib"],
                        icon: Icons.nights_stay,
                        colors: const [
                          Color(0xffEC407A),
                          Color(0xffC2185B),
                        ],
                      ),
                      const SizedBox(width: 12),
                      _PrayerItem(
                        title: "ISYA",
                        time: jadwal["Isha"],
                        icon: Icons.dark_mode,
                        colors: const [
                          Color(0xFFC05C5C),
                          Color(0xFFAB3939),
                        ],
                      ),
                      const SizedBox(width: 12),
                      _PrayerItem(
                        title: "SUNRISE",
                        time: jadwal["Sunrise"],
                        icon: Icons.wb_twilight,
                        colors: const [
                          Color(0xFFA62626),
                          Color(0xFF890000),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                InkWell(
                  borderRadius: BorderRadius.circular(30),
                  onTap: () async {
                    final controller = TextEditingController();

                    final result = await showDialog<String>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text("Ganti Kota"),
                        content: TextField(
                          controller: controller,
                          decoration: InputDecoration(
                            hintText: "Contoh: Yogyakarta",
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text("Batal"),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.pop(
                                context,
                                controller.text.trim(),
                              );
                            },
                            child: const Text("Simpan"),
                          )
                        ],
                      ),
                    );

                    if (result != null && result.isNotEmpty) {
                      await onChange(result);
                    }
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        city,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Icon(
                        Icons.edit_location_alt_rounded,
                        color: Colors.redAccent,
                        size: 18,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PrayerItem extends StatelessWidget {
  final String title;
  final String time;
  final IconData icon;
  final List<Color> colors;

  const _PrayerItem({
    required this.title,
    required this.time,
    required this.icon,
    required this.colors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
  width: 105,
  height: 125,
  decoration: BoxDecoration(
    gradient: LinearGradient(colors: colors),
    borderRadius: BorderRadius.circular(18),
    boxShadow: [
      BoxShadow(
        color: colors.first.withOpacity(.35),
        blurRadius: 8,
        spreadRadius: 0,
      ),
    ],
  ),
  child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Icon(
              icon,
              color: Colors.white,
              size: 20,
            ),

            const Spacer(),

            Text(
              title,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 10,
              ),
            ),

            const SizedBox(height: 3),

            Text(
  time,
  style: const TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.bold,
    fontSize: 20,
    height: 1,
  ),
),

          ],
        ),
      ),
    );
  }
}
// ─── Weather Card ─────────────────────────────────────────────────────────────

// ─── Action Card ──────────────────────────────────────────────────────────────
class _ActionCard extends StatefulWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
  });

  @override
  State<_ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends State<_ActionCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 130),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _pressed ? _C.card.withOpacity(0.9) : _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _pressed ? widget.iconColor.withOpacity(0.3) : _C.border),
            boxShadow: _pressed
                ? [BoxShadow(color: widget.iconColor.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4))]
                : [],
          ),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: widget.iconBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: widget.iconColor.withOpacity(0.2)),
              ),
              child: Icon(widget.icon, color: widget.iconColor, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.title, style: TextStyle(color: _C.text, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(widget.subtitle, style: TextStyle(color: _C.textSub, fontSize: 11)),
              ],
            )),
            if (widget.trailing != null) ...[
              const SizedBox(width: 10),
              widget.trailing!,
            ],
          ]),
        ),
      ),
    );
  }
}

// ─── Dashboard Profile Card (Static System Info) ─────────────────────────────
class DashboardProfileCard extends StatefulWidget {
  final String username;
  final String role;
  final String expired;
  final File? profileImage;
  final String? networkImageUrl;
  final String androidId;
  final String sessionKey;

  const DashboardProfileCard({
    super.key,
    required this.username,
    required this.role,
    required this.expired,
    this.profileImage,
    this.networkImageUrl,
    required this.androidId,
    required this.sessionKey,
  });

  @override
  State<DashboardProfileCard> createState() => _DashboardProfileCardState();
}

class _DashboardProfileCardState extends State<DashboardProfileCard> {
  late Timer _timer;
  String _currentTime = '';
  bool _isVerified = false;

  // Variabel Dummy Statis (Biar gak error build)
  int _batteryLevel = 0;
double _ramUsage = 0.0;
double _storageUsage = 0.0;
String _systemInfo = 'Loading...';
  final String _networkStatus = "Connected";

  @override
  void initState() {
    super.initState();
    _updateTime();
    _loadDeviceInfo();
    _loadVerified();
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        // Jangan reload device info tiap detik — cukup jam
        _updateTime();
      },
    );
    // Refresh device info sesekali
    Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _loadDeviceInfo();
        _loadVerified();
      }
    });
  }

  Future<void> _loadVerified() async {
    final v = await PremiumService.isVerified(widget.username);
    if (mounted) setState(() => _isVerified = v);
  }

  void _updateTime() {
    final now = DateTime.now();
    setState(() {
      _currentTime = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }
  
  Future<void> _loadDeviceInfo() async {
  try {
    // =========================
    // BATTERY
    // =========================
    final battery = Battery();
    final batteryLevel = await battery.batteryLevel;

    // =========================
    // DEVICE / ANDROID INFO
    // =========================
    final deviceInfo = DeviceInfoPlugin();
    final androidInfo = await deviceInfo.androidInfo;

    // =========================
    // RAM
    // =========================
    final totalRam = SysInfo.getTotalPhysicalMemory();
    final freeRam = SysInfo.getFreePhysicalMemory();

    final usedRam = totalRam - freeRam;

    final ramUsage = totalRam > 0
        ? usedRam / totalRam
        : 0.0;

    // =========================
    // STORAGE
    // =========================
    final totalStorage = SysInfo.getTotalStorage();
    final freeStorage = SysInfo.getFreeStorage();

    final usedStorage = totalStorage - freeStorage;

    final storageUsage = totalStorage > 0
        ? usedStorage / totalStorage
        : 0.0;

    if (!mounted) return;

    setState(() {
      _batteryLevel = batteryLevel;

      _ramUsage = ramUsage.clamp(0.0, 1.0);

      _storageUsage = storageUsage.clamp(0.0, 1.0);

      _systemInfo =
          '${androidInfo.model} (API ${androidInfo.version.sdkInt})';
    });
  } catch (e) {
    debugPrint('Failed to load device info: $e');
  }
}

  // Helper buat Bar Loading
  Widget _buildInfoBar(String label, String value, double progress, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: TextStyle(color: _C.textSub, fontSize: 11, fontFamily: 'Roboto')),
            Text(value, style: TextStyle(color: _C.text, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Roboto')),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: _C.surface,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 6,
          ),
        ),
      ],
    );
  }

  // Helper buat Info Text biasa
  Widget _buildInfoTile(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: _C.textSub, size: 14),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(color: _C.textSub, fontSize: 11, fontFamily: 'Roboto')),
        const Spacer(),
        Flexible(
          child: Text(value, style: TextStyle(color: _C.text, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Roboto'), overflow: TextOverflow.ellipsis, maxLines: 1),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final ramPct = (_ramUsage * 100).toInt();
    
    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(.10)),
        boxShadow: [
          BoxShadow(color: _C.green.withOpacity(.08), blurRadius: 20),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: CustomPaint(painter: HoneycombPainter()),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── HEADER ───────────────────────────────────────────────
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 68, height: 68,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [BoxShadow(color: _C.green.withOpacity(.20), blurRadius: 14)],
                      ),
                      child: ClipOval(
                        child: widget.profileImage != null
                            ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                            : widget.networkImageUrl != null && widget.networkImageUrl!.isNotEmpty
                                ? Image.network(widget.networkImageUrl!, fit: BoxFit.cover)
                                : Container(
                                    color: _C.surface,
                                    child: const Icon(Icons.person, color: Colors.white, size: 34),
                                  ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Selamat Datang", style: TextStyle(color: _C.textSub, fontFamily: 'Roboto', fontSize: 12)),
                          const SizedBox(height: 3),
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  widget.username.toUpperCase(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: _C.text, fontWeight: FontWeight.w900, fontFamily: 'Roboto', fontSize: 21, letterSpacing: 1),
                                ),
                              ),
                              if (_isVerified) ...[
                                const SizedBox(width: 6),
                                const VerifiedBadge(size: 20),
                              ],
                            ],
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: _C.green.withOpacity(.12),
                              borderRadius: BorderRadius.circular(25),
                              border: Border.all(color: _C.green),
                            ),
                            child: Text(widget.role.toUpperCase(), style: TextStyle(color: _C.green, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
                    // EXPIRES + jam live bersebelahan
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 86,
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.04),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.white24),
                          ),
                          child: Column(
                            children: [
                              const Icon(Icons.event_busy_rounded, color: Colors.orange, size: 16),
                              const SizedBox(height: 4),
                              Text("EXPIRES", style: TextStyle(color: _C.textSub, fontSize: 8)),
                              const SizedBox(height: 3),
                              Text(
                                widget.expired.toUpperCase(),
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 78,
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                          decoration: BoxDecoration(
                            color: _C.green.withOpacity(.08),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: _C.green.withOpacity(.35)),
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.access_time_rounded, color: _C.green, size: 16),
                              const SizedBox(height: 4),
                              Text("JAM", style: TextStyle(color: _C.textSub, fontSize: 8)),
                              const SizedBox(height: 3),
                              Text(
                                _currentTime.isEmpty ? '--:--:--' : _currentTime,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: _C.green,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                
                const SizedBox(height: 20),
                Divider(color: _C.border, height: 1),
                const SizedBox(height: 20),

                // ── SYSTEM BARS ──────────────────────────────────────────
                _buildInfoBar("BATTERY", "$_batteryLevel%", _batteryLevel / 100, _C.green),
                const SizedBox(height: 12),
                _buildInfoBar("RAM MEMORY", "$ramPct% Usage", _ramUsage, Colors.redAccent),
                const SizedBox(height: 12),
                _buildInfoBar("STORAGE", "${(_storageUsage * 100).toInt()}% Usage", _storageUsage, Colors.amber),
                
                const SizedBox(height: 20),
                Divider(color: _C.border, height: 1),
                const SizedBox(height: 16),

                // ── SYSTEM INFO TILES ───────────────────────────────────
                _buildInfoTile("Device ID", widget.androidId, Icons.phone_android_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Network", _networkStatus, Icons.wifi_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("System", _systemInfo, Icons.system_update_alt_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Session Key", "${widget.sessionKey.substring(0, 8)}********", Icons.vpn_key_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Time", _currentTime, Icons.timer_rounded),
                
                const SizedBox(height: 20),
                
                // ── FOOTER ──────────────────────────────────────────────
                Container(
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.03),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Center(
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        children: [
                          TextSpan(text: "● Powered by NanzzPrime ", style: TextStyle(color: _C.text, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: .5)),
                          TextSpan(text: "ZEVORA PROJECT TEAM", style: TextStyle(color: _C.text, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: .5, fontFamily: 'Roboto')),
                          TextSpan(text: " ●", style: TextStyle(color: _C.text, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: .5)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
// ─── Honeycomb Painter ────────────────────────────────────────────────────────
class HoneycombPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(.07)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    const r = 24.0;
    final h = math.sqrt(3) * r;

    for (double y = 0; y < size.height + h; y += h) {
      for (double x = 0; x < size.width + r; x += r * 3) {
        final dx = ((y ~/ h).isEven) ? x : x + r * 1.5;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = (60 * i - 30) * math.pi / 180;
          final px = dx + r * math.cos(angle);
          final py = y + r * math.sin(angle);
          if (i == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class _DrawerHeader extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final File? profileImage;

  const _DrawerHeader({
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.profileImage,
  });

  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;
  bool _isVerified = false;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade  = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
    _loadVerified();
  }

  Future<void> _loadVerified() async {
    final v = await PremiumService.isVerified(widget.username);
    if (mounted) setState(() => _isVerified = v);
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    return Container(
      height: 240,
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        color: _C.card,
        border: Border(bottom: BorderSide(color: _C.border)),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color.lerp(_C.surface, _C.redLight, .18)!,
                    _C.surface,
                    Color.lerp(_C.surface, const Color(0xFF050A12), .55)!,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: -70,
            right: -55,
            child: Container(
              width: 190,
              height: 190,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_C.redLight.withOpacity(.24), _C.redLight.withOpacity(0)],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -100,
            left: -75,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [_C.blue.withOpacity(.16), _C.blue.withOpacity(0)],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            width: 78, height: 78,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white.withOpacity(.72), width: 2.2),
                              boxShadow: [
                                BoxShadow(color: rColor.withOpacity(0.34), blurRadius: 22, spreadRadius: 2),
                                BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 12, offset: const Offset(0, 5)),
                              ],
                            ),
                            child: ClipOval(
                              child: widget.profileImage != null
                                  ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                                  : Container(
                                      color: _C.surface,
                                      child: Icon(_roleIcon(widget.role), size: 36, color: rColor.withOpacity(0.9)),
                                    ),
                            ),
                          ),
                          Positioned(
                            right: 0, bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: rColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: _C.card, width: 2),
                              ),
                              child: Icon(_roleIcon(widget.role), color: Colors.white, size: 12),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: Text(
                              widget.username,
                              style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (_isVerified) ...[
                            const SizedBox(width: 5),
                            const VerifiedBadge(size: 18),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: rColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: rColor.withOpacity(0.3)),
                        ),
                        child: Text(widget.role.toUpperCase(), style: TextStyle(color: rColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
                      ),
                      const SizedBox(height: 6),
                      Text('Exp: ${widget.expiredDate}', style: TextStyle(color: _C.textSub, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Drawer Item ──────────────────────────────────────────────────────────────
class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDestructive;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.label, required this.onTap, this.isDestructive = false});

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? const Color(0xFFEF4444) : _C.text;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: onTap,
          child: Ink(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              color: _C.card.withOpacity(.48),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: isDestructive
                    ? color.withOpacity(.24)
                    : Colors.white.withOpacity(.075),
                width: 1,
              ),
            ),
            child: Row(children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: color.withOpacity(.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: color.withOpacity(.20)),
                ),
                child: Icon(icon, color: color, size: 19),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Text(label, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w700)),
              ),
              Icon(Icons.chevron_right_rounded, color: _C.textDim, size: 19),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── Menu Button ──────────────────────────────────────────────────────────────
class _MenuBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.surface.withOpacity(.96), _C.card.withOpacity(.78)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(.18), width: 1),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 13, offset: const Offset(0, 5)),
            BoxShadow(color: _C.redLight.withOpacity(.08), blurRadius: 12),
          ],
        ),
        child: Icon(Icons.menu_rounded, color: _C.text, size: 21),
      ),
    );
  }
}

// ─── AppBar Icon Button ───────────────────────────────────────────────────────
class _AppBarIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarIconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: _C.border.withOpacity(0.9)),
        ),
        child: Icon(icon, color: _C.text, size: 18),
      ),
    );
  }
}

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Nav Button ──────────────────────────────────────────────────────────────
/// Speed dial item — animasi scale + fade + slide elegan
class _SpeedDialItem extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final double progress; // 0..1
  final double delay;
  final VoidCallback onTap;

  const _SpeedDialItem({
    required this.label,
    required this.icon,
    required this.color,
    required this.progress,
    required this.delay,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final p = progress.clamp(0.0, 1.0);
    return Opacity(
      opacity: p,
      child: Transform.translate(
        offset: Offset(24 * (1 - p), 16 * (1 - p)),
        child: Transform.scale(
          scale: 0.6 + 0.4 * p,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(28),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Label chip
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF121212),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: color.withOpacity(0.45)),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Text(
                      label,
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Icon circle
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          color,
                          Color.lerp(color, Colors.black, 0.35)!,
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.55),
                          blurRadius: 18,
                          spreadRadius: 1,
                          offset: const Offset(0, 6),
                        ),
                      ],
                      border: Border.all(
                        color: Colors.white.withOpacity(0.25),
                        width: 1.5,
                      ),
                    ),
                    child: Icon(icon, color: Colors.white, size: 24),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NotchItem {
  final IconData? icon;
  final IconData? faIcon;
  final String label;
  final VoidCallback onTap;
  const _NotchItem({
    this.icon,
    this.faIcon,
    required this.label,
    required this.onTap,
  });
}

/// Capsule bottom bar with animated curved notch + floating active bubble (black-red).
class _NotchedNavBar extends StatefulWidget {
  final int selectedIndex;
  final List<_NotchItem> items;
  const _NotchedNavBar({
    required this.selectedIndex,
    required this.items,
  });

  @override
  State<_NotchedNavBar> createState() => _NotchedNavBarState();
}

class _NotchedNavBarState extends State<_NotchedNavBar>
    with TickerProviderStateMixin {
  static const _bar = Color(0xF20E1621);
  static const _border = Color(0xFF29394B);
  static const _red = Color(0xFF527FA8);
  static const _redBright = Color(0xFF9AB6D0);
  static const _inactive = Color(0xFF8493A5);

  late AnimationController _moveCtrl;
  late AnimationController _popCtrl;
  late Animation<double> _moveAnim;
  late Animation<double> _scaleAnim;
  late Animation<double> _glowAnim;
  late Animation<double> _iconCrossAnim;

  int _from = 0;
  int _to = 0;

  @override
  void initState() {
    super.initState();
    _from = widget.selectedIndex;
    _to = widget.selectedIndex;

    // Smooth travel of notch + bubble
    _moveCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 480),
    );
    _moveAnim = CurvedAnimation(
      parent: _moveCtrl,
      curve: Curves.easeOutCubic,
    );

    // Pop / bounce when landing on new tab
    _popCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 520),
    );
    _scaleAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.82), weight: 22),
      TweenSequenceItem(tween: Tween(begin: 0.82, end: 1.18), weight: 38),
      TweenSequenceItem(tween: Tween(begin: 1.18, end: 0.96), weight: 22),
      TweenSequenceItem(tween: Tween(begin: 0.96, end: 1.0), weight: 18),
    ]).animate(CurvedAnimation(parent: _popCtrl, curve: Curves.easeOut));

    _glowAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.45, end: 0.15), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.15, end: 0.75), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 0.75, end: 0.45), weight: 35),
    ]).animate(CurvedAnimation(parent: _popCtrl, curve: Curves.easeInOut));

    _iconCrossAnim = CurvedAnimation(
      parent: _moveCtrl,
      curve: const Interval(0.15, 0.75, curve: Curves.easeInOutCubic),
    );

    _moveCtrl.value = 1.0;
    _popCtrl.value = 1.0;
  }

  @override
  void didUpdateWidget(covariant _NotchedNavBar old) {
    super.didUpdateWidget(old);
    if (old.selectedIndex != widget.selectedIndex) {
      _from = old.selectedIndex;
      _to = widget.selectedIndex;
      _moveCtrl.forward(from: 0);
      _popCtrl.forward(from: 0);
      // Light haptic for premium feel
      HapticFeedback.selectionClick();
    }
  }

  @override
  void dispose() {
    _moveCtrl.dispose();
    _popCtrl.dispose();
    super.dispose();
  }

  double _slotCenter(int index, double width) {
    final n = widget.items.length;
    final slot = width / n;
    return slot * index + slot / 2;
  }

  Widget _buildIcon(int index, {required double size, required Color color}) {
    final item = widget.items[index];
    if (item.faIcon != null) {
      return FaIcon(item.faIcon, size: size, color: color);
    }
    return Icon(item.icon ?? Icons.circle, size: size, color: color);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;

        return AnimatedBuilder(
          animation: Listenable.merge([_moveAnim, _popCtrl]),
          builder: (context, _) {
            final t = _moveAnim.value;
            final fromX = _slotCenter(_from, w);
            final toX = _slotCenter(_to, w);
            // Slight overshoot on the notch for fluid feel
            final overshoot = (1 - t) * t * 18 * ((_to - _from).sign);
            final notchX = fromX + (toX - fromX) * t + overshoot;

            final cross = _iconCrossAnim.value;
            final scale = _scaleAnim.value;
            final glow = _glowAnim.value;
            final activeIndex = cross > 0.5 ? _to : _from;

            return Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.bottomCenter,
              children: [
                // ── Bar with animated notch ──────────────────────────
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  height: 54,
                  child: CustomPaint(
                    painter: _NotchBarPainter(
                      notchCenterX: notchX,
                      barColor: _bar,
                      borderColor: _border,
                      notchRadius: 30,
                    ),
                    child: const SizedBox.expand(),
                  ),
                ),

                // ── Inactive icons (fade when active) ────────────────
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  height: 54,
                  child: Row(
                    children: List.generate(widget.items.length, (i) {
                      final item = widget.items[i];
                      final isActive = i == activeIndex;
                      // Extra soft fade based on distance to current notch
                      final dist = ((i + 0.5) / widget.items.length * w - notchX).abs();
                      final nearBoost = (1.0 - (dist / (w * 0.18)).clamp(0.0, 1.0)) * 0.12;

                      return Expanded(
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: item.onTap,
                          child: Center(
                            child: AnimatedOpacity(
                              duration: const Duration(milliseconds: 180),
                              opacity: isActive ? 0.0 : (0.88 + nearBoost).clamp(0.0, 1.0),
                              child: item.faIcon != null
                                  ? FaIcon(item.faIcon, size: 20, color: _inactive)
                                  : Icon(item.icon, size: 20, color: _inactive),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ),

                // ── Floating active bubble (position + scale + glow) ─
                Positioned(
                  left: notchX - 26,
                  bottom: 25 + (1 - scale) * 6, // subtle lift while expanding
                  child: GestureDetector(
                    onTap: widget.items[activeIndex].onTap,
                    child: Transform.scale(
                      scale: scale,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Outer soft glow ring
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: _red.withOpacity(glow),
                                  blurRadius: 18 + glow * 10,
                                  spreadRadius: 1 + glow * 2,
                                  offset: const Offset(0, 4),
                                ),
                                BoxShadow(
                                  color: _redBright.withOpacity(glow * 0.35),
                                  blurRadius: 8,
                                  spreadRadius: 0,
                                ),
                              ],
                            ),
                            child: Container(
                              margin: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(0xFFFF4D6D),
                                    Color(0xFF0A84FF),
                                    Color(0xFFBE123C),
                                  ],
                                ),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.22),
                                  width: 1.5,
                                ),
                              ),
                              child: Center(
                                // Cross-fade between previous & next icon
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Opacity(
                                      opacity: (1 - cross).clamp(0.0, 1.0),
                                      child: Transform.scale(
                                        scale: 1.0 - cross * 0.35,
                                        child: _buildIcon(
                                          _from,
                                          size: 23,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    Opacity(
                                      opacity: cross.clamp(0.0, 1.0),
                                      child: Transform.scale(
                                        scale: 0.65 + cross * 0.35,
                                        child: _buildIcon(
                                          _to,
                                          size: 23,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 3),
                          // Label with soft fade
                          AnimatedOpacity(
                            duration: const Duration(milliseconds: 160),
                            opacity: cross > 0.4 ? 1.0 : 0.0,
                            child: Text(
                              widget.items[activeIndex].label,
                              style: TextStyle(
                                color: _redBright,
                                fontSize: 9,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.7,
                                shadows: [
                                  Shadow(
                                    color: _red.withOpacity(0.55),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _NotchBarPainter extends CustomPainter {
  final double notchCenterX;
  final Color barColor;
  final Color borderColor;
  final double notchRadius;

  _NotchBarPainter({
    required this.notchCenterX,
    required this.barColor,
    required this.borderColor,
    this.notchRadius = 30,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final r = 28.0;
    final h = size.height;
    final w = size.width;
    final cx = notchCenterX.clamp(r + notchRadius, w - r - notchRadius);
    final nr = notchRadius;

    final path = Path();

    // Start bottom-left rounded
    path.moveTo(r, h);
    path.lineTo(w - r, h);
    path.quadraticBezierTo(w, h, w, h - r);
    path.lineTo(w, r);
    path.quadraticBezierTo(w, 0, w - r, 0);

    // Top edge to right of notch
    path.lineTo(cx + nr + 10, 0);

    // Curved notch (dip down)
    path.cubicTo(
      cx + nr * 0.55, 0,
      cx + nr * 0.85, nr * 0.95,
      cx, nr * 1.05,
    );
    path.cubicTo(
      cx - nr * 0.85, nr * 0.95,
      cx - nr * 0.55, 0,
      cx - nr - 10, 0,
    );

    path.lineTo(r, 0);
    path.quadraticBezierTo(0, 0, 0, r);
    path.lineTo(0, h - r);
    path.quadraticBezierTo(0, h, r, h);
    path.close();

    // Fill
    canvas.drawPath(
      path,
      Paint()
        ..color = barColor
        ..style = PaintingStyle.fill,
    );

    // Border
    canvas.drawPath(
      path,
      Paint()
        ..color = borderColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4,
    );

    // Soft top highlight
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.white.withOpacity(0.04)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );
  }

  @override
  bool shouldRepaint(covariant _NotchBarPainter old) =>
      old.notchCenterX != notchCenterX ||
      old.barColor != barColor ||
      old.borderColor != borderColor;
}

class _NavButton extends StatelessWidget {
  final IconData? icon;
  final IconData? faIcon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  final Color? accentColor;

  const _NavButton({
    super.key,
    this.icon,
    this.faIcon,
    required this.label,
    required this.active,
    required this.onTap,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final color = active
        ? (accentColor ?? Colors.white)
        : Colors.white38;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (faIcon != null)
            FaIcon(faIcon, size: 20, color: color)
          else
            Icon(icon ?? Icons.circle, size: 22, color: color),
          const SizedBox(height: 3),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 9.5,
              color: color,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Gradient Button ──────────────────────────────────────────────────────────
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? null : const EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(13),
            boxShadow: _down ? [] : [
              BoxShadow(color: _C.redMid.withOpacity(0.3), blurRadius: 14, offset: const Offset(0, 4)),
            ],
          ),
          child: Center(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14))),
        ),
      ),
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.border.withOpacity(0.22)..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += step)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.red.withOpacity(0.10 + math.sin(t * math.pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9).createShader(
          Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}


// ─── Pantun Dashboard Card ────────────────────────────────────────────────────
class _PantunDashboardCard extends StatelessWidget {
  final VoidCallback onTap;
  const _PantunDashboardCard({required this.onTap});

  @override
  Widget build(BuildContext context) => _DashboardLiteratureCard(
        title: 'PANTUN',
        subtitle: 'Pantun pilihan untuk menemani harimu',
        icon: Icons.auto_stories_rounded,
        accent: const Color(0xFF7C3AED),
        preview: 'Bunga melati harum semerbak,\nDitanam di tepi kolam yang biru,\nHatiku selalu bergerak-gerak,\nSetiap kali aku melihatmu.',
        buttonText: 'BUKA PANTUN',
        onTap: onTap,
      );
}

// ─── Kata-kata Dashboard Card ────────────────────────────────────────────────
class _KataKataDashboardCard extends StatelessWidget {
  final VoidCallback onTap;
  const _KataKataDashboardCard({required this.onTap});

  @override
  Widget build(BuildContext context) => _DashboardLiteratureCard(
        title: 'KATA-KATA',
        subtitle: 'Kutipan cinta, sahabat, dan motivasi',
        icon: Icons.format_quote_rounded,
        accent: const Color(0xFFDB2777),
        preview: 'Jangan bandingkan perjalananmu dengan orang lain.\nSetiap orang memiliki waktunya masing-masing untuk bersinar.',
        buttonText: 'BUKA KATA-KATA',
        onTap: onTap,
      );
}

// ─── Puisi Dashboard Card ─────────────────────────────────────────────────────
class _PuisiDashboardCard extends StatelessWidget {
  final VoidCallback onTap;
  const _PuisiDashboardCard({required this.onTap});

  @override
  Widget build(BuildContext context) => _DashboardLiteratureCard(
        title: 'PUISI',
        subtitle: 'Kumpulan puisi percintaan, sahabat, dan kehidupan',
        icon: Icons.menu_book_rounded,
        accent: const Color(0xFF0891B2),
        preview: 'Kutulis namamu di tepi langit,\ndengan tinta embun pagi yang sejuk.\nTak perlu perangko, tak perlu alamat,\nsebab hatiku tahu jalan menuju hatimu.',
        buttonText: 'BUKA PUISI',
        onTap: onTap,
      );
}

class _DashboardLiteratureCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final String preview;
  final String buttonText;
  final VoidCallback onTap;

  const _DashboardLiteratureCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.preview,
    required this.buttonText,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF16090E),
                accent.withOpacity(.16),
                const Color(0xFF0B0B0B),
              ],
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: accent.withOpacity(.45), width: 1.2),
            boxShadow: [
              BoxShadow(color: accent.withOpacity(.12), blurRadius: 18),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: accent.withOpacity(.16),
                      border: Border.all(color: accent.withOpacity(.55)),
                    ),
                    child: Icon(icon, color: accent, size: 25),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold, fontFamily: 'Roboto')),
                        const SizedBox(height: 4),
                        Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 11.5)),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios_rounded, color: accent, size: 17),
                ],
              ),
              const SizedBox(height: 15),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.25),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.white.withOpacity(.06)),
                ),
                child: Text(
                  preview,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.white.withOpacity(.82), height: 1.45, fontSize: 12.5),
                ),
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(.18),
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: accent.withOpacity(.45)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(buttonText, style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.bold)),
                      const SizedBox(width: 5),
                      Icon(Icons.open_in_new_rounded, color: accent, size: 15),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Tabungan Dashboard Card ──────────────────────────────────────────────────
class _TabunganDashboardCard extends StatelessWidget {
  final String username;
  final String sessionKey;
  final VoidCallback onTap;

  const _TabunganDashboardCard({
    required this.username,
    required this.sessionKey,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF1A0B2E),
                Color(0xFF2D1B4E),
                Color(0xFF120A1E),
              ],
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: const Color(0xFFCE93D8).withOpacity(.45),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF4A148C).withOpacity(.22),
                blurRadius: 18,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFF4A148C), Color(0xFFCE93D8)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCE93D8).withOpacity(.25),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.savings_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'TABUNGAN',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Atur target, setor, dan tarik tabunganmu',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white.withOpacity(.65),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 13,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF4A148C),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: const Color(0xFFCE93D8).withOpacity(.35),
                  ),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'BUKA',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: .6,
                      ),
                    ),
                    SizedBox(width: 5),
                    Icon(
                      Icons.arrow_forward_rounded,
                      color: Colors.white,
                      size: 16,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Dashboard feature card (Berita / Edukasi) ──────────────────────────────
class _AccountStatData {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _AccountStatData(this.label, this.value, this.icon, this.color);
}

class _WelcomeMeta extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _WelcomeMeta({required this.icon, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 13, color: color),
    const SizedBox(width: 5),
    Text(label, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .6)),
  ]);
}

class _DashFeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _DashFeatureCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF121212),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Roboto',
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 10,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Thanks To Card (mengikuti AppTheme) ─────────────────────────────────────
class _ThanksCard extends StatelessWidget {
  final String username;
  final String role;
  final String link;
  final int index;

  const _ThanksCard({
    required this.username,
    required this.role,
    required this.link,
    this.index = 0,
  });

  Future<void> _openUrl() async {
    if (link.isEmpty) return;
    await launchUrl(
      Uri.parse(link),
      mode: LaunchMode.externalApplication,
    );
  }

  @override
  Widget build(BuildContext context) {
    final roleUpper = role.toUpperCase();
    final isDev = roleUpper.contains('DEV');
    final isPartner = roleUpper.contains('PARTNER');

    // Warna dari tema aktif — sedikit variasi per role agar tidak monoton
    final base = AppTheme.I.accent;
    final dark = AppTheme.I.accentDark;
    final Color accent = isDev
        ? base
        : isPartner
            ? Color.lerp(base, dark, 0.25)!
            : Color.lerp(base, Colors.white, 0.12 + (index % 3) * 0.04)!;

    final cardBg = AppTheme.I.card;
    final surface = AppTheme.I.surface;

    return GestureDetector(
      onTap: _openUrl,
      child: Container(
        width: 132,
        height: 168,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color.lerp(cardBg, accent, 0.12)!,
              Color.lerp(surface, accent, 0.06)!,
              surface,
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: accent.withOpacity(0.45),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.22),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.45),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            // soft glow orb
            Positioned(
              top: -20,
              right: -16,
              child: Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      accent.withOpacity(0.28),
                      accent.withOpacity(0.0),
                    ],
                  ),
                ),
              ),
            ),
            // top role ribbon
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accent.withOpacity(0.1),
                      accent,
                      accent.withOpacity(0.1),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 14, 10, 10),
              child: Column(
                children: [
                  // Avatar with ring
                  Container(
                    padding: const EdgeInsets.all(2.5),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          accent,
                          accent.withOpacity(0.35),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(0.35),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: CircleAvatar(
                      radius: 24,
                      backgroundColor: surface,
                      child: Text(
                        username.isNotEmpty ? username[0].toUpperCase() : '?',
                        style: TextStyle(
                          color: accent,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Username
                  SizedBox(
                    width: double.infinity,
                    child: Text(
                      username,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  // Role chip
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: accent.withOpacity(0.35)),
                    ),
                    child: Text(
                      isDev
                          ? 'DEVELOPER'
                          : isPartner
                              ? 'PARTNER'
                              : roleUpper,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: accent,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                  const Spacer(),
                  // Visit button
                  SizedBox(
                    width: double.infinity,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: _openUrl,
                        borderRadius: BorderRadius.circular(10),
                        child: Ink(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                accent.withOpacity(0.95),
                                dark.withOpacity(0.85),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 7),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.open_in_new_rounded,
                                  color: Colors.white,
                                  size: 12,
                                ),
                                SizedBox(width: 5),
                                Text(
                                  'Visit',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 0.4,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// ─── JJ Qaxer Video Card ──────────────────────────────────────────────────────
class _JJVideoCard extends StatefulWidget {
  final String videoUrl;
  const _JJVideoCard({required this.videoUrl});

  @override
  State<_JJVideoCard> createState() => _JJVideoCardState();
}

class _JJVideoCardState extends State<_JJVideoCard> {
  late VideoPlayerController _ctrl;
  bool _isInit = false;

  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..initialize().then((_) {
        if (mounted) {
          _ctrl.setLooping(true);
          _ctrl.setVolume(0);
          _ctrl.play();
          setState(() {
            _isInit = true;
          });
        }
      }).catchError((e) {
        debugPrint("Error loading JJ Video: $e");
      });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF3D1A1A)),
        color: Colors.black,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.4),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: _isInit
          ? SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: FittedBox(
                fit: BoxFit.cover, // Bikin video nutup seluruh kotak (kayak story WA/Tiktok)
                child: SizedBox(
                  width: _ctrl.value.size.width,
                  height: _ctrl.value.size.height,
                  child: VideoPlayer(_ctrl),
                ),
              ),
            )
          : const Center(
              child: CircularProgressIndicator(color: Color(0xFF0A84FF)),
            ),
    );
  }
}
// ─── News Media ───────────────────────────────────────────────────────────────
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({required this.url});

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Image.asset(
        'assets/images/banner.jpg',
        fit: BoxFit.cover,
      ),
      loadingBuilder: (_, child, loading) {
        if (loading == null) return child;
        return Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/banner2.jpg', fit: BoxFit.cover),
            Center(child: CircularProgressIndicator(color: _C.redLight, strokeWidth: 2)),
          ],
        );
      },
    );
  }
}

// ─── Developer Message Banner (buka dulu, baru hilang saat ditutup) ─────────
class _DeveloperMessageBanner extends StatefulWidget {
  final DeveloperMessage message;
  const _DeveloperMessageBanner({required this.message});

  @override
  State<_DeveloperMessageBanner> createState() =>
      _DeveloperMessageBannerState();
}

class _DeveloperMessageBannerState extends State<_DeveloperMessageBanner> {
  int _extra = 0;

  @override
  void initState() {
    super.initState();
    _loadExtra();
  }

  @override
  void didUpdateWidget(covariant _DeveloperMessageBanner oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.message.id != widget.message.id) _loadExtra();
  }

  Future<void> _loadExtra() async {
    final n =
        await DeveloperMessageService.instance.extraCount(widget.message.id);
    if (mounted) setState(() => _extra = n);
  }

  Color get _bg {
    switch (widget.message.type) {
      case 'warning':
        return const Color(0xFFE65100);
      case 'success':
        return const Color(0xFF2E7D32);
      case 'error':
        return const Color(0xFFC62828);
      case 'announcement':
        return const Color(0xFF6A1B9A);
      default:
        return const Color(0xFF1565C0);
    }
  }

  Future<void> _open() async {
    final msg = widget.message;
    await Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) =>
            DeveloperMessageHistoryPage(focusId: msg.id),
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
        transitionDuration: const Duration(milliseconds: 280),
      ),
    );
    // Setelah kembali dari halaman (pesan sudah dibuka+ditutup di dalam),
    // service sudah markOpenedAndClosed — banner ikut hilang via ValueListenable.
    if (mounted) _loadExtra();
  }

  @override
  Widget build(BuildContext context) {
    final msg = widget.message;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: _open,
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          decoration: BoxDecoration(
            color: _bg,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: _bg.withOpacity(0.4),
                blurRadius: 18,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.mail_rounded,
                      color: Colors.white, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              'PESAN DEVELOPER',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.6,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'dari ${msg.from}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.85),
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        msg.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (msg.message.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          msg.message,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 12,
                            height: 1.25,
                          ),
                        ),
                      ],
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          if (_extra > 0)
                            Text(
                              '+$_extra pesan lainnya',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.75),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          const Spacer(),
                          Text(
                            'Ketuk untuk membuka',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Icon(Icons.chevron_right_rounded,
                              color: Colors.white.withOpacity(0.85), size: 18),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
