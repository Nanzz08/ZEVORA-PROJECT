import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:fiona/Qaxer/api.dart';
import 'tiktok_buy_coin_page.dart';
import 'tiktok_live.dart';
import 'tiktok_coin_service.dart';
import 'premium_service.dart';
import 'premium_buy_page.dart';

/// Aplikasi TikTok-style: Scroll · Search · Upload · Chat · Akun · LIVE · Koin · Premium
class TiktokVideoPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const TiktokVideoPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<TiktokVideoPage> createState() => _TiktokVideoPageState();
}

class _TiktokVideoPageState extends State<TiktokVideoPage> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: IndexedStack(
        index: _tab,
        children: [
          _FeedTab(
            username: widget.username,
            sessionKey: widget.sessionKey,
          ),
          _SearchTab(username: widget.username),
          _UploadTab(
            username: widget.username,
            sessionKey: widget.sessionKey,
            onUploaded: () => setState(() => _tab = 0),
          ),
          _ChatTab(username: widget.username),
          _ProfileTab(
            username: widget.username,
            isMe: true,
            sessionKey: widget.sessionKey,
          ),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: Colors.white12, width: 0.5)),
          color: Colors.black,
        ),
        child: SafeArea(
          child: SizedBox(
            height: 56,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(0, Icons.home_filled, 'Scroll'),
                _navItem(1, Icons.search, 'Search'),
                _uploadNav(),
                _navItem(3, Icons.chat_bubble_outline, 'Chat'),
                _navItem(4, Icons.person_outline, 'Akun'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem(int i, IconData icon, String label) {
    final on = _tab == i;
    return InkWell(
      onTap: () => setState(() => _tab = i),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: on ? Colors.white : Colors.white54, size: 26),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: on ? Colors.white : Colors.white54,
              fontSize: 10,
              fontWeight: on ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }

  Widget _uploadNav() {
    return GestureDetector(
      onTap: () => setState(() => _tab = 2),
      child: Container(
        width: 44,
        height: 28,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: const LinearGradient(
            colors: [Color(0xFF25F4EE), Color(0xFFFE2C55)],
          ),
        ),
        child: Container(
          margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(6),
          ),
          child: const Icon(Icons.add, color: Colors.black, size: 22),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODEL + STORE
// ═══════════════════════════════════════════════════════════════
class _TtVideo {
  final String id;
  final String username;
  final String caption;
  final String videoUrl; // http or local path
  final String? thumb;
  int likes;
  int comments;
  int saves;
  final DateTime createdAt;
  final bool verified;

  _TtVideo({
    required this.id,
    required this.username,
    required this.caption,
    required this.videoUrl,
    this.thumb,
    this.likes = 0,
    this.comments = 0,
    this.saves = 0,
    required this.createdAt,
    this.verified = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'caption': caption,
        'videoUrl': videoUrl,
        'thumb': thumb,
        'likes': likes,
        'comments': comments,
        'saves': saves,
        'createdAt': createdAt.toIso8601String(),
        'verified': verified,
      };

  factory _TtVideo.fromJson(Map<String, dynamic> j) => _TtVideo(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? 'user',
        caption: j['caption']?.toString() ?? '',
        videoUrl: j['videoUrl']?.toString() ?? '',
        thumb: j['thumb']?.toString(),
        likes: int.tryParse('${j['likes']}') ?? 0,
        comments: int.tryParse('${j['comments']}') ?? 0,
        saves: int.tryParse('${j['saves']}') ?? 0,
        createdAt:
            DateTime.tryParse(j['createdAt']?.toString() ?? '') ?? DateTime.now(),
        verified: j['verified'] == true,
      );
}

class _TtComment {
  final String id, videoId, username, text;
  final DateTime at;
  _TtComment({
    required this.id,
    required this.videoId,
    required this.username,
    required this.text,
    required this.at,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'videoId': videoId,
        'username': username,
        'text': text,
        'at': at.toIso8601String(),
      };
  factory _TtComment.fromJson(Map<String, dynamic> j) => _TtComment(
        id: j['id']?.toString() ?? '',
        videoId: j['videoId']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        text: j['text']?.toString() ?? '',
        at: DateTime.tryParse(j['at']?.toString() ?? '') ?? DateTime.now(),
      );
}

class _TtStore {
  static const _vKey = 'tt_videos_v1';
  static const _cKey = 'tt_comments_v1';
  static const _likeKey = 'tt_liked_v1';
  static const _saveKey = 'tt_saved_v1';
  static const _followKey = 'tt_follow_v1';
  static const _blockKey = 'tt_block_v1';
  static const _profileKey = 'tt_profile_v1';
  static const _chatKey = 'tt_chats_v1';

  static Future<List<_TtVideo>> loadVideos() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_vKey) ?? [];
    final list = <_TtVideo>[];
    for (final s in raw) {
      try {
        list.add(_TtVideo.fromJson(jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {}
    }
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (list.isEmpty) {
      // Seed demo feed (network sample clips — optional fallbacks)
      final demo = [
        _TtVideo(
          id: 'demo1',
          username: 'madara',
          caption: 'Nih Vidio bagus',
          videoUrl:
              'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
          likes: 2,
          comments: 3,
          createdAt: DateTime.now().subtract(const Duration(hours: 2)),
        ),
        _TtVideo(
          id: 'demo2',
          username: 'madara',
          caption: 'semoga di sana gw baik #semestalain',
          videoUrl:
              'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4',
          likes: 2,
          comments: 0,
          createdAt: DateTime.now().subtract(const Duration(hours: 5)),
        ),
      ];
      await saveVideos(demo);
      return demo;
    }
    return list;
  }

  static Future<void> saveVideos(List<_TtVideo> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      _vKey,
      list.map((v) => jsonEncode(v.toJson())).toList(),
    );
  }

  static Future<void> addVideo(_TtVideo v) async {
    final list = await loadVideos();
    list.insert(0, v);
    await saveVideos(list);
  }

  static Future<void> updateVideo(_TtVideo v) async {
    final list = await loadVideos();
    final i = list.indexWhere((e) => e.id == v.id);
    if (i >= 0) {
      list[i] = v;
      await saveVideos(list);
    }
  }

  static Future<Set<String>> likedIds() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_likeKey) ?? []).toSet();
  }

  static Future<void> toggleLike(String id) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(_likeKey) ?? []).toSet();
    if (s.contains(id)) {
      s.remove(id);
    } else {
      s.add(id);
    }
    await p.setStringList(_likeKey, s.toList());
  }

  static Future<Set<String>> savedIds() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_saveKey) ?? []).toSet();
  }

  static Future<void> toggleSave(String id) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(_saveKey) ?? []).toSet();
    if (s.contains(id)) {
      s.remove(id);
    } else {
      s.add(id);
    }
    await p.setStringList(_saveKey, s.toList());
  }

  static Future<List<_TtComment>> commentsFor(String videoId) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_cKey) ?? [];
    final out = <_TtComment>[];
    for (final s in raw) {
      try {
        final c = _TtComment.fromJson(jsonDecode(s) as Map<String, dynamic>);
        if (c.videoId == videoId) out.add(c);
      } catch (_) {}
    }
    out.sort((a, b) => a.at.compareTo(b.at));
    return out;
  }

  static Future<void> addComment(_TtComment c) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_cKey) ?? [];
    raw.add(jsonEncode(c.toJson()));
    await p.setStringList(_cKey, raw);
  }

  static Future<Set<String>> following() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_followKey) ?? []).toSet();
  }

  static Future<void> toggleFollow(String user) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(_followKey) ?? []).toSet();
    if (s.contains(user)) {
      s.remove(user);
    } else {
      s.add(user);
    }
    await p.setStringList(_followKey, s.toList());
  }

  static Future<Set<String>> blocked() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_blockKey) ?? []).toSet();
  }

  static Future<void> block(String user) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(_blockKey) ?? []).toSet()..add(user);
    await p.setStringList(_blockKey, s.toList());
  }

  static Future<Map<String, String>> profile(String user) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('$_profileKey$user');
    if (raw == null) return {'bio': '', 'avatar': ''};
    try {
      return Map<String, String>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {'bio': '', 'avatar': ''};
    }
  }

  static Future<void> saveProfile(
      String user, String bio, String avatar) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      '$_profileKey$user',
      jsonEncode({'bio': bio, 'avatar': avatar}),
    );
  }

  static Future<List<Map<String, dynamic>>> chatWith(String peer) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('$_chatKey$peer') ?? [];
    final out = <Map<String, dynamic>>[];
    for (final s in raw) {
      try {
        out.add(Map<String, dynamic>.from(jsonDecode(s) as Map));
      } catch (_) {}
    }
    return out;
  }

  static Future<void> sendChat(String peer, String from, String text) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('$_chatKey$peer') ?? [];
    raw.add(jsonEncode({
      'from': from,
      'text': text,
      'at': DateTime.now().toIso8601String(),
    }));
    await p.setStringList('$_chatKey$peer', raw);
  }
}

// ═══════════════════════════════════════════════════════════════
// FEED (Scroll)
// ═══════════════════════════════════════════════════════════════
class _FeedTab extends StatefulWidget {
  final String username, sessionKey;
  const _FeedTab({required this.username, required this.sessionKey});

  @override
  State<_FeedTab> createState() => _FeedTabState();
}

class _FeedTabState extends State<_FeedTab> {
  List<_TtVideo> _allVideos = [];
  List<_TtVideo> _videos = [];
  Set<String> _liked = {};
  Set<String> _saved = {};
  Set<String> _following = {};
  Set<String> _blocked = {};
  final PageController _page = PageController();
  int _index = 0;
  bool _loading = true;
  /// 0 = Untuk Anda, 1 = Mengikuti
  int _feedMode = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _applyFeedFilter() {
    if (_feedMode == 1) {
      _videos = _allVideos
          .where((v) => _following.contains(v.username))
          .toList();
    } else {
      _videos = List<_TtVideo>.from(_allVideos);
    }
    _index = 0;
    if (_page.hasClients) {
      _page.jumpToPage(0);
    }
  }

  Future<void> _reload() async {
    final vids = await _TtStore.loadVideos();
    final liked = await _TtStore.likedIds();
    final saved = await _TtStore.savedIds();
    final fol = await _TtStore.following();
    final blk = await _TtStore.blocked();
    if (!mounted) return;
    setState(() {
      _blocked = blk;
      _allVideos = vids.where((v) => !blk.contains(v.username)).toList();
      _liked = liked;
      _saved = saved;
      _following = fol;
      _applyFeedFilter();
      _loading = false;
    });
  }

  @override
  void dispose() {
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFFE2C55)),
      );
    }
    return Stack(
      children: [
        if (_videos.isEmpty)
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _feedMode == 1 ? Icons.people_outline : Icons.videocam_off,
                  color: Colors.white38,
                  size: 64,
                ),
                const SizedBox(height: 12),
                Text(
                  _feedMode == 1
                      ? 'Belum ada video dari yang kamu ikuti'
                      : 'Belum ada video',
                  style: const TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                TextButton(
                  onPressed: _reload,
                  child: const Text('Muat ulang',
                      style: TextStyle(color: Color(0xFFFE2C55))),
                ),
              ],
            ),
          )
        else
          PageView.builder(
            controller: _page,
            scrollDirection: Axis.vertical,
            itemCount: _videos.length,
            onPageChanged: (i) => setState(() => _index = i),
            itemBuilder: (_, i) => _VideoPage(
              video: _videos[i],
            isActive: i == _index,
            liked: _liked.contains(_videos[i].id),
            saved: _saved.contains(_videos[i].id),
            following: _following.contains(_videos[i].username),
            me: widget.username,
            onLike: () async {
              final v = _videos[i];
              final was = _liked.contains(v.id);
              await _TtStore.toggleLike(v.id);
              setState(() {
                if (was) {
                  _liked.remove(v.id);
                  v.likes = max(0, v.likes - 1);
                } else {
                  _liked.add(v.id);
                  v.likes++;
                }
              });
              await _TtStore.updateVideo(v);
            },
            onSave: () async {
              final v = _videos[i];
              final was = _saved.contains(v.id);
              await _TtStore.toggleSave(v.id);
              setState(() {
                if (was) {
                  _saved.remove(v.id);
                  v.saves = max(0, v.saves - 1);
                } else {
                  _saved.add(v.id);
                  v.saves++;
                }
              });
              await _TtStore.updateVideo(v);
              if (mounted && !was) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Row(
                      children: [
                        Text('Video disimpan '),
                        Icon(Icons.bookmark, color: Colors.white, size: 16),
                      ],
                    ),
                    duration: Duration(seconds: 1),
                    backgroundColor: Colors.black87,
                  ),
                );
              }
            },
            onComment: () => _openComments(_videos[i]),
            onFollow: () async {
              final u = _videos[i].username;
              await _TtStore.toggleFollow(u);
              final fol = await _TtStore.following();
              setState(() => _following = fol);
            },
            onBlock: () async {
              final u = _videos[i].username;
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: const Color(0xFF1A1A1A),
                  title: Text('Blokir @$u?',
                      style: const TextStyle(color: Colors.white)),
                  content: const Text(
                    'Video dari akun ini tidak akan muncul di feed.',
                    style: TextStyle(color: Colors.white70),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Batal',
                          style: TextStyle(color: Colors.white54)),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Blokir',
                          style: TextStyle(color: Color(0xFFFE2C55))),
                    ),
                  ],
                ),
              );
              if (ok == true) {
                await _TtStore.block(u);
                await _reload();
              }
            },
            onProfile: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => Scaffold(
                    backgroundColor: Colors.transparent,
                    appBar: AppBar(
                      title: Text('@${_videos[i].username}',
                          style: const TextStyle(color: Colors.white)),
                      iconTheme: const IconThemeData(color: Colors.white),
                    ),
                    body: _ProfileTab(
                      username: _videos[i].username,
                      isMe: _videos[i].username == widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        // Top bar — Search | Mengikuti | Untuk Anda + Koin + Notif + LIVE
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Row(
              children: [
                // SEARCH
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: _openSearchSheet,
                    child: const Padding(
                      padding: EdgeInsets.all(6),
                      child: Icon(Icons.search, color: Colors.white70, size: 22),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // MENGIKUTI
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () {
                      if (_feedMode == 1) return;
                      setState(() {
                        _feedMode = 1;
                        _applyFeedFilter();
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Mengikuti',
                            style: TextStyle(
                              color: _feedMode == 1 ? Colors.white : Colors.white54,
                              fontSize: 15,
                              fontWeight: _feedMode == 1
                                  ? FontWeight.w700
                                  : FontWeight.normal,
                            ),
                          ),
                          const SizedBox(height: 3),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 28,
                            height: 2.5,
                            decoration: BoxDecoration(
                              color: _feedMode == 1
                                  ? Colors.white
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // UNTUK ANDA
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () {
                      if (_feedMode == 0) return;
                      setState(() {
                        _feedMode = 0;
                        _applyFeedFilter();
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'Untuk Anda',
                            style: TextStyle(
                              color: _feedMode == 0 ? Colors.white : Colors.white54,
                              fontSize: 15,
                              fontWeight: _feedMode == 0
                                  ? FontWeight.w700
                                  : FontWeight.normal,
                            ),
                          ),
                          const SizedBox(height: 3),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 28,
                            height: 2.5,
                            decoration: BoxDecoration(
                              color: _feedMode == 0
                                  ? Colors.white
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const Spacer(),
                // Beli Koin
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => TiktokBuyCoinPage(
                            username: widget.username,
                            sessionKey: widget.sessionKey,
                          ),
                        ),
                      );
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                      child: Icon(Icons.monetization_on_outlined,
                          color: Color(0xFFFFD54F), size: 22),
                    ),
                  ),
                ),
                // NOTIFIKASI
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: _openNotifSheet,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                      child: Icon(Icons.notifications_none,
                          color: Colors.white70, size: 22),
                    ),
                  ),
                ),
                // LIVE list
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (_) => TiktokLiveListSheet(
                          username: widget.username,
                          sessionKey: widget.sessionKey,
                        ),
                      );
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                      child: Icon(Icons.live_tv,
                          color: Color(0xFFFE2C55), size: 22),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _openSearchSheet() {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF121212),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Cari video / user',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                cursorColor: const Color(0xFFFE2C55),
                decoration: InputDecoration(
                  hintText: 'Cari username atau judul…',
                  hintStyle: const TextStyle(color: Colors.white38),
                  prefixIcon:
                      const Icon(Icons.search, color: Colors.white54),
                  filled: true,
                  fillColor: const Color(0xFF1E1E1E),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                ),
                onSubmitted: (q) {
                  Navigator.pop(ctx);
                  final query = q.trim().toLowerCase();
                  if (query.isEmpty) return;
                  setState(() {
                    _videos = _allVideos
                        .where((v) =>
                            v.username.toLowerCase().contains(query) ||
                            (v.caption ?? '')
                                .toLowerCase()
                                .contains(query))
                        .toList();
                    _index = 0;
                    if (_page.hasClients) _page.jumpToPage(0);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                          'Hasil pencarian: ${_videos.length} video'),
                      backgroundColor: const Color(0xFFFE2C55),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFE2C55),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () {
                    final q = ctrl.text.trim().toLowerCase();
                    Navigator.pop(ctx);
                    if (q.isEmpty) return;
                    setState(() {
                      _videos = _allVideos
                          .where((v) =>
                              v.username.toLowerCase().contains(q) ||
                              (v.caption ?? '').toLowerCase().contains(q))
                          .toList();
                      _index = 0;
                      if (_page.hasClients) _page.jumpToPage(0);
                    });
                  },
                  child: const Text('Cari',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  void _openNotifSheet() {
    final notifs = [
      {
        'icon': Icons.favorite,
        'color': const Color(0xFFFE2C55),
        'title': 'Seseorang menyukai video kamu',
        'sub': '2 menit lalu',
      },
      {
        'icon': Icons.person_add,
        'color': const Color(0xFF25F4EE),
        'title': 'User baru mulai mengikuti kamu',
        'sub': '15 menit lalu',
      },
      {
        'icon': Icons.comment,
        'color': Colors.amber,
        'title': 'Komentar baru di video kamu',
        'sub': '1 jam lalu',
      },
      {
        'icon': Icons.live_tv,
        'color': const Color(0xFFFE2C55),
        'title': 'LIVE sedang berlangsung',
        'sub': 'Baru saja',
      },
      {
        'icon': Icons.monetization_on,
        'color': const Color(0xFFFFD54F),
        'title': 'Koin berhasil ditambahkan',
        'sub': 'Kemarin',
      },
    ];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF121212),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.55,
          minChildSize: 0.35,
          maxChildSize: 0.85,
          builder: (_, scrollCtrl) {
            return Column(
              children: [
                const SizedBox(height: 10),
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Row(
                    children: [
                      Text(
                        'Notifikasi',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Spacer(),
                      Icon(Icons.notifications_active,
                          color: Color(0xFFFE2C55), size: 20),
                    ],
                  ),
                ),
                const Divider(color: Colors.white12, height: 1),
                Expanded(
                  child: ListView.separated(
                    controller: scrollCtrl,
                    itemCount: notifs.length,
                    separatorBuilder: (_, __) =>
                        const Divider(color: Colors.white10, height: 1),
                    itemBuilder: (_, i) {
                      final n = notifs[i];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor:
                              (n['color'] as Color).withOpacity(0.15),
                          child: Icon(n['icon'] as IconData,
                              color: n['color'] as Color, size: 20),
                        ),
                        title: Text(
                          n['title'] as String,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 14),
                        ),
                        subtitle: Text(
                          n['sub'] as String,
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12),
                        ),
                        onTap: () => Navigator.pop(ctx),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _openComments(_TtVideo v) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF161616),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => _CommentsSheet(
        video: v,
        me: widget.username,
        onCountChanged: (n) {
          setState(() => v.comments = n);
          _TtStore.updateVideo(v);
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SINGLE VIDEO PAGE
// ═══════════════════════════════════════════════════════════════
class _VideoPage extends StatefulWidget {
  final _TtVideo video;
  final bool isActive;
  final bool liked, saved, following;
  final String me;
  final VoidCallback onLike, onSave, onComment, onFollow, onBlock, onProfile;

  const _VideoPage({
    required this.video,
    required this.isActive,
    required this.liked,
    required this.saved,
    required this.following,
    required this.me,
    required this.onLike,
    required this.onSave,
    required this.onComment,
    required this.onFollow,
    required this.onBlock,
    required this.onProfile,
  });

  @override
  State<_VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<_VideoPage> {
  VideoPlayerController? _ctrl;
  bool _ready = false;
  bool _paused = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void didUpdateWidget(covariant _VideoPage old) {
    super.didUpdateWidget(old);
    if (widget.isActive && !old.isActive) {
      _ctrl?.play();
      setState(() => _paused = false);
    } else if (!widget.isActive && old.isActive) {
      _ctrl?.pause();
    }
  }

  Future<void> _init() async {
    try {
      final url = widget.video.videoUrl;
      VideoPlayerController c;
      if (url.startsWith('http')) {
        c = VideoPlayerController.networkUrl(Uri.parse(url));
      } else {
        c = VideoPlayerController.file(File(url));
      }
      await c.initialize();
      c.setLooping(true);
      if (widget.isActive) c.play();
      if (mounted) {
        setState(() {
          _ctrl = c;
          _ready = true;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  void _togglePlay() {
    if (_ctrl == null) return;
    if (_ctrl!.value.isPlaying) {
      _ctrl!.pause();
      setState(() => _paused = true);
    } else {
      _ctrl!.play();
      setState(() => _paused = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _togglePlay,
      onDoubleTap: widget.onLike,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Video
          if (_ready && _ctrl != null)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _ctrl!.value.size.width,
                height: _ctrl!.value.size.height,
                child: VideoPlayer(_ctrl!),
              ),
            )
          else if (_error != null)
            Container(
              color: Colors.black,
              alignment: Alignment.center,
              child: const Icon(Icons.broken_image, color: Colors.white38, size: 48),
            )
          else
            const Center(
              child: CircularProgressIndicator(color: Color(0xFFFE2C55)),
            ),

          if (_paused)
            const Center(
              child: Icon(Icons.play_arrow, color: Colors.white70, size: 72),
            ),

          // Gradient bottom
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 220,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
            ),
          ),

          // Right actions
          Positioned(
            right: 10,
            bottom: 100,
            child: Column(
              children: [
                _sideBtn(
                  icon: widget.liked ? Icons.favorite : Icons.favorite_border,
                  color: widget.liked ? const Color(0xFFFE2C55) : Colors.white,
                  count: '${widget.video.likes}',
                  onTap: widget.onLike,
                ),
                const SizedBox(height: 18),
                _sideBtn(
                  icon: Icons.chat_bubble_outline,
                  count: '${widget.video.comments}',
                  onTap: widget.onComment,
                ),
                const SizedBox(height: 18),
                _sideBtn(
                  icon: widget.saved
                      ? Icons.bookmark
                      : Icons.bookmark_border,
                  color: widget.saved ? const Color(0xFFFE2C55) : Colors.white,
                  count: '${widget.video.saves}',
                  onTap: widget.onSave,
                ),
                const SizedBox(height: 18),
                _sideBtn(
                  icon: Icons.block,
                  label: 'Blokir',
                  onTap: widget.onBlock,
                ),
              ],
            ),
          ),

          // Bottom left info
          Positioned(
            left: 12,
            right: 72,
            bottom: 24,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    GestureDetector(
                      onTap: widget.onProfile,
                      child: VerifiedName(
                        username: widget.video.username,
                        displayName: '@${widget.video.username}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                        badgeSize: 16,
                      ),
                    ),
                    const SizedBox(width: 10),
                    if (widget.video.username != widget.me)
                      GestureDetector(
                        onTap: widget.onFollow,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: widget.following
                                ? Colors.white24
                                : const Color(0xFFFE2C55),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            widget.following ? 'Following' : 'Follow',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  widget.video.caption,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sideBtn({
    required IconData icon,
    String? count,
    String? label,
    Color color = Colors.white,
    required VoidCallback onTap,
  }) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Icon(icon, color: color, size: 32),
        ),
        const SizedBox(height: 2),
        Text(
          label ?? count ?? '',
          style: const TextStyle(color: Colors.white, fontSize: 12),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// COMMENTS
// ═══════════════════════════════════════════════════════════════
class _CommentsSheet extends StatefulWidget {
  final _TtVideo video;
  final String me;
  final ValueChanged<int> onCountChanged;

  const _CommentsSheet({
    required this.video,
    required this.me,
    required this.onCountChanged,
  });

  @override
  State<_CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<_CommentsSheet> {
  List<_TtComment> _list = [];
  final _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await _TtStore.commentsFor(widget.video.id);
    if (mounted) setState(() => _list = c);
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    final c = _TtComment(
      id: 'c_${DateTime.now().millisecondsSinceEpoch}',
      videoId: widget.video.id,
      username: widget.me,
      text: t,
      at: DateTime.now(),
    );
    await _TtStore.addComment(c);
    _ctrl.clear();
    await _load();
    widget.onCountChanged(_list.length);
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height * 0.55;
    return SizedBox(
      height: h,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
            child: Row(
              children: [
                const Text(
                  'Komentar',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(color: Colors.white12, height: 1),
          Expanded(
            child: _list.isEmpty
                ? const Center(
                    child: Text(
                      'Belum ada komentar.\nJadilah yang pertama!',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white38),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _list.length,
                    itemBuilder: (_, i) {
                      final c = _list[i];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: const Color(0xFF333333),
                          child: Text(
                            c.username.isNotEmpty
                                ? c.username[0].toUpperCase()
                                : '?',
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                        title: VerifiedName(
                          username: c.username,
                          displayName: '@${c.username}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                          badgeSize: 14,
                        ),
                        subtitle: Text(
                          c.text,
                          style: const TextStyle(color: Colors.white70),
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 12,
              right: 12,
              bottom: MediaQuery.of(context).viewInsets.bottom + 12,
              top: 8,
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Tambah komentar...',
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: const Color(0xFF2A2A2A),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFE2C55),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                  ),
                  onPressed: _send,
                  child: const Text('Kirim',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SEARCH
// ═══════════════════════════════════════════════════════════════
class _SearchTab extends StatefulWidget {
  final String username;
  const _SearchTab({required this.username});

  @override
  State<_SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<_SearchTab> {
  final _ctrl = TextEditingController();
  List<_TtVideo> _results = [];
  bool _searched = false;

  Future<void> _search() async {
    final q = _ctrl.text.trim().toLowerCase().replaceAll('@', '');
    final all = await _TtStore.loadVideos();
    if (q.isEmpty) {
      setState(() {
        _results = [];
        _searched = true;
      });
      return;
    }
    setState(() {
      _results = all
          .where((v) =>
              v.username.toLowerCase().contains(q) ||
              v.caption.toLowerCase().contains(q))
          .toList();
      _searched = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text(
              'Cari',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Cari video / @akun...',
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: const Color(0xFF1F1F1F),
                      prefixIcon:
                          const Icon(Icons.search, color: Colors.white38),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 0),
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFE2C55),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                  ),
                  onPressed: _search,
                  child: const Text('Cari',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
          Expanded(
            child: !_searched
                ? const Center(
                    child: Text(
                      'Ketik untuk mencari video atau akun',
                      style: TextStyle(color: Colors.white38),
                    ),
                  )
                : _results.isEmpty
                    ? const Center(
                        child: Text('Tidak ditemukan',
                            style: TextStyle(color: Colors.white38)),
                      )
                    : ListView.builder(
                        itemCount: _results.length,
                        itemBuilder: (_, i) {
                          final v = _results[i];
                          return ListTile(
                            leading: const CircleAvatar(
                              backgroundColor: Color(0xFF333333),
                              child: Icon(Icons.play_arrow,
                                  color: Colors.white),
                            ),
                            title: Text('@${v.username}',
                                style: const TextStyle(color: Colors.white)),
                            subtitle: Text(
                              v.caption,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white54),
                            ),
                            trailing: Text(
                              '♥ ${v.likes}',
                              style: const TextStyle(color: Colors.white54),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// UPLOAD
// ═══════════════════════════════════════════════════════════════
class _UploadTab extends StatefulWidget {
  final String username, sessionKey;
  final VoidCallback onUploaded;
  const _UploadTab({
    required this.username,
    required this.sessionKey,
    required this.onUploaded,
  });

  @override
  State<_UploadTab> createState() => _UploadTabState();
}

class _UploadTabState extends State<_UploadTab> {
  File? _file;
  final _caption = TextEditingController();
  bool _posting = false;

  Future<void> _pick() async {
    final p = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (p != null) setState(() => _file = File(p.path));
  }

  Future<void> _post() async {
    if (_file == null || _posting) return;
    setState(() => _posting = true);
    final v = _TtVideo(
      id: 'v_${DateTime.now().millisecondsSinceEpoch}',
      username: widget.username,
      caption: _caption.text.trim().isEmpty
          ? 'Video baru'
          : _caption.text.trim(),
      videoUrl: _file!.path,
      createdAt: DateTime.now(),
    );
    await _TtStore.addVideo(v);

    // Coba kirim ke server (opsional)
    try {
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('${Api.api}/tiktok/upload'),
      );
      req.fields['username'] = widget.username;
      req.fields['key'] = widget.sessionKey;
      req.fields['caption'] = v.caption;
      req.files.add(await http.MultipartFile.fromPath('video', _file!.path));
      await req.send().timeout(const Duration(seconds: 30));
    } catch (_) {}

    if (mounted) {
      setState(() {
        _posting = false;
        _file = null;
        _caption.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Video diposting!')),
      );
      widget.onUploaded();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Upload Video',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: _pick,
              child: Container(
                height: 220,
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white12),
                ),
                child: _file == null
                    ? const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.video_library_outlined,
                              color: Colors.white38, size: 48),
                          SizedBox(height: 8),
                          Text('Pilih video dari galeri',
                              style: TextStyle(color: Colors.white54)),
                        ],
                      )
                    : Center(
                        child: Text(
                          _file!.path.split('/').last,
                          style: const TextStyle(color: Colors.white70),
                          textAlign: TextAlign.center,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _caption,
              style: const TextStyle(color: Colors.white),
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Tulis caption...',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF1A1A1A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: _posting || _file == null ? null : _post,
              child: _posting
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Text(
                      'Posting',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// CHAT
// ═══════════════════════════════════════════════════════════════
class _ChatTab extends StatefulWidget {
  final String username;
  const _ChatTab({required this.username});

  @override
  State<_ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<_ChatTab> {
  final _search = TextEditingController();

  void _openChat(String peer) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _ChatRoom(
          me: widget.username,
          peer: peer,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text(
              'Chat',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _search,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Cari @username...',
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: const Color(0xFF1F1F1F),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (v) {
                      final u = v.trim().replaceAll('@', '');
                      if (u.isNotEmpty) _openChat(u);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFE2C55),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                  ),
                  onPressed: () {
                    final u = _search.text.trim().replaceAll('@', '');
                    if (u.isNotEmpty) _openChat(u);
                  },
                  child: const Text('Cari',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
          const Expanded(
            child: Center(
              child: Text(
                'Cari username untuk mulai chat',
                style: TextStyle(color: Colors.white38),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatRoom extends StatefulWidget {
  final String me, peer;
  const _ChatRoom({required this.me, required this.peer});

  @override
  State<_ChatRoom> createState() => _ChatRoomState();
}

class _ChatRoomState extends State<_ChatRoom> {
  List<Map<String, dynamic>> _msgs = [];
  final _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final m = await _TtStore.chatWith(widget.peer);
    if (mounted) setState(() => _msgs = m);
  }

  Future<void> _send() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    await _TtStore.sendChat(widget.peer, widget.me, t);
    _ctrl.clear();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          '@${widget.peer}',
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _msgs.length,
              itemBuilder: (_, i) {
                final m = _msgs[i];
                final mine = m['from'] == widget.me;
                return Align(
                  alignment:
                      mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: mine
                          ? const Color(0xFFFE2C55)
                          : const Color(0xFF2A2A2A),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      m['text']?.toString() ?? '',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Pesan...',
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: const Color(0xFF1F1F1F),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  backgroundColor: const Color(0xFFFE2C55),
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white, size: 18),
                    onPressed: _send,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// PROFILE
// ═══════════════════════════════════════════════════════════════
class _ProfileTab extends StatefulWidget {
  final String username;
  final bool isMe;
  final String sessionKey;

  const _ProfileTab({
    required this.username,
    required this.isMe,
    required this.sessionKey,
  });

  @override
  State<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<_ProfileTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  List<_TtVideo> _myVideos = [];
  List<_TtVideo> _liked = [];
  String _bio = '';
  Set<String> _followers = {};
  Set<String> _following = {};

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    _load();
  }

  Future<void> _load() async {
    final all = await _TtStore.loadVideos();
    final likedIds = await _TtStore.likedIds();
    final fol = await _TtStore.following();
    final prof = await _TtStore.profile(widget.username);
    // Followers = orang yang follow user ini (approx: jika isMe, hitung dari store tidak akurat; tampilkan following count)
    if (!mounted) return;
    setState(() {
      _myVideos = all.where((v) => v.username == widget.username).toList();
      _liked = all.where((v) => likedIds.contains(v.id)).toList();
      _bio = prof['bio'] ?? '';
      _following = fol;
      // Dummy follower for demo of self profile
      _followers = {};
      if (widget.isMe) {
        // users who we know follow — simplified
      }
    });
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  void _editProfile() {
    final bioCtrl = TextEditingController(text: _bio);
    final avCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Edit Profil',
            style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: bioCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Bio',
                labelStyle: TextStyle(color: Colors.white54),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white24)),
              ),
            ),
            TextField(
              controller: avCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'URL foto profil (opsional)',
                labelStyle: TextStyle(color: Colors.white54),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white24)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55)),
            onPressed: () async {
              await _TtStore.saveProfile(
                  widget.username, bioCtrl.text.trim(), avCtrl.text.trim());
              if (mounted) {
                Navigator.pop(ctx);
                _load();
              }
            },
            child: const Text('Simpan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final totalLikes = _myVideos.fold<int>(0, (a, v) => a + v.likes);
    return Column(
      children: [
        if (!widget.isMe) const SizedBox(height: 8),
        if (widget.isMe) const SafeArea(bottom: false, child: SizedBox(height: 8)),
        const SizedBox(height: 16),
        CircleAvatar(
          radius: 44,
          backgroundColor: const Color(0xFF333333),
          child: Text(
            widget.username.isNotEmpty
                ? widget.username[0].toUpperCase()
                : '?',
            style: const TextStyle(color: Colors.white, fontSize: 32),
          ),
        ),
        const SizedBox(height: 10),
        // Username hanya 1x + centang biru (jika verified)
        VerifiedName(
          username: widget.username,
          displayName: widget.username,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
          badgeSize: 18,
        ),
        const SizedBox(height: 2),
        Text(
          '@${widget.username}',
          style: TextStyle(
            color: Colors.white.withOpacity(0.45),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (widget.isMe) ...[
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => PremiumBuyPage(
                    username: widget.username,
                    sessionKey: widget.sessionKey,
                  ),
                ),
              );
            },
            icon: const Icon(Icons.verified, color: Color(0xFF1D9BF0), size: 18),
            label: const Text(
              'Centang Biru',
              style: TextStyle(color: Color(0xFF1D9BF0)),
            ),
          ),
        ],
        const SizedBox(height: 8),
        Text(
          _bio.isEmpty ? 'Belum ada bio' : _bio,
          style: const TextStyle(color: Colors.white54, fontSize: 13),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _stat('${_following.length}', 'Mengikuti'),
            const SizedBox(width: 28),
            _stat('${_followers.length}', 'Pengikut'),
            const SizedBox(width: 28),
            _stat('$totalLikes', 'Suka'),
          ],
        ),
        const SizedBox(height: 16),
        if (widget.isMe)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                onPressed: _editProfile,
                child: const Text('Edit Profil'),
              ),
              const SizedBox(width: 12),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Keluar'),
              ),
            ],
          ),
        const SizedBox(height: 8),
        TabBar(
          controller: _tabs,
          indicatorColor: const Color(0xFF25F4EE),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(text: 'Video'),
            Tab(text: 'Suka'),
            Tab(text: 'Pengikut'),
            Tab(text: 'Mengikuti'),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [
              _videoGrid(_myVideos, empty: 'Belum ada video'),
              _videoGrid(_liked, empty: 'Belum ada video disukai'),
              _userList(_followers.toList(), empty: 'Belum ada pengikut'),
              _userList(_following.toList(), empty: 'Belum mengikuti siapapun'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _stat(String n, String label) {
    return Column(
      children: [
        Text(n,
            style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 17)),
        Text(label,
            style: const TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    );
  }

  Widget _videoGrid(List<_TtVideo> list, {required String empty}) {
    if (list.isEmpty) {
      return Center(
        child: Text(empty, style: const TextStyle(color: Colors.white38)),
      );
    }
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        childAspectRatio: 9 / 16,
      ),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final v = list[i];
        return Container(
          color: const Color(0xFF1A1A1A),
          child: Stack(
            fit: StackFit.expand,
            children: [
              const Center(
                child: Icon(Icons.play_circle_outline,
                    color: Colors.white24, size: 32),
              ),
              Positioned(
                left: 4,
                bottom: 4,
                child: Row(
                  children: [
                    const Icon(Icons.favorite, color: Colors.white, size: 12),
                    const SizedBox(width: 2),
                    Text('${v.likes}',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _userList(List<String> users, {required String empty}) {
    if (users.isEmpty) {
      return Center(
        child: Text(empty, style: const TextStyle(color: Colors.white38)),
      );
    }
    return ListView.builder(
      itemCount: users.length,
      itemBuilder: (_, i) {
        final u = users[i];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF333333),
            child: Text(
              u.isNotEmpty ? u[0].toUpperCase() : '?',
              style: const TextStyle(color: Colors.white),
            ),
          ),
          title: VerifiedName(
            username: u,
            displayName: '@$u',
            style: const TextStyle(color: Colors.white),
            badgeSize: 14,
          ),
          subtitle: const Text('0 pengikut',
              style: TextStyle(color: Colors.white38, fontSize: 12)),
        );
      },
    );
  }
}
