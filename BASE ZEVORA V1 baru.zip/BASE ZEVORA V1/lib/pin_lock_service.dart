import 'package:shared_preferences/shared_preferences.dart';

/// Service penyimpanan PIN / Pattern lock aplikasi.
class PinLockService {
  static const _kEnabled = 'app_pin_enabled';
  static const _kType = 'app_pin_type'; // 'pin' | 'pattern'
  static const _kValue = 'app_pin_value';

  static Future<bool> isEnabled() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(_kEnabled) ?? false;
  }

  static Future<String?> getType() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kType);
  }

  static Future<String?> getValue() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kValue);
  }

  /// value: 4-digit pin string, or pattern as "0-1-4-7" etc (0-8 grid)
  static Future<void> setLock({
    required String type,
    required String value,
  }) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kEnabled, true);
    await p.setString(_kType, type);
    await p.setString(_kValue, value);
  }

  static Future<void> clearLock() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kEnabled, false);
    await p.remove(_kType);
    await p.remove(_kValue);
  }

  static Future<bool> verify(String input) async {
    final enabled = await isEnabled();
    if (!enabled) return true;
    final stored = await getValue();
    if (stored == null || stored.isEmpty) return true;
    return stored == input;
  }
}
