import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'tiktok_coin_service.dart';
import 'tiktok_buy_coin_page.dart';

/// Sheet daftar LIVE Sekarang + tombol mulai LIVE (mirip screenshot 3).
class TiktokLiveListSheet extends StatefulWidget {
  final String username;
  final String sessionKey;

  const TiktokLiveListSheet({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<TiktokLiveListSheet> createState() => _TiktokLiveListSheetState();
}

class _TiktokLiveListSheetState extends State<TiktokLiveListSheet> {
  List<LiveSession> _lives = [];
  bool _loading = true;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _load());
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final list = await TiktokLiveService.activeLives();
    if (!mounted) return;
    setState(() {
      _lives = list;
      _loading = false;
    });
  }

  Future<void> _startLive() async {
    final live = await TiktokLiveService.startLive(username: widget.username);
    if (!mounted) return;
    Navigator.pop(context);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TiktokHostLivePage(
          live: live,
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  void _watch(LiveSession live) {
    Navigator.pop(context);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TiktokWatchLivePage(
          live: live,
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.72,
      decoration: const BoxDecoration(
        color: Color(0xFF121212),
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              children: [
                const Text(
                  'LIVE Sekarang',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _startLive,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFE2C55),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(color: Colors.white12, height: 1),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: Color(0xFFFE2C55)))
                : _lives.isEmpty
                    ? const Center(
                        child: Text(
                          'Belum ada yang LIVE.\nTekan LIVE untuk mulai.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white54, height: 1.4),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: _lives.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) {
                          final live = _lives[i];
                          final isMe = live.username == widget.username;
                          return Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1C1C1E),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              children: [
                                Stack(
                                  children: [
                                    CircleAvatar(
                                      radius: 24,
                                      backgroundColor: const Color(0xFF2C2C2E),
                                      child: Text(
                                        live.username.isNotEmpty
                                            ? live.username[0].toUpperCase()
                                            : '?',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                    Positioned(
                                      left: 0,
                                      bottom: 0,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 1),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFE2C55),
                                          borderRadius:
                                              BorderRadius.circular(4),
                                        ),
                                        child: const Text(
                                          'LIVE',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 9,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '@${live.username}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        '${live.viewers} penonton · ${live.title}',
                                        style: const TextStyle(
                                          color: Colors.white54,
                                          fontSize: 11,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                ElevatedButton(
                                  onPressed: () {
                                    if (isMe) {
                                      Navigator.pop(context);
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => TiktokHostLivePage(
                                            live: live,
                                            username: widget.username,
                                            sessionKey: widget.sessionKey,
                                          ),
                                        ),
                                      );
                                    } else {
                                      _watch(live);
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF4B9EFF),
                                    foregroundColor: Colors.white,
                                    elevation: 0,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    minimumSize: const Size(0, 36),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                  ),
                                  child: Text(
                                    isMe ? 'LANJUT' : 'TONTON',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

/// Host LIVE page (mirip screenshot 4) — AKHIRI LIVE.
class TiktokHostLivePage extends StatefulWidget {
  final LiveSession live;
  final String username;
  final String sessionKey;

  const TiktokHostLivePage({
    super.key,
    required this.live,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<TiktokHostLivePage> createState() => _TiktokHostLivePageState();
}

class _TiktokHostLivePageState extends State<TiktokHostLivePage> {
  late LiveSession _live;
  List<LiveGiftEvent> _gifts = [];
  List<String> _comments = [];
  Timer? _poll;
  final _commentCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _live = widget.live;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _poll = Timer.periodic(const Duration(seconds: 2), (_) => _refresh());
    _refresh();
  }

  Future<void> _refresh() async {
    final gifts = await TiktokLiveService.giftsFor(_live.id);
    final lives = await TiktokLiveService.activeLives();
    final me = lives.where((e) => e.id == _live.id).toList();
    if (!mounted) return;
    setState(() {
      _gifts = gifts.reversed.take(30).toList();
      if (me.isNotEmpty) _live = me.first;
    });
  }

  Future<void> _end() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1E),
        title: const Text('Akhiri LIVE?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Siaran akan dihentikan untuk semua penonton.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFE2C55)),
            onPressed: () => Navigator.pop(ctx, true),
            child:
                const Text('Akhiri', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await TiktokLiveService.endLive(_live.id);
    if (!mounted) return;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _poll?.cancel();
    _commentCtrl.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Simulated camera / stage
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1A1520),
                  Color(0xFF0A0A0C),
                  Color(0xFF151018),
                ],
              ),
            ),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.videocam, color: Colors.white.withOpacity(0.15), size: 72),
                  const SizedBox(height: 8),
                  Text(
                    'Kamu sedang LIVE',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFE2C55),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '@${_live.username}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  Icon(Icons.visibility, color: Colors.white70, size: 16),
                  const SizedBox(width: 4),
                  Text(
                    '${_live.viewers} penonton',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),

          // Gift feed
          Positioned(
            left: 12,
            right: 80,
            bottom: 100,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: _gifts.take(6).map((g) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${g.emoji} @${g.fromUser} mengirim ${g.giftName}',
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          // End button
          Positioned(
            left: 0,
            right: 0,
            bottom: 28,
            child: Center(
              child: GestureDetector(
                onTap: _end,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFE2C55),
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFE2C55).withOpacity(0.4),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.stop_circle, color: Colors.white, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'AKHIRI LIVE',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Watch LIVE + gift panel (mirip screenshot 2).
class TiktokWatchLivePage extends StatefulWidget {
  final LiveSession live;
  final String username;
  final String sessionKey;

  const TiktokWatchLivePage({
    super.key,
    required this.live,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<TiktokWatchLivePage> createState() => _TiktokWatchLivePageState();
}

class _TiktokWatchLivePageState extends State<TiktokWatchLivePage> {
  late LiveSession _live;
  List<LiveGiftEvent> _gifts = [];
  List<_ChatLine> _chats = [];
  int _coins = 0;
  bool _giftOpen = false;
  bool _sending = false;
  final _commentCtrl = TextEditingController();
  Timer? _poll;
  String? _floatingGift;

  @override
  void initState() {
    super.initState();
    _live = widget.live;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    TiktokLiveService.bumpViewers(_live.id, 1);
    _loadCoins();
    _poll = Timer.periodic(const Duration(seconds: 2), (_) => _refresh());
    _refresh();
  }

  Future<void> _loadCoins() async {
    final c = await TiktokCoinService.getCoins(widget.username);
    if (mounted) setState(() => _coins = c);
  }

  Future<void> _refresh() async {
    final gifts = await TiktokLiveService.giftsFor(_live.id);
    final lives = await TiktokLiveService.activeLives();
    final found = lives.where((e) => e.id == _live.id).toList();
    if (!mounted) return;
    if (found.isEmpty) {
      // Live ended
      _poll?.cancel();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('LIVE telah berakhir')),
      );
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      Navigator.pop(context);
      return;
    }
    setState(() {
      _live = found.first;
      _gifts = gifts;
      // Merge gift events into chat feed
      for (final g in gifts) {
        final line =
            _ChatLine(user: g.fromUser, text: 'mengirim ${g.emoji} ${g.giftName}');
        if (!_chats.any((c) =>
            c.user == line.user && c.text == line.text)) {
          _chats.add(line);
        }
      }
      if (_chats.length > 40) _chats = _chats.sublist(_chats.length - 40);
    });
  }

  Future<void> _sendGift(LiveGift gift) async {
    if (_sending) return;
    setState(() => _sending = true);
    final err = await TiktokCoinService.spendCoins(
      username: widget.username,
      cost: gift.cost,
    );
    if (err != null) {
      setState(() => _sending = false);
      if (!mounted) return;
      final goBuy = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1C1C1E),
          title: const Text('Koin tidak cukup',
              style: TextStyle(color: Colors.white)),
          content: Text(err, style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Tutup', style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4B9EFF)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Beli Koin',
                  style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
      if (goBuy == true && mounted) {
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => TiktokBuyCoinPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
        await _loadCoins();
      }
      return;
    }

    await TiktokLiveService.addGift(LiveGiftEvent(
      liveId: _live.id,
      fromUser: widget.username,
      giftId: gift.id,
      giftName: gift.name,
      emoji: gift.emoji,
      cost: gift.cost,
      at: DateTime.now(),
    ));
    HapticFeedback.mediumImpact();
    await _loadCoins();
    if (!mounted) return;
    setState(() {
      _sending = false;
      _giftOpen = false;
      _floatingGift = gift.emoji;
      _chats.add(_ChatLine(
          user: widget.username,
          text: 'mengirim ${gift.emoji} ${gift.name}'));
    });
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _floatingGift = null);
    });
  }

  void _sendComment() {
    final t = _commentCtrl.text.trim();
    if (t.isEmpty) return;
    setState(() {
      _chats.add(_ChatLine(user: widget.username, text: t));
      _commentCtrl.clear();
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _commentCtrl.dispose();
    TiktokLiveService.bumpViewers(_live.id, -1);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Stage
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF0D0D12), Color(0xFF1A1220), Color(0xFF0A0A0C)],
              ),
            ),
            child: Center(
              child: Text(
                '@${_live.username}',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.2),
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),

          // Floating gift
          if (_floatingGift != null)
            Center(
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.5, end: 1.2),
                duration: const Duration(milliseconds: 800),
                builder: (_, v, child) => Opacity(
                  opacity: (1.5 - v).clamp(0.0, 1.0),
                  child: Transform.scale(scale: v, child: child),
                ),
                child: Text(_floatingGift!, style: const TextStyle(fontSize: 72)),
              ),
            ),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFE2C55),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '@${_live.username}',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  Text(
                    '${_live.viewers} penonton',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.close, color: Colors.white70),
                  ),
                ],
              ),
            ),
          ),

          // Chat feed
          Positioned(
            left: 12,
            right: 90,
            bottom: 90,
            child: SizedBox(
              height: 160,
              child: ListView(
                reverse: true,
                children: _chats.reversed.take(12).map((c) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '@${c.user}: ',
                            style: const TextStyle(
                              color: Color(0xFF4B9EFF),
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                          ),
                          TextSpan(
                            text: c.text,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Bottom input + gift button
          Positioned(
            left: 12,
            right: 12,
            bottom: 24,
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 42,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1C1C2E),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: TextField(
                      controller: _commentCtrl,
                      style: const TextStyle(color: Colors.white, fontSize: 13),
                      decoration: const InputDecoration(
                        hintText: 'Komentar LIVE...',
                        hintStyle:
                            TextStyle(color: Colors.white38, fontSize: 13),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                      onSubmitted: (_) => _sendComment(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Gift toggle
                GestureDetector(
                  onTap: () => setState(() => _giftOpen = !_giftOpen),
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: _giftOpen
                          ? const Color(0xFF4B9EFF)
                          : const Color(0xFF1C1C2E),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.card_giftcard,
                        color: Colors.white, size: 20),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _sendComment,
                  child: Container(
                    width: 42,
                    height: 42,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.send, color: Colors.black, size: 18),
                  ),
                ),
              ],
            ),
          ),

          // Gift panel (screenshot 2 style)
          if (_giftOpen)
            Positioned(
              right: 16,
              bottom: 80,
              child: Container(
                width: 180,
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF152033),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        children: [
                          const Icon(Icons.monetization_on,
                              color: Color(0xFFFFD54F), size: 16),
                          const SizedBox(width: 4),
                          Text(
                            '$_coins koin',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          GestureDetector(
                            onTap: () async {
                              await Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => TiktokBuyCoinPage(
                                    username: widget.username,
                                    sessionKey: widget.sessionKey,
                                  ),
                                ),
                              );
                              await _loadCoins();
                            },
                            child: const Text(
                              'Beli',
                              style: TextStyle(
                                color: Color(0xFF4B9EFF),
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    ...TiktokCoinService.gifts.map((g) {
                      return InkWell(
                        onTap: _sending ? null : () => _sendGift(g),
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Row(
                            children: [
                              Text(g.emoji, style: const TextStyle(fontSize: 18)),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  g.name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Text(
                                '${g.cost} koin',
                                style: const TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ChatLine {
  final String user, text;
  _ChatLine({required this.user, required this.text});
}
