/// Base URL API utama ZEVORA PROJECT. Endpoint dan kontrak request tetap didefinisikan
/// pada masing-masing service/page seperti sebelumnya.
class Api {
  static const String api = "http://web.antirusuhvvip.web.id:3024";
}
