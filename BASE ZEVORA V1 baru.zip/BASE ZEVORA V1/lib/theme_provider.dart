import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ColorPreset {
  final String name;
  final Color primary;
  final Color accent;

  const ColorPreset({
    required this.name,
    required this.primary,
    required this.accent,
  });
}

class ThemeProvider extends ChangeNotifier {
  static const Color defaultPrimary = Color(0xFFD500F9);
  static const Color defaultAccent = Color(0xFF7B1FA2);
  static const Color defaultDarkBackground = Color(0xFF08050D);
  static const Color defaultLightBackground = Color(0xFFF5F5F5);

  static Color currentPrimary = defaultPrimary;
  static Color currentSecondary = defaultAccent;

  static Color get currentPrimaryLight =>
      Color.lerp(currentPrimary, Colors.white, 0.24) ?? currentPrimary;

  static Color get currentSecondaryLight =>
      Color.lerp(currentSecondary, Colors.white, 0.24) ??
      currentSecondary;

  static void _syncStaticColors(
    Color primary,
    Color secondary,
  ) {
    currentPrimary = primary;
    currentSecondary = secondary;
  }

  Color _primaryColor = defaultPrimary;
  Color _accentColor = defaultAccent;
  Color? _customBackground;

  bool _isDarkMode = true;
  int _currentPresetIndex = 0;
  bool _disposed = false;

  Color get primaryColor => _primaryColor;
  Color get accentColor => _accentColor;

  bool get isDarkMode => _isDarkMode;

  Color get backgroundColor =>
      _customBackground ??
      (_isDarkMode
          ? defaultDarkBackground
          : defaultLightBackground);

  Color get textPrimaryColor =>
      _isDarkMode ? Colors.white : Colors.black87;

  Color get textSecondaryColor =>
      _isDarkMode ? Colors.white70 : Colors.black54;

  Color get glassPrimary =>
      (_isDarkMode ? Colors.white : Colors.black).withOpacity(0.05);

  Color get glassSecondary =>
      (_isDarkMode ? Colors.white : Colors.black).withOpacity(0.08);

  int get currentPresetIndex => _currentPresetIndex;

  static const List<ColorPreset> colorPresets = [
    ColorPreset(
      name: 'Purple',
      primary: Color(0xFFD500F9),
      accent: Color(0xFF7B1FA2),
    ),
    ColorPreset(
      name: 'Neon Cyan',
      primary: Color(0xFF00E5FF),
      accent: Color(0xFF006064),
    ),
    ColorPreset(
      name: 'Hijau',
      primary: Color(0xFF4CAF50),
      accent: Color(0xFF1B5E20),
    ),
    ColorPreset(
      name: 'Biru',
      primary: Color(0xFF2196F3),
      accent: Color(0xFF0D47A1),
    ),
    ColorPreset(
      name: 'Oranye',
      primary: Color(0xFFFF9800),
      accent: Color(0xFFE65100),
    ),
    ColorPreset(
      name: 'Pink',
      primary: Color(0xFFE91E63),
      accent: Color(0xFF880E4F),
    ),
    ColorPreset(
      name: 'Emas',
      primary: Color(0xFFFFD700),
      accent: Color(0xFF8B6914),
    ),
    ColorPreset(
      name: 'Merah',
      primary: Color(0xFFF44336),
      accent: Color(0xFF8B0000),
    ),
    ColorPreset(
      name: 'Putih',
      primary: Color(0xFFFFFFFF),
      accent: Color(0xFF607D8B),
    ),
    ColorPreset(
      name: 'Slate',
      primary: Color(0xFF607D8B),
      accent: Color(0xFF263238),
    ),
  ];

  ThemeProvider() {
    _loadSavedTheme();
  }

  Future<void> _loadSavedTheme() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final savedIndex = prefs.getInt('theme_preset_index') ?? 0;

      _currentPresetIndex =
          savedIndex >= 0 && savedIndex < colorPresets.length
              ? savedIndex
              : 0;

      _isDarkMode = prefs.getBool('theme_dark_mode') ?? true;

      final customPrimary = prefs.getInt('theme_custom_primary');
      final customAccent = prefs.getInt('theme_custom_accent');
      final customBg = prefs.getInt('theme_custom_background');

      if (customPrimary != null && customAccent != null) {
        _primaryColor = Color(customPrimary);
        _accentColor = Color(customAccent);
        _currentPresetIndex = -1;
      } else {
        _applyPresetByIndex(_currentPresetIndex);
      }

      if (customBg != null) {
        _customBackground = Color(customBg);
      }

      _syncStaticColors(_primaryColor, _accentColor);

      if (!_disposed) {
        notifyListeners();
      }
    } catch (error, stackTrace) {
      debugPrint('ThemeProvider load error: $error');
      debugPrintStack(stackTrace: stackTrace);

      _primaryColor = defaultPrimary;
      _accentColor = defaultAccent;
      _currentPresetIndex = 0;

      _syncStaticColors(_primaryColor, _accentColor);

      if (!_disposed) {
        notifyListeners();
      }
    }
  }

  Future<void> _saveTheme() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      await prefs.setInt(
        'theme_preset_index',
        _currentPresetIndex,
      );

      await prefs.setBool(
        'theme_dark_mode',
        _isDarkMode,
      );

      await prefs.setInt(
        'theme_custom_primary',
        _primaryColor.value,
      );

      await prefs.setInt(
        'theme_custom_accent',
        _accentColor.value,
      );

      if (_customBackground != null) {
        await prefs.setInt(
          'theme_custom_background',
          _customBackground!.value,
        );
      } else {
        await prefs.remove('theme_custom_background');
      }
    } catch (error, stackTrace) {
      debugPrint('ThemeProvider save error: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  void applyPreset(ColorPreset preset) {
    final index = colorPresets.indexWhere(
      (item) => item.name == preset.name,
    );

    if (index < 0) return;

    _applyPresetByIndex(index);
    _customBackground = null;

    _syncStaticColors(
      _primaryColor,
      _accentColor,
    );

    _saveTheme();
    _notify();
  }

  void _applyPresetByIndex(int index) {
    if (index < 0 || index >= colorPresets.length) {
      return;
    }

    _currentPresetIndex = index;

    _primaryColor = colorPresets[index].primary;
    _accentColor = colorPresets[index].accent;
  }

  void setCustomColors(
    Color primary,
    Color accent,
  ) {
    _primaryColor = primary;
    _accentColor = accent;
    _currentPresetIndex = -1;

    _syncStaticColors(
      _primaryColor,
      _accentColor,
    );

    _saveTheme();
    _notify();
  }

  void setBackgroundColor(Color color) {
    _customBackground = color;

    _saveTheme();
    _notify();
  }

  void resetBackground() {
    _customBackground = null;

    _saveTheme();
    _notify();
  }

  bool isActivePreset(ColorPreset preset) {
    return _primaryColor.value == preset.primary.value &&
        _accentColor.value == preset.accent.value;
  }

  void resetToDefault() {
    _currentPresetIndex = 0;

    _primaryColor = defaultPrimary;
    _accentColor = defaultAccent;

    _customBackground = null;
    _isDarkMode = true;

    _syncStaticColors(
      _primaryColor,
      _accentColor,
    );

    _saveTheme();
    _notify();
  }

  void toggleDarkMode() {
    setDarkMode(!_isDarkMode);
  }

  void setDarkMode(bool value) {
    if (_isDarkMode == value) return;

    _isDarkMode = value;

    _saveTheme();
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}