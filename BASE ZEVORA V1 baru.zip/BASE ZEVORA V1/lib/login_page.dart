import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'splash.dart';
import 'maintenance.dart';
import 'package:fiona/Qaxer/api.dart';
import 'glass_kit.dart';
final baseUrl = Api.api;

// ─── Palette ──────────────────────────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFF090D14);
  static const surface    = Color(0xFF101722);
  static const card       = Color(0xFF182130);
  static const border     = Color(0xFF293547);
  static const borderLit  = Color(0xFF3D5878);

  static const steel      = Color(0xFF12345A);
  static const blueMid    = Color(0xFF1769AA);
  static const blueLight  = Color(0xFF0A84FF);
  static const chrome     = Color(0xFF2563A6);
  static const frost      = Color(0xFF8CC8FF);

  static const green      = Color(0xFF30D158);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFEF4444);

  static const text       = Color(0xFFF5F7FA);
  static const textSub    = Color(0xFFA5B1C2);
  static const textDim    = Color(0xFF65748A);

  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF145A9E), Color(0xFF0A84FF), Color(0xFF75BCFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl    = TextEditingController();
  final passCtrl    = TextEditingController();
  final _formKey    = GlobalKey<FormState>();
  static const platform = MethodChannel('app_security');

  bool _isLoading       = false;
  bool _obscurePass     = true;
  String? _androidId;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnPulse;
  late Animation<double>  _shake;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.3, end: 0.85)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.03)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -7.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 7.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 7.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
  try {
    // Ambil Android ID
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    _androidId = deviceInfo.id;

    // Ambil versi APK
    final packageInfo = await PackageInfo.fromPlatform();
    final appVersion = packageInfo.version;

    // Ambil certificate SHA-256 dari Android native
    String appCertificate;

    try {
      appCertificate =
          await platform.invokeMethod<String>('getSignature') ?? '';
    } catch (_) {
      appCertificate = '';
    }

    // Kalau security information gagal didapatkan,
    // jangan lanjutkan request ke server.
    if (appVersion.isEmpty || appCertificate.isEmpty) {
      if (!mounted) return;

      _showAlert(
        title: 'APK Tidak Valid',
        message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
        type: _AlertType.error,
        showContact: true,
      );

      return;
    }

    final prefs = await SharedPreferences.getInstance();

    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');

    if (savedUser == null ||
        savedPass == null ||
        savedKey == null) {
      return;
    }

    // Gunakan Uri agar username/password/certificate
    // otomatis di-encode dengan benar.
    final uri = Uri.parse('$baseUrl/myInfo').replace(
      queryParameters: {
        'username': savedUser,
        'password': savedPass,
        'androidId': _androidId ?? '',
        'key': savedKey,
        'appVersion': appVersion,
        'appCertificate': appCertificate,
      },
    );

    final res = await http.get(uri);

    final data = jsonDecode(res.body);

    // APK tidak sah / dimodifikasi / versi tidak sesuai
    if (data['error'] == 'SECURITY_FAILED' ||
        data['error'] == 'SECURITY_REQUIRED') {
      if (!mounted) return;

      _showAlert(
        title: 'Akses Ditolak',
        message: data['message'] ?? 'APK tidak valid.',
        type: _AlertType.error,
        showContact: true,
      );

      return;
    }

    // Login/session masih valid
    if (data['valid'] == true && mounted) {
      await _updateFCM(savedKey);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => PostLoginEngineerMusicGate(
            username: savedUser,
            password: savedPass,
            role: data['role'],
            sessionKey: data['key'],
            expiredDate: data['expiredDate'],
            listBug: _parseList(data['listBug']),
            listBugGroup: _parseList(data['listBugGroup']),
            listDoos: _parseList(data['listDDoS']),
            news: _parseList(data['news']),
            jjVideos: _parseList(data['jjVideos']),
            thanksTo: _parseList(data['thanksTo']),
          ),
        ),
      );
    }
  } catch (e) {
    if (!mounted) return;

    _showAlert(
      title: 'Koneksi Error',
      message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
      type: _AlertType.error,
    );
  }
}

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      
  Future<void> _updateFCM(String sessionKey) async {
    try {
      await FirebaseMessaging.instance.requestPermission();
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null) return;
      await http.get(
        Uri.parse('$baseUrl/updateFCM?key=$sessionKey&token=${Uri.encodeComponent(token)}'),
      );
    } catch(_){}
  }

    Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      // 1. Ambil Versi APK & SHA-256 Certificate
      String appVersion = "";
String appCertificate = "";

final info = await PackageInfo.fromPlatform();
appVersion = info.version;

try {
  appCertificate =
      await platform.invokeMethod<String>('getSignature') ?? '';
} catch (_) {
  appCertificate = '';
}

if (appVersion.isEmpty || appCertificate.isEmpty) {
  _shakeCtrl.forward(from: 0);

  _showAlert(
    title: 'APK Tidak Valid',
    message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
    type: _AlertType.error,
    showContact: true,
  );

  if (mounted) setState(() => _isLoading = false);
  return;
}
  
      // 2. Kirim ke Server
      final res = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
        'appVersion': appVersion,
        'appCertificate': appCertificate,
      });
      
      final data = jsonDecode(res.body);

      // 3. Handle Error Security (APK Modif / Outdated)
      if (data['error'] == 'SECURITY_FAILED') {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Ditolak',
          message: data['message'] ?? 'APK tidak valid.',
          type: _AlertType.error,
          showContact: true, // Munculin tombol chat telegram
        );
        if (mounted) setState(() => _isLoading = false);
        return; // Stop disini, jangan lanjut login
      }

      // 4. Lanjut Handle Login Biasa (Maintenance, Banned, Expired, Valid)
      if (data['maintenance'] == true) {
        if (mounted) setState(() => _isLoading = false);
        DateTime? endsAt;
        if (data['endsAt'] != null) {
          endsAt = DateTime.tryParse(data['endsAt'].toString());
        }
        final unlimited = data['unlimited'] == true || endsAt == null;
        if (!mounted) return;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MaintenancePage(
              message: data['message']?.toString(),
              reason: data['reason']?.toString(),
              endsAt: endsAt,
              unlimited: unlimited,
              onBackToLogin: () {
                Navigator.of(context).pop();
              },
            ),
          ),
        );
        return;
      } else if (data['banned'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akun Dibanned',
          message: data['message'] ?? 'Akun Anda telah dibanned oleh Admin.',
          type: _AlertType.error,
        );
      } else if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        // LOGIN BERHASIL
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);
        await _updateFCM(data['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => PostLoginEngineerMusicGate(
              username: username, password: password,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug:  _parseList(data['listBug']),
              listBugGroup:  _parseList(data['listBugGroup']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
              jjVideos: _parseList(data['jjVideos']),
              thanksTo: _parseList(data['thanksTo']),
            )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error   => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.green,
    };
    final icon = switch (type) {
      _AlertType.error   => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: color.withOpacity(0.15), blurRadius: 50)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 16),
            Text(title, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Roboto')),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(color: _C.textSub, fontSize: 13, height: 1.5, fontFamily: 'Roboto')),
            const SizedBox(height: 22),
            if (showContact) ...[
              _GradBtn(
                label: 'Hubungi Admin',
                fullWidth: true,
                onTap: () async {
                  Navigator.pop(ctx);
                  await launchUrl(Uri.parse('https://t.me/NanzzPrime'), mode: LaunchMode.externalApplication);
                },
              ),
              const SizedBox(height: 10),
            ],
            _OutlineBtn(
              label: showContact ? 'Tutup' : 'OK',
              fullWidth: true,
              onTap: () => Navigator.pop(ctx),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Dark character / gradient background
          Positioned.fill(
            child: Image.asset(
              'assets/images/reze.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF1A0508), Color(0xFF080808), Color(0xFF050505)],
                  ),
                ),
              ),
            ),
          ),
          // Dark overlay for readability
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.55),
                    Colors.black.withOpacity(0.75),
                    Colors.black.withOpacity(0.92),
                  ],
                ),
              ),
            ),
          ),
          // Red ambient glow
          Positioned(
            top: -80,
            left: 0,
            right: 0,
            child: Container(
              height: 280,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  colors: [
                    _C.blueLight.withOpacity(0.18),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 12),
                        // Title
                        ShaderMask(
                          shaderCallback: (b) => const LinearGradient(
                            colors: [Color(0xFFFFEFEF), Color(0xFFFF8A80)],
                          ).createShader(b),
                          child: const Text(
                            'ZEVORA PROJECT',
                            style: TextStyle(
                              fontSize: 34,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: 2.8,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        // Badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _C.blueLight.withOpacity(0.5)),
                            color: const Color(0xFF111A27).withOpacity(0.88),
                          ),
                          child: Text(
                            'APK BUG X SADAP',
                            style: TextStyle(
                              color: _C.frost,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 2,
                              fontFamily: null,
                            ),
                          ),
                        ),
                        const SizedBox(height: 13),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                          decoration: BoxDecoration(
                            color: const Color(0xCC101A28),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _C.blueLight.withOpacity(.28)),
                          ),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('WELCOME BACK', style: TextStyle(color: _C.frost, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.6, fontFamily: 'Rajdhani')),
                            const SizedBox(height: 5),
                            const Text('Masuk ke akun ZEVORA PROJECT', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Rajdhani')),
                            const SizedBox(height: 3),
                            Text('Gunakan username dan password terdaftar untuk melanjutkan ke dashboard.', style: TextStyle(color: _C.textSub.withOpacity(.78), fontSize: 11, height: 1.35, fontFamily: 'Rajdhani')),
                          ]),
                        ),
                        const SizedBox(height: 18),
                        // Character card
                        Container(
                          height: 160,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: _C.borderLit.withOpacity(0.72)),
                            boxShadow: [
                              BoxShadow(
                                color: _C.blueMid.withOpacity(0.25),
                                blurRadius: 24,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(23),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.asset(
                                  'assets/images/reze.png',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Image.asset(
                                    'assets/images/logo.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      color: _C.card,
                                      child: const Icon(Icons.person, color: _C.blueLight, size: 48),
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.black.withOpacity(0.55),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 32),
                        // Form fields
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: GlassPanel(
                            radius: 26,
                            blur: 16,
                            opacity: .105,
                            padding: const EdgeInsets.all(18),
                            child: Form(
                              key: _formKey,
                              child: Column(
                                children: [
                                  const GlassSectionHeader(
                                    title: 'SECURE SIGN IN',
                                    subtitle: 'Masuk ke akun ZEVORA PROJECT',
                                    icon: Icons.lock_rounded,
                                  ),
                                  const SizedBox(height: 18),
                                  // Username
                                  _HiyukiField(
                                    controller: userCtrl,
                                    hint: 'USERNAME',
                                    icon: Icons.person_outline_rounded,
                                    validator: (v) =>
                                        (v == null || v.isEmpty) ? 'Username tidak boleh kosong' : null,
                                  ),
                                  const SizedBox(height: 14),
                                  // Password
                                  _HiyukiField(
                                    controller: passCtrl,
                                    hint: 'PASSWORD',
                                    icon: Icons.lock_outline_rounded,
                                    obscure: _obscurePass,
                                    onToggleObscure: () =>
                                        setState(() => _obscurePass = !_obscurePass),
                                    validator: (v) =>
                                        (v == null || v.isEmpty) ? 'Password tidak boleh kosong' : null,
                                  ),
                                  const SizedBox(height: 28),
                                  // LOGIN button
                                  ScaleTransition(
                                    scale: _btnPulse,
                                    child: SizedBox(
                                      width: double.infinity,
                                      height: 52,
                                      child: ElevatedButton(
                                        onPressed: _isLoading ? null : _login,
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.white,
                                          foregroundColor: Colors.black,
                                          disabledBackgroundColor: Colors.white70,
                                          elevation: 0,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(28),
                                          ),
                                        ),
                                        child: _isLoading
                                            ? const SizedBox(
                                                width: 22,
                                                height: 22,
                                                child: CircularProgressIndicator(
                                                  strokeWidth: 2.2,
                                                  color: Color(0xFF0A84FF),
                                                ),
                                              )
                                            : const Text(
                                                'LOGIN',
                                                style: TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w800,
                                                  letterSpacing: 3,
                                                  fontFamily: null,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 28),
                        // Footer
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Belum punya akses ',
                              style: TextStyle(
                                color: _C.textSub.withOpacity(0.8),
                                fontSize: 12,
                                fontFamily: null,
                              ),
                            ),
                            GestureDetector(
                              onTap: () => launchUrl(
                                Uri.parse('https://t.me/NanzzPrime'),
                                mode: LaunchMode.externalApplication,
                              ),
                              child: Text(
                                'Beli Sekarang',
                                style: TextStyle(
                                  color: _C.frost,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: null,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          '© 2026 ZEVORA PROJECT',
                          style: TextStyle(
                            color: _C.textDim,
                            fontSize: 11,
                            fontFamily: null,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── HIYUKI-style input field ────────────────────────────────
class _HiyukiField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _HiyukiField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_HiyukiField> createState() => _HiyukiFieldState();
}

class _HiyukiFieldState extends State<_HiyukiField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: _focused
              ? const Color(0xFF0A84FF).withOpacity(0.78)
              : Colors.white.withOpacity(0.18),
          width: _focused ? 1.4 : 1,
        ),
        color: Colors.black.withOpacity(0.35),
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
          letterSpacing: 1,
          fontFamily: 'Rajdhani',
        ),
        validator: widget.validator,
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: TextStyle(
            color: Colors.white.withOpacity(0.35),
            fontSize: 13,
            letterSpacing: 2,
            fontFamily: 'Rajdhani',
          ),
          prefixIcon: Icon(
            widget.icon,
            color: _focused
                ? const Color(0xFF70B8FF)
                : Colors.white.withOpacity(0.45),
            size: 20,
          ),
          suffixIcon: widget.onToggleObscure != null
              ? IconButton(
                  icon: Icon(
                    widget.obscure
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: Colors.white.withOpacity(0.4),
                    size: 20,
                  ),
                  onPressed: widget.onToggleObscure,
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
        ),
      ),
    );
  }
}

// Keep helper buttons used by _showAlert
class _GradBtn extends StatelessWidget {
  final String label;
  final bool fullWidth;
  final VoidCallback onTap;
  const _GradBtn({required this.label, this.fullWidth = false, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 44,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0A84FF),
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontFamily: null, fontSize: 13)),
      ),
    );
  }
}

class _OutlineBtn extends StatelessWidget {
  final String label;
  final bool fullWidth;
  final VoidCallback onTap;
  const _OutlineBtn({required this.label, this.fullWidth = false, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 44,
      child: OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white70,
          side: BorderSide(color: Colors.white.withOpacity(0.2)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontFamily: null, fontSize: 13)),
      ),
    );
  }
}

enum _AlertType { error, warning, success }
