import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'music_player_service.dart';

// ─── SPOTIFY-LIKE THEME (dark + green) ───────────────────────
const _bg = Color(0xFF121212);
const _card = Color(0xFF181818);
const _surface = Color(0xFF282828);
const _green = Color(0xFF1DB954);
const _text = Color(0xFFFFFFFF);
const _muted = Color(0xFFB3B3B3);
const _sub = Color(0xFFA7A7A7);

/// Public Piped / Invidious instances (no API key) — fallback search & stream
const _pipedHosts = <String>[
  'https://pipedapi.kavin.rocks',
  'https://pipedapi.adminforge.de',
  'https://api.piped.private.coffee',
  'https://pipedapi.nosebs.ru',
];

const _invidiousHosts = <String>[
  'https://yewtu.be',
  'https://inv.nadeko.net',
  'https://invidious.nerdvpn.de',
];

// ─── Default tracks matching the screenshot (SoundHelix free MP3) ──
final List<MusicTrack> kDefaultTracks = [
  MusicTrack(
    id: 'sh1',
    title: 'Sunset Drive',
    artist: 'SoundHelix',
    album: 'Chill Vibes',
    duration: '6:12',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    coverUrl: 'https://picsum.photos/seed/sunsetdrive/300',
    genre: 'Chill',
  ),
  MusicTrack(
    id: 'sh2',
    title: 'Midnight City',
    artist: 'SoundHelix',
    album: 'Night Drive',
    duration: '7:05',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    coverUrl: 'https://picsum.photos/seed/midnightcity/300',
    genre: 'Night',
  ),
  MusicTrack(
    id: 'sh3',
    title: 'Ocean Waves',
    artist: 'SoundHelix',
    album: 'Deep Blue',
    duration: '5:48',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    coverUrl: 'https://picsum.photos/seed/oceanwaves/300',
    genre: 'Ambient',
  ),
  MusicTrack(
    id: 'sh4',
    title: 'Electric Dreams',
    artist: 'SoundHelix',
    album: 'Synthwave',
    duration: '6:33',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    coverUrl: 'https://picsum.photos/seed/electricdreams/300',
    genre: 'Synthwave',
  ),
  MusicTrack(
    id: 'sh5',
    title: 'Mountain Peak',
    artist: 'SoundHelix',
    album: 'Adventure',
    duration: '5:21',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    coverUrl: 'https://picsum.photos/seed/mountainpeak/300',
    genre: 'Adventure',
  ),
  MusicTrack(
    id: 'sh6',
    title: 'City Lights',
    artist: 'SoundHelix',
    album: 'Urban',
    duration: '7:12',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    coverUrl: 'https://picsum.photos/seed/citylights/300',
    genre: 'Urban',
  ),
  MusicTrack(
    id: 'sh7',
    title: 'Forest Walk',
    artist: 'SoundHelix',
    album: 'Nature',
    duration: '6:00',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    coverUrl: 'https://picsum.photos/seed/forestwalk/300',
    genre: 'Nature',
  ),
  MusicTrack(
    id: 'sh8',
    title: 'Starlight',
    artist: 'SoundHelix',
    album: 'Cosmic',
    duration: '5:55',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    coverUrl: 'https://picsum.photos/seed/starlight/300',
    genre: 'Cosmic',
  ),
];

// ─── YouTube search (no API key) ─────────────────────────────
class YtSearchService {
  static Future<List<MusicTrack>> search(String query) async {
    final q = query.trim();
    if (q.isEmpty) return [];

    for (final host in _pipedHosts) {
      try {
        final tracks = await _pipedSearch(host, q);
        if (tracks.isNotEmpty) return tracks;
      } catch (_) {}
    }

    for (final host in _invidiousHosts) {
      try {
        final tracks = await _invidiousSearch(host, q);
        if (tracks.isNotEmpty) return tracks;
      } catch (_) {}
    }

    return [];
  }

  static Future<List<MusicTrack>> _pipedSearch(String host, String q) async {
    final uri = Uri.parse('$host/search').replace(queryParameters: {
      'q': q,
      'filter': 'all',
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return [];
    final decoded = jsonDecode(res.body);
    if (decoded is! List) return [];

    final out = <MusicTrack>[];
    for (final e in decoded) {
      if (e is! Map) continue;
      final type = e['type']?.toString() ?? '';
      if (type != 'stream' && type != 'video') continue;
      final id = e['url']?.toString().replaceAll('/watch?v=', '') ??
          e['id']?.toString() ??
          '';
      final videoId = id.contains('v=')
          ? id.split('v=').last.split('&').first
          : id.replaceAll('/watch?v=', '').split('?').first;
      if (videoId.isEmpty) continue;

      final title = e['title']?.toString() ?? 'Unknown';
      final uploader = e['uploaderName']?.toString() ??
          e['uploader']?.toString() ??
          'YouTube';
      final secs = e['duration'] is num
          ? (e['duration'] as num).toInt()
          : int.tryParse('${e['duration']}') ?? 0;
      final thumb = _pickThumb(e['thumbnail']) ??
          _pickThumb(e['thumbnailUrl']) ??
          'https://i.ytimg.com/vi/$videoId/hqdefault.jpg';

      out.add(MusicTrack(
        id: videoId,
        title: title,
        artist: uploader,
        album: 'YouTube',
        duration: _fmtSecs(secs),
        url: '',
        coverUrl: thumb,
        videoId: videoId,
      ));
      if (out.length >= 30) break;
    }
    return out;
  }

  static Future<List<MusicTrack>> _invidiousSearch(String host, String q) async {
    final uri = Uri.parse('$host/api/v1/search').replace(queryParameters: {
      'q': q,
      'type': 'video',
    });
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return [];
    final decoded = jsonDecode(res.body);
    if (decoded is! List) return [];

    final out = <MusicTrack>[];
    for (final e in decoded) {
      if (e is! Map) continue;
      final videoId = e['videoId']?.toString() ?? '';
      if (videoId.isEmpty) continue;
      final title = e['title']?.toString() ?? 'Unknown';
      final author = e['author']?.toString() ?? 'YouTube';
      final secs = e['lengthSeconds'] is num
          ? (e['lengthSeconds'] as num).toInt()
          : 0;
      String thumb = 'https://i.ytimg.com/vi/$videoId/hqdefault.jpg';
      final thumbs = e['videoThumbnails'];
      if (thumbs is List && thumbs.isNotEmpty) {
        final best = thumbs.firstWhere(
          (t) => t is Map && (t['quality'] == 'medium' || t['quality'] == 'high'),
          orElse: () => thumbs.first,
        );
        if (best is Map && best['url'] != null) thumb = best['url'].toString();
      }
      out.add(MusicTrack(
        id: videoId,
        title: title,
        artist: author,
        album: 'YouTube',
        duration: _fmtSecs(secs),
        url: '',
        coverUrl: thumb,
        videoId: videoId,
      ));
      if (out.length >= 30) break;
    }
    return out;
  }

  static String? _pickThumb(dynamic t) {
    if (t == null) return null;
    if (t is String && t.isNotEmpty) return t;
    if (t is List && t.isNotEmpty) {
      final first = t.first;
      if (first is Map && first['url'] != null) return first['url'].toString();
      if (first is String) return first;
    }
    if (t is Map && t['url'] != null) return t['url'].toString();
    return null;
  }

  static String _fmtSecs(int secs) {
    if (secs <= 0) return '';
    final m = secs ~/ 60;
    final s = (secs % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  static Future<String?> resolveStream(String videoId) async {
    for (final host in _pipedHosts) {
      try {
        final uri = Uri.parse('$host/streams/$videoId');
        final res = await http.get(uri).timeout(const Duration(seconds: 10));
        if (res.statusCode != 200) continue;
        final data = jsonDecode(res.body);
        if (data is! Map) continue;
        final audio = data['audioStreams'] ?? data['audio'];
        if (audio is List && audio.isNotEmpty) {
          final list = List<Map>.from(audio.whereType<Map>());
          list.sort((a, b) {
            final qa = (a['bitrate'] is num) ? (a['bitrate'] as num).toInt() : 0;
            final qb = (b['bitrate'] is num) ? (b['bitrate'] as num).toInt() : 0;
            return qb.compareTo(qa);
          });
          final url = list.first['url']?.toString();
          if (url != null && url.isNotEmpty) return url;
        }
        final video = data['videoStreams'] ?? data['video'];
        if (video is List && video.isNotEmpty) {
          for (final v in video) {
            if (v is Map && (v['videoOnly'] == false || v['videoOnly'] == null)) {
              final url = v['url']?.toString();
              if (url != null && url.isNotEmpty) return url;
            }
          }
        }
      } catch (_) {}
    }
    for (final host in _invidiousHosts) {
      try {
        final uri = Uri.parse('$host/api/v1/videos/$videoId');
        final res = await http.get(uri).timeout(const Duration(seconds: 10));
        if (res.statusCode != 200) continue;
        final data = jsonDecode(res.body);
        if (data is! Map) continue;
        final formats = data['adaptiveFormats'] ?? data['formatStreams'];
        if (formats is List) {
          for (final f in formats) {
            if (f is! Map) continue;
            final type = f['type']?.toString() ?? '';
            if (type.contains('audio')) {
              final url = f['url']?.toString();
              if (url != null && url.isNotEmpty) return url;
            }
          }
        }
      } catch (_) {}
    }
    return null;
  }
}

// ─── Optional Spotify Web API (Client Credentials) ───────────
// Set Client ID & Secret via SharedPreferences:
//   spotify_client_id / spotify_client_secret
// Full track playback requires Spotify Premium + official SDK.
// Here: rich search + 30s previews when available.
class SpotifyApiService {
  static String? _token;
  static DateTime? _tokenExpiry;

  static Future<String?> _getToken(String clientId, String clientSecret) async {
    if (_token != null &&
        _tokenExpiry != null &&
        DateTime.now().isBefore(_tokenExpiry!)) {
      return _token;
    }
    final creds = base64Encode(utf8.encode('$clientId:$clientSecret'));
    final res = await http.post(
      Uri.parse('https://accounts.spotify.com/api/token'),
      headers: {
        'Authorization': 'Basic $creds',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {'grant_type': 'client_credentials'},
    ).timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) return null;
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    _token = data['access_token']?.toString();
    final expires = data['expires_in'] is num ? (data['expires_in'] as num).toInt() : 3600;
    _tokenExpiry = DateTime.now().add(Duration(seconds: expires - 60));
    return _token;
  }

  static Future<List<MusicTrack>> search(
    String query, {
    String? clientId,
    String? clientSecret,
  }) async {
    if (clientId == null ||
        clientId.isEmpty ||
        clientSecret == null ||
        clientSecret.isEmpty) {
      return [];
    }
    final token = await _getToken(clientId, clientSecret);
    if (token == null) return [];

    final uri = Uri.parse('https://api.spotify.com/v1/search').replace(
      queryParameters: {
        'q': query,
        'type': 'track',
        'limit': '30',
        'market': 'ID',
      },
    );
    final res = await http.get(uri, headers: {
      'Authorization': 'Bearer $token',
    }).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return [];

    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final items = data['tracks']?['items'];
    if (items is! List) return [];

    final out = <MusicTrack>[];
    for (final e in items) {
      if (e is! Map) continue;
      final id = e['id']?.toString() ?? '';
      final name = e['name']?.toString() ?? 'Unknown';
      final artists = (e['artists'] is List)
          ? (e['artists'] as List)
              .map((a) => a is Map ? a['name']?.toString() ?? '' : '')
              .where((s) => s.isNotEmpty)
              .join(', ')
          : 'Unknown';
      final album = e['album'] is Map ? (e['album']['name']?.toString() ?? '') : '';
      final preview = e['preview_url']?.toString() ?? '';
      final images = e['album'] is Map ? e['album']['images'] : null;
      String cover = '';
      if (images is List && images.isNotEmpty) {
        cover = images.first['url']?.toString() ?? '';
        if (images.length > 1) cover = images[1]['url']?.toString() ?? cover;
      }
      final ms = e['duration_ms'] is num ? (e['duration_ms'] as num).toInt() : 0;
      final secs = ms ~/ 1000;
      out.add(MusicTrack(
        id: id,
        title: name,
        artist: artists,
        album: album,
        duration: '${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}',
        url: preview,
        coverUrl: cover,
        genre: 'Spotify',
      ));
    }
    return out;
  }
}

// ═══════════════════════════════════════════════════════════════
class SpotifyMusicPage extends StatefulWidget {
  const SpotifyMusicPage({super.key});

  @override
  State<SpotifyMusicPage> createState() => _SpotifyMusicPageState();
}

class _SpotifyMusicPageState extends State<SpotifyMusicPage> {
  final _svc = MusicPlayerService.I;
  final _searchCtrl = TextEditingController();
  final _focus = FocusNode();

  int _tab = 0; // 0 Home, 1 Search, 2 Library
  List<MusicTrack> _results = [];
  bool _searching = false;
  String? _error;
  bool _hasSearched = false;

  @override
  void initState() {
    super.initState();
    _svc.setShowFloating(false);
    _svc.streamResolver = (track) async {
      if (track.videoId.isNotEmpty) {
        return YtSearchService.resolveStream(track.videoId);
      }
      if (track.url.isNotEmpty) return track.url;
      return null;
    };
    _svc.addListener(_onSvc);
  }

  void _onSvc() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _svc.removeListener(_onSvc);
    if (_svc.current != null) {
      _svc.setShowFloating(true);
    }
    _searchCtrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _doSearch() async {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _searching = true;
      _error = null;
      _hasSearched = true;
      _results = [];
    });
    try {
      final list = await YtSearchService.search(q);
      if (!mounted) return;
      setState(() {
        _results = list;
        _searching = false;
        if (list.isEmpty) _error = 'Tidak ada hasil untuk "$q"';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _searching = false;
        _error = 'Gagal mencari. Coba lagi.';
      });
    }
  }

  Future<void> _playTrack(MusicTrack track, {List<MusicTrack>? contextList}) async {
    HapticFeedback.selectionClick();
    final list = contextList ?? [track];
    final idx = list.indexWhere((t) => t.uniqueKey == track.uniqueKey);
    _svc.setPlaylist(list, startIndex: idx >= 0 ? idx : 0);
    await _svc.playIndex(idx >= 0 ? idx : 0);
    if (_svc.lastError != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_svc.lastError!),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  String _fmt(Duration d) {
    if (d.inMilliseconds <= 0) return '0:00';
    final m = d.inMinutes;
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: IndexedStack(
                index: _tab,
                children: [
                  _buildHome(),
                  _buildSearch(),
                  _buildLibrary(),
                ],
              ),
            ),
            if (_svc.current != null) _NowPlayingBar(svc: _svc, fmt: _fmt),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  // ─── HOME (matches screenshot) ─────────────────────────────
  Widget _buildHome() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Selamat Datang',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 2),
                const Text(
                  'ENJOY PLAY',
                  style: TextStyle(
                    color: _text,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Quick Pick',
                  style: TextStyle(
                    color: _text,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 160,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: kDefaultTracks.length.clamp(0, 6),
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (ctx, i) {
                final t = kDefaultTracks[i];
                return _QuickPickCard(
                  track: t,
                  onTap: () => _playTrack(t, contextList: kDefaultTracks),
                );
              },
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
            child: const Text(
              'Semua Lagu',
              style: TextStyle(
                color: _text,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (ctx, i) {
              final t = kDefaultTracks[i];
              final isCurrent = _svc.current?.uniqueKey == t.uniqueKey;
              return _TrackRow(
                track: t,
                isCurrent: isCurrent,
                isPlaying: isCurrent && _svc.isPlaying,
                isFavorite: _svc.isFavorite(t),
                onTap: () => _playTrack(t, contextList: kDefaultTracks),
                onFav: () => _svc.toggleFavorite(t),
              );
            },
            childCount: kDefaultTracks.length,
          ),
        ),
        const SliverPadding(padding: EdgeInsets.only(bottom: 24)),
      ],
    );
  }

  // ─── SEARCH ────────────────────────────────────────────────
  Widget _buildSearch() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Search',
                style: TextStyle(
                  color: _text,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(
                  color: _surface,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: TextField(
                  controller: _searchCtrl,
                  focusNode: _focus,
                  style: const TextStyle(color: _text, fontSize: 15),
                  cursorColor: _green,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _doSearch(),
                  decoration: InputDecoration(
                    hintText: 'Apa yang ingin kamu dengarkan?',
                    hintStyle: TextStyle(color: _muted.withOpacity(0.8)),
                    prefixIcon: const Icon(Icons.search, color: _muted),
                    suffixIcon: _searchCtrl.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.close, color: _muted, size: 20),
                            onPressed: () {
                              _searchCtrl.clear();
                              setState(() {
                                _results = [];
                                _hasSearched = false;
                                _error = null;
                              });
                            },
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ],
          ),
        ),
        if (_searching)
          const Expanded(
            child: Center(
              child: CircularProgressIndicator(color: _green, strokeWidth: 2.5),
            ),
          )
        else if (_error != null)
          Expanded(
            child: Center(
              child: Text(_error!, style: const TextStyle(color: _muted)),
            ),
          )
        else if (!_hasSearched)
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.search_rounded, size: 64, color: _muted.withOpacity(0.4)),
                  const SizedBox(height: 12),
                  Text(
                    'Cari lagu, artis, atau album',
                    style: TextStyle(color: _muted.withOpacity(0.8), fontSize: 15),
                  ),
                ],
              ),
            ),
          )
        else
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 16),
              itemCount: _results.length,
              itemBuilder: (ctx, i) {
                final t = _results[i];
                final isCurrent = _svc.current?.uniqueKey == t.uniqueKey;
                return _TrackRow(
                  track: t,
                  isCurrent: isCurrent,
                  isPlaying: isCurrent && _svc.isPlaying,
                  isFavorite: _svc.isFavorite(t),
                  onTap: () => _playTrack(t, contextList: _results),
                  onFav: () => _svc.toggleFavorite(t),
                );
              },
            ),
          ),
      ],
    );
  }

  // ─── LIBRARY ───────────────────────────────────────────────
  Widget _buildLibrary() {
    final favs = _svc.favorites;
    final recent = _svc.recentlyPlayed;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                const Text(
                  'Library',
                  style: TextStyle(
                    color: _text,
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const Spacer(),
                if (recent.isNotEmpty)
                  TextButton(
                    onPressed: () async {
                      await _svc.clearRecent();
                    },
                    child: const Text(
                      'Hapus riwayat',
                      style: TextStyle(color: _muted, fontSize: 12),
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (favs.isEmpty && recent.isEmpty)
          const SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.library_music_rounded, size: 64, color: _muted),
                  SizedBox(height: 12),
                  Text(
                    'Belum ada lagu di Library',
                    style: TextStyle(color: _muted, fontSize: 15),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Putar lagu atau tandai favorit',
                    style: TextStyle(color: _sub, fontSize: 13),
                  ),
                ],
              ),
            ),
          )
        else ...[
          if (favs.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Favorit',
                  style: TextStyle(
                    color: _text,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) {
                  final t = favs[i];
                  final isCurrent = _svc.current?.uniqueKey == t.uniqueKey;
                  return _TrackRow(
                    track: t,
                    isCurrent: isCurrent,
                    isPlaying: isCurrent && _svc.isPlaying,
                    isFavorite: true,
                    onTap: () => _playTrack(t, contextList: favs),
                    onFav: () => _svc.toggleFavorite(t),
                  );
                },
                childCount: favs.length,
              ),
            ),
          ],
          if (recent.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
                child: Text(
                  'Baru diputar',
                  style: TextStyle(
                    color: _text,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) {
                  final t = recent[i];
                  final isCurrent = _svc.current?.uniqueKey == t.uniqueKey;
                  return _TrackRow(
                    track: t,
                    isCurrent: isCurrent,
                    isPlaying: isCurrent && _svc.isPlaying,
                    isFavorite: _svc.isFavorite(t),
                    onTap: () => _playTrack(t, contextList: recent),
                    onFav: () => _svc.toggleFavorite(t),
                  );
                },
                childCount: recent.length,
              ),
            ),
          ],
          const SliverPadding(padding: EdgeInsets.only(bottom: 24)),
        ],
      ],
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: _bg,
        border: Border(top: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(Icons.home_rounded, 'Home', 0),
          _navItem(Icons.search_rounded, 'Search', 1),
          _navItem(Icons.library_music_rounded, 'Library', 2),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int idx) {
    final selected = _tab == idx;
    return InkWell(
      onTap: () => setState(() => _tab = idx),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: selected ? _green : _muted, size: 26),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: selected ? _green : _muted,
                fontSize: 11,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Quick Pick card ─────────────────────────────────────────
class _QuickPickCard extends StatelessWidget {
  final MusicTrack track;
  final VoidCallback onTap;

  const _QuickPickCard({required this.track, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 130,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: AspectRatio(
                aspectRatio: 1,
                child: track.coverUrl.isNotEmpty
                    ? Image.network(
                        track.coverUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: _surface,
                          child: const Icon(Icons.music_note, color: _muted, size: 40),
                        ),
                      )
                    : Container(
                        color: _surface,
                        child: const Icon(Icons.music_note, color: _muted, size: 40),
                      ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              track.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _text,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              '${track.artist} · ${track.album}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _muted, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Track row (list item) ───────────────────────────────────
class _TrackRow extends StatelessWidget {
  final MusicTrack track;
  final bool isCurrent;
  final bool isPlaying;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onFav;

  const _TrackRow({
    required this.track,
    required this.isCurrent,
    required this.isPlaying,
    required this.isFavorite,
    required this.onTap,
    required this.onFav,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: isCurrent ? _green.withOpacity(0.12) : Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: SizedBox(
                  width: 52,
                  height: 52,
                  child: track.coverUrl.isNotEmpty
                      ? Image.network(
                          track.coverUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: _surface,
                            child: const Icon(Icons.music_note, color: _muted),
                          ),
                        )
                      : Container(
                          color: _surface,
                          child: const Icon(Icons.music_note, color: _muted),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isCurrent ? _green : _text,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${track.artist} · ${track.album}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(
                  isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: isFavorite ? _green : _muted,
                  size: 22,
                ),
                onPressed: onFav,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Mini player bar (bottom of page) ────────────────────────
class _NowPlayingBar extends StatelessWidget {
  final MusicPlayerService svc;
  final String Function(Duration) fmt;

  const _NowPlayingBar({required this.svc, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final t = svc.current!;
    final totalMs = svc.total.inMilliseconds;
    final posMs = svc.position.inMilliseconds;
    final progress = totalMs > 0 ? (posMs / totalMs).clamp(0.0, 1.0) : 0.0;

    return Container(
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 4),
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A2A),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.transparent,
              valueColor: const AlwaysStoppedAnimation(_green),
              minHeight: 2,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: SizedBox(
                    width: 40,
                    height: 40,
                    child: t.coverUrl.isNotEmpty
                        ? Image.network(
                            t.coverUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: _surface,
                              child: const Icon(Icons.music_note, color: _muted, size: 20),
                            ),
                          )
                        : Container(
                            color: _surface,
                            child: const Icon(Icons.music_note, color: _muted, size: 20),
                          ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _text,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        t.artist,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _muted, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    svc.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: _text,
                    size: 28,
                  ),
                  onPressed: svc.toggle,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
                ),
                IconButton(
                  icon: const Icon(Icons.skip_next_rounded, color: _text, size: 26),
                  onPressed: svc.next,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 36, minHeight: 40),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// FLOATING BALL — mini player di halaman lain (lebih keren)
// ═══════════════════════════════════════════════════════════════
class SpotifyFloatingBall extends StatefulWidget {
  const SpotifyFloatingBall({super.key});

  @override
  State<SpotifyFloatingBall> createState() => _SpotifyFloatingBallState();
}

class _SpotifyFloatingBallState extends State<SpotifyFloatingBall>
    with SingleTickerProviderStateMixin {
  final _svc = MusicPlayerService.I;
  bool _expanded = false;
  Offset _pos = const Offset(16, 120);
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _svc.addListener(_onSvc);
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  void _onSvc() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _svc.removeListener(_onSvc);
    _pulse.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    if (d.inMilliseconds <= 0) return '0:00';
    final m = d.inMinutes;
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    if (!_svc.showFloating || _svc.current == null) {
      return const SizedBox.shrink();
    }

    final t = _svc.current!;
    final size = MediaQuery.of(context).size;
    final totalMs = _svc.total.inMilliseconds;
    final posMs = _svc.position.inMilliseconds;
    final progress = totalMs > 0 ? (posMs / totalMs).clamp(0.0, 1.0) : 0.0;

    return Positioned(
      left: _pos.dx.clamp(0, size.width - (_expanded ? 300.0 : 64.0)),
      top: _pos.dy.clamp(40.0, size.height - (_expanded ? 260.0 : 80.0)),
      child: GestureDetector(
        onPanUpdate: (d) {
          setState(() {
            _pos += d.delta;
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          width: _expanded ? 300 : 64,
          decoration: BoxDecoration(
            color: const Color(0xF0121212),
            borderRadius: BorderRadius.circular(_expanded ? 16 : 32),
            border: Border.all(
              color: _green.withOpacity(_expanded ? 0.5 : 0.7),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _green.withOpacity(0.35),
                blurRadius: 20,
                spreadRadius: 0,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: _expanded ? _buildExpanded(t, progress) : _buildCollapsed(t),
        ),
      ),
    );
  }

  Widget _buildCollapsed(MusicTrack t) {
    return GestureDetector(
      onTap: () => setState(() => _expanded = true),
      child: SizedBox(
        width: 64,
        height: 64,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (_svc.isPlaying)
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) {
                  return Container(
                    width: 58 + _pulse.value * 4,
                    height: 58 + _pulse.value * 4,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: _green.withOpacity(0.3 + _pulse.value * 0.3),
                        width: 2,
                      ),
                    ),
                  );
                },
              ),
            ClipOval(
              child: SizedBox(
                width: 50,
                height: 50,
                child: t.coverUrl.isNotEmpty
                    ? Image.network(
                        t.coverUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: _green,
                          child: const Icon(Icons.music_note, color: Colors.white),
                        ),
                      )
                    : Container(
                        color: _green,
                        child: const Icon(Icons.music_note, color: Colors.white),
                      ),
              ),
            ),
            if (_svc.isPlaying)
              Positioned(
                bottom: 2,
                right: 2,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: const BoxDecoration(
                    color: _green,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.equalizer, size: 10, color: Colors.white),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpanded(MusicTrack t, double progress) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: SizedBox(
                  width: 48,
                  height: 48,
                  child: t.coverUrl.isNotEmpty
                      ? Image.network(
                          t.coverUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: _surface,
                            child: const Icon(Icons.music_note, color: _muted),
                          ),
                        )
                      : Container(
                          color: _surface,
                          child: const Icon(Icons.music_note, color: _muted),
                        ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      t.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _text,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      t.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _muted, fontSize: 12),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close_rounded, color: _muted, size: 20),
                onPressed: () => setState(() => _expanded = false),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
              activeTrackColor: _green,
              inactiveTrackColor: _surface,
              thumbColor: _text,
            ),
            child: Slider(
              value: progress,
              onChanged: (v) {
                if (_svc.total.inMilliseconds > 0) {
                  _svc.seek(Duration(
                    milliseconds: (v * _svc.total.inMilliseconds).round(),
                  ));
                }
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _fmt(_svc.position),
                  style: const TextStyle(color: _muted, fontSize: 10),
                ),
                Text(
                  _fmt(_svc.total),
                  style: const TextStyle(color: _muted, fontSize: 10),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: Icon(
                  _svc.isShuffle ? Icons.shuffle_on_rounded : Icons.shuffle_rounded,
                  color: _svc.isShuffle ? _green : _muted,
                  size: 20,
                ),
                onPressed: _svc.toggleShuffle,
              ),
              IconButton(
                icon: const Icon(Icons.skip_previous_rounded, color: _text, size: 28),
                onPressed: _svc.previous,
              ),
              GestureDetector(
                onTap: _svc.toggle,
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: _green,
                  ),
                  child: _svc.loading
                      ? const Padding(
                          padding: EdgeInsets.all(10),
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Icon(
                          _svc.isPlaying
                              ? Icons.pause_rounded
                              : Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 26,
                        ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.skip_next_rounded, color: _text, size: 28),
                onPressed: _svc.next,
              ),
              IconButton(
                icon: const Icon(Icons.open_in_new_rounded, color: _muted, size: 18),
                onPressed: () {
                  setState(() => _expanded = false);
                  _svc.setShowFloating(false);
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const SpotifyMusicPage(),
                    ),
                  );
                },
              ),
            ],
          ),
          TextButton(
            onPressed: () async {
              await _svc.stopAndHide();
            },
            child: const Text(
              'Tutup player',
              style: TextStyle(color: _muted, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}
