import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'anime.dart';
import 'comic.dart';
import 'dracin_page.dart';
import 'hentai.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'email_osint_page.dart';
import 'phone_lookup_page.dart';
import 'all_quran.dart';
import 'galau_page.dart';
import 'chat_ai_page.dart';
import 'minibrowser_tool.dart';
import 'youtube_tool.dart';
import 'horror.dart';
// Integrated Games & Tools
import 'tools/asah_otak.dart';
import 'tools/berhitung_cepat.dart';
import 'tools/catur_page.dart';
import 'tools/mario_game.dart';
import 'tools/quiz_page.dart';
import 'tools/snake_game.dart';
import 'tools/iqc.dart';
import 'tools/kalkulator_page.dart';
import 'tools/meme.dart';
import 'tools/chees_game.dart';
import 'tools/uno_game.dart';
import 'tools/ludo_game.dart';
import 'tools/slot_tools.dart';
import 'block_blast.dart';
import 'minesweeper_game.dart';
import 'flappy_bird.dart';
import 'game_2048.dart';
import 'brick_breaker.dart';
import 'memory_card.dart';
import 'ular_tangga.dart';
import 'tebak_tebakan.dart';
import 'teka_teki_matematika.dart';
import 'wordle_game.dart';
import 'tebak_kata.dart';
import 'shortlink_page.dart';
import 'live_photo_page.dart';
import 'cek_ban_wa_page.dart';
import 'news_page.dart';
import 'speed_test.dart';
import 'web_scanner.dart';
import 'typosquat_checker.dart';
import 'converter_page.dart';
import 'encoder_tools.dart';
import 'fake_identity.dart';
import 'hijri_doa_page.dart';
import 'sholat_tools_page.dart';
import 'bokep_tools.dart';
import 'bokep_tools2.dart';
import 'cpanel.dart';
import 'ff.dart';
import 'faketweet.dart';
import 'home_page.dart';
import 'theme_picker_page.dart';
import 'Background/Background_Page.dart';
import 'theme_effects.dart';
import 'fakestory.dart';
import 'bug_menu.dart';




// ======================== CUSTOM CLIPPER ========================
class _ClippedCornerClipper extends CustomClipper<Path> {
  final double cut;
  const _ClippedCornerClipper({this.cut = 14});

  @override
  Path getClip(Size size) {
    final p = Path();
    final c = cut;
    p.moveTo(c, 0);
    p.lineTo(size.width - c, 0);
    p.lineTo(size.width, c);
    p.lineTo(size.width, size.height - c);
    p.lineTo(size.width - c, size.height);
    p.lineTo(c, size.height);
    p.lineTo(0, size.height - c);
    p.lineTo(0, c);
    p.close();
    return p;
  }

  @override
  bool shouldReclip(_ClippedCornerClipper old) => cut != old.cut;
}

// ======================== CUSTOM PAINTERS ========================
class _DotGridPainter extends CustomPainter {
  final Color color;
  _DotGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    const spacing = 28.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 0.8, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DotGridPainter old) => color != old.color;
}

class _ScanLinePainter extends CustomPainter {
  final double position;
  final Color color;
  _ScanLinePainter({required this.position, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final y = position * (size.height + 80) - 40;
    final rect = Rect.fromLTWH(0, y - 35, size.width, 70);
    final shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.transparent,
        color.withOpacity(0.07),
        color.withOpacity(0.12),
        color.withOpacity(0.07),
        Colors.transparent,
      ],
      stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = shader);
  }

  @override
  bool shouldRepaint(_ScanLinePainter old) => position != old.position;
}

class _RadarPainter extends CustomPainter {
  final double angle;
  final Color color;
  _RadarPainter({required this.angle, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 2;

    final circlePaint = Paint()
      ..color = color.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (int i = 1; i <= 3; i++) {
      canvas.drawCircle(center, r * i / 3, circlePaint);
    }

    final linePaint = Paint()
      ..color = color.withOpacity(0.1)
      ..strokeWidth = 0.5;
    canvas.drawLine(
        Offset(center.dx - r, center.dy), Offset(center.dx + r, center.dy), linePaint);
    canvas.drawLine(
        Offset(center.dx, center.dy - r), Offset(center.dx, center.dy + r), linePaint);

    final sweepShader = SweepGradient(
      startAngle: angle - 0.6,
      endAngle: angle,
      colors: [color.withOpacity(0.0), color.withOpacity(0.3)],
    ).createShader(Rect.fromCircle(center: center, radius: r));
    canvas.drawCircle(center, r, Paint()..shader = sweepShader);

    final endPt = Offset(
        center.dx + math.cos(angle) * r, center.dy + math.sin(angle) * r);
    canvas.drawLine(center, endPt, Paint()..color = color.withOpacity(0.7)..strokeWidth = 1.5);

    canvas.drawCircle(center, 2.5, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_RadarPainter old) => angle != old.angle;
}

class _DiagonalStripePainter extends CustomPainter {
  final Color color;
  _DiagonalStripePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (double i = -size.height; i < size.width + size.height; i += 18) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(_DiagonalStripePainter old) => color != old.color;
}

// ======================== TOOL ITEM MODEL ========================
class _ToolItem {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool locked;
  const _ToolItem(
      {required this.icon, required this.label, required this.onTap, this.locked = false});
}

// ======================== MAIN WIDGET ========================
class ToolsPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final String password;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final VoidCallback? onAppearanceChanged;

  const ToolsPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    this.password = '',
    this.expiredDate = '',
    this.listBug = const [],
    this.listBugGroup = const [],
    this.onAppearanceChanged,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  Widget _buildTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF29415B).withOpacity(0.18),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF9AB6D0).withOpacity(0.45)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF9AB6D0),
          fontFamily: 'Roboto',
          fontSize: 9,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  final Color primaryDark = const Color(0xFF0A0F16);
  final Color primaryRed = const Color(0xFF20364D);
  final Color accentRed = const Color(0xFF345675);
  final Color lightRed = const Color(0xFF527FA8);
  final Color primaryWhite = const Color(0xFFF1F5F9);
  final Color accentGrey = const Color(0xFFA7B4C4);
  final Color cardDark = const Color(0xFF0A0F16);
  final Color borderDark = const Color(0xFF17212D);

  late AnimationController _scanCtrl;
  late AnimationController _radarCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _tickerCtrl;
  late PageController _carouselCtrl;
  int _carouselIndex = 0;
  String _searchQuery = '';

  // Black + red theme
  static const _purple = Color(0xFF527FA8);      // merah accent
  static const _purpleDeep = Color(0xFF29415B);  // merah tua
  static const _pink = Color(0xFFEF5350);       // merah soft (gradient)
  static const _spaceBg = Color(0xFF0A0F16);    // hitam

  List<_CarouselModule> _modules(BuildContext context) => [
        _CarouselModule(
          title: 'Bug Center',
          subtitle: 'WhatsApp Modes',
          description: 'Pilih Bug Number, Bug Group, atau Test Function sebelum membuka form.',
          icon: Icons.bug_report_rounded,
          onOpen: () => _openBugCenter(context),
        ),
        _CarouselModule(
          title: 'Panel',
          subtitle: 'Server & Wings',
          description: 'Akses panel server Anda dengan fitur manajemen lengkap',
          icon: Icons.dns_rounded,
          onOpen: () => _showPanelTools(context),
        ),
        _CarouselModule(
          title: 'Attack',
          subtitle: 'Stress Testing',
          description: 'Tools untuk stress testing dan performance analysis',
          icon: Icons.bolt_rounded,
          onOpen: () => _showAttackTools(context),
        ),
        _CarouselModule(
          title: 'OSINT',
          subtitle: 'Intel & Lookup',
          description: 'Pencarian informasi dan OSINT tools terintegrasi',
          icon: Icons.travel_explore_rounded,
          onOpen: () => _showOSINTTools(context),
        ),
        _CarouselModule(
          title: 'Attack',
          subtitle: 'WiFi & Spam',
          description: 'Tools jaringan, WiFi killer, dan spam utilities',
          icon: Icons.wifi_tethering_rounded,
          onOpen: () => _showNetworkTools(context),
        ),
        _CarouselModule(
          title: 'Media',
          subtitle: 'Anime & Stream',
          description: 'Akses konten media dengan berbagai kategori',
          icon: Icons.play_circle_rounded,
          onOpen: () => _showMediaTools(context),
        ),
        _CarouselModule(
          title: 'Games',
          subtitle: 'Mini Games',
          description: 'Kumpulan game dan tools hiburan terintegrasi',
          icon: Icons.sports_esports_rounded,
          onOpen: () => _showGamesTools(context),
        ),
        _CarouselModule(
          title: 'Downloader',
          subtitle: 'Media & File',
          description: 'Download konten dari berbagai platform',
          icon: Icons.download_rounded,
          onOpen: () => _showDownloaderTools(context),
        ),
        _CarouselModule(
          title: 'Utility',
          subtitle: 'QR & Konverter',
          description: 'Tools utilitas sehari-hari untuk produktivitas',
          icon: Icons.build_rounded,
          onOpen: () => _showUtilityTools(context),
        ),
        _CarouselModule(
          title: 'Tools',
          subtitle: 'AI & Extra',
          description: 'Fitur tambahan: AI chat, browser, YouTube, identity',
          icon: Icons.handyman_rounded,
          onOpen: () => _showMoreTools(context),
        ),
        _CarouselModule(
          title: 'Islami',
          subtitle: 'Quran & Sholat',
          description: 'Al-Quran, jadwal sholat, kalender hijriah, doa harian',
          icon: Icons.mosque_rounded,
          onOpen: () => _showIslamiTools(context),
        ),
      ];

  @override
  void initState() {
    super.initState();
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _radarCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _pulseCtrl =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
          ..repeat(reverse: true);
    _tickerCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 25))..repeat();
    _carouselCtrl = PageController(viewportFraction: 0.78);
  }

  @override
  void dispose() {
    _scanCtrl.dispose();
    _radarCtrl.dispose();
    _pulseCtrl.dispose();
    _tickerCtrl.dispose();
    _carouselCtrl.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    final role = widget.userRole.toUpperCase();
    // Grid modules — style X-SPYDER, brand ZEVORA PROJECT, tema hitam + merah
    final gridItems = <_GwGridItem>[
      _GwGridItem(
        icon: Icons.bug_report_rounded,
        title: 'Bug WhatsApp',
        subtitle: 'Number • Group • Function',
        iconColor: const Color(0xFFFF7188),
        onTap: () => _openBugCenter(context),
      ),
      _GwGridItem(
        icon: Icons.bolt_rounded,
        title: 'DDos Tools',
        subtitle: 'Attack & Server',
        iconColor: const Color(0xFF7899B9),
        onTap: () => _showAttackTools(context),
      ),
      _GwGridItem(
        icon: Icons.wifi_rounded,
        title: 'Attack',
        subtitle: 'WiFi & Spam',
        iconColor: const Color(0xFF8AA7C4),
        onTap: () => _showNetworkTools(context),
      ),
      _GwGridItem(
        icon: Icons.search_rounded,
        title: 'OSINT',
        subtitle: 'Investigation',
        iconColor: const Color(0xFF9AB6D0),
        onTap: () => _showOSINTTools(context),
      ),
      _GwGridItem(
        icon: Icons.download_rounded,
        title: 'Downloader',
        subtitle: 'Social Media',
        iconColor: const Color(0xFF527FA8),
        onTap: () => _showDownloaderTools(context),
      ),
      _GwGridItem(
        icon: Icons.play_circle_rounded,
        title: 'Streaming',
        subtitle: 'Motion & Telegram',
        iconColor: const Color(0xFF7899B9),
        onTap: () => _showMediaTools(context),
      ),
      _GwGridItem(
        icon: Icons.handyman_rounded,
        title: 'Tools',
        subtitle: 'AI & Extra Tools',
        iconColor: const Color(0xFF8AA7C4),
        onTap: () => _showMoreTools(context),
      ),
      _GwGridItem(
        icon: Icons.dns_rounded,
        title: 'Panel Server',
        subtitle: 'VPS & Wings',
        iconColor: const Color(0xFF9AB6D0),
        onTap: () => _showPanelTools(context),
      ),
      _GwGridItem(
        icon: Icons.build_rounded,
        title: 'Utility',
        subtitle: 'QR & Konverter',
        iconColor: const Color(0xFF527FA8),
        onTap: () => _showUtilityTools(context),
      ),
      _GwGridItem(
        icon: Icons.mosque_rounded,
        title: 'Islami',
        subtitle: 'Quran & Sholat',
        iconColor: const Color(0xFF5C9C82),
        onTap: () => _showIslamiTools(context),
      ),
      _GwGridItem(
        icon: Icons.sports_esports_rounded,
        title: 'Games',
        subtitle: 'Mini Games',
        iconColor: const Color(0xFF7899B9),
        onTap: () => _showGamesTools(context),
      ),
      _GwGridItem(
        icon: Icons.newspaper_rounded,
        title: 'Berita',
        subtitle: 'Google News',
        iconColor: const Color(0xFF7899B9),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NewsPage()),
          );
        },
      ),
    ];
    final visibleItems = gridItems.where((item) {
      final q = _searchQuery.trim().toLowerCase();
      if (q.isEmpty) return true;
      return item.title.toLowerCase().contains(q) || item.subtitle.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background transparan agar video landing.mp4 dari parent dashboard terlihat
          // subtle red ambient
          Positioned(
            top: -60,
            left: -30,
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  const Color(0xFF527FA8).withOpacity(0.14),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          Positioned(
            bottom: 40,
            right: -40,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  const Color(0xFF29415B).withOpacity(0.12),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // Top bar — ZEVORA PROJECT brand
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 6, 14, 0),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new,
                            color: Colors.white70, size: 18),
                        onPressed: () => Navigator.pop(context),
                      ),
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: const Color(0xFF527FA8).withOpacity(0.55)),
                          color: const Color(0xFF1A0A0A),
                        ),
                        child: const Icon(Icons.person,
                            color: Color(0xFF527FA8), size: 16),
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'ZEVORA PROJECT',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: const Color(0xFF527FA8).withOpacity(0.55)),
                          color: const Color(0xFF527FA8).withOpacity(0.12),
                        ),
                        child: Text(
                          role,
                          style: const TextStyle(
                            color: Color(0xFFFFCDD2),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF527FA8).withOpacity(0.12),
                          border: Border.all(
                              color: const Color(0xFF527FA8).withOpacity(0.4)),
                        ),
                        child: const Icon(Icons.headphones_rounded,
                            color: Color(0xFF527FA8), size: 16),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // Brand header card
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.white.withOpacity(0.04),
                      border: Border.all(color: Colors.white.withOpacity(0.08)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: const LinearGradient(
                              colors: [Color(0xFF527FA8), Color(0xFF29415B)],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF527FA8).withOpacity(0.4),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.graphic_eq_rounded,
                              color: Colors.white, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ShaderMask(
                                shaderCallback: (b) => const LinearGradient(
                                  colors: [
                                    Color(0xFF8AA7C4),
                                    Color(0xFF527FA8),
                                    Color(0xFF9AB6D0),
                                  ],
                                ).createShader(b),
                                child: const Text(
                                  'ZEVORA PROJECT',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ),
                              Text(
                                'Pusat fitur dan utilitas ZEVORA PROJECT',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.5),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '${visibleItems.length} item',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.35),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      color: const Color(0xFF111C29).withOpacity(.92),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFF527FA8).withOpacity(.30)),
                    ),
                    child: TextField(
                      onChanged: (value) => setState(() => _searchQuery = value),
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                      decoration: InputDecoration(
                        hintText: 'Cari tools atau kategori...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(.38), fontSize: 12),
                        prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF9AB6D0), size: 19),
                        suffixIcon: _searchQuery.isEmpty ? null : IconButton(
                          onPressed: () => setState(() => _searchQuery = ''),
                          icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 17),
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 13),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Jelajahi kategori dan fitur',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.55),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // ── 2-column tool grid ──
                Expanded(
                  child: visibleItems.isEmpty
                      ? Center(child: Text('Kategori tidak ditemukan', style: TextStyle(color: Colors.white.withOpacity(.5), fontSize: 12)))
                      : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                    physics: const BouncingScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.05,
                    ),
                    itemCount: visibleItems.length,
                    itemBuilder: (context, i) {
                      final g = visibleItems[i];
                      return _buildGwGridCard(g);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGwGridCard(_GwGridItem g) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: g.onTap,
        child: Semantics(
          button: true,
          label: '${g.title}. ${g.subtitle}',
          child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 13, sigmaY: 13),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(.085),
                    const Color(0xFF101722).withOpacity(.88),
                    const Color(0xFF090E15).withOpacity(.94),
                  ],
                ),
                border: Border.all(
                  color: g.iconColor.withOpacity(.42),
                  width: 1.05,
                ),
                boxShadow: [
                  BoxShadow(
                    color: g.iconColor.withOpacity(.11),
                    blurRadius: 20,
                    spreadRadius: -5,
                    offset: const Offset(0, 9),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(.22),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    left: 18,
                    right: 18,
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            Colors.white.withOpacity(.25),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                g.iconColor.withOpacity(.24),
                                g.iconColor.withOpacity(.07),
                              ],
                            ),
                            border: Border.all(
                              color: g.iconColor.withOpacity(.58),
                              width: 1.15,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: g.iconColor.withOpacity(.17),
                                blurRadius: 17,
                                spreadRadius: -3,
                              ),
                            ],
                          ),
                          child: Icon(g.icon, color: g.iconColor, size: 26),
                        ),
                        const SizedBox(height: 13),
                        Text(
                          g.title,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFFF4F7FB),
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .2,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          g.subtitle,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white.withOpacity(.52),
                            fontSize: 10.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          ),
        ),
      ),
    );
  }


  Widget _circleNav(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.06),
          border: Border.all(color: Colors.white12),
        ),
        child: Icon(icon, color: Colors.white70, size: 26),
      ),
    );
  }

  Widget _buildCarouselCard(_CarouselModule m, bool isActive) {
    return GestureDetector(
      onTap: m.onOpen,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1A0C0C),
              const Color(0xFF0E0606),
              Color.lerp(const Color(0xFF0A0505), const Color(0xFF527FA8), 0.06)!,
            ],
          ),
          border: Border.all(
            color: isActive
                ? const Color(0xFF527FA8).withOpacity(0.75)
                : Colors.white.withOpacity(0.08),
            width: isActive ? 1.6 : 1,
          ),
          boxShadow: [
            if (isActive)
              BoxShadow(
                color: const Color(0xFF527FA8).withOpacity(0.28),
                blurRadius: 28,
                spreadRadius: 1,
                offset: const Offset(0, 12),
              ),
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            // soft corner glow
            Positioned(
              top: -30,
              right: -20,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [
                    const Color(0xFF527FA8).withOpacity(isActive ? 0.2 : 0.06),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 28, 22, 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // icon box
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF527FA8).withOpacity(0.12),
                      border: Border.all(
                        color: const Color(0xFF527FA8).withOpacity(0.4),
                      ),
                    ),
                    child: Icon(m.icon,
                        color: const Color(0xFF8AA7C4), size: 26),
                  ),
                  const Spacer(),
                  Text(
                    m.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    m.subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.45),
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 18),
                  // OPEN chip
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: const Color(0xFF527FA8).withOpacity(0.55),
                      ),
                      color: const Color(0xFF527FA8).withOpacity(0.1),
                    ),
                    child: const Text(
                      'OPEN',
                      style: TextStyle(
                        color: Color(0xFF9AB6D0),
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== DATA TICKER ====================
  Widget _buildDataTicker() {
    final text =
        "SYS.ONLINE  //  TOOLS:25+  //  NODE:ACTIVE  //  ENCRYPTED:AES-256  //  LATENCY:12ms  //  UPTIME:99.9%  //  ";
    final textStyle = TextStyle(
      color: primaryRed.withOpacity(0.5),
      fontSize: 10,
      fontFamily: 'Roboto',
      letterSpacing: 1.5,
    );

    return SizedBox(
      height: 22,
      child: ClipRect(
        child: AnimatedBuilder(
          animation: _tickerCtrl,
          builder: (context, _) {
            return Transform.translate(
              offset: Offset(-_tickerCtrl.value * 600, 0),
              child: Row(
                children: [
                  Text(text, style: textStyle),
                  Text(text, style: textStyle),
                  Text(text, style: textStyle),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          // Radar
          SizedBox(
            width: 56,
            height: 56,
            child: AnimatedBuilder(
              animation: _radarCtrl,
              builder: (context, _) {
                return CustomPaint(
                  painter: _RadarPainter(
                    angle: _radarCtrl.value * 2 * math.pi,
                    color: lightRed,
                  ),
                );
              },
            ),
          ),
          const SizedBox(width: 16),
          // Judul
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "TOOLS DASHBOARD",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 22,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(color: lightRed.withOpacity(0.4), blurRadius: 12),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "Utilities, Media & Productivity Suite",
                  style: TextStyle(
                    color: accentGrey.withOpacity(0.7),
                    fontSize: 11,
                    fontFamily: 'Roboto',
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          // Indikator online
          Column(
            children: [
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (context, _) {
                  return Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: lightRed.withOpacity(0.4 + _pulseCtrl.value * 0.6),
                      boxShadow: [
                        BoxShadow(
                          color: lightRed.withOpacity(0.3 + _pulseCtrl.value * 0.4),
                          blurRadius: 8,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 4),
              Text(
                "ONLINE",
                style: TextStyle(
                  color: lightRed,
                  fontSize: 8,
                  fontFamily: 'Roboto',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ==================== STATUS BAR ====================
  Widget _buildStatusBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
      child: Row(
        children: [
          _buildStatusChip(Icons.widgets, "25+ TOOLS", lightRed),
          const SizedBox(width: 8),
          _buildStatusChip(Icons.bolt, "PRIORITY", primaryWhite),
          const SizedBox(width: 8),
          _buildStatusChip(Icons.shield, "SECURED", accentGrey),
        ],
      ),
    );
  }

  Widget _buildStatusChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: primaryRed.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: borderDark, width: 0.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color.withOpacity(0.8),
              fontSize: 9,
              fontFamily: 'Roboto',
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HERO CARD (Attack) ====================
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => _showAttackTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 18),
          child: Container(
            height: 140,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  cardDark,
                  primaryRed.withOpacity(0.15),
                  cardDark,
                ],
              ),
              border: Border.all(color: primaryRed.withOpacity(0.4)),
            ),
            child: Stack(
              children: [
                // Diagonal stripes
                Positioned.fill(
                  child: CustomPaint(
                    painter: _DiagonalStripePainter(
                        color: lightRed.withOpacity(0.04)),
                  ),
                ),
                // Pulse border overlay
                AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (context, _) {
                    return Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: lightRed.withOpacity(0.1 + _pulseCtrl.value * 0.2),
                          width: 1,
                        ),
                      ),
                    );
                  },
                ),
                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      // Icon container
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [primaryRed, accentRed],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: lightRed.withOpacity(0.3)),
                          boxShadow: [
                            BoxShadow(
                              color: primaryRed.withOpacity(0.4),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.flash_on,
                            color: Color(0xFFF1F5F9), size: 30),
                      ),
                      const SizedBox(width: 18),
                      // Text
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "ATTACK TOOLS",
                                  style: TextStyle(
                                    color: primaryWhite,
                                    fontSize: 17,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: lightRed.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(3),
                                    border: Border.all(
                                        color: lightRed.withOpacity(0.4)),
                                  ),
                                  child: Text(
                                    "PRIORITY",
                                    style: TextStyle(
                                      color: lightRed,
                                      fontSize: 7,
                                      fontFamily: 'Roboto',
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Attack Panel",
                              style: TextStyle(
                                color: accentGrey.withOpacity(0.6),
                                fontSize: 11,
                                fontFamily: 'Roboto',
                              ),
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: lightRed,
                                    boxShadow: [
                                      BoxShadow(
                                          color: lightRed,
                                          blurRadius: 4,
                                          spreadRadius: 1),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  "2 MODULES AVAILABLE",
                                  style: TextStyle(
                                    color: lightRed.withOpacity(0.6),
                                    fontSize: 9,
                                    fontFamily: 'Roboto',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      // Arrow
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.chevron_right,
                              color: accentGrey.withOpacity(0.3), size: 28),
                        ],
                      ),
                    ],
                  ),
                ),
                // Corner marks
                _buildCornerMarks(color: lightRed, size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== NETWORK CARD ====================
  Widget _buildNetworkCard() {
    final toolCount = (widget.userRole == "vip" || widget.userRole == "owner") ? 3 : 2;
    return _buildClippedCard(
      icon: Icons.wifi,
      title: "ATTACK",
      subtitle: "WiFi & Spam",
      toolCount: toolCount,
      accentColor: primaryWhite,
      onTap: () => _showNetworkTools(context),
      cut: 14,
    );
  }

  // ==================== OSINT CARD ====================
  Widget _buildOsintCard() {
    return _buildClippedCard(
      icon: Icons.search,
      title: "OSINT",
      subtitle: "Investigation",
      toolCount: 4,
      accentColor: primaryWhite,
      onTap: () => _showOSINTTools(context),
      cut: 14,
    );
  }

  // ==================== DOWNLOADER CARD ====================
  Widget _buildDownloaderCard() {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: GestureDetector(
        onTap: () => _showDownloaderTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              color: cardDark,
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: primaryRed.withOpacity(0.3)),
                        ),
                        child: const Icon(Icons.download,
                            color: Color(0xFFF1F5F9), size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "DOWNLOADER",
                              style: TextStyle(
                                color: primaryWhite,
                                fontSize: 13,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              "Social Media",
                              style: TextStyle(
                                color: accentGrey.withOpacity(0.5),
                                fontSize: 10,
                                fontFamily: 'Roboto',
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _buildPlatformBadge("TT", Colors.redAccent),
                                const SizedBox(width: 6),
                                _buildPlatformBadge("IG",
                                    Color(0xFFE1306C).withOpacity(0.8)),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: accentGrey.withOpacity(0.25), size: 24),
                    ],
                  ),
                ),
                _buildCornerMarks(color: primaryRed, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlatformBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ==================== UTILITY CARD ====================
  Widget _buildUtilityCard() {
    return Padding(
      padding: const EdgeInsets.only(right: 20),
      child: GestureDetector(
        onTap: () => _showUtilityTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              color: cardDark,
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: primaryRed.withOpacity(0.3)),
                        ),
                        child: const Icon(Icons.build,
                            color: Color(0xFFF1F5F9), size: 20),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "UTILS",
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 12,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "3 Tools",
                        style: TextStyle(
                          color: accentGrey.withOpacity(0.4),
                          fontSize: 9,
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ],
                  ),
                ),
                _buildCornerMarks(color: primaryRed, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== GAMES CARD ====================
  Widget _buildGamesCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => _showGamesTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 118,
            decoration: BoxDecoration(
              color: cardDark.withOpacity(0.96),
              border: Border.all(color: primaryRed.withOpacity(0.75)),
            ),
            child: Row(
              children: [
                const SizedBox(width: 22),
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    color: const Color(0xFF240018),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFF29415B)),
                  ),
                  child: const Icon(Icons.nightlight_round, color: Color(0xFF9AB6D0), size: 34),
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'GAMES',
                            style: TextStyle(
                              color: primaryWhite,
                              fontFamily: 'Roboto',
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          _buildTag('NEW'),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Games • Utilities • Explore • Survive',
                        style: TextStyle(
                          color: accentGrey.withOpacity(0.7),
                          fontFamily: 'Rajdhani',
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: accentGrey.withOpacity(0.5), size: 28),
                const SizedBox(width: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== GAMES TOOLS ====================
  void _showGamesTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: 'Games & Tools',
      icon: Icons.sports_esports,
      tools: [
        _ToolItem(
          icon: Icons.psychology,
          label: 'Asah\nOtak',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const AsahOtakPage()));
          },
        ),
        _ToolItem(
          icon: Icons.calculate,
          label: 'Berhitung\nCepat',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const BerhitungCepatPage()));
          },
        ),
        _ToolItem(
          icon: Icons.grid_4x4,
          label: 'Catur',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const CaturPage()));
          },
        ),
        _ToolItem(
          icon: Icons.videogame_asset,
          label: 'Mario',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const GameScreen()));
          },
        ),
        _ToolItem(
          icon: Icons.quiz,
          label: 'Quiz',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage()));
          },
        ),
        _ToolItem(
          icon: Icons.sports_esports,
          label: 'Snake',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SnakeGamePage()));
          },
        ),
        _ToolItem(
          icon: Icons.grid_3x3,
          label: 'Chess',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ChessGamePage()));
          },
        ),
        _ToolItem(
          icon: Icons.style,
          label: 'UNO',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const UnoGamePage()));
          },
        ),
        _ToolItem(
          icon: Icons.casino,
          label: 'Ludo',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const LudoKingTools()));
          },
        ),
        _ToolItem(
          icon: Icons.local_activity,
          label: 'Slot Tools',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const SlotMachineTools()));
          },
        ),
        _ToolItem(
          icon: Icons.grid_view_rounded,
          label: 'Block\nBlast',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const BlockBlastPage()));
          },
        ),
        _ToolItem(
          icon: Icons.flag_rounded,
          label: 'Minesweeper',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MinesweeperPage()));
          },
        ),
        _ToolItem(
          icon: Icons.flutter_dash_rounded,
          label: 'Flappy\nBird',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const FlappyBirdPage()));
          },
        ),
        _ToolItem(
          icon: Icons.looks_4_rounded,
          label: '2048',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const Game2048Page()));
          },
        ),
        _ToolItem(
          icon: Icons.breakfast_dining_rounded,
          label: 'Brick\nBreaker',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const BrickBreakerPage()));
          },
        ),
        _ToolItem(
          icon: Icons.style_rounded,
          label: 'Memory\nCard',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MemoryCardPage()));
          },
        ),
        _ToolItem(
          icon: Icons.stairs_rounded,
          label: 'Ular\nTangga',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const UlarTanggaPage()));
          },
        ),
        _ToolItem(
          icon: Icons.help_outline_rounded,
          label: 'Tebak-\nTebakan',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const TebakTebakanPage()));
          },
        ),
        _ToolItem(
          icon: Icons.functions_rounded,
          label: 'Teka-Teki\nMatematika',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const TekaTekiMatematikaPage()));
          },
        ),
        _ToolItem(
          icon: Icons.abc_rounded,
          label: 'Wordle',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const WordleGamePage()));
          },
        ),
        _ToolItem(
          icon: Icons.nightlight_round,
          label: 'Horror\nSurvival',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const HorrorGameScreen()));
          },
        ),
        _ToolItem(
          icon: Icons.text_fields_rounded,
          label: 'Tebak\nKata',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const TebakKataPage()));
          },
        ),
      ],
    );
  }

  // ==================== MORE TOOLS CARD ====================
  Widget _buildMoreToolsCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => _showMoreTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 118,
            decoration: BoxDecoration(
              color: cardDark,
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: _DiagonalStripePainter(
                      color: lightRed.withOpacity(0.025),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: primaryRed.withOpacity(0.35)),
                        ),
                        child: const Icon(Icons.apps,
                            color: Color(0xFFF1F5F9), size: 25),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "MORE TOOLS",
                                  style: TextStyle(
                                    color: primaryWhite,
                                    fontSize: 15,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: lightRed.withOpacity(0.14),
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                        color: lightRed.withOpacity(0.28)),
                                  ),
                                  child: Text(
                                    "4 TOOLS",
                                    style: TextStyle(
                                      color: lightRed,
                                      fontSize: 8,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(
                              "AI • Al-Quran • Mini Browser • YouTube",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: accentGrey.withOpacity(0.55),
                                fontSize: 9,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: accentGrey.withOpacity(0.3), size: 24),
                    ],
                  ),
                ),
                _buildCornerMarks(color: primaryRed, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== MEDIA CARD ====================
  Widget _buildMediaCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GestureDetector(
        onTap: () => _showMediaTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 118,
            decoration: BoxDecoration(
              color: cardDark,
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: CustomPaint(
                    painter: _DiagonalStripePainter(
                      color: lightRed.withOpacity(0.025),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: primaryRed.withOpacity(0.35),
                          ),
                        ),
                        child: const Icon(
                          Icons.movie_filter,
                          color: Color(0xFFF1F5F9),
                          size: 25,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "MEDIA",
                                  style: TextStyle(
                                    color: primaryWhite,
                                    fontSize: 15,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 3,
                                  ),
                                  decoration: BoxDecoration(
                                    color: lightRed.withOpacity(0.14),
                                    borderRadius: BorderRadius.circular(4),
                                    border: Border.all(
                                      color: lightRed.withOpacity(0.28),
                                    ),
                                  ),
                                  child: Text(
                                    "4 TOOLS",
                                    style: TextStyle(
                                      color: lightRed,
                                      fontSize: 8,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 5),
                            Text(
                              "Anime • Comic • Dracin • Hentai",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: accentGrey.withOpacity(0.55),
                                fontSize: 9,
                                fontFamily: 'Roboto',
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.chevron_right,
                        color: accentGrey.withOpacity(0.3),
                        size: 24,
                      ),
                    ],
                  ),
                ),
                _buildCornerMarks(color: primaryRed, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Appearance Studio menyatukan warna tema, background, dan efek visual.
  void _showAppearanceTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: 'Appearance Studio',
      icon: Icons.palette_rounded,
      tools: [
        _ToolItem(
          icon: Icons.color_lens_rounded,
          label: 'Theme Colors',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ThemePickerPage()));
          },
        ),
        _ToolItem(
          icon: Icons.wallpaper_rounded,
          label: 'Background',
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => BackgroundPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
              role: widget.userRole,
            )));
          },
        ),
        _ToolItem(
          icon: Icons.auto_awesome_rounded,
          label: 'Theme Effects',
          onTap: () {
            Navigator.pop(context);
            _showThemeEffects(context);
          },
        ),
      ],
    );
  }

  void _showThemeEffects(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0D1520),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('THEME EFFECTS', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1)),
            const SizedBox(height: 6),
            Text('Pilih efek visual yang digunakan aplikasi.', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
            const SizedBox(height: 14),
            _effectChoice(sheetContext, 'Tidak ada efek', 'none', Icons.layers_clear_rounded),
            _effectChoice(sheetContext, 'Snow / Frost', 'snow', Icons.ac_unit_rounded),
            _effectChoice(sheetContext, 'Sakura', 'sakura', Icons.local_florist_rounded),
          ]),
        ),
      ),
    );
  }

  Widget _effectChoice(BuildContext sheetContext, String label, String value, IconData icon) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: Icon(icon, color: const Color(0xFF9AB6D0)),
      title: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      trailing: const Icon(Icons.chevron_right_rounded, color: Colors.white38),
      onTap: () async {
        final effect = value == 'snow' ? FxTheme.snow : value == 'sakura' ? FxTheme.sakura : FxTheme.none;
        await FxThemeStorage.save(effect);
        if (sheetContext.mounted) Navigator.pop(sheetContext);
        widget.onAppearanceChanged?.call();
      },
    );
  }

  // ==================== MORE TOOLS ====================
  void _showMoreTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Tools",
      icon: Icons.handyman_rounded,
      tools: [
        _ToolItem(
          icon: Icons.auto_awesome,
          label: "AI\nAssistant",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatAIPage(
                  username: widget.username,
                  sessionKey: widget.sessionKey,
                ),
              ),
            );
          },
        ),
        _ToolItem(
          icon: Icons.palette_rounded,
          label: "Appearance\nStudio",
          onTap: () {
            Navigator.pop(context);
            _showAppearanceTools(context);
          },
        ),
        _ToolItem(
          icon: Icons.person_search_rounded,
          label: "Fake\nIdentity",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeIdentityPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.camera_alt_outlined,
          label: "Fake\nStory",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeStoryPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.chat_bubble_outline,
          label: "Fake\nTweet",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const FakeTweetPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.sports_esports_rounded,
          label: "Free\nFire",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => FreeFireToolsPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
        _ToolItem(
          icon: Icons.favorite_rounded,
          label: "Galau",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const GalauPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.language,
          label: "Mini\nBrowser",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MiniBrowserToolPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.play_circle_fill,
          label: "YouTube",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const YouTubeToolPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.psychology_alt,
          label: "IQC\nMaker",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const IQCScreen()));
          },
        ),
        _ToolItem(
          icon: Icons.calculate_outlined,
          label: "Kalkulator",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const KalkulatorPage()));
          },
        ),
        _ToolItem(
          icon: Icons.emoji_emotions,
          label: "Meme",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MemeGeneratorPage()));
          },
        ),
        _ToolItem(
          icon: Icons.link_rounded,
          label: "Short\nLink",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ShortlinkPage(sessionKey: widget.sessionKey)),
            );
          },
        ),
        _ToolItem(
          icon: Icons.newspaper_rounded,
          label: "Berita\nUpdates",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const NewsPage()),
            );
          },
        ),
      ],
    );
  }

  void _showIslamiTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Islami",
      icon: Icons.mosque_rounded,
      tools: [
        _ToolItem(
          icon: Icons.menu_book_rounded,
          label: "Al-Quran",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AllQuranPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.access_time_rounded,
          label: "Jadwal\nSholat",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SholatToolsPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.calendar_month_rounded,
          label: "Hijri &\nDoa",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HijriDoaPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.explore_rounded,
          label: "Sholat\nTools",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SholatToolsPage()),
            );
          },
        ),
      ],
    );
  }

  // ==================== MEDIA TOOLS ====================
  void _showMediaTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Streaming",
      icon: Icons.movie_filter,
      tools: [
        _ToolItem(
          icon: Icons.movie_creation,
          label: "Anime",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HomeAnimePage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.menu_book,
          label: "Comic",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ComicPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.live_tv,
          label: "Dracin",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DracinPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.visibility_off,
          label: "Hentai",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HomeHentaiPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.play_circle_filled,
          label: "18+\nTools",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BokepToolsPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
        _ToolItem(
          icon: Icons.videocam_rounded,
          label: "18+\nTools 2",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BokepTools2Page(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  // ==================== QUICK ACCESS ====================
  Widget _buildQuickAccess() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(
              "QUICK ACCESS",
              style: TextStyle(
                color: accentGrey.withOpacity(0.4),
                fontSize: 9,
                fontFamily: 'Roboto',
                letterSpacing: 2,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                _buildQuickPill(Icons.flash_on, "Attack",
                    () => _showAttackTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.wifi, "Attack",
                    () => _showNetworkTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.search, "OSINT",
                    () => _showOSINTTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.download, "Download",
                    () => _showDownloaderTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.build, "Utility",
                    () => _showUtilityTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.movie_filter, "Media",
                    () => _showMediaTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.handyman_rounded, "Tools",
                    () => _showMoreTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.mosque_rounded, "Islami",
                    () => _showIslamiTools(context)),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.newspaper_rounded, "Berita", () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const NewsPage()));
                }),
                const SizedBox(width: 8),
                _buildQuickPill(Icons.qr_code, "QR Gen", () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickPill(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: cardDark,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: borderDark, width: 0.5),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: lightRed, size: 14),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: primaryWhite.withOpacity(0.7),
                fontSize: 10,
                fontFamily: 'Roboto',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== GENERIC CLIPPED CARD ====================
  Widget _buildClippedCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required int toolCount,
    required Color accentColor,
    required VoidCallback onTap,
    required double cut,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: GestureDetector(
        onTap: onTap,
        child: ClipPath(
          clipper: _ClippedCornerClipper(cut: cut),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              color: cardDark,
              border: Border.all(color: primaryRed.withOpacity(0.3)),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: primaryRed.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: primaryRed.withOpacity(0.3)),
                        ),
                        child: Icon(icon, color: accentColor, size: 20),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        title,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 13,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Text(
                            subtitle,
                            style: TextStyle(
                              color: accentGrey.withOpacity(0.5),
                              fontSize: 10,
                              fontFamily: 'Roboto',
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "$toolCount",
                            style: TextStyle(
                              color: lightRed.withOpacity(0.6),
                              fontSize: 9,
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Arrow
                Positioned(
                  right: 12,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: Icon(Icons.chevron_right,
                        color: accentGrey.withOpacity(0.2), size: 22),
                  ),
                ),
                _buildCornerMarks(color: primaryRed, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== CORNER MARKS ====================
  Widget _buildCornerMarks({required Color color, required double size}) {
    final markSize = size * 0.4;
    final linePaint = Paint()
  ..color = color.withOpacity(0.5)
  ..strokeWidth = 1.5
  ..style = PaintingStyle.stroke;

return CustomPaint(
  size: Size(double.infinity, double.infinity),
  painter: _CornerMarkPainter(
    markSize: markSize,
    linePaint: linePaint,
  ),
);
  }

  // ==================== ENTRY ANIMATION ====================
  Widget _animateEntry(int index, Widget child) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + index * 120),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 24 * (1 - value)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  // ==================== PREMIUM TOOL SELECTOR ====================
  // Selector berbentuk sheet responsif: pengguna memilih tool dahulu,
  // baru halaman fitur dibuka. Semua callback asli tetap dipertahankan.
  void _showCategorySheet(
    BuildContext context, {
    required String title,
    required IconData icon,
    required List<_ToolItem> tools,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _ToolSelectionSheet(
        title: title,
        icon: icon,
        tools: tools,
        onLockedTap: () => _showComingSoon(context),
      ),
    );
  }

  // Alur baru: pilih tipe terlebih dahulu, lalu buka workspace lama.
  // Semua API, payload, role, dan proses di HomePage tetap dipertahankan.
  Future<void> _openBugCenter(BuildContext context) async {
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BugMenuPage(
          username: widget.username,
          password: widget.password,
          sessionKey: widget.sessionKey,
          role: widget.userRole,
          expiredDate: widget.expiredDate,
          listBug: widget.listBug,
          listBugGroup: widget.listBugGroup,
          listDoos: widget.listDoos,
        ),
      ),
    );
  }


  // ==================== CATEGORY METHODS ====================
  // Panel menu: VPS only.
  void _showPanelTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Panel Server",
      icon: Icons.dns,
      tools: [
        _ToolItem(
          icon: Icons.dns,
          label: "VPS",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
              ),
            );
          },
        ),
        _ToolItem(
          icon: Icons.dashboard_customize_rounded,
          label: "CPanel\nPtero",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CpanelPage(
                  username: widget.username,
                  role: widget.userRole,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  // Attack menu: Attack Panel only.
  void _showAttackTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Attack",
      icon: Icons.flash_on,
      tools: [
        _ToolItem(
          icon: Icons.flash_on,
          label: "Attack\nPanel",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: widget.sessionKey,
                  listDoos: widget.listDoos,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    final tools = <_ToolItem>[
      _ToolItem(
        icon: Icons.newspaper_outlined,
        label: "Spam\nNGL",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const NglPage()));
        },
      ),
      _ToolItem(
        icon: Icons.wifi_off,
        label: "WiFi Killer\n(Internal)",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
        },
      ),
      if (widget.userRole == "vip" || widget.userRole == "owner")
        _ToolItem(
          icon: Icons.router,
          label: "WiFi Killer\n(External)",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
    ];
    _showCategorySheet(
      context,
      title: "Attack",
      icon: Icons.wifi,
      tools: tools,
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "OSINT Tools",
      icon: Icons.search,
      tools: [
        _ToolItem(
          icon: Icons.badge,
          label: "NIK\nDetail",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _ToolItem(
          icon: Icons.domain,
          label: "Domain\nOSINT",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _ToolItem(
          icon: Icons.person_search,
          label: "Phone\nLookup",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PhoneLookupPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.email,
          label: "Email\nOSINT",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const EmailOsintPage()),
            );
          },
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Media Downloader",
      icon: Icons.download,
      tools: [
        _ToolItem(
          icon: Icons.video_library,
          label: "TikTok\nDownloader",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _ToolItem(
          icon: Icons.camera_alt,
          label: "Instagram\nDownloader",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Utility",
      icon: Icons.build,
      tools: [
        _ToolItem(
          icon: Icons.photo_camera_back_rounded,
          label: "Live\nPhoto",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LivePhotoPage()));
          },
        ),
        _ToolItem(
          icon: Icons.shield_outlined,
          label: "Cek Ban\nWA",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CekBanWaPage()));
          },
        ),
        _ToolItem(
          icon: Icons.qr_code,
          label: "QR\nGenerator",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
          },
        ),
        _ToolItem(
          icon: Icons.security,
          label: "IP\nScanner",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const IpScannerPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.network_check,
          label: "Port\nScanner",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PortScannerPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.speed_rounded,
          label: "Speed\nTest",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SpeedTestPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.radar_rounded,
          label: "Web\nScanner",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WebScannerPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.find_replace_rounded,
          label: "Typosquat\nChecker",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TyposquatPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.swap_horiz_rounded,
          label: "Converter",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ConverterPage()),
            );
          },
        ),
        _ToolItem(
          icon: Icons.lock_outline_rounded,
          label: "Encoder\nHash",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const EncoderToolsPage()),
            );
          },
        ),
      ],
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showComingSoon(context);
  }

  // ==================== COMING SOON ====================
  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: primaryWhite),
            const SizedBox(width: 8),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontWeight: FontWeight.bold,
                color: primaryWhite,
              ),
            ),
          ],
        ),
        backgroundColor: primaryRed,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
          side: BorderSide(color: lightRed.withOpacity(0.3)),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ======================== CORNER MARK PAINTER ========================
class _CornerMarkPainter extends CustomPainter {
  final double markSize;
  final Paint linePaint;

  _CornerMarkPainter({
    required this.markSize,
    required this.linePaint,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final s = markSize;

    // Kiri atas
    canvas.drawLine(const Offset(2, 2), Offset(2 + s, 2), linePaint);
    canvas.drawLine(const Offset(2, 2), Offset(2, 2 + s), linePaint);

    // Kanan atas
    canvas.drawLine(
      Offset(size.width - 2 - s, 2),
      Offset(size.width - 2, 2),
      linePaint,
    );
    canvas.drawLine(
      Offset(size.width - 2, 2),
      Offset(size.width - 2, 2 + s),
      linePaint,
    );

    // Kiri bawah
    canvas.drawLine(
      Offset(2, size.height - 2),
      Offset(2 + s, size.height - 2),
      linePaint,
    );
    canvas.drawLine(
      Offset(2, size.height - 2 - s),
      Offset(2, size.height - 2),
      linePaint,
    );

    // Kanan bawah
    canvas.drawLine(
      Offset(size.width - 2 - s, size.height - 2),
      Offset(size.width - 2, size.height - 2),
      linePaint,
    );
    canvas.drawLine(
      Offset(size.width - 2, size.height - 2 - s),
      Offset(size.width - 2, size.height - 2),
      linePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _CornerMarkPainter oldDelegate) {
    return markSize != oldDelegate.markSize ||
        linePaint.color != oldDelegate.linePaint.color ||
        linePaint.strokeWidth != oldDelegate.linePaint.strokeWidth;
  }
}



// ======================== GATEWAY MENU TILE ========================
class _ToolSelectionSheet extends StatefulWidget {
  final String title;
  final IconData icon;
  final List<_ToolItem> tools;
  final VoidCallback onLockedTap;

  const _ToolSelectionSheet({
    required this.title,
    required this.icon,
    required this.tools,
    required this.onLockedTap,
  });

  @override
  State<_ToolSelectionSheet> createState() => _ToolSelectionSheetState();
}

class _ToolSelectionSheetState extends State<_ToolSelectionSheet> {
  final TextEditingController _search = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final accent = scheme.primary;
    final filtered = widget.tools.where((tool) =>
      tool.label.replaceAll('\n', ' ').toLowerCase().contains(_query.toLowerCase())
    ).toList();
    final height = MediaQuery.of(context).size.height;

    return Container(
      height: height * .82,
      decoration: BoxDecoration(
        color: const Color(0xFF0B111B).withOpacity(.98),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border.all(color: accent.withOpacity(.25)),
        boxShadow: [BoxShadow(color: accent.withOpacity(.12), blurRadius: 30, spreadRadius: 1)],
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(9))),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 16, 14),
            child: Row(children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(colors: [accent.withOpacity(.95), accent.withOpacity(.42)]),
                  boxShadow: [BoxShadow(color: accent.withOpacity(.22), blurRadius: 16, offset: const Offset(0, 5))],
                ),
                child: Icon(widget.icon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 13),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.title, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: .2)),
                const SizedBox(height: 3),
                Text('${widget.tools.length} fitur tersedia · Pilih untuk melanjutkan', style: TextStyle(color: Colors.white.withOpacity(.48), fontSize: 11.5)),
              ])),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: Colors.white60)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
            child: TextField(
              controller: _search,
              onChanged: (value) => setState(() => _query = value.trim()),
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Cari fitur...',
                hintStyle: TextStyle(color: Colors.white.withOpacity(.35)),
                prefixIcon: Icon(Icons.search_rounded, color: accent),
                filled: true,
                fillColor: Colors.white.withOpacity(.055),
                contentPadding: const EdgeInsets.symmetric(vertical: 13),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.08))),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: Colors.white.withOpacity(.08))),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: accent.withOpacity(.7))),
              ),
            ),
          ),
          Expanded(
            child: filtered.isEmpty
              ? Center(child: Text('Fitur tidak ditemukan', style: TextStyle(color: Colors.white.withOpacity(.45))))
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(18, 2, 18, 24),
                  itemCount: filtered.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.42,
                  ),
                  itemBuilder: (context, index) {
                    final item = filtered[index];
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: item.locked ? widget.onLockedTap : item.onTap,
                        borderRadius: BorderRadius.circular(20),
                        child: Ink(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.045),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: item.locked ? Colors.white.withOpacity(.08) : accent.withOpacity(.24)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(13),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(color: accent.withOpacity(.13), borderRadius: BorderRadius.circular(12)),
                                child: Icon(item.icon, color: accent.withOpacity(.95), size: 20),
                              ),
                              const Spacer(),
                              Text(item.label.replaceAll('\n', ' '), maxLines: 2, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 5),
                              Row(children: [
                                Expanded(child: Text(item.locked ? 'Segera hadir' : 'Buka fitur', style: TextStyle(color: Colors.white.withOpacity(.42), fontSize: 10.5))),
                                Icon(item.locked ? Icons.lock_outline_rounded : Icons.arrow_forward_rounded, color: accent.withOpacity(.75), size: 15),
                              ]),
                            ]),
                          ),
                        ),
                      ),
                    );
                  },
                ),
          ),
        ],
      ),
    );
  }
}

class _GwMenu {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _GwMenu(this.label, this.icon, this.color, this.onTap);
}

// ======================== CAROUSEL MODULE MODEL ========================
class _GwGridItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color iconColor;
  final VoidCallback onTap;
  const _GwGridItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.iconColor,
    required this.onTap,
  });
}

class _CarouselModule {
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final VoidCallback onOpen;

  const _CarouselModule({
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.onOpen,
  });
}

// ======================== SPACE + CLOUD BACKGROUND ========================
class _SpaceCloudBackground extends StatelessWidget {
  const _SpaceCloudBackground();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: const Color(0xFF0E1621).withOpacity(0.35)),
        // Stars
        CustomPaint(painter: _StarsPainter()),
        // Soft clouds at bottom
        Positioned(
          left: -40,
          right: -40,
          bottom: -20,
          height: 280,
          child: CustomPaint(painter: _CloudPainter()),
        ),
        // Top subtle purple haze
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: 160,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  const Color(0xFF527FA8).withOpacity(0.05),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _StarsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white;
    final rnd = math.Random(42);
    for (int i = 0; i < 120; i++) {
      final x = rnd.nextDouble() * size.width;
      final y = rnd.nextDouble() * size.height * 0.75;
      final r = rnd.nextDouble() * 1.4 + 0.3;
      paint.color = Colors.white.withOpacity(0.12 + rnd.nextDouble() * 0.28);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CloudPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF9CA3AF).withOpacity(0.08)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);

    void cloud(double cx, double cy, double s) {
      canvas.drawCircle(Offset(cx, cy), 40 * s, paint);
      canvas.drawCircle(Offset(cx + 35 * s, cy - 8 * s), 32 * s, paint);
      canvas.drawCircle(Offset(cx - 30 * s, cy + 4 * s), 28 * s, paint);
      canvas.drawCircle(Offset(cx + 55 * s, cy + 10 * s), 24 * s, paint);
    }

    cloud(size.width * 0.15, size.height * 0.55, 1.4);
    cloud(size.width * 0.55, size.height * 0.4, 1.8);
    cloud(size.width * 0.88, size.height * 0.62, 1.5);
    cloud(size.width * 0.35, size.height * 0.78, 1.2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
